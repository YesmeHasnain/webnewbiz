<?php
/**
 * Claude CLI Client - Uses structured tool calls for reliable editing
 * Supports: text, styles, images, sections, site settings, pages
 */
class AICopilot_ClaudeAPI
{
    public static function chat(array $messages, string $systemPrompt, array $tools, int $pageId = 0, ?array $selectedElement = null): array
    {
        $actions = [];
        $userMessage = '';
        foreach ($messages as $msg) {
            if (($msg['role'] ?? '') === 'user') {
                $userMessage = is_string($msg['content']) ? $msg['content'] : json_encode($msg['content']);
            }
        }

        // Step 1: Get full page structure with IDs, types, styles
        $pageContext = '';
        if ($pageId) {
            $editables = AICopilot_Executor::execute('get_page_editables', ['page_id' => $pageId]);
            if (!empty($editables['editables'])) {
                $pageContext = json_encode($editables['editables'], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
            }
        }

        // Step 2: Build prompt with all available tools
        $prompt = self::buildPrompt($userMessage, $pageContext, $pageId, $selectedElement);

        // Step 3: Call Claude CLI
        $response = self::callCLI($prompt);
        if (!$response['success']) return $response;

        // Step 4: Parse response
        $parsed = self::parseJSON($response['data']);
        if (!$parsed) {
            return ['success' => true, 'reply' => $response['data'], 'actions' => []];
        }

        $reply = $parsed['reply'] ?? 'Changes applied.';

        // Step 5: Execute structured tool calls
        if (!empty($parsed['actions']) && is_array($parsed['actions'])) {
            foreach ($parsed['actions'] as $action) {
                $tool = $action['tool'] ?? '';
                $input = $action['input'] ?? [];
                if (!$tool || !is_array($input)) continue;

                // Auto-inject page_id if missing
                if ($pageId && empty($input['page_id'])) {
                    $input['page_id'] = $pageId;
                }

                $result = AICopilot_Executor::execute($tool, $input);
                $actions[] = ['tool' => $tool, 'input' => $input, 'result' => $result];
            }
        }

        // Legacy support: text replacements via "changes" array
        if (!empty($parsed['changes']) && is_array($parsed['changes']) && $pageId) {
            foreach ($parsed['changes'] as $change) {
                $old = $change['old_text'] ?? '';
                $new = $change['new_text'] ?? '';
                if ($old && $new && $old !== $new) {
                    $result = AICopilot_Executor::execute('edit_text_by_content', [
                        'page_id' => $pageId,
                        'old_text' => $old,
                        'new_text' => $new,
                    ]);
                    $actions[] = ['tool' => 'edit_text', 'input' => ['old' => $old, 'new' => $new], 'result' => $result];
                }
            }
        }

        // Legacy support: site_settings
        if (!empty($parsed['site_settings'])) {
            $result = AICopilot_Executor::execute('update_site_settings', $parsed['site_settings']);
            $actions[] = ['tool' => 'update_site_settings', 'input' => $parsed['site_settings'], 'result' => $result];
        }

        // Legacy support: new_page
        if (!empty($parsed['new_page'])) {
            $result = AICopilot_Executor::execute('create_page', $parsed['new_page']);
            $actions[] = ['tool' => 'create_page', 'input' => $parsed['new_page'], 'result' => $result];
        }

        // Clear cache after all changes
        if (!empty($actions) && $pageId) {
            AICopilot_Executor::execute('clear_cache', ['page_id' => $pageId]);
        }

        return ['success' => true, 'reply' => $reply, 'actions' => $actions];
    }

    private static function buildPrompt(string $userMessage, string $pageContext, int $pageId, ?array $selectedElement = null): string
    {
        $prompt = "You are an AI website editor for a WordPress + Elementor site.\n\n";

        if ($pageContext) {
            $prompt .= "CURRENT PAGE ELEMENTS (page_id={$pageId}):\n{$pageContext}\n\n";
        }

        // If user selected a specific element in the preview
        if ($selectedElement && !empty($selectedElement['id'])) {
            $selType = $selectedElement['widgetType'] ?? $selectedElement['elType'] ?? $selectedElement['type'] ?? 'element';
            $selText = $selectedElement['text'] ?? '';
            $selId = $selectedElement['id'];
            $prompt .= "USER HAS SELECTED THIS ELEMENT: id=\"{$selId}\", type=\"{$selType}\", content=\"{$selText}\"\n";
            $prompt .= "IMPORTANT: Apply changes to THIS specific element (id={$selId}). Use this element_id in your actions.\n\n";
        }

        $prompt .= <<<'TOOLS'
AVAILABLE TOOLS (use these in your "actions" array):

1. edit_element_text - Change text content of a widget
   Input: {"element_id":"id", "field":"title|editor|text", "value":"new text"}
   - title = headings, editor = paragraphs/text-editor widgets, text = buttons

2. edit_element_style - Change styling (color, font, background, spacing)
   Input: {"element_id":"id", "property":"prop_name", "value":"value"}
   Properties (USE EXACT NAMES - they differ per widget type!):
   - title_color: heading widget text color (hex, e.g. "#ff0000")
   - text_color: text-editor/paragraph widget text color (NOT "color", must be "text_color")
   - button_text_color: button widget text color
   - button_background_color: button widget background color
   - background_color: section/container/column background (hex)
   - font_family: font name (e.g. "Poppins", "Montserrat")
   - font_size: e.g. "32px", "1.5rem"
   - font_weight: e.g. "400", "600", "700"
   - text_align: "left", "center", "right"
   - padding: e.g. "20px" or {"top":"20","right":"20","bottom":"40","left":"20","unit":"px"}
   - margin: same format as padding
   - border_radius: e.g. "8px"
   - opacity: e.g. "0.8"

3. edit_element_image - Change an image widget's image
   Input: {"element_id":"id", "image_url":"https://..."}

4. add_section - Add a new section to the page
   Input: {"section_type":"hero|features|testimonials|cta|contact|pricing|faq|custom", "position":0, "content":{"title":"...","subtitle":"...","items":[{"title":"...","text":"..."}]}}
   position: 0=top, -1=bottom (default)

5. remove_section - Remove a section/container from page
   Input: {"element_id":"section_or_container_id"}

6. set_global_colors - Change site-wide Elementor colors
   Input: {"primary":"#hex","secondary":"#hex","text":"#hex","accent":"#hex"}

7. update_site_settings - Change site title/tagline
   Input: {"blogname":"...","blogdescription":"..."}

8. create_page - Create a new WordPress page
   Input: {"title":"Page Title","content":"HTML","status":"publish"}

9. search_images - Search for stock photos (returns options for user to choose)
   Input: {"query":"modern building sunset","count":4}
   Use when user asks to find/change/generate an image. The user will pick from results.

10. use_image - Download an image and insert into an element
    Input: {"image_url":"https://...","element_id":"id","alt":"description"}

11. duplicate_widget - Duplicate/copy a widget or section (inserts copy right after original)
    Input: {"element_id":"id_to_duplicate"}

12. generate_page - Generate a full page with multiple sections at once
    Input: {"sections":[{"type":"hero","content":{"title":"...","subtitle":"..."}},{"type":"features","content":{"title":"...","items":[{"title":"...","text":"..."}]}}], "mode":"replace|append"}
    Section types: hero, features, testimonials, cta, contact, pricing, faq, gallery, custom

TOOLS;

        $prompt .= "\n\nUSER REQUEST: \"{$userMessage}\"\n\n";

        $prompt .= <<<'INSTRUCTIONS'
Return ONLY a valid JSON object:
{
  "reply": "Friendly message explaining what you did",
  "actions": [
    {"tool": "tool_name", "input": {parameters}}
  ]
}

RULES:
- Use element_id values from the CURRENT PAGE ELEMENTS list
- For style changes (color, font, background): use edit_element_style, NOT text replacement
- For text changes: use edit_element_text with the element's id and correct field
- For section/container background: use edit_element_style on the section/container id
- Multiple actions in one response are fine
- Return ONLY valid JSON, no markdown fences, no extra text

CONTENT GENERATION:
When user asks to write, rewrite, expand, shorten, or change tone:
- "Write a paragraph about X" → Generate text, use edit_element_text on selected/relevant element (field:"editor", value:"<p>generated HTML</p>")
- "Rewrite this heading" → Read current text from element list, write improved version, use edit_element_text
- "Make this shorter/longer" → Read current text, shorten/expand it, use edit_element_text
- "Change tone to professional/casual/friendly" → Rewrite current text in that tone
- "Add a section about X" → Use add_section with generated title, subtitle, and items
- For editor fields, use proper HTML: <p>, <strong>, <em>, <ul><li> etc.
- Write content that matches the website's existing style and industry
- If SEO keywords are mentioned, naturally incorporate them into the content

CONTEXT TAGS (may appear at end of user message):
- [Tone: professional] → Write all content in that tone
- [Language: Urdu] → Write all content in that language
- [SEO Keywords: luxury, homes] → Naturally include these keywords in generated content
These tags are set by the user via UI dropdowns. Respect them for ALL content generation.

PAGE GENERATION:
When user asks to "generate a page", "create full page layout", "build a landing page":
- Use the generate_page tool with sections array
- Each section: {"type":"hero|features|testimonials|cta|faq|custom", "content":{"title":"...","subtitle":"...","items":[...]}}
- Generate 4-6 sections for a full page
- mode: "replace" replaces all content, "append" adds to existing

WIDGET MANAGEMENT:
- "duplicate this widget/element" → use duplicate_widget tool with element_id
- "copy this section" → use duplicate_widget on the section/container id
INSTRUCTIONS;

        return $prompt;
    }

    private static function callCLI(string $prompt): array
    {
        $claudeBin = self::findClaude();
        if (!$claudeBin) return ['success' => false, 'error' => 'Claude CLI not found'];

        $promptFile = tempnam(sys_get_temp_dir(), 'aic_') . '.txt';
        file_put_contents($promptFile, $prompt);

        $cmd = escapeshellarg($claudeBin);
        $cmd .= ' --print --dangerously-skip-permissions --max-turns 1 --model sonnet';

        // Extend PHP time limit for Claude CLI call
        @set_time_limit(300);

        $descriptors = [0 => ['file', $promptFile, 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']];
        $proc = proc_open($cmd, $descriptors, $pipes, sys_get_temp_dir());

        if (!is_resource($proc)) {
            @unlink($promptFile);
            return ['success' => false, 'error' => 'Failed to start Claude CLI'];
        }

        // Set stream timeout to 180 seconds
        stream_set_timeout($pipes[1], 180);
        stream_set_timeout($pipes[2], 180);

        $stdout = stream_get_contents($pipes[1]);
        $stderr = stream_get_contents($pipes[2]);
        fclose($pipes[1]);
        fclose($pipes[2]);
        $exitCode = proc_close($proc);
        @unlink($promptFile);

        if ($exitCode !== 0) {
            return ['success' => false, 'error' => 'Claude CLI error: ' . ($stderr ?: "Exit {$exitCode}")];
        }

        return ['success' => true, 'data' => $stdout];
    }

    private static function parseJSON(string $text): ?array
    {
        $text = trim($text);
        // Strip markdown code fences
        $text = preg_replace('/^```(?:json)?\s*\n?/m', '', $text);
        $text = preg_replace('/\n?```\s*$/m', '', $text);
        $text = trim($text);

        $first = strpos($text, '{');
        $last = strrpos($text, '}');
        if ($first !== false && $last !== false) {
            $json = substr($text, $first, $last - $first + 1);
            $parsed = json_decode($json, true);
            if (is_array($parsed)) return $parsed;
        }
        return null;
    }

    private static function findClaude(): ?string
    {
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $appData = getenv('APPDATA') ?: '';
            $paths = [$appData . '\\npm\\claude.cmd', $appData . '\\npm\\claude'];
            foreach ($paths as $p) {
                if (file_exists($p)) return $p;
            }
            $result = trim(shell_exec('where claude 2>nul') ?? '');
            if ($result) return explode("\n", $result)[0];
        } else {
            $home = getenv('HOME') ?: '';
            $paths = [$home . '/.local/bin/claude', '/usr/local/bin/claude', '/usr/bin/claude'];
            foreach ($paths as $p) {
                if (file_exists($p)) return $p;
            }
        }
        return null;
    }
}
