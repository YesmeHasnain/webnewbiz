<?php
namespace Elementor;
class Xcency_Tab_Widget extends Widget_Base {

	public function get_name() {

		return 'xcency_tab';
	}

	public function get_title() {
		return esc_html__( 'Xcency Tabs', 'xcency-core' );
	}

	public function get_icon() {

		return 'eicon-tabs';
	}

	public function get_categories() {
		return [ 'xcency_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'tab_content_settings',
			[
				'label' => esc_html__( 'Tabs', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'menu_text',
			[
				'label'       => esc_html__('Menu Text', 'xcency-core'),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Menu 1',
				'label_block' => true,
			]
		);


		$repeater->add_control(
			'content_text',
			[
				'label'   => esc_html__('Content Text', 'xcency-core'),
				'type'    => Controls_Manager::WYSIWYG,
				'default' => '<p>It is a long established fact that is reader will be then distracted by the thing and readable content off page when looking at that page layout. It is a long fact that a readable content of page.</p>',
			]
		);

		$this->add_control(
			'tab_items',
			[
				'label'       => esc_html__('Tab List', 'xcency-core'),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'menu_text'        => 'Menu 1',
						'content_text' => '<p>It is a long established fact that is reader will be then distracted by the thing and readable content off page when looking at that page layout. It is a long fact that a readable content of page.</p>',
					],
				],
				'title_field' => '{{{ menu_text }}}',
			]
		);

		$this->add_control(
			'open_by_default',
			[
				'label'       => esc_html__('Open By Default', 'xcency-core'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 1,
				'max'         => 1000,
				'step'        => 1,
				'default'     => 1,
				'description' => esc_html__('Which tab you want to open by default.', 'xcency-core'),
			]
		);

		$this->end_controls_section();


        // Start Button section
        $this->start_controls_section(
            'nadtek_tab_style',
            [
                'label' => esc_html__('NadTek Tabs', 'xcency-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs('xcency_button_style_tabs');

        //Default style tab start
        $this->start_controls_tab(
            'xcency_btn_style_default',
            [
                'label' => esc_html__('Default', 'xcency-core'),
            ]
        );

        $this->add_control(
            'button_default_bg',
            [
                'label'       => esc_html__('Nav Button Background', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .xcency-tab-wrapper .nav-link' => 'background-color: {{VALUE}};',
                ],
            ]
        );

		$this->add_control(
			'button_default_color',
			[
				'label'       => esc_html__('Nav Button Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-tab-wrapper .nav-link' => 'color: {{VALUE}};',
				],
			]
		);


        $this->end_controls_tab();//Default style tab end

        //Hover style tab start
        $this->start_controls_tab(
            'xcency_btn_style_hover',
            [
                'label' => esc_html__('Hover', 'xcency-core'),
            ]
        );

		$this->add_control(
			'button_hover_bg',
			[
				'label'       => esc_html__('Nav Button Background', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-tab-wrapper .nav-tabs .nav-item.show .nav-link,
					{{WRAPPER}} .xcency-tab-wrapper .nav-tabs .nav-link.active,{{WRAPPER}} .xcency-tab-wrapper .nav-tabs .nav-link:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_hover_color',
			[
				'label'       => esc_html__('Nav Button Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-tab-wrapper .nav-tabs .nav-item.show .nav-link,
					{{WRAPPER}} .xcency-tab-wrapper .nav-tabs .nav-link.active,{{WRAPPER}} .xcency-tab-wrapper .nav-tabs .nav-link:hover' => 'color: {{VALUE}};',
				],
			]
		);


        $this->end_controls_tabs();//Hover style tab end

        $this->end_controls_section();// End Button section
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$xcency_tab_id = rand(10, 10000);
		?>

		<div class="xcency-tab-wrapper">
            <div class="nav nav-tabs" role=tablist>
                <?php
                if ($settings['tab_items']) {
                    $menu_count = 0;
                    foreach ($settings['tab_items'] as $tab_menu) {
                        $menu_count++;
                        ?>
                        <button class="nav-link <?php if($menu_count == $settings['open_by_default']){ echo 'active';}?>" data-bs-toggle="tab" data-bs-target="#xcency-tab-number-<?php echo $xcency_tab_id.$menu_count?>" type="button" role="tab">
                            <?php echo $tab_menu['menu_text'];?>
                        </button>
                    <?php }
                }
                ?>
            </div>

            <div class="tab-content">
                <?php
                if ($settings['tab_items']) {
                    $content_count = 0;
                    foreach ($settings['tab_items'] as $tab_content) {
                        $content_count++;
                        ?>
                            <div class="td-tab-item tab-pane fade <?php if($content_count == $settings['open_by_default'] ){ echo 'active show';}?>" id="xcency-tab-number-<?php echo $xcency_tab_id.$content_count?>" role="tabpanel">
                                <div class="xcency-tab-text-wrapper">
	                                <?php echo $tab_content['content_text'];?>
                                </div>
                            </div>
                        <?php
                    }
                }
                ?>
            </div>

		</div>

		<?php
	}
}

Plugin::instance()->widgets_manager->register( new Xcency_Tab_Widget );