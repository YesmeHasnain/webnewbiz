<?php namespace EARLSPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Team_Grid extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'earls_team_grid';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Earls Team Grid', 'earls' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-post-list';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'earls' ];
    }
    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'team_grid',
            [
                'label' => esc_html__( 'Earls Team Grid', 'earls' ),
            ]
        );
		
		$this->add_control(
			'col_grid',
			[
				'label'   => esc_html__( 'Choose Column', 'earls' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'default',
				'options' => array(
					'default'  => esc_html__( 'Default', 'earls' ),
					'one' => esc_html__( 'One Column Grid ', 'earls'),
					'two'  => esc_html__( 'Two Column Grid', 'earls' ),
					'three'  => esc_html__( 'Three Column Grid', 'earls' ),
					'four'  => esc_html__( 'Four Column Grid', 'earls' ),
					'five'  => esc_html__( 'Six Column Grid', 'earls' ),
				),
			]
		);
		$this->add_control(
            'query_number',
            [
                'label'   => esc_html__( 'Number of post', 'earls' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 5,
                'min'     => 1,
                'max'     => 100,
                'step'    => 1,
            ]
        );
        $this->add_control(
            'query_orderby',
            [
                'label'   => esc_html__( 'Order By', 'earls' ),
				'label_block' => true,
                'type'    => Controls_Manager::SELECT,
                'default' => 'date',
                'options' => array(
                    'date'       => esc_html__( 'Date', 'earls' ),
                    'title'      => esc_html__( 'Title', 'earls' ),
                    'menu_order' => esc_html__( 'Menu Order', 'earls' ),
                    'rand'       => esc_html__( 'Random', 'earls' ),
                ),
            ]
        );
        $this->add_control(
            'query_order',
            [
                'label'   => esc_html__( 'Order', 'earls' ),
				'label_block' => true,
                'type'    => Controls_Manager::SELECT,
                'default' => 'ASC',
                'options' => array(
                    'DESC' => esc_html__( 'DESC', 'earls' ),
                    'ASC'  => esc_html__( 'ASC', 'earls' ),
                ),
            ]
        );
        $this->add_control(
            'query_category',
            [
                'type' => Controls_Manager::SELECT,
				'label' => esc_html__('Category', 'earls'),
				'label_block' => true,
				'options' => get_team_categories()
            ]
        );
		
		$this->end_controls_section();
		
		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'earls' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'earls' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .team-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
        $this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'earls' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .team-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'earls' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .team-section',				
			]
		);
		
		
	}
	
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		
		$grid_col = $settings[ 'col_grid' ];
		if( $grid_col == 'one' ){
			$classes = 'col-lg-12 col-md-12';
		}elseif( $grid_col == 'two' ){
			$classes = 'col-lg-6 col-md-6 col-sm-12';
		}elseif( $grid_col == 'three' ){
			$classes = 'col-lg-4 col-md-4 col-sm-12';
		}elseif( $grid_col == 'four' ){
			$classes = 'col-lg-3 col-md-3 col-sm-12';
		}elseif( $grid_col == 'five' ){
			$classes = 'col-lg-2 col-md-4 col-sm-12';
		}else{
			$classes = 'col-lg-4 col-md-6 col-sm-12';
		}
		
		$paged = get_query_var('paged');
		$paged = earls_set($_REQUEST, 'paged') ? esc_attr($_REQUEST['paged']) : $paged;
		
        $this->add_render_attribute( 'wrapper', 'class', 'templatepath-greenture' );
        
		$args = array(
			'post_type'      => 'team',
			'posts_per_page' => earls_set( $settings, 'query_number' ),
			'orderby'        => earls_set( $settings, 'query_orderby' ),
			'order'          => earls_set( $settings, 'query_order' ),
			'paged'         => $paged
		);
		if( earls_set( $settings, 'query_category' ) ) $args['team_cat'] = earls_set( $settings, 'query_category' );
		$query = new \WP_Query( $args );

		if ( $query->have_posts() ) 
	{ ?>
    
    <!-- team-section --> 
    <section class="team-section chefs p_relative see__pad">
        <div class="medium-container">
            <div class="team__content">
                <div class="row">
                	<?php 
						while ( $query->have_posts() ) : $query->the_post();
					?>
                    <div class="<?php echo esc_attr( $classes );?> p-0">
                        <div class="team-block-one">
                            <div class="inner-box">
                                
                                <figure class="image-box">
                                    <?php the_post_thumbnail('earls_480x560'); ?>
                                </figure>
                                
                                <div class="lower-content">
                                    <div class="team__block__bottom">
                                        <h5><a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h5>
                                        <span><?php echo (get_post_meta( get_the_id(), 'designation', true ));?></span>
                                        <?php
                                            $icons = get_post_meta( get_the_id(), 'social_profile', true );
                                            if ( ! empty( $icons ) ) :
                                        ?>
                                        <div class="social__media">
                                            <ul>
                                                <?php
												foreach ( $icons as $h_icon ) :
												$header_social_icons = json_decode( urldecode( earls_set( $h_icon, 'data' ) ) );
												if ( earls_set( $header_social_icons, 'enable' ) == '' ) {
													continue;
												}
												$icon_class = explode( '-', earls_set( $header_social_icons, 'icon' ) );
												?>
												<li><a href="<?php echo esc_url(earls_set( $header_social_icons, 'url' )); ?>" <?php if( earls_set( $header_social_icons, 'background' ) || earls_set( $header_social_icons, 'color' ) ):?>style="background-color:<?php echo esc_attr(earls_set( $header_social_icons, 'background' )); ?>; color: <?php echo esc_attr(earls_set( $header_social_icons, 'color' )); ?>"<?php endif;?>><span class="fab <?php echo esc_attr( earls_set( $header_social_icons, 'icon' ) ); ?>"></span></a></li>
												<?php endforeach; ?>
                                            </ul>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>
     </section>
     <!-- team-section -->
      
   	 <?php }
	 wp_reset_postdata();
	}
}