<?php

namespace EARLSPLUGIN\Inc;


use EARLSPLUGIN\Inc\Abstracts\Taxonomy;


class Taxonomies extends Taxonomy {


	public static function init() {

		$labels = array(
			'name'              => _x( 'Project Category', 'wpearls' ),
			'singular_name'     => _x( 'Project Category', 'wpearls' ),
			'search_items'      => __( 'Search Category', 'wpearls' ),
			'all_items'         => __( 'All Categories', 'wpearls' ),
			'parent_item'       => __( 'Parent Category', 'wpearls' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpearls' ),
			'edit_item'         => __( 'Edit Category', 'wpearls' ),
			'update_item'       => __( 'Update Category', 'wpearls' ),
			'add_new_item'      => __( 'Add New Category', 'wpearls' ),
			'new_item_name'     => __( 'New Category Name', 'wpearls' ),
			'menu_name'         => __( 'Project Category', 'wpearls' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'project_cat' ),
		);

		register_taxonomy( 'project_cat', 'project', $args );
		
		//Menu Taxonomy Start
		$labels = array(
			'name'              => _x( 'Menu Category', 'wpearls' ),
			'singular_name'     => _x( 'Menu Category', 'wpearls' ),
			'search_items'      => __( 'Search Category', 'wpearls' ),
			'all_items'         => __( 'All Categories', 'wpearls' ),
			'parent_item'       => __( 'Parent Category', 'wpearls' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpearls' ),
			'edit_item'         => __( 'Edit Category', 'wpearls' ),
			'update_item'       => __( 'Update Category', 'wpearls' ),
			'add_new_item'      => __( 'Add New Category', 'wpearls' ),
			'new_item_name'     => __( 'New Category Name', 'wpearls' ),
			'menu_name'         => __( 'Menu Category', 'wpearls' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'menu_cat' ),
		);

		register_taxonomy( 'menu_cat', 'menu', $args );
		
		
		//Testimonials Taxonomy Start
		$labels = array(
			'name'              => _x( 'Testimonials Category', 'wpearls' ),
			'singular_name'     => _x( 'Testimonials Category', 'wpearls' ),
			'search_items'      => __( 'Search Category', 'wpearls' ),
			'all_items'         => __( 'All Categories', 'wpearls' ),
			'parent_item'       => __( 'Parent Category', 'wpearls' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpearls' ),
			'edit_item'         => __( 'Edit Category', 'wpearls' ),
			'update_item'       => __( 'Update Category', 'wpearls' ),
			'add_new_item'      => __( 'Add New Category', 'wpearls' ),
			'new_item_name'     => __( 'New Category Name', 'wpearls' ),
			'menu_name'         => __( 'Testimonials Category', 'wpearls' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'testimonials_cat' ),
		);


		register_taxonomy( 'testimonials_cat', 'testimonials', $args );
		
		
		//Team Taxonomy Start
		$labels = array(
			'name'              => _x( 'Team Category', 'wpearls' ),
			'singular_name'     => _x( 'Team Category', 'wpearls' ),
			'search_items'      => __( 'Search Category', 'wpearls' ),
			'all_items'         => __( 'All Categories', 'wpearls' ),
			'parent_item'       => __( 'Parent Category', 'wpearls' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpearls' ),
			'edit_item'         => __( 'Edit Category', 'wpearls' ),
			'update_item'       => __( 'Update Category', 'wpearls' ),
			'add_new_item'      => __( 'Add New Category', 'wpearls' ),
			'new_item_name'     => __( 'New Category Name', 'wpearls' ),
			'menu_name'         => __( 'Team Category', 'wpearls' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'team_cat' ),
		);


		register_taxonomy( 'team_cat', 'team', $args );
		
		
		
	}
	
}
