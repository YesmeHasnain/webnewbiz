<?php
namespace Elementor;
class Xcency_Project_Slider_One_Widget extends Widget_Base {

	public function get_name() {

		return 'xcency_project_slider_one';
	}

	public function get_title() {
		return esc_html__( 'Project Slider One', 'xcency-core' );
	}

	public function get_icon() {

		return 'eicon-gallery-grid';
	}

	public function get_categories() {
		return [ 'xcency_core_elements' ];
	}


	protected function register_controls() {

		//Content tab start
		$this->start_controls_section(
			'project_slider_settings',
			[
				'label' => esc_html__( 'Project Slider', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'number',
			[
				'label'       => __('Number', 'xcency-core'),
				'type'        => Controls_Manager::TEXT,
				'default'     => '01',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'title',
			[
				'label'       => __('Title', 'xcency-core'),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Modern Website Design & Branding',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'desc',
			[
				'label'   => __('Description', 'xcency-core'),
				'type'    => Controls_Manager::WYSIWYG,
				'default' => 'Design and Development is the phase where the conceptual work',
			]
		);

		$repeater->add_control(
			'photo',
			[
				'label'       => __( 'Image', 'xcency-core' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'default'     => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
            'details',
            [
                'label'         => esc_html__( 'Details URL', 'xcency-core' ),
                'type'          => Controls_Manager::URL,
                'placeholder'   => esc_html__( 'https://your-link.com', 'xcency-core' ),
                'show_external' => true,
                'default'       => [
                    'url'         => '',
                    'is_external' => false,
                    'nofollow'    => false,
                ],
            ]
        );

		$this->add_control(
			'projects',
			[
				'label'       => __('Projects List', 'xcency-core'),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'number'        => '01',
						'title'        => 'Modern Website Design & Branding',
						'desc'        => 'Design and Development is the phase where the conceptual work',
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

        $this->add_control(
            'btn_text',
            [
                'label'       => esc_html__( 'Button Text', 'xcency-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => esc_html__( 'Read More', 'xcency-core' ),
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'slider_options',
			[
				'label' => esc_html__( 'Slider Options', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'autoplay',
			[
				'label'       => __( 'Autoplay', 'xcency-core' ),
				'type'        => Controls_Manager::SWITCHER,
				'show_label'  => true,
				'label_block' => false,
				'default'     => 'yes',
			]
		);

		$this->add_control(
			'autoplay_interval',
			[
				'label'       => __( 'Autoplay Interval', 'xcency-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					'2000'  => __( '2 seconds', 'xcency-core' ),
					'3000'  => __( '3 seconds', 'xcency-core' ),
					'4000'  => __( '4 seconds', 'xcency-core' ),
					'5000'  => __( '5 seconds', 'xcency-core' ),
					'6000'  => __( '6 seconds', 'xcency-core' ),
					'7000'  => __( '7 seconds', 'xcency-core' ),
					'8000'  => __( '8 seconds', 'xcency-core' ),
					'9000'  => __( '9 seconds', 'xcency-core' ),
					'10000' => __( '10 seconds', 'xcency-core' ),
				],
				'default'     => '4000',
				'condition'   => [
					'autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'infinity_loop',
			[
				'label'       => __( 'Loop', 'xcency-core' ),
				'type'        => Controls_Manager::SWITCHER,
				'show_label'  => true,
				'label_block' => false,
				'default'     => 'yes',
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'project_slider_style',
            [
                'label' => esc_html__( 'Project Slider', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs('td_default_and_hover_style_tabs_start');

        //Default style tab start
        $this->start_controls_tab(
            'td_project_style_default',
            [
                'label' => esc_html__('Default', 'xcency-core'),
            ]
        );

        $this->add_control(
            'content_default_bg_color',
            [
                'label'       => esc_html__('Content Background', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .xcency-project-slider-left' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();//Default style tab end

        //Hover style tab start
        $this->start_controls_tab(
            'td_project_style_hover',
            [
                'label' => esc_html__('Hover', 'xcency-core'),
            ]
        );

		$this->add_control(
			'content_hover_bg_color',
			[
				'label'       => esc_html__('Content Background', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-project-slider-one-item:hover .xcency-project-slider-left' => 'background-color: {{VALUE}};',
				],
			]
		);

        $this->end_controls_tabs();//Hover style tab end

        $this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$slide_id = rand(100, 100000);
		?>

		<div class="xcency-project-slider-one-wrapper">
            <div class="xcency-project-slider-arrow">
                <div class="xcency-project-prev-arrow slick-arrow">
                    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="14" viewBox="0 0 15 14" fill="none"><path d="M8.1875 0.21875C8.0625 0.0625 7.8125 0.0625 7.65625 0.21875L1.125 6.75C0.96875 6.90625 0.96875 7.125 1.125 7.28125L7.65625 13.8125C7.8125 13.9688 8.0625 13.9688 8.1875 13.8125L8.8125 13.2188C8.96875 13.0625 8.96875 12.8125 8.8125 12.6875L3.96875 7.8125H14.625C14.8438 7.8125 15 7.65625 15 7.4375V6.5625C15 6.375 14.8438 6.1875 14.625 6.1875H3.96875L8.8125 1.34375C8.96875 1.21875 8.96875 0.96875 8.8125 0.8125L8.1875 0.21875Z" fill="#10171E"></path></svg>
                </div>
                <div class="xcency-project-next-arrow slick-arrow">
                    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="14" viewBox="0 0 15 14" fill="none"><path d="M8.1875 0.21875C8.0625 0.0625 7.8125 0.0625 7.65625 0.21875L1.125 6.75C0.96875 6.90625 0.96875 7.125 1.125 7.28125L7.65625 13.8125C7.8125 13.9688 8.0625 13.9688 8.1875 13.8125L8.8125 13.2188C8.96875 13.0625 8.96875 12.8125 8.8125 12.6875L3.96875 7.8125H14.625C14.8438 7.8125 15 7.65625 15 7.4375V6.5625C15 6.375 14.8438 6.1875 14.625 6.1875H3.96875L8.8125 1.34375C8.96875 1.21875 8.96875 0.96875 8.8125 0.8125L8.1875 0.21875Z" fill="#10171E"></path></svg>
                </div>
            </div>

			<div class="row" id="xcency-project-slider-<?php echo esc_attr($slide_id);?>">
				<?php if($settings['projects']){
					foreach ($settings['projects'] as $project){
						?>
						<div class="col-12">
							<div class="xcency-project-slider-one-item">
                                <div class="xcency-project-slider-left">
                                    <div class="project-slider-one-number"><?php echo esc_html($project['number']);?></div>
                                    <h6 class="project-slider-one-title"><?php echo esc_html($project['title']);?></h6>

                                    <div class="project-slider-desc-and-btn">
                                        <div class="project-slider-one-desc xcency-last-p-0">
		                                    <?php echo wp_kses($project['desc'], xcency_allow_html());?>
                                        </div>

                                        <div class="project-details-button">
                                            <a href="<?php echo $project['details']['url'];?>" class="xcency-button"><?php echo $settings['btn_text'];?></a>
                                        </div>
                                    </div>
                                </div>

                                <div class="xcency-project-slider-right">
                                    <div class="project-slider-one-image" style="background-image: url(<?php echo $project['photo']['url'];?>)"></div>
                                </div>
							</div>
						</div>
						<?php
					}
				} ?>
			</div>
		</div>

		<script>
            (function ($) {
                "use strict";
                $(document).ready(function () {
                    $("#xcency-project-slider-<?php echo esc_attr($slide_id);?>").slick({
                        slidesToShow: 2,
                        autoplay: <?php echo json_encode( $settings['autoplay'] == 'yes' ? true : false ); ?>,
                        autoplaySpeed: <?php echo json_encode( $settings['autoplay_interval'] )?>, //interval
                        speed: 1500, // slide speed
                        dots: false,
                        arrows: true,
                        prevArrow: $('.xcency-project-prev-arrow'),
                        nextArrow: $('.xcency-project-next-arrow'),
                        fade: false,
                        infinite: <?php echo json_encode( $settings['infinity_loop'] == 'yes' ? true : false ); ?>,
                        pauseOnHover: false,
                        centerMode: false,
                        responsive: [
                            {
                                breakpoint: 1025,
                                settings: {
                                    slidesToShow: 1,
                                }
                            },
                            {
                                breakpoint: 992,
                                settings: {
                                    slidesToShow: 1, //768-991
                                }
                            },
                            {
                                breakpoint: 768,
                                settings: {
                                    slidesToShow: 1, // 0 -767
                                    arrows: false,
                                }
                            }
                        ]
                    });
                });
            })(jQuery);
		</script>

		<?php
	}
}

Plugin::instance()->widgets_manager->register( new Xcency_Project_Slider_One_Widget );