<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * download Widget .
 *
 */
class Barab_Download extends Widget_Base {

	public function get_name() {
		return 'barabdownload';
	}
	public function get_title() {
		return __( 'Download', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		 $this->start_controls_section(
			'service_section',
			[
				'label'     => __( 'Downloads', 'barab' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two'] );

		barab_general_fields($this, 'title', 'Title', 'TEXT', 'Download' , ['1', '2'] );
		barab_general_fields($this, 'content', 'Content', 'TEXTAREA', 'We blend timeless culinary traditions with modern flair to bring you a dining.' , ['2'] );
		barab_media_fields( $this, 'title_shape', 'Choose Title Shape', ['1'] );

		$repeater = new Repeater();

		barab_media_fields( $repeater, 'image', 'Choose Image' );
		barab_url_fields( $repeater, 'button_url', 'Image URL');

		$this->add_control(
			'download_lists',
			[
				'label' 		=> __( 'Download', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'condition'	=> [
					'layout_style' => ['1', '2']
				]
			]
		);

        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------
		barab_common_style_fields( $this, 'title', 'Title', '{{WRAPPER}} .widget_title' );
		barab_common_style_fields( $this, '23', 'Content', '{{WRAPPER}} .box-text', ['2'] );


	}

	protected function render() {

	$settings = $this->get_settings_for_display();

		if( $settings['layout_style'] == '1' ){
			echo '<div class="widget widget_download footer-widget">';
				if(!empty($settings['title'])){
					echo '<h3 class="widget_title">'.esc_html($settings['title']).'</h3>';
				}
				if(!empty($settings['title_shape']['url'])){
					echo '<div class="icon">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['title_shape']['url'] ),
						));
					echo '</div>';
				}
				echo '<div class="download-widget-wrap">';
					foreach( $settings['download_lists'] as $data ){
						echo '<a '.barab_link_attrs($data['button_url']).'>';
							echo barab_img_tag( array(
								'url'   => esc_url( $data['image']['url'] ),
							));
						echo '</a>';
					}
				echo '</div>';
			echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
			echo '<div class="widget widget_download footer-widget wow fadeinup">';
				if(!empty($settings['title'])){
					echo '<h4 class="widget_title">'.esc_html($settings['title']).'</h4>';
				}
				if($settings['content']){
                    echo '<p class="box-text">'.esc_html($settings['content']).'</p>';
                }
				echo '<div class="download-widget-wrap">';
					foreach( $settings['download_lists'] as $data ){
						echo '<a '.barab_link_attrs($data['button_url']).'>';
							echo barab_img_tag( array(
								'url'   => esc_url( $data['image']['url'] ),
							));
						echo '</a>';
					}
				echo '</div>';
			echo '</div>';

		}elseif( $settings['layout_style'] == '3' ){

		}else{
			echo '<div class="widget widget_download  ">';
				if($settings['title']){
					echo '<h4 class="widget_title style2">'.wp_kses_post($settings['title']).'</h4>';
				}
				echo '<div class="download-media-wrap">';
					foreach( $settings['download_list'] as $data ){
						// Get the file URL
						$file_url = esc_url( $data['button_url']['url'] );
						// Parse the URL to extract the file extension
						$file_extension = pathinfo( parse_url( $file_url, PHP_URL_PATH ), PATHINFO_EXTENSION );
						// Define allowed file extensions for download
						$allowed_extensions = ['pdf', 'zip', 'jpg', 'jpeg', 'png', 'docx', 'xlsx'];

						// Check if the file extension is in the allowed list
						$download_attr = in_array( strtolower( $file_extension ), $allowed_extensions ) ? ' download' : '';

						echo '<div class="download-media">';
							echo '<div class="download-media_info">';
								echo '<h5 class="download-media_title">'.esc_html( $data['title'] ).'</h5>';
							echo '</div>';
							echo '<a href="'.esc_url( $file_url ).'" class="download-media_btn"'. $download_attr .'><i class="far fa-arrow-right"></i></a>';
						echo '</div>';
					}
				echo '</div>';
			echo '</div>';

		}
	

	}

}