<?php

/**
 * Elementor Widget
 * @package Saasten
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_home_counter_one extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'theme-counter-onee';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Home Counter 1', 'saasten-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saasten_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {




        $this->start_controls_section( 'section_content_aCOUNTER_featurelist', [
            'label' => esc_html__( 'Counter Item List', 'saasten-extra' ),
        ] ); 

        $this->add_control( 'featureItems', [
            'label'       => esc_html__( 'Features items', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'default'     => [
                [
                    'count-number'        => esc_html__( '500', 'saasten-extra' ),
                ]
            ],

            'fields'      => [
                [
                    'name'        => 'count-number',
                    'label'       => esc_html__( 'Number', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'description' => esc_html__( 'Enter Number', 'saasten-extra' )
                ],

                [
                    'name'        => 'count-title',
                    'label'       => esc_html__( 'Title', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'description' => esc_html__( 'Enter Title', 'saasten-extra' )
                ],

                [
                    'name'        => 'count-title2',
                    'label'       => esc_html__( 'Title Bottom', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'description' => esc_html__( 'Enter Title Bottom', 'saasten-extra' )
                ],

                

            ],
            'title_field' => "{{name}}"
        ] );



        $this->end_controls_section();


        // ===================== Title ======================//

        $this->start_controls_section( 'title_style', [
            'label' => __( 'Title', 'saasten-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_typography',
            'label'    => __( 'Typography', 'saasten-extra' ),
            'selector' => '
                {{WRAPPER}} .theme-banner-startup-wrapper h1.banner-heading,
                {{WRAPPER}} .__title
            ',
        ] );


        $this->add_control( 'title_color', [
            'label'     => __( 'Color', 'saasten-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-startup-wrapper h1.banner-heading' => 'color: {{VALUE}}',
                '{{WRAPPER}} .__title' => 'color: {{VALUE}}',
            ],
        ] );

        $this->end_controls_section(); //End Title Style


        // ===================== Subtitle Style ========================//
        $this->start_controls_section( 'sub_title_style', [
            'label' => __( 'Sub Title', 'saasten-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_sub_typography',
            'label'    => __( 'Typography', 'saasten-extra' ),
            'selector' => '{{WRAPPER}} .theme-banner-startup-wrapper h4.banner-sub-heading',
        ] );

        $this->add_control( 'sub_title_color', [
            'label'     => __( 'Sub Title Color', 'saasten-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-startup-wrapper h4.banner-sub-heading' => 'color: {{VALUE}}',
            ],

        ] );

        $this->end_controls_section(); //End Subtitle Style

		
	}
	


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

        $featureItems = $settings['featureItems'];

        extract($settings); 


		
		?>


    <!-- FunFact -->
    <section class="funfact-v2" data-aos="fade-up">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="funfact-v2__inner">


            <?php
                foreach ( $featureItems as $item ):
            ?>



              <!-- Funfact Single -->
              <div class="funfact-v2__single">
                <h4 class="funfact-v2__number">
                  <span class="counter-active"><?php echo esc_html( $item['count-number'] ); ?></span>
                </h4>
                <div class="funfact-v2__content">
                  <p class="funfact-v2__label"><?php echo esc_html( $item['count-title'] ); ?></p>
                  <h3 class="funfact-v2__title"><?php echo esc_html( $item['count-title2'] ); ?></h3>
                </div>
              </div>
              <!-- End Funfact Single -->

            <?php endforeach; ?> 


            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End FunFact -->




	<?php 


	}
				

}

