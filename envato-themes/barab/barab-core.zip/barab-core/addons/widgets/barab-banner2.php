<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Group_Control_Border;
/**
 *
 * Banner Widget.
 *
 */
class barab_Banner2 extends Widget_Base {

	public function get_name() {
		return 'barabbanner2';
	}
	public function get_title() {
		return __( 'Banner / Hero', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab_header_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'banner_section',
			[
				'label' 	=> __( 'Banner', 'barab' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One' ] );

		barab_media_fields( $this, 'bg', 'Choose Background', ['1'] ); 
		barab_media_fields( $this, 'image1', 'Choose Image', ['1'] );

		barab_general_fields( $this, 'subtitle', 'Subtitle', 'TEXTAREA2', 'Fast Food Restaurant' );
		barab_general_fields( $this, 'title', 'Title', 'TEXTAREA', 'Delicious Fast food For today' );
		
		barab_general_fields($this, 'circle_text', 'Circle Text', 'TEXTAREA2', 'MAKE FRESH EAT REFRESH MAKE FRESH EAT REFRESH', ['1'] ); 
		barab_general_fields($this, 'circle_middle_text', 'Circle Middle Text', 'TEXTAREA2', 'ORDER YOUR BURGER', ['1'] ); 
		barab_url_fields($this, 'circle_url', 'Circle Middle Text URL', ['1']);
		

		barab_media_fields( $this, 'shape1', 'Choose Shape', ['1'] );
		barab_media_fields( $this, 'shape2', 'Choose Shape', ['1'] );
		barab_media_fields( $this, 'shape3', 'Choose Shape', ['1'] );
		barab_media_fields( $this, 'shape4', 'Choose Shape', ['1'] );
		barab_media_fields( $this, 'shape5', 'Choose Shape', ['1'] );

		$this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------

		barab_common_style_fields( $this, '01', 'Subtitle', '{{WRAPPER}} .sub-title', ['1', '2', '3'] );
		barab_common_style_fields( $this, '02', 'Title', '{{WRAPPER}} .hero-title', ['1', '2', '3'] );

    }

	protected function render() {

    $settings = $this->get_settings_for_display();
 
		if( $settings['layout_style'] == '1' ){
			echo '<div class="th-hero-wrapper hero-1 bg-smoke" id="hero">';

				echo '<div class="hero-img-shape-1">';
					echo '<div class="logo-icon-wrap">';
						if(!empty($settings['circle_middle_text'])){
							echo '<div class="logo-icon">';
								echo '<h4 class="order"><a '.barab_link_attrs($settings['circle_url']).'>'.esc_html( $settings['circle_middle_text'] ).'</a></h4>';
							echo '</div>';
						}
						if(!empty($settings['circle_text'])){
							echo '<div class="logo-icon-wrap__text">';
								echo '<span class="logo-animation">'.esc_html( $settings['circle_text'] ).'</span>';
							echo '</div>';
						}
					echo '</div>';
				echo '</div>';

				if($settings['shape1']['url'] ){
					echo '<div class="shape-mockup d-none d-xl-block movingX" data-top="0%" data-right="5%">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['shape1']['url'] ),
						)); 
					echo '</div>';
				}
				if($settings['shape2']['url'] ){
					echo '<div class="shape-mockup d-none d-xxl-block gsap-scroll-rotate" data-top="14%" data-left="1%">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['shape2']['url'] ),
						)); 
					echo '</div>';
				}
				if($settings['shape3']['url'] ){
					echo '<div class="shape-mockup d-none d-xxl-block jump-reverse" data-top="13%" data-right="2%">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['shape3']['url'] ),
						)); 
					echo '</div>';
				}
				if($settings['shape4']['url'] ){
					echo '<div class="shape-mockup d-none d-xxl-block movingX" data-bottom="0%" data-left="5%">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['shape4']['url'] ),
						)); 
					echo '</div>';
				}
				if($settings['shape5']['url'] ){
					echo '<div class="shape-mockup d-none d-xxl-block jump" data-bottom="0%" data-right="0%">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['shape5']['url'] ),
						)); 
					echo '</div>';
				}

				if($settings['bg']['url'] ){
					echo '<div class="hero-1-bg">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['bg']['url'] ),
						)); 
					echo '</div>';
				} 
				echo '<div class="hero-inner">';
					echo '<div class="container">';
						echo '<div class="row justify-content-center">';
							echo '<div class="col-xl-8 col-lg-10">';
								echo '<div class="hero-style1">';
									if(!empty($settings['subtitle'])){
										echo '<span class="sub-title gsap-scale-down-fade">'.esc_html($settings['subtitle']).'</span>';
									}
									if(!empty($settings['title'])){
										echo '<h1 class="hero-title text-anime-style-2">'.wp_kses_post($settings['title']).'</h1>';
									}
									if($settings['image1']['url'] ){
										echo '<div class="hero-img1 gsap-scale-up-fade">';
											echo barab_img_tag( array(
												'url'   => esc_url( $settings['image1']['url'] ),
											)); 
										echo '</div>';
									}
								echo '</div>';
							echo '</div>';
						echo '</div>';
					echo '</div>';
				echo '</div>';
			echo '</div>';
		
		}elseif( $settings['layout_style'] == '2' ){


		}elseif( $settings['layout_style'] == '3' ){


		}

		
	}

}