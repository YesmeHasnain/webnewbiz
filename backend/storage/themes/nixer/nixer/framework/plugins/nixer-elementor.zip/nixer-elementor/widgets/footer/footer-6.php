<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsFooterSection6 extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-footer-6';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Footer Section 6', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-footer';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-footer' ];
	}

	public function get_keywords() {
		return [ 'footer6', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_footer_section',
			[
				'label' => esc_html__( 'Footer Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'bg_color',
			[
				'label' 		=> esc_html__( 'Background Color (Default: #FFFFFF)', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::COLOR,
				'default'		=> '#FFFFFF',
			]
		);
		$this->add_control(
			'ft_copyright',
			[
				'label'       => __( 'Footer Copyright', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your text footer copyright', 'bdevs-elementor' ),
				'default'     => __( 'All rights reserved — 2025 © Shtheme', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'switch_social',
			[
				'label'   		=> esc_html__( 'Switch Show/Hide Social', 'bdevs-elementor' ),
				'type'    		=> Controls_Manager::SWITCHER,
				'label_on' 		=> esc_html__( 'Show', 'bdevs-elementor' ),
				'label_off' 	=> esc_html__( 'Hide', 'bdevs-elementor' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);
		$rp_social = new \Elementor\Repeater();
		$rp_social->add_control(
			'text_sc_item',
			[
				'label' 		=> esc_html__( 'Text Social Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Text Social' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_social->add_control(
			'link_sc_item',
			[
				'label' 		=> esc_html__( 'Link Social Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '#' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'tab_sc',
			[
				'label' 		=> esc_html__( 'List Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $rp_social->get_controls(),
				'default' 		=> [
					[
					],
				],
				'condition' 	=> [
					'switch_social' 	=> 'yes',
				],
				'title_field' 	=> '{{{ text_sc_item }}}',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_wrapper_footer',
			[
				'label' => esc_html__( 'Wrapper Footer Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'switch_wrapper_footer',
			[
				'label'   		=> esc_html__( 'Switch Show/Hide Wrapper Footer', 'bdevs-elementor' ),
				'type'    		=> Controls_Manager::SWITCHER,
				'label_on' 		=> esc_html__( 'Show', 'bdevs-elementor' ),
				'label_off' 	=> esc_html__( 'Hide', 'bdevs-elementor' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);
		$this->add_control(
			'switch_ft_top',
			[
				'label'   		=> esc_html__( 'Switch Show/Hide Footer Top', 'bdevs-elementor' ),
				'type'    		=> Controls_Manager::SWITCHER,
				'label_on' 		=> esc_html__( 'Show', 'bdevs-elementor' ),
				'label_off' 	=> esc_html__( 'Hide', 'bdevs-elementor' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);
		$this->add_control(
			'text_ft_top',
			[
				'label' 		=> esc_html__( 'Text Footer Top', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'support@nixer.com' , 'bdevs-elementor' ),
				'show_label' 	=> true,
				'condition' 	=> [
					'switch_ft_top' 	=> 'yes',
				],
			]
		);
		$this->add_control(
			'link_ft_top',
			[
				'label' 		=> esc_html__( 'Link Footer Top - If have', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'mailto:support@nixer.com' , 'bdevs-elementor' ),
				'show_label' 	=> true,
				'condition' 	=> [
					'switch_ft_top' 	=> 'yes',
				],
			]
		);
		$this->add_control(
			'hr1',
			[
				'type' 			=> Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'col1_img',
			[
				'label'       	=> esc_html__( 'Column 1 Logo', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image logo', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'col1_text',
			[
				'label' 		=> esc_html__( 'Column 1 Text', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'We can create solutions that <br> elevate growth and sales.' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'hr2',
			[
				'type' 			=> Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'col2_title',
			[
				'label' 		=> esc_html__( 'Column 2 Title', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Company' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_col2 = new \Elementor\Repeater();
		$rp_col2->add_control(
			'col2_text',
			[
				'label' 		=> esc_html__( 'Column 2 Text Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Text Item' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_col2->add_control(
			'col2_link',
			[
				'label' 		=> esc_html__( 'Column 2 Link Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '#' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'tab_col2',
			[
				'label' 		=> esc_html__( 'List Column 2 Content', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $rp_col2->get_controls(),
				'default' 		=> [
					[
						
					],
				],
				'title_field' 	=> '{{{ col2_text }}}',
			]
		);
		$this->add_control(
			'hr3',
			[
				'type' 			=> Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'col3_title',
			[
				'label' 		=> esc_html__( 'Column 3 Title', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Address' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_col3 = new \Elementor\Repeater();
		$rp_col3->add_control(
			'col3_text',
			[
				'label' 		=> esc_html__( 'Column 3 Text Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Text Item' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_col3->add_control(
			'col3_link',
			[
				'label' 		=> esc_html__( 'Column 3 Link Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '#' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_col3->add_control(
			'col3_target',
			[
				'label'   		=> esc_html__( 'Choose Target Link When Click', 'bdevs-elementor' ),
				'type'    		=> Controls_Manager::SWITCHER,
				'label_on' 		=> esc_html__( 'Blank', 'bdevs-elementor' ),
				'label_off' 	=> esc_html__( 'Self', 'bdevs-elementor' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);
		$this->add_control(
			'tab_col3',
			[
				'label' 		=> esc_html__( 'List Column 3 Content', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $rp_col3->get_controls(),
				'default' 		=> [
					[
						
					],
				],
				'title_field' 	=> '{{{ col3_text }}}',
			]
		);
		$this->add_control(
			'hr4',
			[
				'type' 			=> Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'col4_title',
			[
				'label' 		=> esc_html__( 'Column 4 Title', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Newsletter' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'col4_shortcode',
			[
				'label'       => __( 'Columns 4 Shortcode', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your shortcode form', 'bdevs-elementor' ),
				'default'     => __( '[contact-form-7 id="d11cc5e" title="Newsletter Footer Form"]', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>

<?php if (!empty($settings['switch_wrapper_footer'])) { ?>
	<section class="tp-footer-4-ptb pt-100" data-bg-color="<?php echo wp_kses_post($settings['bg_color']); ?>">
<?php } else { ?>
	<section class="tp-footer-4-ptb" data-bg-color="<?php echo wp_kses_post($settings['bg_color']); ?>">
<?php } ?>
		<?php if (!empty($settings['switch_wrapper_footer'])): ?>
			<div class="container container-1480">
				<div class="tp-footer-4-text inner-color">
					<h3 class="tp-footer-4-text-title">
						<?php if (!empty($settings['link_ft_top'])) { ?>
							<a href="<?php echo wp_kses_post($settings['link_ft_top']); ?>">
								<?php echo wp_kses_post($settings['text_ft_top']); ?>
							</a>
						<?php } else { ?>
							<span><?php echo wp_kses_post($settings['text_ft_top']); ?></span>
						<?php } ?>
					</h3>
				</div>
				<div class="tp-footer-2-wrapper inner-color pb-50">
					<div class="row">
						<div class="col-xl-3 col-lg-3 col-md-6 col-12">
							<div class="tp-footer-2-widget tp-footer-2-col-1 mb-50">
								<div class="tp-footer-2-logo mb-30">
									<?php if (!empty($settings['col1_img']['url'])): ?>
										<a href="<?php echo esc_url(home_url('/')); ?>"> 
											<img data-width="120" src="<?php echo wp_kses_post($settings['col1_img']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>" style="width: 120px;">
										</a>
									<?php endif ?>
								</div>
								<?php if (!empty($settings['col1_text'])): ?>
									<div class="tp-footer-2-widget-content">
										<p><?php echo wp_kses_post($settings['col1_text']); ?></p>
									</div>
								<?php endif ?>
							</div>
						</div>
						<div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
							<div class="tp-footer-2-widget tp-footer-2-col-2 mb-50">
								<?php if (!empty($settings['col2_title'])): ?>
									<h3 class="tp-footer-2-widget-title"><?php echo wp_kses_post($settings['col2_title']); ?></h3>
								<?php endif ?>
								<div class="tp-footer-2-widget-content">
									<ul>
										<?php
										foreach ($settings['tab_col2'] as $item2) :
										?>
											<?php if (!empty($item2['col2_link']) && !empty($item2['col2_text'])): ?>
												<li>
													<a href="<?php echo wp_kses_post($item2['col2_link']); ?>">
														<?php echo wp_kses_post($item2['col2_text']); ?>
													</a>
												</li>
											<?php endif ?>
										<?php endforeach; ?>
									</ul>
								</div>
							</div> 
						</div>
						<div class="col-xl-3 col-lg-3 col-md-7 col-sm-6 col-12">
							<div class="tp-footer-2-widget tp-footer-2-col-3 mb-50">
								<?php if (!empty($settings['col3_title'])): ?>
									<h3 class="tp-footer-2-widget-title"><?php echo wp_kses_post($settings['col3_title']); ?></h3>
								<?php endif ?>
								<div class="tp-footer-2-widget-content">
									<div class="tp-footer-2-widget-content-contact">
										<?php
										foreach ($settings['tab_col3'] as $item3) :
										?>
											<?php if (!empty($item3['col3_link']) && !empty($item3['col3_text'])): ?>
												<?php if (!empty($item3['col3_target'])) { ?>
													<a target="_blank" href="<?php echo wp_kses_post($item3['col3_link']); ?>">
												<?php } else { ?>
													<a href="<?php echo wp_kses_post($item3['col3_link']); ?>">
												<?php } ?>
														<?php echo wp_kses_post($item3['col3_text']); ?>
													</a>
											<?php endif ?>
										<?php endforeach; ?>
									</div>
								</div>
							</div>
						</div>
						<div class="col-xl-3 col-lg-3 col-md-5 col-12">
							<div class="tp-footer-2-widget tp-footer-2-col-4 mb-50 inner-color">
								<?php if (!empty($settings['col4_title'])): ?>
									<h3 class="tp-footer-2-widget-title"><?php echo wp_kses_post($settings['col4_title']); ?></h3>
								<?php endif ?>
								<?php if (!empty($settings['col4_shortcode'])): ?>
									<div class="tp-footer-2-widget-content">
										<div class="tp-footer-2-widget-content-input">
											<?php echo do_shortcode($settings['col4_shortcode']); ?>
										</div>
									</div>
								<?php endif ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php endif ?>
		<div class="tp-footer-2-copyright-ptb inner-color">
			<div class="container container-1480">
				<div class="row">
					<?php if (!empty($settings['switch_social'])): ?>
						<div class="col-lg-6">
							<div class="tp-footer-2-copyright-social">
								<?php
								foreach ($settings['tab_sc'] as $items) :
								?>
									<?php if (!empty($items['link_sc_item']) && !empty($items['text_sc_item'])): ?>
										<a href="<?php echo wp_kses_post($items['link_sc_item']); ?>">
											<?php echo wp_kses_post($items['text_sc_item']); ?>
										</a>
									<?php endif ?>
								<?php endforeach; ?>
							</div>
						</div>
					<?php endif ?>
					<?php if (!empty($settings['ft_copyright'])): ?>
						<?php if (!empty($settings['switch_social'])) { ?>
							<div class="col-lg-6">
								<div class="tp-footer-2-copyright-text text-end">
						<?php } else { ?>
							<div class="col-lg-12 text-center">
								<div class="tp-footer-2-copyright-text">
						<?php } ?>
									<p><?php echo wp_kses_post($settings['ft_copyright']); ?></p>
								</div>
							</div>
					<?php endif ?>
				</div>
			</div>
		</div>
	</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-bg-color]").each(function () {
			jQuery(this).css("background-color", jQuery(this).attr("data-bg-color"));
		});
		jQuery("[data-width], [data-height]").each(function () {
			const $this = $(this);
			
			// Set the width if data-width is present
			if ($this.attr("data-width")) {
					$this.css("width", $this.attr("data-width"));
			}
	
			// Set the height if data-height is present
			if ($this.attr("data-height")) {
					$this.css("height", $this.attr("data-height"));
			}
		});
	</script>
<?php } ?>

<?php
}

}