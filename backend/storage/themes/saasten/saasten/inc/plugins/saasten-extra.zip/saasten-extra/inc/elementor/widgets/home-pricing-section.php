<?php

/**
 * Elementor Widget
 * @package Saasten
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_home_pricing_one extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'theme-pricing-onee';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Home Prcing 1', 'saasten-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saasten_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {


        $this->start_controls_section( 'section_content_pricing_heading', [
            'label' => esc_html__( 'Heading Content', 'saasten-extra' ),
        ] ); 


        $this->add_control( 'subtitle', [
            'label'       => __( 'Sub Title', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => __( 'About Us', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type section subtitle here.", 'saasten-extra' ),
        ] );

        $this->add_control( 'title', [
            'label'       => __( 'Title', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Invest in Startup', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type section title here.", 'saasten-extra' ),

        ] );

        $this->add_control( 'feature_image_bg', [
            'label'   => __( 'Choose Banner Image Background', 'saasten-core' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );


        $this->end_controls_section();



        $this->start_controls_section( 'section_content_pricing_fitemlist', [
            'label' => esc_html__( 'Pricing Item List', 'saasten-extra' ),
        ] ); 

        $this->add_control( 'priceItems', [
            'label'       => esc_html__( 'Prcing Single Item', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'default'     => [
                [
                    'price-title'        => esc_html__( 'Personal Plan', 'saasten-extra' ),
                ]
            ],

            'fields'      => [


                [
                    'name'        => 'price-title',
                    'label'       => esc_html__( 'Title', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'default'     => __( 'Personal Plan', 'saasten-extra' ),
                    'description' => esc_html__( 'Enter Title', 'saasten-extra' )
                ],

                [
                    'name'        => 'price-des',
                    'label'       => esc_html__( 'Short description', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'default'     => __( 'Web Development', 'saasten-extra' ),
                    'description' => esc_html__( 'Enter Description', 'saasten-extra' )
                ],


                [
                    'name'        => 'price-number',
                    'label'       => esc_html__( 'Pricing Number', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXT,
                    'default'     => __( '18.00', 'saasten-extra' ),
                    'description' => esc_html__( 'Enter Number', 'saasten-extra' )
                ],


                [
                    'name'        => 'price-cycle',
                    'label'       => esc_html__( 'Pricing Cycle', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXT,
                    'default'     => __( 'Monthly', 'saasten-extra' ),
                    'description' => esc_html__( 'Enter Cycle', 'saasten-extra' )
                ],

                [
                    'name'        => 'price-content',
                    'label'       => __( 'Pricing Content', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::WYSIWYG,
                    'default'     => __( 'Pricing Content', 'saasten-extra' ),
                    'description' => esc_html__( 'Enter Pricing item features', 'saasten-extra' )
                ],



                [
                    'name'        => 'btn-text',
                    'label'       => esc_html__( 'Pricing Button Text', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXT,
                    'default'     => __( 'Get Started Now', 'saasten-extra' ),
                    'description' => esc_html__( 'Enter Number', 'saasten-extra' )
                ],


                [
                    'name'        => 'btn-link',
                    'label'       => esc_html__( 'Pricing Button Link', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::URL,
                    'placeholder' => __( 'https://your-link.com', 'saasten-extra' ),
                    'default'     => [
                        'url' => '#',
                    ],
                ],


                [
                    'name'        => 'pricing_highlight',
                    'label' => esc_html__( 'Make Highlight', 'saasten-extra' ),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => esc_html__( 'Show', 'saasten-extra' ),
                    'label_off' => esc_html__( 'Hide', 'saasten-extra' ),
                    'return_value' => 'yes',
                    'default' => 'no',
                ],


                [
                    'name'        => 'tag-popular',
                    'label'       => esc_html__( 'Pricing Button Text', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXT,
                    'default'     => __( 'Most Popular', 'saasten-extra' ),
                    'description' => esc_html__( 'Highlighted item title', 'saasten-extra' )
                ],

            


            ],
            'title_field' => "{{name}}"
        ] );



        $this->end_controls_section();


        // ===================== Title ======================//

        $this->start_controls_section( 'title_style', [
            'label' => __( 'Title', 'saasten-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_typography',
            'label'    => __( 'Typography', 'saasten-extra' ),
            'selector' => '
                {{WRAPPER}} .theme-banner-startup-wrapper h1.banner-heading,
                {{WRAPPER}} .__title
            ',
        ] );


        $this->add_control( 'title_color', [
            'label'     => __( 'Color', 'saasten-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-startup-wrapper h1.banner-heading' => 'color: {{VALUE}}',
                '{{WRAPPER}} .__title' => 'color: {{VALUE}}',
            ],
        ] );

        $this->end_controls_section(); //End Title Style


        // ===================== Subtitle Style ========================//
        $this->start_controls_section( 'sub_title_style', [
            'label' => __( 'Sub Title', 'saasten-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_sub_typography',
            'label'    => __( 'Typography', 'saasten-extra' ),
            'selector' => '{{WRAPPER}} .theme-banner-startup-wrapper h4.banner-sub-heading',
        ] );

        $this->add_control( 'sub_title_color', [
            'label'     => __( 'Sub Title Color', 'saasten-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-startup-wrapper h4.banner-sub-heading' => 'color: {{VALUE}}',
            ],

        ] );

        $this->end_controls_section(); //End Subtitle Style

		
	}
	


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

        $priceItems = $settings['priceItems'];

        extract($settings); 


		
		?>



    <!-- Pricing Area -->
    <section
      class="pricing-section-v3 section-padding saastain-bg__cover"
      style="background-image: url(<?php echo esc_url( $settings['feature_image_bg']['url'] ); ?>);"
    >
      <div class="container">
        <div class="row">
          <div class="col-12 mg-btm-80 pricing-section-title">
            <!-- Section Title -->
            <div class="section-title-v3 text-center" data-aos="fade-in">
              <p class="section-title-v3__label text-white mg-btm-20">
                <?php echo wp_kses_post( $settings['subtitle'] ); ?>
              </p>
              <h2
                class="section-title-v3__title text-white m-0 saastain-gsap-anim2"
              >
                <?php echo wp_kses_post( $settings['title'] ); ?>
              </h2>
            </div>
          </div>
        </div>
        <div class="row">



        <?php
            foreach ( $priceItems as $item ):
        ?>


          <div data-aos="fade-right" class="col-lg-4 col-12" data-aos="fade-in">
            <!-- Single Pricing -->
            <div class="single-price-table single-price-table__v3 <?php if($item['pricing_highlight'] == 'yes' ) { echo "middle-active"; } else { echo "middle-normal"; } ?>">


             <?php if($item['pricing_highlight'] == 'yes') :?>
              <div class="popular-text">
                <img src="<?php echo SAASTEN_IMG ."/price-vector-2.svg"; ?>" />
                <span><?php echo esc_html( $item['tag-popular'] ); ?></span>
              </div>
              <?php endif; ?>


              <h2 class="single-price-table__title"><?php echo wp_kses_post( $item['price-title'] ); ?></h2>
              <p class="single-price-table__text">
                <?php echo wp_kses_post( $item['price-des'] ); ?>
              </p>
              <h3 class="price-amount range__output rang-out-1">
                <output><?php echo esc_html( $item['price-number'] ); ?></output>
                <span class="duration"><?php echo esc_html( $item['price-cycle'] ); ?></span>
              </h3>
              <span class="price-range-bar"></span>


              <!-- Price Features -->
              <div class="single-price-table__features">



                <?php echo $item['price-content']; ?>


                <a
                  class="saastain-btn__v2 pricing-button w-100 primary-bg primary-bg-hover-1"
                  href="<?php echo esc_url( $item['btn-link']['url'] ) ?>"
                >
                  <span> <?php echo esc_html( $item['btn-text'] ); ?> </span>
                  <span>
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="18"
                      height="12"
                      viewBox="0 0 18 12"
                      fill="none"
                    >
                      <path
                        d="M1.5 5.93341L16.5 5.93341"
                        stroke-width="1.7"
                        stroke-linecap="round"
                      />
                      <path
                        d="M12.5 0.937317C12.5 0.937317 17 5.70534 17 5.93301C17 6.16067 12.5 10.9287 12.5 10.9287"
                        stroke-width="1.7"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      />
                    </svg>
                  </span>
                </a>
              </div>
            </div>
            <!-- End Single Pricing -->
          </div>

          <?php endforeach; ?>  



        </div>
      </div>
    </section>
    <!-- End Pricing Area -->





	<?php 


	}
				

}

