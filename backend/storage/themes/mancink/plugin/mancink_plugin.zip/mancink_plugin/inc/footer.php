<?php
// Registers the new post type 

function mancink_footer_post_type() {
	register_post_type( 'footer',
		array(
			'labels' => array(
				'name' => __( 'Custom Footer', 'mancink_plugin' ),
				'singular_name' => __( 'Custom Footer' , 'mancink_plugin'),
				'add_new' => __( 'Add New Custom Footer', 'mancink_plugin' ),
				'add_new_item' => __( 'Add New Custom Footer', 'mancink_plugin' ),
				'edit_item' => __( 'Edit Custom Footer', 'mancink_plugin' ),
				'new_item' => __( 'Add New Custom Footer', 'mancink_plugin' ),
				'view_item' => __( 'View Custom Footer', 'mancink_plugin' ),
				'search_items' => __( 'Search Custom Footer', 'mancink_plugin' ),
				'not_found' => __( 'No Custom Footer found', 'mancink_plugin' ),
				'not_found_in_trash' => __( 'No Custom Footer found in trash', 'mancink_plugin' )
			),
			'public' => true,
			'supports' => array( 'title'),
			'capability_type' => 'post',
			'rewrite' => array("slug" => "footer"), // Permalinks format
			'menu_position' => 5,
			'menu_icon'           => 'dashicons-art',
			'exclude_from_search' => true 
		)
	);

}

add_action( 'init', 'mancink_footer_post_type' );


//function custom footer output elementor css
function mancink_footer_css() {
    global $post;
    if (is_singular()) { //if single page/post
        global $post;
        if (get_post_meta($post->ID, 'mancink_footer_option', true) == 'custom' && get_post_meta($post->ID, 'mancink_meta_choose_footer', true)) {

            //if page setting choose footer custom
            $footer_id = get_post_meta(get_the_ID(), 'mancink_meta_choose_footer', true);
        }

        //if page setting choose footer global
        else if (get_post_meta($post->ID, 'mancink_footer_option', true) == 'global') {

            //if custom footer & list are selected in theme options
            if (get_theme_mod('custom_footer_setting_value') == 'custom' && get_theme_mod('mancink_select_footer') != '') {

                $footer_id = get_theme_mod('mancink_select_footer');
            } 
        }

    } else { //if not single page/post

        //if custom footer & list are selected in theme options
        if (get_theme_mod('custom_footer_setting_value') == 'custom' && get_theme_mod('mancink_select_footer') != '') {

            $footer_id = get_theme_mod('mancink_select_footer');
        } 
    }
    if ( did_action( 'elementor/loaded' ) ) {
        if (! empty( $header_id)){
            if ( class_exists( '\Elementor\Core\Files\CSS\Post' ) ) {
                $css_file = new \Elementor\Core\Files\CSS\Post( $footer_id );
            } elseif ( class_exists( '\Elementor\Post_CSS_File' ) ) {
                $css_file = new \Elementor\Post_CSS_File( $footer_id );
            }
            $css_file->enqueue();
        }
    }
}

//custom footer css call
add_action( 'wp_enqueue_scripts', 'mancink_footer_css' );