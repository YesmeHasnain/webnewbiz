<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
/**
 *
 * Image Widget .
 *
 */
class Barab_Image extends Widget_Base {

	public function get_name() {
		return 'barabimage';
	}
	public function get_title() {
		return __( 'Image', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'image_section',
			[
				'label' 	=> __( 'Image', 'barab' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two', 'Style Three', 'Style Four' ] );

		barab_media_fields( $this, 'image', 'Choose Image' );
		barab_media_fields( $this, 'image2', 'Choose Image', ['2', '3'] );
		barab_general_fields($this, 'circle_text', 'Circle Text', 'TEXTAREA2', 'BOOK PRIVATE DINING & BANQUET ROOMS*', ['3'] );  
		barab_media_fields( $this, 'icon', 'Choose Icon', ['2', '3'] );
		barab_url_fields($this, 'circle_url', 'Circle Icon URL', ['3']);

       $this->end_controls_section();

      	//---------------------------------------
			//Style Section Start
		//---------------------------------------	
		

	}

	protected function render() {

        $settings = $this->get_settings_for_display();
       
		if( $settings['layout_style'] == '1' ){
			echo '<div class="img-box1 ms-xl-2">';
				if(!empty($settings['image']['url'])){
					echo '<div class="img1 gsap-fade-left">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['image']['url'] ),
						));
					echo '</div>';
				}
			echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
			echo '<div class="testi-thumb-wrap-2"> ';
				if(!empty($settings['icon']['url'])){
					echo '<div class="testi-3-quote">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['icon']['url'] ),
						));
					echo '</div>'; 
				}
				if(!empty($settings['image']['url'])){
					echo '<div class="img-thumb-2 wow fadeinleft">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['image']['url'] ),
						));
					echo '</div>';
				}
				if(!empty($settings['image2']['url'])){
					echo '<div class="img-thumb-2-1 global-img">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['image2']['url'] ),
						));
					echo '</div>';
				}
			echo '</div>';

		}elseif( $settings['layout_style'] == '3' ){
			echo '<div class="process-thumb-wrap me-xl-4">'; 
				if(!empty($settings['circle_text'])){
					echo '<div class="process-2-icon" data-bg-src="">';
						echo '<img class="prog-2-circle" src="'.BARAB_ASSETS.'img/icon/prog-2-circle.png">';
						echo '<div class="logo-icon-wrap">';
								if(!empty($settings['icon']['url'])){
									echo '<div class="logo-icon">';
										echo '<h4 class="order"><a '.barab_link_attrs($settings['circle_url']).'>';
											echo barab_img_tag( array(
												'url'   => esc_url( $settings['icon']['url'] ),
											));
										echo '</a></h4>';
									echo '</div>';
								}
								echo '<div class="logo-icon-wrap__text">';
									echo '<span class="logo-animation">'.esc_html( $settings['circle_text'] ).'</span>';
								echo '</div>';
						echo '</div>';
					echo '</div>';
				}
				if(!empty($settings['image']['url'])){
					echo '<div class="thumb global-img">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['image']['url'] ),
						));
					echo '</div>';
				}
				if(!empty($settings['image2']['url'])){
					echo '<div class="thumb global-img">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['image2']['url'] ),
						));
					echo '</div>';
				}
			echo '</div>';

		}elseif( $settings['layout_style'] == '4' ){
			if(!empty($settings['image']['url'])){
				echo '<div class="reservation-thumb wow fadeinleft">';
					echo barab_img_tag( array(
						'url'   => esc_url( $settings['image']['url'] ),
					));
				echo '</div>';
			}

		}


	}

}