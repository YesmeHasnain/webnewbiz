<?php
/**
 * Tool Executor - Executes AI tool calls on WordPress/Elementor
 * All style changes go through parsed JSON (never str_replace on raw JSON)
 */
class AICopilot_Executor
{
    public static function execute(string $tool, array $input): array
    {
        return match ($tool) {
            'edit_element_text'    => self::editElementText($input),
            'edit_element_style'   => self::editElementStyle($input),
            'edit_element_image'   => self::editElementImage($input),
            'edit_text_by_content' => self::editTextByContent($input),
            'get_page_editables'   => self::getPageEditables($input),
            'add_section'          => self::addSection($input),
            'remove_section'       => self::removeSection($input),
            'create_page'          => self::createPage($input),
            'update_page_seo'      => self::updatePageSeo($input),
            'set_global_colors'    => self::setGlobalColors($input),
            'upload_image'         => self::uploadImage($input),
            'search_images'        => self::searchImages($input),
            'use_image'            => self::useImage($input),
            'duplicate_widget'     => self::duplicateWidget($input),
            'generate_page'        => self::generateFullPage($input),
            'update_site_settings' => self::updateSiteSettings($input),
            'clear_cache'          => self::clearCache($input),
            default => ['success' => false, 'error' => "Unknown tool: {$tool}"],
        };
    }

    // ─── Text Editing ───

    private static function editElementText(array $input): array
    {
        $pageId = $input['page_id'] ?? 0;
        $elementId = $input['element_id'] ?? '';
        $field = $input['field'] ?? 'title';
        $value = $input['value'] ?? '';

        $fieldMap = [
            'button_text' => 'text',
            'btn_text'    => 'text',
            'heading'     => 'title',
            'content'     => 'editor',
            'paragraph'   => 'editor',
            'description' => 'editor',
        ];
        $field = $fieldMap[$field] ?? $field;

        $data = get_post_meta($pageId, '_elementor_data', true);
        if (!$data) return ['success' => false, 'error' => 'No Elementor data found'];

        $elements = json_decode($data, true);
        if (!$elements) return ['success' => false, 'error' => 'Invalid Elementor data'];

        // Track before value for diff
        $oldValue = self::getElementFieldValue($elements, $elementId, $field);

        $elements = self::updateElementField($elements, $elementId, $field, $value);
        self::saveElementorData($pageId, $elements);

        return [
            'success' => true,
            'message' => "Updated {$field} on element {$elementId}",
            'diff' => ['field' => $field, 'before' => substr(strip_tags($oldValue ?? ''), 0, 60), 'after' => substr(strip_tags($value), 0, 60)],
        ];
    }

    /**
     * Safe text replacement - searches through parsed JSON tree, not raw string
     */
    private static function editTextByContent(array $input): array
    {
        $pageId = $input['page_id'] ?? 0;
        $oldText = $input['old_text'] ?? '';
        $newText = $input['new_text'] ?? '';

        $data = get_post_meta($pageId, '_elementor_data', true);
        if (!$data) return ['success' => false, 'error' => 'No Elementor data found'];

        $elements = json_decode($data, true);
        if (!$elements) return ['success' => false, 'error' => 'Invalid Elementor data'];

        $found = false;
        $elements = self::replaceTextInElements($elements, $oldText, $newText, $found);

        if (!$found) {
            return ['success' => false, 'error' => "Text '{$oldText}' not found on page"];
        }

        self::saveElementorData($pageId, $elements);
        return ['success' => true, 'message' => "Replaced '{$oldText}' with '{$newText}'"];
    }

    // ─── Style Editing ───

    /**
     * Edit element style - handles Elementor's complex property naming
     */
    private static function editElementStyle(array $input): array
    {
        $pageId = $input['page_id'] ?? 0;
        $elementId = $input['element_id'] ?? '';
        $property = $input['property'] ?? '';
        $value = $input['value'] ?? '';

        $data = get_post_meta($pageId, '_elementor_data', true);
        if (!$data) return ['success' => false, 'error' => 'No Elementor data found'];

        $elements = json_decode($data, true);
        if (!$elements) return ['success' => false, 'error' => 'Invalid Elementor data'];

        // Detect widget type to fix property names per widget
        $widgetType = self::getWidgetType($elements, $elementId);
        $property = self::fixPropertyForWidget($property, $widgetType);

        // Build all Elementor settings needed for this property
        $settings = self::buildStyleSettings($property, $value);

        // Button special handling: background_color should NOT add background_background:classic
        // and should also set button_background_color for compatibility
        if ($widgetType === 'button' && ($property === 'background_color' || $property === 'button_background_color')) {
            $settings = [
                'background_color' => $value,
                'button_background_color' => $value,
            ];
        }

        foreach ($settings as $key => $val) {
            $elements = self::updateElementSetting($elements, $elementId, $key, $val);
        }

        // Clear any global color references that would override our change
        $colorProps = ['title_color', 'text_color', 'color', 'button_text_color', 'button_background_color', 'background_color'];
        if (in_array($property, $colorProps)) {
            $elements = self::clearGlobalColorRef($elements, $elementId, $property);
        }

        // Track before value for diff
        $oldValue = self::getElementFieldValue($elements, $elementId, array_key_first($settings));

        self::saveElementorData($pageId, $elements);
        return [
            'success' => true,
            'message' => "Updated style {$property} on element {$elementId}",
            'diff' => ['field' => $property, 'before' => is_string($oldValue) ? $oldValue : '', 'after' => is_string($value) ? $value : ''],
        ];
    }

    /**
     * Map a simple property name to the full Elementor settings needed
     */
    private static function buildStyleSettings(string $property, $value): array
    {
        $settings = [];

        switch ($property) {
            // Background needs type flag + color
            case 'background_color':
                $settings['background_background'] = 'classic';
                $settings['background_color'] = $value;
                break;

            // Font family needs typography enabled
            case 'font_family':
                $settings['typography_typography'] = 'custom';
                $settings['typography_font_family'] = $value;
                break;

            // Font size needs typography enabled + structured value
            case 'font_size':
                $settings['typography_typography'] = 'custom';
                $settings['typography_font_size'] = self::parseSizeValue($value);
                break;

            // Font weight needs typography enabled
            case 'font_weight':
                $settings['typography_typography'] = 'custom';
                $settings['typography_font_weight'] = (string) $value;
                break;

            // Line height
            case 'line_height':
                $settings['typography_typography'] = 'custom';
                $settings['typography_line_height'] = self::parseSizeValue($value);
                break;

            // Letter spacing
            case 'letter_spacing':
                $settings['typography_typography'] = 'custom';
                $settings['typography_letter_spacing'] = self::parseSizeValue($value);
                break;

            // Padding / margin need structured value
            case 'padding':
            case 'margin':
                $settings[$property] = self::parseSpacingValue($value);
                break;

            // Border radius
            case 'border_radius':
                $settings['border_radius'] = self::parseSpacingValue($value);
                break;

            // Button-specific background
            case 'button_background_color':
                $settings['button_background_color'] = $value;
                break;

            // Everything else: direct setting (title_color, color, text_align, opacity, etc.)
            default:
                $settings[$property] = $value;
                break;
        }

        return $settings;
    }

    private static function parseSizeValue($value): array
    {
        if (is_array($value)) return $value;

        $value = trim((string) $value);
        if (preg_match('/^(\d+(?:\.\d+)?)\s*(px|em|rem|%|vw|vh)?$/', $value, $m)) {
            return ['size' => (float) $m[1], 'unit' => $m[2] ?? 'px', 'sizes' => []];
        }

        return ['size' => (float) $value, 'unit' => 'px', 'sizes' => []];
    }

    private static function parseSpacingValue($value): array
    {
        if (is_array($value)) return $value;

        $value = trim((string) $value);
        if (preg_match('/^(\d+)\s*(px|em|rem|%)?$/', $value, $m)) {
            $v = $m[1];
            $unit = $m[2] ?? 'px';
            return ['top' => $v, 'right' => $v, 'bottom' => $v, 'left' => $v, 'unit' => $unit, 'isLinked' => true];
        }

        return ['top' => '0', 'right' => '0', 'bottom' => '0', 'left' => '0', 'unit' => 'px', 'isLinked' => true];
    }

    // ─── Image Editing ───

    private static function editElementImage(array $input): array
    {
        $pageId = $input['page_id'] ?? 0;
        $elementId = $input['element_id'] ?? '';
        $imageUrl = $input['image_url'] ?? '';

        if (!$imageUrl) return ['success' => false, 'error' => 'No image URL provided'];

        // Check if it's a local/existing media URL (no need to sideload)
        $attachmentId = 0;
        $finalUrl = $imageUrl;

        if (strpos($imageUrl, home_url()) === 0) {
            // Local URL - find attachment ID
            $attachmentId = attachment_url_to_postid($imageUrl);
        } else {
            // External URL - sideload to media library
            $attachmentId = self::sideloadImage($imageUrl);
            if (!$attachmentId) return ['success' => false, 'error' => 'Failed to download/upload image'];
            $finalUrl = wp_get_attachment_url($attachmentId);
        }

        $data = get_post_meta($pageId, '_elementor_data', true);
        if (!$data) return ['success' => false, 'error' => 'No Elementor data found'];

        $elements = json_decode($data, true);
        if (!$elements) return ['success' => false, 'error' => 'Invalid Elementor data'];

        $elements = self::updateElementImage($elements, $elementId, $finalUrl, $attachmentId);
        self::saveElementorData($pageId, $elements);

        return ['success' => true, 'message' => 'Image updated', 'url' => $finalUrl];
    }

    // ─── Page Structure ───

    private static function getPageEditables(array $input): array
    {
        $pageId = $input['page_id'] ?? 0;
        $data = get_post_meta($pageId, '_elementor_data', true);
        if (!$data) return ['success' => false, 'error' => 'No Elementor data'];

        $elements = json_decode($data, true);
        if (!$elements) return ['success' => false, 'error' => 'Invalid Elementor data'];

        $editables = [];
        self::extractEditables($elements, $editables);

        return ['success' => true, 'editables' => $editables];
    }

    private static function addSection(array $input): array
    {
        $pageId = $input['page_id'] ?? 0;
        $type = $input['section_type'] ?? 'custom';
        $position = $input['position'] ?? -1;
        $content = $input['content'] ?? [];

        $data = get_post_meta($pageId, '_elementor_data', true);
        $elements = $data ? json_decode($data, true) : [];
        if (!is_array($elements)) $elements = [];

        // Detect if page uses containers (modern Elementor) or sections (legacy)
        $usesContainers = false;
        foreach ($elements as $el) {
            if (($el['elType'] ?? '') === 'container') {
                $usesContainers = true;
                break;
            }
        }

        // Extract existing page theme (colors, fonts) so new section matches
        $pageTheme = self::extractPageTheme($elements);
        $section = self::buildNewSection($type, $content, $usesContainers, $pageTheme);

        if ($position >= 0 && $position < count($elements)) {
            array_splice($elements, $position, 0, [$section]);
        } else {
            $elements[] = $section;
        }

        self::saveElementorData($pageId, $elements);
        return ['success' => true, 'message' => "Added {$type} section", 'element_id' => $section['id']];
    }

    private static function removeSection(array $input): array
    {
        $pageId = $input['page_id'] ?? 0;
        $elementId = $input['element_id'] ?? '';

        $data = get_post_meta($pageId, '_elementor_data', true);
        if (!$data) return ['success' => false, 'error' => 'No Elementor data found'];

        $elements = json_decode($data, true);
        if (!$elements) return ['success' => false, 'error' => 'Invalid Elementor data'];

        $elements = self::removeElementById($elements, $elementId);
        self::saveElementorData($pageId, $elements);

        return ['success' => true, 'message' => "Removed element {$elementId}"];
    }

    private static function createPage(array $input): array
    {
        $title = $input['title'] ?? 'New Page';
        $content = $input['content'] ?? '';
        $status = $input['status'] ?? 'publish';

        $pageId = wp_insert_post([
            'post_title'   => $title,
            'post_content' => $content,
            'post_status'  => $status,
            'post_type'    => 'page',
        ]);

        if (is_wp_error($pageId)) {
            return ['success' => false, 'error' => $pageId->get_error_message()];
        }

        update_post_meta($pageId, '_elementor_edit_mode', 'builder');
        return ['success' => true, 'page_id' => $pageId, 'message' => "Created page: {$title}"];
    }

    private static function updatePageSeo(array $input): array
    {
        $pageId = $input['page_id'] ?? 0;
        if ($input['meta_title'] ?? '') update_post_meta($pageId, '_yoast_wpseo_title', $input['meta_title']);
        if ($input['meta_description'] ?? '') update_post_meta($pageId, '_yoast_wpseo_metadesc', $input['meta_description']);
        if ($input['keywords'] ?? '') update_post_meta($pageId, '_yoast_wpseo_focuskw', $input['keywords']);
        return ['success' => true, 'message' => 'SEO updated'];
    }

    private static function setGlobalColors(array $input): array
    {
        $colors = [];
        foreach (['primary', 'secondary', 'text', 'accent'] as $key) {
            if (!empty($input[$key])) $colors[$key] = $input[$key];
        }

        $kit = get_option('elementor_active_kit');
        if ($kit) {
            $kitData = get_post_meta($kit, '_elementor_page_settings', true);
            if (is_array($kitData)) {
                $kitData['system_colors'] = array_map(fn($color, $id) => [
                    '_id' => $id, 'title' => ucfirst($id), 'color' => $color,
                ], $colors, array_keys($colors));
                update_post_meta($kit, '_elementor_page_settings', $kitData);
            }
        }

        return ['success' => true, 'message' => 'Global colors updated', 'colors' => $colors];
    }

    private static function uploadImage(array $input): array
    {
        $url = $input['url'] ?? '';
        $alt = $input['alt'] ?? '';

        $attachmentId = self::sideloadImage($url);
        if (!$attachmentId) return ['success' => false, 'error' => 'Upload failed'];

        if ($alt) update_post_meta($attachmentId, '_wp_attachment_image_alt', $alt);
        return ['success' => true, 'attachment_id' => $attachmentId, 'url' => wp_get_attachment_url($attachmentId)];
    }

    /**
     * Search for stock images - returns options for user to pick from
     */
    /**
     * Duplicate a widget (copies it right after the original)
     */
    private static function duplicateWidget(array $input): array
    {
        $pageId = $input['page_id'] ?? 0;
        $elementId = $input['element_id'] ?? '';

        $data = get_post_meta($pageId, '_elementor_data', true);
        if (!$data) return ['success' => false, 'error' => 'No Elementor data'];

        $elements = json_decode($data, true);
        if (!$elements) return ['success' => false, 'error' => 'Invalid data'];

        $found = false;
        $elements = self::duplicateInTree($elements, $elementId, $found);
        if (!$found) return ['success' => false, 'error' => 'Element not found'];

        self::saveElementorData($pageId, $elements);
        return ['success' => true, 'message' => "Duplicated element {$elementId}"];
    }

    private static function duplicateInTree(array $elements, string $id, bool &$found): array
    {
        $result = [];
        foreach ($elements as $el) {
            $result[] = $el;
            if (($el['id'] ?? '') === $id) {
                $found = true;
                // Deep clone with new IDs
                $clone = self::cloneWithNewIds($el);
                $result[] = $clone;
            }
            if (!$found && !empty($el['elements'])) {
                $lastIdx = count($result) - 1;
                $result[$lastIdx]['elements'] = self::duplicateInTree($el['elements'], $id, $found);
            }
        }
        return $result;
    }

    private static function cloneWithNewIds(array $element): array
    {
        $element['id'] = self::genId();
        if (!empty($element['elements'])) {
            foreach ($element['elements'] as &$child) {
                $child = self::cloneWithNewIds($child);
            }
        }
        return $element;
    }

    /**
     * Generate a full page with multiple sections from AI description
     */
    private static function generateFullPage(array $input): array
    {
        $pageId = $input['page_id'] ?? 0;
        $sections = $input['sections'] ?? [];

        if (empty($sections)) return ['success' => false, 'error' => 'No sections provided'];

        $data = get_post_meta($pageId, '_elementor_data', true);
        $existing = $data ? json_decode($data, true) : [];
        if (!is_array($existing)) $existing = [];

        // Detect container vs section
        $usesContainers = false;
        foreach ($existing as $el) {
            if (($el['elType'] ?? '') === 'container') { $usesContainers = true; break; }
        }

        $newElements = [];
        foreach ($sections as $sec) {
            $type = $sec['type'] ?? 'custom';
            $content = $sec['content'] ?? $sec;
            $newElements[] = self::buildNewSection($type, $content, $usesContainers);
        }

        // Replace or append
        $mode = $input['mode'] ?? 'replace';
        if ($mode === 'replace') {
            $final = $newElements;
        } else {
            $final = array_merge($existing, $newElements);
        }

        self::saveElementorData($pageId, $final);
        return ['success' => true, 'message' => 'Generated ' . count($newElements) . ' sections'];
    }

    private static function searchImages(array $input): array
    {
        $query = $input['query'] ?? '';
        $count = $input['count'] ?? 4;
        if (!$query) return ['success' => false, 'error' => 'No search query'];

        $images = AICopilot_ImageGen::search($query, $count);
        if (empty($images)) {
            return ['success' => false, 'error' => 'No images found'];
        }

        return [
            'success' => true,
            'message' => 'Found ' . count($images) . ' images for "' . $query . '"',
            'images' => $images,
            'needs_selection' => true,
        ];
    }

    /**
     * Download selected image and insert into element
     */
    private static function useImage(array $input): array
    {
        $imageUrl = $input['image_url'] ?? '';
        $elementId = $input['element_id'] ?? '';
        $pageId = $input['page_id'] ?? 0;
        $alt = $input['alt'] ?? '';

        if (!$imageUrl) return ['success' => false, 'error' => 'No image URL'];

        // Download to media library
        $media = AICopilot_ImageGen::downloadToMedia($imageUrl, $alt);
        if (!$media) return ['success' => false, 'error' => 'Failed to download image'];

        // If element specified, insert into it
        if ($elementId && $pageId) {
            $data = get_post_meta($pageId, '_elementor_data', true);
            if ($data) {
                $elements = json_decode($data, true);
                if ($elements) {
                    $elements = self::updateElementImage($elements, $elementId, $media['url'], $media['id']);
                    self::saveElementorData($pageId, $elements);
                }
            }
        }

        return [
            'success' => true,
            'message' => 'Image added to media library' . ($elementId ? ' and inserted into element' : ''),
            'url' => $media['url'],
            'attachment_id' => $media['id'],
        ];
    }

    private static function clearCache(array $input): array
    {
        self::clearElementorCache($input['page_id'] ?? 0);
        return ['success' => true, 'message' => 'Cache cleared'];
    }

    private static function updateSiteSettings(array $input): array
    {
        if ($input['blogname'] ?? '') update_option('blogname', $input['blogname']);
        if ($input['blogdescription'] ?? '') update_option('blogdescription', $input['blogdescription']);
        return ['success' => true, 'message' => 'Site settings updated'];
    }

    // ─── Element Tree Helpers ───

    private static function updateElementField(array $elements, string $id, string $field, $value): array
    {
        foreach ($elements as &$el) {
            if (($el['id'] ?? '') === $id) {
                $el['settings'][$field] = $value;
                return $elements;
            }
            if (!empty($el['elements'])) {
                $el['elements'] = self::updateElementField($el['elements'], $id, $field, $value);
            }
        }
        return $elements;
    }

    private static function updateElementSetting(array $elements, string $id, string $prop, $value): array
    {
        foreach ($elements as &$el) {
            if (($el['id'] ?? '') === $id) {
                $el['settings'][$prop] = $value;
                return $elements;
            }
            if (!empty($el['elements'])) {
                $el['elements'] = self::updateElementSetting($el['elements'], $id, $prop, $value);
            }
        }
        return $elements;
    }

    /**
     * Clear Elementor global color reference so our custom value takes effect
     * Elementor uses __globals__ to link to kit colors - these override inline values
     */
    private static function clearGlobalColorRef(array $elements, string $id, string $prop): array
    {
        foreach ($elements as &$el) {
            if (($el['id'] ?? '') === $id) {
                if (isset($el['settings']['__globals__'][$prop])) {
                    unset($el['settings']['__globals__'][$prop]);
                }
                return $elements;
            }
            if (!empty($el['elements'])) {
                $el['elements'] = self::clearGlobalColorRef($el['elements'], $id, $prop);
            }
        }
        return $elements;
    }

    private static function updateElementImage(array $elements, string $id, string $url, int $attachId): array
    {
        foreach ($elements as &$el) {
            if (($el['id'] ?? '') === $id) {
                $widgetType = $el['widgetType'] ?? '';
                if ($widgetType === 'image' || $widgetType === 'image-box') {
                    $el['settings']['image'] = ['url' => $url, 'id' => $attachId, 'alt' => '', 'source' => 'library'];
                } elseif ($widgetType === 'html' || $widgetType === '') {
                    // Section/container background image
                    $el['settings']['background_background'] = 'classic';
                    $el['settings']['background_image'] = ['url' => $url, 'id' => $attachId];
                } else {
                    $el['settings']['image'] = ['url' => $url, 'id' => $attachId, 'alt' => '', 'source' => 'library'];
                }
                return $elements;
            }
            if (!empty($el['elements'])) {
                $el['elements'] = self::updateElementImage($el['elements'], $id, $url, $attachId);
            }
        }
        return $elements;
    }

    /**
     * Safe text replacement through parsed JSON tree (NOT raw string)
     * Only replaces in known text fields: title, editor, text, description, html
     */
    private static function replaceTextInElements(array $elements, string $old, string $new, bool &$found): array
    {
        $textFields = ['title', 'editor', 'text', 'description', 'html'];

        foreach ($elements as &$el) {
            if (isset($el['settings']) && is_array($el['settings'])) {
                foreach ($textFields as $field) {
                    if (isset($el['settings'][$field]) && is_string($el['settings'][$field])) {
                        if (strpos($el['settings'][$field], $old) !== false) {
                            $el['settings'][$field] = str_replace($old, $new, $el['settings'][$field]);
                            $found = true;
                        }
                    }
                }
            }
            if (!empty($el['elements'])) {
                $el['elements'] = self::replaceTextInElements($el['elements'], $old, $new, $found);
            }
        }
        return $elements;
    }

    /**
     * Remove element by ID - fixed to properly modify nested elements
     */
    private static function removeElementById(array $elements, string $id): array
    {
        $result = [];
        foreach ($elements as $el) {
            if (($el['id'] ?? '') === $id) {
                continue; // skip = remove
            }
            if (!empty($el['elements'])) {
                $el['elements'] = self::removeElementById($el['elements'], $id);
            }
            $result[] = $el;
        }
        return $result;
    }

    /**
     * Extract all editable elements with IDs, types, text, styles, images
     * Includes sections/containers so they can be targeted for styling/removal
     */
    private static function extractEditables(array $elements, array &$result, int $depth = 0): void
    {
        foreach ($elements as $el) {
            $elType = $el['elType'] ?? '';
            $widgetType = $el['widgetType'] ?? '';
            $type = $widgetType ?: $elType;
            $id = $el['id'] ?? '';
            $settings = $el['settings'] ?? [];

            // Include sections/containers (for background styling & removal)
            if (in_array($elType, ['section', 'container'])) {
                $entry = ['id' => $id, 'type' => $elType, 'is_structure' => true];
                if (!empty($settings['background_color'])) {
                    $entry['background_color'] = $settings['background_color'];
                }
                // Count child widgets to help Claude identify sections
                $childCount = self::countWidgets($el['elements'] ?? []);
                if ($childCount > 0) {
                    $entry['widgets_inside'] = $childCount;
                }
                // Get first heading text as label
                $label = self::getFirstText($el['elements'] ?? []);
                if ($label) {
                    $entry['label'] = $label;
                }
                $result[] = $entry;
            }

            // Include editable widgets
            if (in_array($widgetType, ['heading', 'text-editor', 'button', 'image', 'image-box', 'icon-box', 'html'])) {
                $entry = ['id' => $id, 'type' => $widgetType];

                switch ($widgetType) {
                    case 'heading':
                        $entry['text'] = $settings['title'] ?? '';
                        $entry['field'] = 'title';
                        if (!empty($settings['title_color'])) $entry['title_color'] = $settings['title_color'];
                        if (!empty($settings['typography_font_family'])) $entry['font_family'] = $settings['typography_font_family'];
                        if (!empty($settings['typography_font_size']['size'])) $entry['font_size'] = $settings['typography_font_size']['size'] . ($settings['typography_font_size']['unit'] ?? 'px');
                        break;

                    case 'text-editor':
                        $entry['text'] = substr(strip_tags($settings['editor'] ?? ''), 0, 150);
                        $entry['field'] = 'editor';
                        if (!empty($settings['text_color'])) $entry['color'] = $settings['text_color'];
                        break;

                    case 'button':
                        $entry['text'] = $settings['text'] ?? '';
                        $entry['field'] = 'text';
                        if (!empty($settings['button_text_color'])) $entry['button_text_color'] = $settings['button_text_color'];
                        if (!empty($settings['button_background_color'])) $entry['button_background_color'] = $settings['button_background_color'];
                        break;

                    case 'image':
                    case 'image-box':
                        $entry['image_url'] = $settings['image']['url'] ?? '';
                        if ($widgetType === 'image-box') {
                            $entry['text'] = $settings['title_text'] ?? '';
                        }
                        break;

                    case 'icon-box':
                        $entry['text'] = $settings['title_text'] ?? '';
                        $entry['description'] = substr(strip_tags($settings['description_text'] ?? ''), 0, 100);
                        break;
                }

                $result[] = $entry;
            }

            // Recurse into children
            if (!empty($el['elements'])) {
                self::extractEditables($el['elements'], $result, $depth + 1);
            }
        }
    }

    // ─── Section Builder ───

    /**
     * Extract dominant colors/fonts from existing page elements
     */
    private static function extractPageTheme(array $elements): array
    {
        $bgColors = [];
        $headingColors = [];
        $textColors = [];
        $fonts = [];

        $walker = function ($els) use (&$walker, &$bgColors, &$headingColors, &$textColors, &$fonts) {
            foreach ($els as $el) {
                $s = $el['settings'] ?? [];
                $wt = $el['widgetType'] ?? '';
                $et = $el['elType'] ?? '';

                // Collect background colors from containers/sections
                if (in_array($et, ['container', 'section']) && !empty($s['background_color'])) {
                    $bgColors[] = $s['background_color'];
                }
                // Heading colors
                if ($wt === 'heading' && !empty($s['title_color'])) {
                    $headingColors[] = $s['title_color'];
                }
                // Text colors
                if ($wt === 'text-editor' && !empty($s['text_color'])) {
                    $textColors[] = $s['text_color'];
                }
                // Fonts
                if (!empty($s['typography_font_family'])) {
                    $fonts[] = $s['typography_font_family'];
                }

                if (!empty($el['elements'])) $walker($el['elements']);
            }
        };
        $walker($elements);

        // Pick most common values
        return [
            'bg_color' => self::mostCommon($bgColors) ?: '#0C0A09',
            'heading_color' => self::mostCommon($headingColors) ?: '#FAFAF9',
            'text_color' => self::mostCommon($textColors) ?: 'rgba(250,250,249,0.5)',
            'font' => self::mostCommon($fonts) ?: 'Montserrat',
        ];
    }

    private static function mostCommon(array $arr): string
    {
        if (empty($arr)) return '';
        $counts = array_count_values($arr);
        arsort($counts);
        return array_key_first($counts);
    }

    private static function buildNewSection(string $type, array $content, bool $useContainer, array $theme = []): array
    {
        $title = $content['title'] ?? ucfirst($type) . ' Section';
        $subtitle = $content['subtitle'] ?? '';
        $items = $content['items'] ?? [];

        // Theme defaults
        $bgColor = $theme['bg_color'] ?? '#0C0A09';
        $headingColor = $theme['heading_color'] ?? '#FAFAF9';
        $textColor = $theme['text_color'] ?? 'rgba(250,250,249,0.5)';
        $font = $theme['font'] ?? 'Montserrat';

        // Build inner widgets with matching theme
        $widgets = [];

        // Heading widget
        $widgets[] = [
            'id' => self::genId(),
            'elType' => 'widget',
            'widgetType' => 'heading',
            'settings' => [
                'title' => $title,
                'align' => 'center',
                'title_color' => $headingColor,
                'typography_typography' => 'custom',
                'typography_font_family' => $font,
                'typography_font_size' => ['size' => 32, 'unit' => 'px', 'sizes' => []],
                'typography_font_weight' => '700',
                'typography_letter_spacing' => ['size' => 1, 'unit' => 'px', 'sizes' => []],
                'typography_text_transform' => 'uppercase',
            ],
            'elements' => [],
        ];

        // Subtitle
        if ($subtitle) {
            $widgets[] = [
                'id' => self::genId(),
                'elType' => 'widget',
                'widgetType' => 'text-editor',
                'settings' => [
                    'editor' => "<p>{$subtitle}</p>",
                    'align' => 'center',
                    'text_color' => $textColor,
                    'typography_typography' => 'custom',
                    'typography_font_family' => $font,
                ],
                'elements' => [],
            ];
        }

        // Items (for features, testimonials, faq, etc.)
        foreach ($items as $item) {
            $itemTitle = $item['title'] ?? '';
            $itemText = $item['text'] ?? $item['description'] ?? '';

            // Item heading
            if ($itemTitle) {
                $widgets[] = [
                    'id' => self::genId(),
                    'elType' => 'widget',
                    'widgetType' => 'heading',
                    'settings' => [
                        'title' => $itemTitle,
                        'header_size' => 'h4',
                        'title_color' => $headingColor,
                        'typography_typography' => 'custom',
                        'typography_font_family' => $font,
                        'typography_font_size' => ['size' => 18, 'unit' => 'px', 'sizes' => []],
                        'typography_font_weight' => '600',
                    ],
                    'elements' => [],
                ];
            }
            // Item text
            if ($itemText) {
                $widgets[] = [
                    'id' => self::genId(),
                    'elType' => 'widget',
                    'widgetType' => 'text-editor',
                    'settings' => [
                        'editor' => "<p>{$itemText}</p>",
                        'text_color' => $textColor,
                        'typography_typography' => 'custom',
                        'typography_font_family' => $font,
                    ],
                    'elements' => [],
                ];
            }
        }

        $sectionPadding = ['top' => '60', 'right' => '40', 'bottom' => '60', 'left' => '40', 'unit' => 'px', 'isLinked' => false];

        if ($useContainer) {
            return [
                'id' => self::genId(),
                'elType' => 'container',
                'settings' => [
                    'content_width' => 'boxed',
                    'padding' => $sectionPadding,
                    'background_background' => 'classic',
                    'background_color' => $bgColor,
                ],
                'elements' => $widgets,
            ];
        }

        // Legacy Elementor: section > column > widgets
        return [
            'id' => self::genId(),
            'elType' => 'section',
            'settings' => [
                'padding' => $sectionPadding,
                'background_background' => 'classic',
                'background_color' => $bgColor,
            ],
            'elements' => [[
                'id' => self::genId(),
                'elType' => 'column',
                'settings' => ['_column_size' => 100],
                'elements' => $widgets,
            ]],
        ];
    }

    // ─── Save & Cache ───

    private static function saveElementorData(int $pageId, array $elements): void
    {
        // Save snapshot for undo before overwriting
        AICopilot_History::saveSnapshot($pageId);

        // Use json_encode (NOT wp_json_encode) to preserve escaped slashes
        // wp_json_encode adds JSON_UNESCAPED_SLASHES which changes Elementor's URL format
        $json = wp_slash(json_encode($elements));
        update_post_meta($pageId, '_elementor_data', $json);
        self::clearElementorCache($pageId);
    }

    private static function clearElementorCache(int $pageId): void
    {
        global $wpdb;

        if ($pageId) {
            // Only clear cache for THIS specific page - not all pages
            $wpdb->query($wpdb->prepare(
                "DELETE FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key IN ('_elementor_css','_elementor_element_cache','_elementor_page_assets')",
                $pageId
            ));

            // Delete only this page's CSS file
            $upload_dir = wp_upload_dir();
            $css_file = $upload_dir['basedir'] . '/elementor/css/post-' . $pageId . '.css';
            if (file_exists($css_file)) @unlink($css_file);
        }

        // Regenerate CSS via Elementor API (if available)
        if (class_exists('\Elementor\Plugin')) {
            try {
                // Clear just this page's CSS so Elementor regenerates it on next load
                $post_css = \Elementor\Core\Files\CSS\Post::create($pageId);
                $post_css->update();
            } catch (\Exception $e) {
                // Fallback: delete post CSS meta so it regenerates
            }
        }

        // Clear WordPress object cache for this post
        clean_post_cache($pageId);
    }

    // ─── Utility Helpers ───

    private static function sideloadImage(string $url): ?int
    {
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $tmp = download_url($url);
        if (is_wp_error($tmp)) return null;

        $file = ['name' => basename(parse_url($url, PHP_URL_PATH)) ?: 'image.jpg', 'tmp_name' => $tmp];
        $id = media_handle_sideload($file, 0);
        if (is_wp_error($id)) {
            @unlink($tmp);
            return null;
        }

        return $id;
    }

    /**
     * Detect widget type for an element ID
     */
    private static function getWidgetType(array $elements, string $id): string
    {
        foreach ($elements as $el) {
            if (($el['id'] ?? '') === $id) {
                return $el['widgetType'] ?? $el['elType'] ?? '';
            }
            if (!empty($el['elements'])) {
                $type = self::getWidgetType($el['elements'], $id);
                if ($type) return $type;
            }
        }
        return '';
    }

    /**
     * Map generic color/style property to correct Elementor property per widget type
     */
    private static function fixPropertyForWidget(string $property, string $widgetType): string
    {
        // Normalize generic color names to correct per-widget property
        $colorNames = ['color', 'text_color', 'text-color', 'textColor', 'title_color'];

        if (in_array($property, $colorNames)) {
            return match ($widgetType) {
                'heading' => 'title_color',
                'text-editor' => 'text_color',
                'button' => 'button_text_color',
                'icon-box' => 'title_color',
                default => 'text_color',
            };
        }

        return $property;
    }

    private static function getElementFieldValue(array $elements, string $id, string $field): mixed
    {
        foreach ($elements as $el) {
            if (($el['id'] ?? '') === $id) {
                return $el['settings'][$field] ?? null;
            }
            if (!empty($el['elements'])) {
                $val = self::getElementFieldValue($el['elements'], $id, $field);
                if ($val !== null) return $val;
            }
        }
        return null;
    }

    private static function genId(): string
    {
        return substr(md5(uniqid(mt_rand(), true)), 0, 7);
    }

    private static function countWidgets(array $elements): int
    {
        $count = 0;
        foreach ($elements as $el) {
            if (!empty($el['widgetType'])) $count++;
            if (!empty($el['elements'])) $count += self::countWidgets($el['elements']);
        }
        return $count;
    }

    private static function getFirstText(array $elements): string
    {
        foreach ($elements as $el) {
            $s = $el['settings'] ?? [];
            if (!empty($s['title'])) return substr($s['title'], 0, 50);
            if (!empty($s['editor'])) return substr(strip_tags($s['editor']), 0, 50);
            if (!empty($s['text'])) return substr($s['text'], 0, 50);
            if (!empty($el['elements'])) {
                $text = self::getFirstText($el['elements']);
                if ($text) return $text;
            }
        }
        return '';
    }
}
