<?php

/**
 * Elementor Widget
 * @package Saasten
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_home_services_two extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'theme-services-two';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Home Services 2', 'saasten-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saasten_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {



       $this->start_controls_section( 'section_content_servicestop_two', [
            'label' => esc_html__( 'Top Heading', 'saasten-extra' ),
        ] ); 

        $this->add_control( 'sub-title', [
            'label'       => __( 'Sub Title', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => __( 'Trusted by 20,000+ clients', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type section subtitle here.", 'saasten-extra' ),
        ] );

        $this->add_control( 'title', [
            'label'       => __( 'Title', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Invest in Startup', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type section title here.", 'saasten-extra' ),

        ] );


        $this->end_controls_section();



        $this->start_controls_section( 'section_content_sertwo1', [
            'label' => esc_html__( 'Services Items', 'saasten-extra' ),
        ] ); 

        $this->add_control( 'serItems', [
            'label'       => esc_html__( 'Service Items', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'default'     => [
                [
                    'service-title'        => esc_html__( 'Web Development', 'saasten-extra' ),
                ]
            ],

            'fields'      => [


              [
                    'name'        => 'service-title',
                    'label'       => esc_html__( 'Title', 'deaxautt-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'default'     => __( 'Web Development', 'deaxautt-extra' ),
                    'description' => esc_html__( 'Enter Title', 'deaxautt-extra' )
                ],

                [
                    'name'        => 'service-des',
                    'label'       => esc_html__( 'Short Description', 'deaxautt-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'default'     => __( 'Our Sustainable Construction Advisors', 'deaxautt-extra' ),
                    'label_block' => true,
                    'description' => esc_html__( 'Enter Description', 'deaxautt-extra' )
                ],


                [
                    'name'        => 'service-list1',
                    'label'       => esc_html__( 'List 1', 'deaxautt-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'default'     => __( 'Web Development', 'deaxautt-extra' ),
                    'description' => esc_html__( 'Enter Title', 'deaxautt-extra' )
                ],

                [
                    'name'        => 'service-list2',
                    'label'       => esc_html__( 'List 2', 'deaxautt-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'default'     => __( 'Web Development', 'deaxautt-extra' ),
                    'description' => esc_html__( 'Enter Title', 'deaxautt-extra' )
                ],

                [
                    'name'        => 'service-list3',
                    'label'       => esc_html__( 'List 3', 'deaxautt-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'default'     => __( 'Web Development', 'deaxautt-extra' ),
                    'description' => esc_html__( 'Enter Title', 'deaxautt-extra' )
                ],


                [
                    'name'        => 'service-image',
                    'label'       => esc_html__( 'Service Image', 'deaxautt-extra' ),
                    'type'        => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                    ],

                    'description' => esc_html__( 'Upload service image', 'deaxautt-extra' )
                ],

                [
                    'name'        => 'service-icon',
                    'label'       => esc_html__( 'Service Icon', 'deaxautt-extra' ),
                    'type'        => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                    ],

                    'description' => esc_html__( 'Upload service icon', 'deaxautt-extra' )
                ],
                

                [
                    'name'        => 'btn-link',
                    'label'       => esc_html__( 'Service Button Link', 'deaxautt-extra' ),
                    'type'        => \Elementor\Controls_Manager::URL,
                    'placeholder' => __( 'https://your-link.com', 'deaxautt-extra' ),
                    'default'     => [
                        'url' => '#',
                    ],
                ],


                

            ],
            'title_field' => "{{name}}"
        ] );



        $this->end_controls_section();


		
	}
	


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

    $serItems = $settings['serItems'];

    extract($settings); 


		
		?>





    <!-- Software Service -->
    <section class="software-service section-padding">
      <div class="container">
        <div class="row">
          <div class="col-12 mg-btm-40">
            <!-- Section Title -->
            <div
              class="section-title-v3 text-center aos-init aos-animate"
              data-aos="fade-in"
            >
              <p
                class="section-title-v3__label mg-btm-20 m-0 saastain-gsap-anim2"
              >
                <?php echo wp_kses_post( $settings['sub-title'] ); ?>
              </p>
              <h2 class="section-title-v3__title m-0 saastain-gsap-anim3">
                <?php echo wp_kses_post( $settings['title'] ); ?>
              </h2>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12">


            <?php
                foreach ( $serItems as $item ):
            ?>

            <!-- Software Card -->
            <div class="software-card mg-btm-30" data-aos="fade-up">
              <div class="software-card__content">
                <div class="software-card__icon">
                  <img src="<?php echo esc_url( $item['service-icon']['url'] ); ?>" alt="#" />
                </div>
                <div class="software-card__main">
                  <h4 class="software-card__heading">
                    <?php echo wp_kses_post( $item['service-title'] ); ?>
                  </h4>
                  <p class="software-card__text">
                    <?php echo wp_kses_post( $item['service-des'] ); ?>
                  </p>
                  <div class="software-card-expand">
                    <ul class="list-features m-0 mg-top-25">
                      <li>
                        <span class="flex-shrink-0"
                          ><img src="<?php echo SAASTEN_IMG ."/check-icon-v3.svg"; ?>"
                        /></span>
                        <span class="text-color"><?php echo wp_kses_post( $item['service-list1'] ); ?></span>
                      </li>
                      <li>
                        <span class="flex-shrink-0"
                          ><img src="<?php echo SAASTEN_IMG ."/check-icon-v3.svg"; ?>"
                        /></span>
                        <span class="text-color"
                          ><?php echo wp_kses_post( $item['service-list2'] ); ?></span
                        >
                      </li>
                      <li>
                        <span class="flex-shrink-0"
                          ><img src="<?php echo SAASTEN_IMG ."/check-icon-v3.svg"; ?>"
                        /></span>
                        <span class="text-color"><?php echo wp_kses_post( $item['service-list3'] ); ?></span>
                      </li>
                    </ul>
                    <a
                      href="<?php echo esc_url( $item['btn-link']['url'] ) ?>"
                      class="saastain-btn mg-top-50 primary-bg-hover primary-bg border-radius-31"
                      >Read More</a
                    >
                  </div>
                </div>
              </div>
              <div class="software-card__image">
                <img src="<?php echo esc_url( $item['service-image']['url'] ); ?>" alt="#" />
              </div>
              <div class="software-card__button">
                <a href="<?php echo esc_url( $item['btn-link']['url'] ) ?>">
                  <svg
                    width="56"
                    height="56"
                    viewBox="0 0 56 56"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <rect x="0.5" y="0.5" width="55" height="55" rx="27.5" />
                    <path
                      d="M31.6667 36L39 28M39 28L31.6667 20M39 28L17 28"
                      stroke-width="1.5"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                  </svg>
                </a>
              </div>
            </div>
            <!-- End Software Card -->

            <?php endforeach; ?>




          </div>
        </div>
      </div>
    </section>
    <!-- End Software Service -->






	<?php 


	}
				

}

