<?php
namespace Elementor;
class Xcency_Testimonial_Two_Widget extends Widget_Base {

	public function get_name() {

		return 'xcency_testimonial_two';
	}

	public function get_title() {
		return esc_html__( 'Testimonials Two', 'xcency-core' );
	}

	public function get_icon() {

		return 'eicon-testimonial';
	}

	public function get_categories() {
		return [ 'xcency_core_elements' ];
	}


	protected function register_controls() {

		//Content tab start
		$this->start_controls_section(
			'testimonial_settings',
			[
				'label' => esc_html__( 'Testimonial Two', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'author_name',
			[
				'label'       => __('Name', 'xcency-core'),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Karen Mckenzie',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'designation',
			[
				'label'       => __('Designation', 'xcency-core'),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'CEO Of Xcency',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'photo',
			[
				'label'       => __( 'Image', 'xcency-core' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'default'     => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);


		$repeater->add_control(
			'testimonial_text',
			[
				'label'   => __('Description', 'xcency-core'),
				'type'    => Controls_Manager::WYSIWYG,
				'default' => 'This is due to their excellent servic and competiti of pricing and custome office refresing to get more such personal and most flamable furtune touch of the hol lorem ipsum text.',
			]
		);

		$this->add_control(
			'testimonials',
			[
				'label'       => __('Testimonial List', 'xcency-core'),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'author_name'        => 'Karen Mckenzie',
						'designation'        => 'CEO Of Xcency',
						'testimonial_text' => 'This is due to their excellent servic and competiti of pricing and custome office refresing to get more such personal and most flamable furtune touch of the hol lorem ipsum text.',
					],
				],
				'title_field' => '{{{ author_name }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'column_options',
			[
				'label' => esc_html__( 'Colum Options', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'desktop_col',
			[
				'label'   => __( 'Columns On Desktop', 'xcency-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-xl-4',
				'options' => [
					'col-xl-12' => __( '1 Column', 'xcency-core' ),
					'col-xl-6'  => __( '2 Column', 'xcency-core' ),
					'col-xl-4'  => __( '3 Column', 'xcency-core' ),
					'col-xl-3'  => __( '4 Column', 'xcency-core' ),
				],
			]
		);

		$this->add_control(
			'iPad_pro_col',
			[
				'label'   => __( 'Columns On iPad Pro', 'xcency-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-lg-6',
				'options' => [
					'col-lg-12' => __( '1 Column', 'xcency-core' ),
					'col-lg-6'  => __( '2 Column', 'xcency-core' ),
					'col-lg-4'  => __( '3 Column', 'xcency-core' ),
					'col-lg-3'  => __( '4 Column', 'xcency-core' ),
				],
			]
		);

		$this->add_control(
			'tab_col',
			[
				'label'   => __( 'Columns On Tablet', 'xcency-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-md-6',
				'options' => [
					'col-md-12' => __( '1 Column', 'xcency-core' ),
					'col-md-6'  => __( '2 Column', 'xcency-core' ),
					'col-md-4'  => __( '3 Column', 'xcency-core' ),
					'col-md-3'  => __( '4 Column', 'xcency-core' ),
				],
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'testimonial_style_option',
            [
                'label' => esc_html__( 'Testimonial', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'item_bg',
            [
                'label'       => esc_html__('Background Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .xcency-testimonial-one-item' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$column = $settings['desktop_col'] . ' ' . $settings['iPad_pro_col'] . ' ' . $settings['tab_col'];
		?>

		<div class="xcency-testimonial-two-wrapper xcency-testimonial-one-wrapper">
			<div class="row">
				<?php if($settings['testimonials']){
					foreach ($settings['testimonials'] as $testimonial){
						?>
						<div class="<?php echo $column;?>">
							<div class="xcency-testimonial-one-item">
                                <div class="testimonial-one-text">
									<?php echo wp_kses($testimonial['testimonial_text'], xcency_allow_html());?>
                                </div>

                                <div class="testimonial-one-content">
                                    <div class="person-img" style="background-image: url(<?php echo $testimonial['photo']['url'];?>)"></div>
                                    <div class="testimonial-one-person">
                                        <h6 class="testimonial-one-person-name"><?php echo esc_html($testimonial['author_name']);?></h6>
                                        <span class="testimonial-one-person-designation"><?php echo esc_html($testimonial['designation']);?></span>
                                    </div>
                                </div>

                                <div class="testimonial-one-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="45" height="45" viewBox="0 0 45 45" fill="none">
                                        <path d="M13.1443 2.85589C13.056 2.76616 12.9336 2.71843 12.8076 2.72529C12.6818 2.73197 12.565 2.79235 12.4868 2.89105L2.37935 15.6352C2.30482 15.7291 2.27195 15.8496 2.28839 15.9684C2.30482 16.0872 2.36907 16.1942 2.46628 16.2645C2.54353 16.3204 10.1944 21.9312 10.1944 28.6525C10.1944 35.4066 3.80661 41.4546 3.7421 41.5149C3.59066 41.6564 3.55867 41.8845 3.66528 42.0622C3.74649 42.1975 3.89116 42.2756 4.04216 42.2756C4.08953 42.2756 4.13743 42.268 4.18427 42.2519C4.35759 42.1926 8.47852 40.7611 12.7722 37.4032C15.3003 35.4262 17.3536 33.1912 18.8753 30.7603C20.783 27.7125 21.8542 24.3504 22.0589 20.7675C22.059 20.7642 22.0592 20.7611 22.0593 20.7578C22.0624 20.6694 22.1228 18.5547 21.0487 15.2772C20.0651 12.2753 17.8953 7.68373 13.1443 2.85589ZM21.181 20.7234C20.735 28.4909 16.0796 33.6952 12.2521 36.694C9.80409 38.612 7.37154 39.9002 5.76842 40.6409C6.33619 39.9832 7.01673 39.132 7.70104 38.1284C9.23939 35.8721 11.0733 32.3965 11.0733 28.6524C11.0733 25.6712 9.66909 22.4571 7.01242 19.3576C5.5065 17.6007 4.01684 16.3565 3.3465 15.8301L12.8645 3.82911C17.2375 8.38483 19.2649 12.6759 20.1979 15.5033C21.2148 18.5842 21.1832 20.6266 21.181 20.7234ZM41.7036 15.277C40.7201 12.2753 38.5501 7.68373 33.7991 2.85589C33.7108 2.76607 33.5876 2.71826 33.4625 2.72529C33.3366 2.73197 33.2198 2.79235 33.1416 2.89105L23.0342 15.6352C22.9596 15.7291 22.9269 15.8496 22.9433 15.9684C22.9597 16.0872 23.024 16.1942 23.1211 16.2645C23.1984 16.3204 30.8492 21.9312 30.8492 28.6525C30.8492 35.4066 24.4614 41.4546 24.3969 41.5149C24.2455 41.6564 24.2135 41.8845 24.3202 42.0622C24.4014 42.1975 24.546 42.2756 24.697 42.2756C24.7444 42.2756 24.7923 42.268 24.8391 42.2519C25.0125 42.1926 29.1333 40.7611 33.4271 37.4032C35.9552 35.4262 38.0085 33.1912 39.5301 30.7603C41.4379 27.7125 42.509 24.3504 42.7138 20.7675C42.7139 20.7642 42.7141 20.7611 42.7142 20.7578C42.7174 20.6692 42.7778 18.5545 41.7036 15.277ZM41.8359 20.7234C41.39 28.4909 36.7345 33.6952 32.907 36.694C30.459 38.612 28.0264 39.9002 26.4232 40.6409C26.9911 39.9832 27.6716 39.132 28.3558 38.1284C29.8942 35.8721 31.7281 32.3965 31.7281 28.6524C31.7281 25.6712 30.3238 22.4571 27.6672 19.3576C26.1612 17.6007 24.6716 16.3565 24.0013 15.8301L33.5194 3.82911C37.8924 8.38483 39.9197 12.6759 40.8529 15.5033C41.8697 18.5842 41.8382 20.6266 41.8359 20.7234Z" fill="#101010" fill-opacity="0.1"/>
                                    </svg>
                                </div>
							</div>
						</div>
						<?php
					}
				} ?>
			</div>
            <div class="testi-two-overlay"></div>
		</div>

		<?php
	}
}

Plugin::instance()->widgets_manager->register( new Xcency_Testimonial_Two_Widget );