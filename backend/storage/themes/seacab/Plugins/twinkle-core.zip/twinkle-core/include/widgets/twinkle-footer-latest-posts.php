<?php



/**

 * Seacab Footer Latest Posts

 *

 *

 * @author 		TwinkleTheme

 * @category 	Widgets

 * @package 	Seacab/Widgets

 * @version 	1.0.0

 * @extends 	WP_Widget

 */



add_action('widgets_init', function(){

	register_widget('Twinkle_footer_latest_posts');

});



Class Twinkle_footer_latest_posts extends WP_Widget{



	public function __construct(){

		parent::__construct('Twinkle_footer_latest_posts', esc_html__('Seacab Footer Latest Posts', 'twinkle-core'), array(

			'description'	=> esc_html__('Show Footer Latest Post by Seacab', 'twinkle-core'),

		));

	}



	public function widget($args, $instance){

			extract($args);

			extract($instance);



	 	echo $before_widget; 

	 		if($instance['title']):

     		echo $before_title; ?> 

     			<?php echo apply_filters( 'widget_title', $instance['title'] ); ?>

     		<?php echo $after_title; ?>

     	<?php endif; ?>



		 	<ul class="footer-widget__blog-list list-unstyled clearfix">

			 	<?php 

				$q = new WP_Query( array(

				    'post_type'     => 'post',

				    'posts_per_page'=> ($instance['count']) ? $instance['count'] : '3',

				    'order'			=> ($instance['posts_order']) ? $instance['posts_order'] : 'DESC',

				    'orderby' => 'comment_count'

				));



				if( $q->have_posts() ):

				while( $q->have_posts() ):$q->the_post();

				?>

					<li>

						<?php if(has_post_thumbnail()): ?>

						<div class="footer-widget__blog-img">

							<?php the_post_thumbnail('thumbnail'); ?>

							<a href="<?php the_permalink(); ?>"><i class="icon-link"></i></a>

						</div>

						<?php endif; ?>

						<div class="footer-widget__blog-content">

							<p class="footer-widget__blog-text">

								<a href="<?php the_permalink(); ?>"><?php print wp_trim_words(get_the_title(), 7, ''); ?></a>

							</p>

							<p class="footer-widget__blog-date"><?php the_time('F d, Y'); ?></p>

						</div>

					</li>

				<?php endwhile;            

				 endif; ?> 

			</ul>





		<?php echo $after_widget; ?>



		<?php

	}







	public function form($instance){

		$title = ! empty( $instance['title'] ) ? $instance['title'] : '';

		$count = ! empty( $instance['count'] ) ? $instance['count'] : esc_html__( '3', 'twinkle-core' );

		$posts_order = ! empty( $instance['posts_order'] ) ? $instance['posts_order'] : esc_html__( 'DESC', 'twinkle-core' );

		$choose_style = ! empty( $instance['choose_style'] ) ? $instance['choose_style'] : esc_html__( 'style_1', 'twinkle-core' );

		

		?>	

			<p>

				<label for="<?php echo $this->get_field_id('title'); ?>">Title</label>

				<input type="text" name="<?php echo $this->get_field_name('title'); ?>" id="<?php echo $this->get_field_id('title'); ?>" value="<?php echo esc_attr( $title ); ?>" class="widefat">

			</p>



			<p>

				<label for="<?php echo $this->get_field_id('count'); ?>">How many posts you want to show ?</label>

				<input type="number" name="<?php echo $this->get_field_name('count'); ?>" id="<?php echo $this->get_field_id('count'); ?>" value="<?php echo esc_attr( $count ); ?>" class="widefat">

			</p>



			<p>

				<label for="<?php echo $this->get_field_id('posts_order'); ?>">Posts Order</label>

				<select name="<?php echo $this->get_field_name('posts_order'); ?>" id="<?php echo $this->get_field_id('posts_order'); ?>" class="widefat">

					<option value="" disabled="disabled">Select Post Order</option>

					<option value="ASC" <?php if($posts_order === 'ASC'){ echo 'selected="selected"'; } ?>>ASC</option>

					<option value="DESC" <?php if($posts_order === 'DESC'){ echo 'selected="selected"'; } ?>>DESC</option>

				</select>

			</p>



		<?php

	}



}