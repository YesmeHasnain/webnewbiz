<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome5BlogSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home5-blog-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 5 - Blog Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-post-list';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home5' ];
	}

	public function get_keywords() {
		return [ 'home5blogsection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}
	

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_blog_section',
			[
				'label' => esc_html__( 'Home 5 Blog Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Discover the latest tips, <br> trends and ideas.' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'img_thumb_bt',
			[
				'label'       	=> esc_html__( 'Image Thumbnail Bottom Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image thumbnail bottom', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'post_number',
			[
				'label'       => __( 'Post Number', 'bdevs-elementor' ),
				'type'        => Controls_Manager::NUMBER,
				'placeholder' => __( 'Enter your post number', 'bdevs-elementor' ),
				'min'		  => 0,
				'default'     => __( '3', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order_by',
			[
				'label'       => __( 'Post Order By', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text post order by', 'bdevs-elementor' ),
				'default'     => __( 'ID', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
				],
				'default'   => 'desc',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-blog-5-ptb pt-150">
	<?php if (!empty($settings['title_sec'])): ?>
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="tp-blog-5-heading text-center mb-100">
						<h3 class="tp-section-5-title tp-title-anim"><?php echo wp_kses_post($settings['title_sec']); ?></h3>
					</div>
				</div>
			</div>
		</div>
	<?php endif ?>
	<div class="tp-blog-5-box pb-120">
		<?php
		$wp_query = new \WP_Query([
			'post_type'      => 'post',
			'posts_per_page' => intval($settings['post_number']),
			'orderby'        => sanitize_text_field($settings['post_order_by']),
			'order'          => sanitize_text_field($settings['post_order']),
		]);
		$i = 0;
		while ($wp_query->have_posts()) : $wp_query->the_post();
			$i++;
			$post_id         = get_the_ID();

			$custom_title    = get_post_meta($post_id, '_cmb_post_title_home_5', true);
			$post_excerpt    = get_post_meta($post_id, '_cmb_post_excerpt_home_5', true);
			$img_id          = get_post_meta($post_id, '_cmb_post_thumb_home_5', true);
			$post_link       = get_permalink();
			$title_attribute = the_title_attribute(['echo' => false]);

			$title = !empty($custom_title) ? $custom_title : get_the_title();
			if (!empty($img_id)) {
				$img_url = wp_get_attachment_url($img_id);
			} elseif (has_post_thumbnail()) {
				$img_url = get_the_post_thumbnail_url();
			} else {
				$img_url = get_template_directory_uri() . '/assets/img/blog/home-5/blog-5-1.jpg';
			}

			$cls_active = ($i === 2) ? 'active' : '';
		?>
			<div class="tp-blog-5-wrapper <?php echo esc_attr($cls_active); ?>">
				<div class="container">
					<div class="row justify-content-center">
						<div class="col-xl-9 col-lg-12">
							<div class="tp-blog-5-item d-flex">
								<div class="tp-blog-5-item-thumb mr-40">
									<a href="<?php the_permalink(); ?>">
										<img class="ratio-31x23" src="<?php echo esc_url($img_url); ?>" alt="<?php the_title_attribute(); ?>">
									</a>
								</div>
								<div class="tp-blog-5-item-content">
									<h3 class="tp-blog-5-item-title">
										<a href="<?php the_permalink(); ?>"><?php echo wp_kses_post($title); ?></a>
									</h3>
									<p>
										<?php if ( '' !== wp_specialchars_decode($post_excerpt)): ?>
											<?php print wp_specialchars_decode($post_excerpt); ?>
										<?php else:?>
											<?php if(isset($nixer_redux_demo['blog_excerpt'])){?>
											<?php echo esc_attr(nixer_excerpt($nixer_redux_demo['blog_excerpt'])); ?>
											<?php }else{?>
											<?php echo esc_attr(nixer_excerpt(20)); 
											}?>
										<?php endif ?>
									</p>
									<div class="tp-blog-5-item-btn-box d-flex justify-content-between align-items-center">
										<span class="tp-blog-5-item-date"><?php echo get_the_time('F j, Y'); ?></span>
										<div class="tp-blog-5-item-btn">
											<a href="<?php the_permalink(); ?>">
												<span>
													<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
														<path d="M0.9375 15.0696L14.1073 1.89973M3.25781 1.43284C6.38524 4.56026 11.6718 4.33494 15.0777 0.929064M15.0759 0.92627C11.67 4.33215 11.4447 9.61875 14.5721 12.7462" stroke="currentColor" stroke-width="2" stroke-miterlimit="10"/>
													</svg>
												</span>
											</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php endwhile; ?>
	</div>
	<?php if (!empty($settings['img_thumb_bt']['url'])): ?>
		<div class="container-fluid">
			<div class="row gx-0 p-0">
				<div class="tp-blog-5-wrap fix">
					<img class="w-100" data-speed=".8" src="<?php echo wp_kses_post($settings['img_thumb_bt']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_thumb_bt']['alt']); ?>">
				</div>
			</div>
		</div>
	<?php endif ?>
</section>

<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		if ($('.tp-blog-5-heading .tp-title-anim').length > 0) {
			var splitTitleLines = gsap.utils.toArray(".tp-blog-5-heading .tp-title-anim");
			splitTitleLines.forEach(splitTextLine => {
				var tl = gsap.timeline({
				scrollTrigger: {
					trigger: splitTextLine,
					start: 'top 90%',
					end: 'bottom 60%',
					scrub: false,
					markers: false,
					toggleActions: 'play none none none'
				}
				});
	
				var itemSplitted = new SplitText(splitTextLine, { type: "words, lines" });
				gsap.set(splitTextLine, { perspective: 300});
				itemSplitted.split({ type: "lines" })
				tl.from(itemSplitted.lines, { duration: 1, delay: 0.3, opacity: 0, rotationX: -50, force3D: true, transformOrigin: "top center -50", stagger: 0.2 });
			});	
		}

		jQuery('.tp-blog-5-wrapper').on('mouseenter', function () {
			jQuery('.tp-blog-5-wrapper').removeClass('active');
			jQuery(this).addClass('active');
		});

		gsap.registerPlugin(ScrollTrigger, ScrollSmoother);
		var smoother = ScrollSmoother.create({
			smooth: 2,
			effects: true,
			smoothTouch: true
		});
	</script>
<?php } ?>

<?php
}

}