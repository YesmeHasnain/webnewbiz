<?php
/**
 * AI Tool Definitions - Claude tool-use schema
 */
class AICopilot_Tools
{
    public static function getAll(): array
    {
        return [
            [
                'name' => 'edit_element_text',
                'description' => 'Edit the text content of an element on the current page. Use this to change headings, paragraphs, button text, or any text content.',
                'input_schema' => [
                    'type' => 'object',
                    'properties' => [
                        'page_id' => ['type' => 'integer', 'description' => 'WordPress page ID'],
                        'element_id' => ['type' => 'string', 'description' => 'Elementor element ID'],
                        'field' => ['type' => 'string', 'description' => 'Field name: title, editor, text, button_text'],
                        'value' => ['type' => 'string', 'description' => 'New text content (HTML allowed for editor field)'],
                    ],
                    'required' => ['page_id', 'element_id', 'field', 'value'],
                ],
            ],
            [
                'name' => 'edit_element_style',
                'description' => 'Change a style property of an element. Use for colors, font sizes, backgrounds, padding, etc.',
                'input_schema' => [
                    'type' => 'object',
                    'properties' => [
                        'page_id' => ['type' => 'integer', 'description' => 'WordPress page ID'],
                        'element_id' => ['type' => 'string', 'description' => 'Elementor element ID'],
                        'property' => ['type' => 'string', 'description' => 'CSS property: title_color, background_color, typography_font_size, padding, etc.'],
                        'value' => ['type' => 'string', 'description' => 'New value'],
                    ],
                    'required' => ['page_id', 'element_id', 'property', 'value'],
                ],
            ],
            [
                'name' => 'edit_element_image',
                'description' => 'Change an image on the page. Provide a new image URL.',
                'input_schema' => [
                    'type' => 'object',
                    'properties' => [
                        'page_id' => ['type' => 'integer', 'description' => 'WordPress page ID'],
                        'element_id' => ['type' => 'string', 'description' => 'Elementor element ID'],
                        'image_url' => ['type' => 'string', 'description' => 'New image URL'],
                    ],
                    'required' => ['page_id', 'element_id', 'image_url'],
                ],
            ],
            [
                'name' => 'get_page_editables',
                'description' => 'Get all editable elements on a page with their IDs, types, and current content. Call this FIRST to understand what can be edited.',
                'input_schema' => [
                    'type' => 'object',
                    'properties' => [
                        'page_id' => ['type' => 'integer', 'description' => 'WordPress page ID'],
                    ],
                    'required' => ['page_id'],
                ],
            ],
            [
                'name' => 'add_section',
                'description' => 'Add a new section to a page. Types: hero, features, testimonials, cta, contact, pricing, team, faq, gallery, custom.',
                'input_schema' => [
                    'type' => 'object',
                    'properties' => [
                        'page_id' => ['type' => 'integer', 'description' => 'WordPress page ID'],
                        'section_type' => ['type' => 'string', 'description' => 'Section type'],
                        'position' => ['type' => 'integer', 'description' => 'Position index (0 = top)'],
                        'content' => ['type' => 'object', 'description' => 'Section content (title, subtitle, items)'],
                    ],
                    'required' => ['page_id', 'section_type'],
                ],
            ],
            [
                'name' => 'remove_section',
                'description' => 'Remove a section from a page by its element ID.',
                'input_schema' => [
                    'type' => 'object',
                    'properties' => [
                        'page_id' => ['type' => 'integer', 'description' => 'WordPress page ID'],
                        'element_id' => ['type' => 'string', 'description' => 'Section element ID to remove'],
                    ],
                    'required' => ['page_id', 'element_id'],
                ],
            ],
            [
                'name' => 'create_page',
                'description' => 'Create a new WordPress page.',
                'input_schema' => [
                    'type' => 'object',
                    'properties' => [
                        'title' => ['type' => 'string', 'description' => 'Page title'],
                        'content' => ['type' => 'string', 'description' => 'Page content (HTML)'],
                        'status' => ['type' => 'string', 'description' => 'publish or draft'],
                    ],
                    'required' => ['title'],
                ],
            ],
            [
                'name' => 'update_page_seo',
                'description' => 'Update SEO meta tags for a page.',
                'input_schema' => [
                    'type' => 'object',
                    'properties' => [
                        'page_id' => ['type' => 'integer', 'description' => 'WordPress page ID'],
                        'meta_title' => ['type' => 'string'],
                        'meta_description' => ['type' => 'string'],
                        'keywords' => ['type' => 'string'],
                    ],
                    'required' => ['page_id'],
                ],
            ],
            [
                'name' => 'set_global_colors',
                'description' => 'Update the website global/brand colors.',
                'input_schema' => [
                    'type' => 'object',
                    'properties' => [
                        'primary' => ['type' => 'string', 'description' => 'Primary brand color (hex)'],
                        'secondary' => ['type' => 'string', 'description' => 'Secondary color (hex)'],
                        'text' => ['type' => 'string', 'description' => 'Text color (hex)'],
                        'accent' => ['type' => 'string', 'description' => 'Accent color (hex)'],
                    ],
                    'required' => ['primary'],
                ],
            ],
            [
                'name' => 'upload_image',
                'description' => 'Upload an image from URL to the media library.',
                'input_schema' => [
                    'type' => 'object',
                    'properties' => [
                        'url' => ['type' => 'string', 'description' => 'Image URL to download'],
                        'alt' => ['type' => 'string', 'description' => 'Alt text for the image'],
                    ],
                    'required' => ['url'],
                ],
            ],
            [
                'name' => 'update_site_settings',
                'description' => 'Update WordPress site settings like site title and tagline.',
                'input_schema' => [
                    'type' => 'object',
                    'properties' => [
                        'blogname' => ['type' => 'string', 'description' => 'Site title'],
                        'blogdescription' => ['type' => 'string', 'description' => 'Site tagline'],
                    ],
                    'required' => [],
                ],
            ],
        ];
    }
}
