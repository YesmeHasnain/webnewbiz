<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Menu List Widget .
 *
 */
class Barab_Menu_List extends Widget_Base {

	public function get_name() {
		return 'barabmenu_list';
	}
	public function get_title() {
		return __( 'Menu List', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		 $this->start_controls_section(
			'section_title_section',
			[
				'label'		 	=> __( 'Menu List', 'barab' ),
				'tab' 			=> Controls_Manager::TAB_CONTENT,
				
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two', 'Style Three' ] ); 

		barab_media_fields($this, 'image', 'Choose Image', ['1'] );

		barab_general_fields( $this, 'title', 'Title', 'TEXTAREA2', 'Visit Our restaurant', ['1', '2'] );
		barab_general_fields( $this, 'desc', 'Description', 'TEXTAREA', 'Content', ['1', '2'] );

		$repeater = new Repeater();

		barab_media_fields($repeater, 'image', 'Choose Image' );
		barab_general_fields($repeater, 'title', 'Title', 'TEXTAREA2', 'Initial process');
		barab_url_fields($repeater, 'button_url', 'Button URL');

		$this->add_control(
			'feature_list',
			[
				'label' 		=> __( 'Menu Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'Initial Consultation', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['1', '2']
				]
			]
		);

		$repeater = new Repeater();

		barab_media_fields($repeater, 'image', 'Choose Image' );
		barab_media_fields($repeater, 'shape', 'Choose Shape' );
		barab_general_fields($repeater, 'title', 'Title', 'TEXTAREA2', 'Food');
		barab_general_fields($repeater, 'desc', 'Content', 'TEXTAREA2', '10 Items Available');
		barab_general_fields($repeater, 'button_text', 'Button Text', 'TEXT', 'View Menu');
		barab_url_fields($repeater, 'button_url', 'Button URL');

		$this->add_control(
			'feature_list2',
			[
				'label' 		=> __( 'Menu Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'Food', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['3']
				]
			]
		);
		
		barab_general_fields($this, 'button_text', 'Button Text', 'TEXT', 'Viw All List', ['1', '2']);
		barab_url_fields($this, 'button_url', 'Button URL', ['1', '2']);

		$this->end_controls_section();

        //---------------------------------------
			//Style Section Start 
		//---------------------------------------
		barab_common_style_fields( $this, '01', 'Title', '{{WRAPPER}} .box-title', ['3'] );
		barab_common_style_fields( $this, '02', 'Title', '{{WRAPPER}} .sec-title', ['1', '2'] );
		barab_common_style_fields( $this, '03', 'Description', '{{WRAPPER}} .box-text', ['1', '2', '3'] );
		//------Button Style-------
		barab_button_style_fields( $this, '10', 'Button Styling', '{{WRAPPER}} .th-btn', ['3'] );

	}

	protected function render() {

        $settings = $this->get_settings_for_display();


			if( $settings['layout_style'] == '1' ){
				echo '<div class="row gy-4 justify-content-center">';
					if($settings['image']['url'] ){
						echo '<div class="col-xl-5">';
							echo '<div class="menu-left-2-img">';
								echo barab_img_tag( array(
									'url'   => esc_url( $settings['image']['url'] ),
								)); 
							echo '</div>'; 
						echo '</div> ';
					}
					echo '<div class="col-xl-7">';
						echo '<div class="menu-2-content-wrap ps-xxl-5">';
							echo '<div class="title-area style3 mb-40 pe-xxl-5 me-xxl-5">';
								if(!empty($settings['title'])){
									echo '<h2 class="sec-title text-anime-style-2">'.wp_kses_post($settings['title']).'</h2>';
								}
								if(!empty($settings['desc'])){
									echo '<p class="box-text pe-xxl-5 me-xl-5 text-anime-style-3">'.wp_kses_post($settings['desc']).'</p>';
								}
							echo '</div>';
							echo '<div class="menu-item-2-wrap wow fadeinup">';
								foreach( $settings['feature_list'] as $key => $data ){
									echo '<div class="menu-item-2 fade-up-card">';
										if($data['button_url']['url'] ){
											echo '<a class="menu-icon" '.barab_link_attrs($data['button_url']).'>';
												echo '<img src="'.BARAB_ASSETS.'img/icon/menu-right-arrows.svg" alt="'.esc_attr__('Arrow', 'barab').'">';
											echo '</a>';
										}
										if(!empty($data['title'])){
											echo '<h3 class="box-title">';
												echo '<a '.barab_link_attrs($data['button_url']).'>'.esc_html($data['title']).'</a>';
											echo '</h3>';
										}
										if($data['image']['url'] ){
											echo '<div class="thumb">';
												echo barab_img_tag( array(
													'url'   => esc_url( $data['image']['url'] ),
												));
											echo '</div>';
										}
									echo '</div>';
								}
							echo '</div>';
							if(!empty($settings['button_text'])){
								echo '<div class="menu-2-btn-wrap">';
									echo '<a '.barab_link_attrs($settings['button_url']).' class="th-btn style6">'.wp_kses_post( $settings['button_text'] ).'</a>';
								echo '</div>';
							}
						echo '</div>';
					echo '</div>';
				echo '</div>';
				 
			}elseif( $settings['layout_style'] == '2' ){
                echo '<div class="row justify-content-center align-items-center">';
                    echo '<div class="col-xxl-6 col-xl-7 col-lg-8">';
                        echo '<div class="title-area style3 text-center mb-40">';
                            if(!empty($settings['title'])){
                                echo '<h2 class="sec-title text-anime-style-2 z-index-1 position-relative">'.wp_kses_post($settings['title']).'</h2>';
                            }
                            if(!empty($settings['desc'])){
                                echo '<p class="box-text pe-xxl-5 ms-xxl-5 text-anime-style-3">'.wp_kses_post($settings['desc']).'</p>';
                            }
                        echo '</div>';
                    echo '</div>';
                echo '</div>';

                echo '<div class="row gy-4 justify-content-center">';
                    echo '<div class="col-xl-12">';
                        echo '<div class="menu-2-content-wrap style2">';
                            echo '<div class="menu-item-2-wrap wow fadeinup">';
								foreach( $settings['feature_list'] as $key => $data ){
									echo '<div class="menu-item-2 fade-up-card">';
										if($data['button_url']['url'] ){
											echo '<a class="menu-icon" '.barab_link_attrs($data['button_url']).'>';
												echo '<img src="'.BARAB_ASSETS.'img/icon/menu-right-arrows.svg" alt="'.esc_attr__('Arrow', 'barab').'">';
											echo '</a>';
										}
										if(!empty($data['title'])){
											echo '<h3 class="box-title">';
												echo '<a '.barab_link_attrs($data['button_url']).'>'.esc_html($data['title']).'</a>';
											echo '</h3>';
										}
										if($data['image']['url'] ){
											echo '<div class="thumb">';
												echo barab_img_tag( array(
													'url'   => esc_url( $data['image']['url'] ),
												));
											echo '</div>';
										}
									echo '</div>';
								}
                            echo '</div>';
                            if(!empty($settings['button_text'])){
                                echo '<div class="menu-2-btn-wrap">';
                                    echo '<a '.barab_link_attrs($settings['button_url']).' class="th-btn style6">'.wp_kses_post( $settings['button_text'] ).'</a>';
                                echo '</div>';
                            }
                        echo '</div>';
                    echo '</div>';
                echo '</div>';

			}elseif( $settings['layout_style'] == '3' ){ 
				$unique_id = 'sigMenuSlider3-' . uniqid();
				echo '<div class="slider-area">';
					echo '<div class="swiper th-slider has-shadow sigMenuSlider3" id="'.esc_attr($unique_id).'" data-slider-options=\'{"autoplay":false,"breakpoints":{"0":{"slidesPerView":1},"576":{"slidesPerView":"1"},"768":{"slidesPerView":"1"},"992":{"slidesPerView":"2"},"1200":{"slidesPerView":"2"}}}\'>';
						echo '<div class="swiper-wrapper">';
							foreach( $settings['feature_list2'] as $key => $data ){
								echo '<div class="swiper-slide">';
									echo '<div class="menu-signature-card">';
										echo barab_img_tag( array(
											'url'   => esc_url( $data['image']['url'] ),
										));
										if($data['shape']['url'] ){
											echo '<div class="sig-menu-shape">';
												echo barab_img_tag( array(
													'url'   => esc_url( $data['shape']['url'] ),
												));
											echo '</div>';
										}
										echo '<div class="menu-signature-card-content">';
											if(!empty($data['title'])){
												echo '<h3 class="box-title">';
													echo '<a '.barab_link_attrs($data['button_url']).'>'.esc_html($data['title']).'</a>';
												echo '</h3>';
											}
											if(!empty($data['desc'])){
												echo '<p class="box-text">'.esc_html($data['desc']).'</p>';
											}
											if(!empty($data['button_text'])){
												echo '<span class="line"></span>';
												echo '<a '.barab_link_attrs($data['button_url']).' class="th-btn style6">'.wp_kses_post( $data['button_text'] ).'</a>';
											}
										echo '</div>';
									echo '</div>';
								echo '</div>';
							}
						echo '</div>';
					echo '</div>';
					echo '<button data-slider-prev="#'.esc_attr($unique_id).' " class="sin-menu-arrow slider-arrow slider-prev"><i class="far fa-arrow-left"></i></button>';
					echo '<button data-slider-next="#'.esc_attr($unique_id).' " class="sin-menu-arrow slider-arrow slider-next"><i class="far fa-arrow-right"></i></button>';
				echo '</div>';

			}


	}

}