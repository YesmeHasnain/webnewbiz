<?php

/**
 * Elementor Widget
 * @package Saasten
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_home_overview_two extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'theme-overview-two';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Home Overview 2', 'saasten-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saasten_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {


        $this->start_controls_section( 'section_content_overvw_inner_two_left', [
            'label' => esc_html__( 'Overview Content Left', 'saasten-extra' ),
        ] ); 

        $this->add_control( 'feature_image_bg', [
            'label'   => __( 'Choose Banner Image Background', 'saasten-core' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        $this->add_control( 'title1', [
            'label'       => __( 'Title', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Invest in Startup', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type section title here.", 'saasten-extra' ),

        ] );

        $this->add_control( 'description1', [
            'label'       => __( 'Description', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Our Sustainable Construction Advisors provide sustainable construction expertise', 'saasten-extra' ),
            'label_block' => true,
        ] );

        $this->add_control( 'overview_feature_image1', [
            'label'   => __( 'Choose Right Image', 'saasten-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        $this->add_control( 'btn_text1', [
            'label'       => __( 'Button Label', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'placeholder' => __( 'Type your button label here', 'saasten-extra' ),
            'default'     => __( 'KNOW MORE', 'saasten-extra' ),
        ] );

        $this->add_control( 'btn_link1', [
            'label'       => __( 'Button Link', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::URL,
            'placeholder' => __( 'https://your-link.com', 'saasten-extra' ),
            'default'     => [
                'url' => '#',
            ],
        ] );



        $this->end_controls_section();


       $this->start_controls_section( 'section_content_overvw_inner_two_right', [
            'label' => esc_html__( 'Overview Content Right', 'saasten-extra' ),
        ] ); 


        $this->add_control( 'title2', [
            'label'       => __( 'Title', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Invest in Startup', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type section title here.", 'saasten-extra' ),

        ] );

        $this->add_control( 'description2', [
            'label'       => __( 'Description', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Our Sustainable Construction Advisors provide sustainable construction expertise', 'saasten-extra' ),
            'label_block' => true,
        ] );

        $this->add_control( 'overview_feature_image2', [
            'label'   => __( 'Choose Right Image', 'saasten-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        $this->add_control( 'btn_text2', [
            'label'       => __( 'Button Label', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'placeholder' => __( 'Type your button label here', 'saasten-extra' ),
            'default'     => __( 'KNOW MORE', 'saasten-extra' ),
        ] );

        $this->add_control( 'btn_link2', [
            'label'       => __( 'Button Link', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::URL,
            'placeholder' => __( 'https://your-link.com', 'saasten-extra' ),
            'default'     => [
                'url' => '#',
            ],
        ] );



        $this->end_controls_section();

        $this->start_controls_section( 'section_content_aboutov_featurelist_left', [
            'label' => esc_html__( 'Overview Feature List Left', 'saasten-extra' ),
        ] ); 

        $this->add_control( 'featureItems', [
            'label'       => esc_html__( 'Features items', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'default'     => [
                [
                    'feature-title'        => esc_html__( 'Website design', 'saasten-extra' ),
                ]
            ],

            'fields'      => [
                [
                    'name'        => 'feature-title',
                    'label'       => esc_html__( 'Title', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'description' => esc_html__( 'Enter Title', 'saasten-extra' )
                ],
                

            ],
            'title_field' => "{{name}}"
        ] );



        $this->end_controls_section();

        $this->start_controls_section( 'section_content_aboutov_featurelist_rightt', [
            'label' => esc_html__( 'Overview Feature List Right', 'saasten-extra' ),
        ] ); 

        $this->add_control( 'featureItems2', [
            'label'       => esc_html__( 'Features items', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'default'     => [
                [
                    'feature-title2'        => esc_html__( 'Website design', 'saasten-extra' ),
                ]
            ],

            'fields'      => [
                [
                    'name'        => 'feature-title2',
                    'label'       => esc_html__( 'Title', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'description' => esc_html__( 'Enter Title', 'saasten-extra' )
                ],
                

            ],
            'title_field' => "{{name}}"
        ] );



        $this->end_controls_section();


        // ===================== Title ======================//

        $this->start_controls_section( 'title_style', [
            'label' => __( 'Title', 'saasten-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_typography',
            'label'    => __( 'Typography', 'saasten-extra' ),
            'selector' => '
                {{WRAPPER}} .theme-banner-startup-wrapper h1.banner-heading,
                {{WRAPPER}} .__title
            ',
        ] );


        $this->add_control( 'title_color', [
            'label'     => __( 'Color', 'saasten-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-startup-wrapper h1.banner-heading' => 'color: {{VALUE}}',
                '{{WRAPPER}} .__title' => 'color: {{VALUE}}',
            ],
        ] );

        $this->end_controls_section(); //End Title Style


        // ===================== Subtitle Style ========================//
        $this->start_controls_section( 'sub_title_style', [
            'label' => __( 'Sub Title', 'saasten-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_sub_typography',
            'label'    => __( 'Typography', 'saasten-extra' ),
            'selector' => '{{WRAPPER}} .theme-banner-startup-wrapper h4.banner-sub-heading',
        ] );

        $this->add_control( 'sub_title_color', [
            'label'     => __( 'Sub Title Color', 'saasten-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-startup-wrapper h4.banner-sub-heading' => 'color: {{VALUE}}',
            ],

        ] );

        $this->end_controls_section(); //End Subtitle Style

		
	}
	


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

        $featureItems = $settings['featureItems'];
        $featureItems2 = $settings['featureItems2'];

        extract($settings); 


		
		?>



    <!-- Features Area -->
    <section
      class="images-featuers-area saastain-bg__cover pd-btm-130"
      style="background-image: url(<?php echo esc_url( $settings['feature_image_bg']['url'] ); ?>);"
    >
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-md-6 col-12 mg-top-30" data-aos="fade-up">
            <!-- Image Features Box -->
            <div class="images-featuers-box">
              <div class="images-featuers-box__img mg-btm-40">
                <img src="<?php echo esc_url( $settings['overview_feature_image1']['url'] ); ?>" alt="#" />
              </div>
              <div class="section-title-area text-left">
                <h2 class="section-title m-0"><?php echo $settings['title1']; ?></h2>
                <p class="section-text m-0 mg-top-25">
                  <?php echo wp_kses_post( $settings['description1'] ); ?>
                </p>
              </div>
              <ul class="list-features m-0 mg-top-25">


                <?php
                    foreach ( $featureItems as $item ):
                ?>

                <li>
                  <span class="flex-shrink-0">
                    <img src="<?php echo SAASTEN_IMG ."/price-check-icon.svg"; ?>" />
                  </span>
                  <span class="text-color"
                    ><?php echo esc_html( $item['feature-title'] ); ?></span
                  >
                </li>

                <?php endforeach; ?> 


              </ul>
              <a
                href="<?php echo esc_url( $settings['btn_link1']['url'] ) ?>"
                class="saastain-btn mg-top-50 saastain-btn__v4 border-radius-31 py-20 pr-lg"
                ><?php echo $settings['btn_text1'] ?></a
              >
            </div>
            <!-- End Image Features Box -->
          </div>
          <div class="col-md-6 col-md-6 col-12 mg-top-30" data-aos="fade-left">
            <!-- Image Features Box -->
            <div class="images-featuers-box">
              <div class="section-title-area text-left">
                <h2 class="section-title m-0"><?php echo $settings['title2']; ?></h2>
                <p class="section-text m-0 mg-top-25">
                 <?php echo wp_kses_post( $settings['description2'] ); ?>
                </p>
              </div>
              <ul class="list-features m-0 mg-top-25">

                <?php
                    foreach ( $featureItems2 as $item ):
                ?>

                <li>
                  <span class="flex-shrink-0">
                    <img src="<?php echo SAASTEN_IMG ."/price-check-icon.svg"; ?>" />
                  </span>
                  <span class="text-color"
                    ><?php echo esc_html( $item['feature-title2'] ); ?></span
                  >
                </li>

                <?php endforeach; ?> 


              </ul>
              <a
                href="<?php echo esc_url( $settings['btn_link2']['url'] ) ?>"
                class="saastain-btn mg-top-50 saastain-btn__v4 border-radius-31 py-20 pr-lg"
                ><?php echo $settings['btn_text2'] ?></a
              >
              <div class="images-featuers-box__img mg-top-40">
                <img src="<?php echo esc_url( $settings['overview_feature_image2']['url'] ); ?>" alt="#" />
              </div>
            </div>
            <!-- End Image Features Box -->
          </div>
        </div>
      </div>
    </section>
    <!-- End Features Area -->



	<?php 


	}
				

}

