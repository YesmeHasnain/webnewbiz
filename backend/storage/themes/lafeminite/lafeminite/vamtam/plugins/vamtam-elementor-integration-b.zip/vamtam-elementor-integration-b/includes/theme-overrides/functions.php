<?php

// vamtam_theme_supports
if ( ! function_exists( 'vamtam_theme_supports' ) ) {
    function vamtam_theme_supports( $feature, $relation = 'OR' ) {
        $supported = false;

        if ( is_array( $feature ) ) {
            // Multiple features.
            $not_supported_found = false;
            foreach ( $feature as $ftr ) {
                if ( current_theme_supports( $ftr ) || current_theme_supports( 'vamtam-elementor-widgets', $ftr ) ) {
                    if ( $relation === 'OR' ) {
                        $supported = true;
                        break;
                    }
                } else {
                    if ( $relation === 'AND' ) {
                        $not_supported_found = true;
                        break;
                    }
                }
            }

            if ( $relation === 'AND' && $not_supported_found === false ) {
                $supported = true;
            }
        } else {
            // Single feature.
            if ( current_theme_supports( $feature ) || current_theme_supports( 'vamtam-elementor-widgets', $feature ) ) {
                $supported = true;
            }
        }

        return $supported;
    }
}

if ( ! defined( 'VAMTAM_VC_OK' ) && ! class_exists( 'Vamtam_Theme_Update_Recovery' ) ) {

    class Vamtam_Theme_Update_Override {

        private $update_api_url = 'https://updates.vamtam.com/0/envato/check-theme';

        public function __construct() {
			delete_site_transient( 'update_themes' );
			add_filter( 'pre_set_site_transient_update_themes', array( $this, 'override_theme_update' ), 20 );
        }

        public function prevent_wp_org_conflicts( $updates ) {
            // prevent conflicts with themes hosted on wp.org
            $theme_name = wp_get_theme()->get_template();

            if (
                isset( $updates->response ) &&
                isset( $updates->response[ $theme_name ] ) &&
                isset( $updates->response[ $theme_name ]['package'] ) &&
                strpos( $updates->response[ $theme_name ]['package'], 'downloads.wordpress.org' ) !== false
            ) {
                unset( $updates->response[ $theme_name ] );
            }

            return $updates;
        }

        public function override_theme_update( $updates ) {
            $theme_name = wp_get_theme()->get_template();

            $updates = $this->prevent_wp_org_conflicts( $updates );

            $response = $this->update_api_request( $updates );

            if ( false === $response ) {
                // No update is available.
                $item = array(
                    'theme'        => $theme_name,
                    'new_version'  => \VamtamFramework::get_version(),
                    'url'          => '',
                    'package'      => '',
                    'requires'     => '',
                    'requires_php' => '',
                );

                // Adding the "mock" item to the `no_update` property is required
                // for the enable/disable auto-updates links to correctly appear in UI.
                $updates->no_update[ $theme_name ] = $item;

                return $updates;
            }

            if ( ! isset( $updates->response ) ) {
                $updates->response = array();
            }

            // Prefix normalization so update notices display properly.
            $prefixed_theme_name = 'vamtam-' . $theme_name;
            if ( isset( $response[ $prefixed_theme_name ] ) && $theme_name !== $prefixed_theme_name ) {
                $response[ $theme_name ]            = $response[ $prefixed_theme_name ];
                $response[ $theme_name ][ 'theme' ] = $theme_name;
                unset( $response[ $prefixed_theme_name ] );
            }

            $updates->response = array_merge( $updates->response, $response );

            // Small trick to ensure the updates get shown in the network admin
            if ( is_multisite() && ! is_main_site() ) {
                global $current_site;

                switch_to_blog( $current_site->blog_id );
                set_site_transient( 'update_themes', $updates );
                restore_current_blog();
            }

            return $updates;
        }

        private function update_api_request( $update_cache ) {
            global $wp_version;

            $theme_name = wp_get_theme()->get_template();

            $raw_response = wp_remote_post( $this->update_api_url, array(
                'body' => array(
                    'theme_name'   => VAMTAM_THEME_NAME,
                    'version'      => isset( $update_cache->checked[ $theme_name ] ) ? $update_cache->checked[ $theme_name ] : \VamtamFramework::get_version(),
                    'purchase_key' => \Version_Checker::is_valid_purchase_code() ? apply_filters( 'vamtam_purchase_code', '' ) : '',
                ),
                'user-agent' => 'WordPress/' . $wp_version . '; ' . get_option( 'home' ),
            ) );

            if ( is_wp_error( $raw_response ) || 200 !== wp_remote_retrieve_response_code( $raw_response ) ) {
                return false;
            }

            $response = json_decode( wp_remote_retrieve_body( $raw_response ), true );

            return $response['themes'];
        }

    }

    new Vamtam_Theme_Update_Override();
}
