<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Video Widget .
 *
 */
class barab_Video extends Widget_Base {

	public function get_name() {
		return 'barabvideo';
	}
	public function get_title() {
		return __( 'Video Box', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'video_section',
			[
				'label' 	=> __( 'video Box', 'barab' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two' ] );

		barab_media_fields( $this, 'bg', 'Choose Background', [ '2' ] );
		barab_media_fields( $this, 'image1', 'Choose Image', [ '1' ] );
		barab_general_fields( $this, 'icon', 'Icon', 'TEXTAREA2', '<i class="fa-sharp fa-solid fa-play"></i>' );
		barab_url_fields( $this, 'video_url', 'Video URL' );

		barab_general_fields( $this, 'subtitle', 'Subtitle', 'TEXTAREA2', 'Opening Hours', ['1'] );
		barab_general_fields( $this, 'title', 'Title', 'TEXTAREA2', 'Our Opening Hours', ['1', '2'] );
		barab_media_fields( $this, 'title_shape', 'Choose Title Shape', ['1'] );
		barab_general_fields($this, 'button_text', 'Button Text', 'TEXT', 'Book Your Table', ['1']);
		barab_url_fields($this, 'button_url', 'Button URL', ['1']);

		barab_general_fields( $this, 'circle_text', 'Circle Text', 'TEXTAREA2', 'Book private dining & banquet rooms * ', ['2'] );

		barab_general_fields( $this, 'label', 'Label', 'TEXTAREA2', 'Monday to Tuesday', ['1'] );
		barab_general_fields( $this, 'content', 'Content', 'TEXTAREA', '', ['1'] );

		barab_general_fields( $this, 'label2', 'Label', 'TEXTAREA2', 'Friday to Sunday', ['1'] );
		barab_general_fields( $this, 'content2', 'Content', 'TEXTAREA', '', ['1'] );

		$this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------
		barab_common_style_fields( $this, '01', 'Subtitle', '{{WRAPPER}} .sub-title', ['1'] );
		barab_common_style_fields( $this, '02', 'Title', '{{WRAPPER}} .sec-title', ['1'] );
		barab_common_style_fields( $this, '03', 'Label', '{{WRAPPER}} .box-text', ['1'] );
		barab_common_style_fields( $this, '04', 'Content', '{{WRAPPER}} .open-time .box-title, {{WRAPPER}} .open-time', ['1'] );
		//------Button Style-------
		barab_button_style_fields($this, '10', 'Button Styling', '{{WRAPPER}} .th-btn', ['1'], null, '--white-color', null, '--theme-color3');
	
	}

	protected function render() {

        $settings = $this->get_settings_for_display();

		if( $settings['layout_style'] == '1' ){
			echo '<div class="opening-container-wrap" data-mask-src="'.BARAB_ASSETS.'img/bg/opening-bg-mask.png">';
                echo '<div class="row gy-40 align-items-center">';
                    echo '<div class="col-xl-7">';
                        echo '<div class="opening-1-thumb" data-mask-src="'.BARAB_ASSETS.'img/bg/opening-1-mask.png">';
                            echo barab_img_tag( array(
								'url'   => esc_url( $settings['image1']['url'] ), 
							)); 
                            echo '<div class="opening-1-video">';
                                echo '<a '.barab_link_attrs($settings['video_url']).' class="play-btn popup-video" savefrom_lm_index="0">'.wp_kses_post($settings['icon']).'</a>';
                            echo '</div>';
                        echo '</div>';
                    echo '</div>';
                    echo '<div class="col-xl-5">';
                        echo '<div class="opening-right">';
                            echo '<div class="title-area text-center mb-60">';
								if(!empty($settings['subtitle'])){
									echo '<span class="sub-title text-anime-style-1">'.esc_html($settings['subtitle']).'</span>';
								}
								if(!empty($settings['title'])){
									echo '<h2 class="sec-title text-anime-style-2">'.wp_kses_post($settings['title']).'</h2>';
								}
								echo barab_img_tag( array(
									'url'   => esc_url( $settings['title_shape']['url'] ),
									'class' => 'img-anime-style-1'
								)); 
                            echo '</div>';
                            echo '<div class="time-table-wrap me-xl-5 wow fadeinup" data-wow-delay=".4s">';
                                echo '<div class="item">';
									if(!empty($settings['label'])){
										echo '<p class="box-text">'.esc_html($settings['label']).'</p>';
									}
									if(!empty($settings['content'])){
										echo '<div class="open-time">'.wp_kses_post($settings['content']).'</div>';
									}
                                echo '</div>';
                                echo '<div class="item">';
                                    if(!empty($settings['label2'])){
										echo '<p class="box-text">'.esc_html($settings['label2']).'</p>';
									}
									if(!empty($settings['content2'])){
										echo '<div class="open-time">'.wp_kses_post($settings['content2']).'</div>';
									}
                                echo '</div>';
                            echo '</div>';
							if(!empty($settings['button_text'])){
                            	echo '<div class="bottom text-center mt-40 wow fadeinup" data-wow-delay=".2s">';
									echo '<a '.barab_link_attrs($settings['button_url']).' class="th-btn btn-mask style5">'.wp_kses_post( $settings['button_text'] ).'</a>';
								echo '</div>';
							}
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
            echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
			echo '<div class="video-area-1 overflow-hidden position-relative z-index-common">';
				echo '<div class="container-fluid p-0">';
					echo '<div class="video-box1 style2">';
						if(!empty($settings['title'])){
							echo '<h2 class="video-text">'.wp_kses_post($settings['title']).'</h2>';
						}
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['bg']['url'] ), 
						));
						echo '<a '.barab_link_attrs($settings['video_url']).' class="play-btn popup-video" savefrom_lm_index="0">'.wp_kses_post($settings['icon']).'</a>';
						echo '<div class="logo-icon-wrap video-1">';
							echo '<div class="logo-icon">';
								echo '<a href="https://www.youtube.com/watch?v=_sI_Ps7JSEk" class="play-btn popup-video"><i class="fa-sharp fa-solid fa-play"></i></a>';
							echo '</div>';
							if(!empty($settings['circle_text'])){
								echo '<div class="logo-icon-wrap__text">';
									echo '<span class="logo-animation">'.esc_html($settings['circle_text']).'</span>';
								echo '</div>';
							}
						echo '</div>';
					echo '</div>';
				echo '</div>';
			echo '</div>';

		}


	}

}