<?php 
/*
* @packge Knor Extra
* @since 1.0.0
 */
function knor_import() { 
  return array(
  
    array(
      'import_file_name'             => __('Main Demo - SaaS','knor-extra'),
      'page_title'                   => __('Import Demo Data','knor-extra'),
      'local_import_file'            => KNOR_EXTRA_ROOT_PATH.'/demo/demo-sass.xml',
      'local_import_widget_file'     => KNOR_EXTRA_ROOT_PATH.'/demo/widget.wie',
      'local_import_customizer_file' =>  KNOR_EXTRA_ROOT_PATH.'/demo/knor-customizer.dat',
	  'import_preview_image_url'     => 'https://flawlessdigitalagency.com/demo-img/knor.png',
      'import_notice'                => __( 'This import maybe finish on 2-3 minutes', 'knor-extra' ),
	  'preview_url'                  => 'https://gossip-themes.com/knormain',

  ),    
  
  
	array(
      'import_file_name'             => __('Demo - Digital Agecny','knor-extra'),
      'page_title'                   => __('Import Demo Data','knor-extra'),
      'local_import_file'            => KNOR_EXTRA_ROOT_PATH.'/demo/demo-agency.xml',
      'local_import_widget_file'     => KNOR_EXTRA_ROOT_PATH.'/demo/widget-agency.wie',
      'local_import_customizer_file' =>  KNOR_EXTRA_ROOT_PATH.'/demo/knor-customizer-agency.dat',
	  'import_preview_image_url'     => 'https://flawlessdigitalagency.com/demo-img/knor-agency.png',
      'import_notice'                => __( 'This import maybe finish on 2-5 minutes', 'knor-extra' ),
	  'preview_url'                  => 'https://gossip-themes.com/agency',

	), 
	
	array(
      'import_file_name'             => __('Demo - IT Solutions','knor-extra'),
      'page_title'                   => __('Import Demo Data','knor-extra'),
      'local_import_file'            => KNOR_EXTRA_ROOT_PATH.'/demo/demo-it.xml',
      'local_import_widget_file'     => KNOR_EXTRA_ROOT_PATH.'/demo/widget-it.wie',
      'local_import_customizer_file' =>  KNOR_EXTRA_ROOT_PATH.'/demo/knor-customizer-it.dat',
	  'import_preview_image_url'     => 'https://flawlessdigitalagency.com/demo-img/knor-it.png',
      'import_notice'                => __( 'This import maybe finish on 2-5 minutes', 'knor-extra' ),
	  'preview_url'                  => 'https://gossip-themes.com/agency',

	), 
	
  
  
 

);
}
add_filter( 'pt-ocdi/import_files', 'knor_import' );


add_action( 'pt-ocdi/after_import',  'knor_after_import' );

if(!function_exists( 'knor_after_import')):
function knor_after_import($selected_import) {
	
if ( 'Demo' === $selected_import['import_file_name'] ) {

	$main_menu = get_term_by('name', 'Main Nav', 'nav_menu');

    set_theme_mod( 'nav_menu_locations', array(
        'primary' => $main_menu->term_id,
     ) );

	//Set Front page

	$front_page_id = get_page_by_title( 'Home' );
	$blog_page_id  = get_page_by_title( 'Blog' );

	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $front_page_id->ID );
	update_option( 'page_for_posts', $blog_page_id->ID );
	
}}
endif;
