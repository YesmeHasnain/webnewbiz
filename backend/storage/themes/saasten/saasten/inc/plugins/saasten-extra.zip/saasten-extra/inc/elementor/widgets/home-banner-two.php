<?php

/**
 * Elementor Widget
 * @package Saasten
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_banner_two extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'theme-banner-style-two';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Banner Two', 'saasten-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saasten_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {


        $this->start_controls_section( 'section_content_banner_two', [
            'label' => esc_html__( 'Banner Top Content', 'saasten-core' ),
        ] );

        $this->add_control( 'title', [
            'label'       => __( 'Title', 'saasten-core' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'The Only all', 'saasten-core' ),
            'label_block' => true,
            'description' => __( "Type banner title here.", 'saasten-core' ),

        ] );

        $this->add_control( 'colored-title', [
            'label'       => __( 'Colored Title', 'saasten-core' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'The Only all', 'saasten-core' ),
            'label_block' => true,
            'description' => __( "Type banner colored title here.", 'saasten-core' ),

        ] );


        $this->add_control( 'sub-title', [
            'label'       => __( 'Sub Title', 'saasten-core' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Digital Agency', 'saasten-core' ),
            'label_block' => true,
            'description' => __( "Type banner sub title here.", 'saasten-core' ),

        ] );

        $this->add_control( 'review-title', [
            'label'       => __( 'Review Title', 'saasten-core' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Trusted Client', 'saasten-core' ),
            'label_block' => true,
            'description' => __( "Type banner review title here.", 'saasten-core' ),

        ] );

        $this->add_control( 'review-text', [
            'label'       => __( 'Review Text', 'saasten-core' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( '(4900+) Review', 'saasten-core' ),
            'label_block' => true,
            'description' => __( "Type banner review text here.", 'saasten-core' ),

        ] );

        $this->add_control( 'customer-number', [
            'label'       => __( 'Customer Number', 'saasten-core' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( '2,291', 'saasten-core' ),
            'label_block' => true,
            'description' => __( "Type number here.", 'saasten-core' ),

        ] );

        $this->add_control( 'customer-text', [
            'label'       => __( 'Customer Title', 'saasten-core' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Trusted Client', 'saasten-core' ),
            'label_block' => true,
            'description' => __( "Type title here.", 'saasten-core' ),

        ] );


        $this->add_control( 'btn_text_left', [
            'label'       => __( 'Button Left Text', 'saasten-core' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'placeholder' => __( 'Type your button left text here', 'saasten-core' ),
            'default'     => __( 'Already using saastain?', 'techogy-core' ),
        ] );


        $this->add_control( 'btn_text', [
            'label'       => __( 'Button Label', 'saasten-core' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'placeholder' => __( 'Type your button label here', 'saasten-core' ),
            'default'     => __( 'Sign In', 'techogy-core' ),
        ] );

        $this->add_control( 'btn_link', [
            'label'       => __( 'Button Link', 'saasten-core' ),
            'type'        => \Elementor\Controls_Manager::URL,
            'placeholder' => __( 'https://your-link.com', 'saasten-core' ),
            'default'     => [
                'url' => '#',
            ],
        ] );


        $this->add_control( 'feature_image_bg', [
            'label'   => __( 'Choose Banner Image Background', 'saasten-core' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        $this->add_control( 'feature_image1', [
            'label'   => __( 'Choose Banner Image 1', 'saasten-core' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );


         $this->add_control( 'feature_image2', [
            'label'   => __( 'Choose Banner Image 2', 'saasten-core' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

          $this->add_control( 'feature_image3', [
            'label'   => __( 'Choose Banner Image 3', 'saasten-core' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );


        $this->add_control( 'feature_imagegroup', [
            'label'   => __( 'Choose Banner Image group', 'saasten-core' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        $this->end_controls_section(); 


		
	}
	


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

    extract($settings); 


		
		?>



    <!-- Hero Banner -->
    <section
      class="hero-area-v4 fluid-space saastain-bg__cover"
      style="background-image: url(<?php echo esc_url( $settings['feature_image_bg']['url'] ); ?>);"
    >
      <div class="container-fluid p-0">
        <div class="row">
          <div class="col-12">
            <div class="hero-area-v4__inner">
              <div class="hero-area-v4__inside">
                <!-- Banner Left  -->
                <div data-aos="fade-in" class="hero-area-v4__content">
                  <p class="hero-area-v4__label saastain-gsap-anim2">
                    <?php echo wp_kses_post( $settings['sub-title'] ); ?>
                  </p>
                  <h2 class="hero-area-v4__title m-0 saastain-gsap-anim1">
                   <?php echo wp_kses_post( $settings['title'] ); ?>
                    <span class="hero-area-v4__title--"><?php echo wp_kses_post( $settings['colored-title'] ); ?></span>
                  </h2>
                </div>
                <!-- End Banner Left -->
                <div class="hero-area-v4-bottom">
                  <p class="hero-area-v4-bottom__label saastain-gsap-anim3">
                    <?php echo $settings['btn_text_left'] ?> <a href="#"><?php echo $settings['btn_text'] ?></a>
                  </p>
                  <div class="hero-area-v4-bottom__group">
                    <img src="<?php echo esc_url( $settings['feature_imagegroup']['url'] ); ?>" />
                    <div class="hero-area-v4-bottom__info">
                      <div class="hero-area-v4-bottom__customer">
                        <h4 class="hero-area-v4-bottom__title"><?php echo wp_kses_post( $settings['customer-number'] ); ?></h4>
                        <p class="hero-area-v4-bottom__label">
                          <?php echo wp_kses_post( $settings['customer-text'] ); ?>
                        </p>
                      </div>
                      <div class="hero-area-v4-border"></div>
                      <div class="hero-area-v4-bottom__customer">
                        <h4 class="hero-area-v4-bottom__title"><?php echo wp_kses_post( $settings['review-title'] ); ?></h4>
                        <div class="hero-area-v4-bottom__rating">
                          <div
                            class="ratting-icons saastain-flex-start saastain-flex-gap-10"
                          >
                            <span><i class="fas fa-star"></i></span>
                            <span><i class="fas fa-star"></i></span>
                            <span><i class="fas fa-star"></i></span>
                            <span><i class="fas fa-star"></i></span>
                            <span><i class="far fa-star"></i></span>
                          </div>
                          <p><?php echo wp_kses_post( $settings['review-text'] ); ?></p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="hero-area-v4__img">
                <img
                  data-aos="zoom-out-down"
                  src="<?php echo esc_url( $settings['feature_image1']['url'] ); ?>"
                  alt="#"
                />
                <div
                  class="hero-area-v4__img-single hero-area-v4__img-single1 saastain-anim-shape8"
                >
                  <img src="<?php echo esc_url( $settings['feature_image2']['url'] ); ?>" alt="#" />
                </div>
                <div
                  class="hero-area-v4__img-single hero-area-v4__img-single2 saastain-anim-shape6"
                >
                  <img src="<?php echo esc_url( $settings['feature_image3']['url'] ); ?>" alt="#" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- End Hero Banner -->





	<?php 


	}
				

}

