<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Category Widget .
 *
 */
class Barab_Category extends Widget_Base {

	public function get_name() {
		return 'barabcategory';
	}
	public function get_title() {
		return __( 'Category', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'arrow_section',
			[
				'label'     => __( 'Category', 'barab' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two' ] ); 

		barab_media_fields($this, 'bg_shape', 'Choose BG Shape', ['1']);

		$repeater = new Repeater();

		barab_media_fields($repeater, 'choose_icon', 'Choose Icon');
		barab_general_fields($repeater, 'title', 'Title', 'TEXTAREA2', 'Dominos Pizza');
		barab_general_fields($repeater, 'description', 'Description', 'TEXTAREA2', '25 Items Available'); 
		barab_url_fields($repeater, 'button_url', 'Button URL');

		$this->add_control(
			'category_list',
			[
				'label' 		=> __( 'Category Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'Dominos Pizza', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['1']
				]
			]
		);

        $repeater = new Repeater();

		barab_media_fields($repeater, 'choose_icon', 'Choose Icon');
		barab_general_fields($repeater, 'title', 'Title', 'TEXTAREA2', 'Dominos Pizza');
		barab_url_fields($repeater, 'button_url', 'Button URL');

		$this->add_control(
			'category_list2',
			[
				'label' 		=> __( 'Category Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'Dominos Pizza', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['2']
				]
			]
		);

        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------

		barab_common2_style_fields( $this, '02', 'Title', '{{WRAPPER}} .box-title a', ['1', '2'] );
		barab_common_style_fields( $this, '03', 'Description', '{{WRAPPER}} .box-subtitle', ['1'] );


	}

	protected function render() {

    $settings = $this->get_settings_for_display(); 

		if( $settings['layout_style'] == '1' ){ 
            echo '<div class="slider-area">';
                echo '<div class="swiper th-slider" id="catSlider1" data-slider-options=\'{"autoplay":true,"loop":true,"breakpoints":{"0":{"slidesPerView":1},"400":{"slidesPerView":"2"},"768":{"slidesPerView":"3"},"992":{"slidesPerView":"4"},"1200":{"slidesPerView":"5"},"1400":{"slidesPerView":"6"}}}\'>';
                    echo '<div class="swiper-wrapper">';
                        foreach( $settings['category_list'] as $key => $data ){
                            echo '<div class="swiper-slide">';
                                echo '<div class="category-card">';
                                    echo barab_img_tag( array(
                                        'url'   => esc_url( $settings['bg_shape']['url'] ),
                                        'class' => 'cat-i-bottom'
                                    ));
                                    if(!empty($data['choose_icon']['url'])){
                                        echo '<div class="box-icon">';
                                            echo barab_img_tag( array(
                                                'url'   => esc_url( $data['choose_icon']['url'] ),
                                            ));
                                        echo '</div>';
                                    }
                                    if(!empty($data['title'])){
                                        echo '<h3 class="box-title"><a'.barab_link_attrs($data['button_url']).'>'.esc_html($data['title']).'</a></h3>';
                                    }
                                    if(!empty($data['description'])){
                                        echo '<p class="box-subtitle">'.esc_html($data['description']).'</p>';
                                    }
                                echo '</div>';
                            echo '</div>';
                        }
                    echo '</div>';
				echo '</div>';
				echo '<button data-slider-prev="#catSlider1" class="slider-arrow slider-prev">';
					echo '<img src="'.BARAB_ASSETS.'img/icon/left-arrow.svg" alt="'.esc_attr__('Arrow', 'barab').'">';
				echo '</button>';
				echo '<button data-slider-next="#catSlider1" class="slider-arrow slider-next">';
					echo '<img src="'.BARAB_ASSETS.'img/icon/right-arrow.svg" alt="'.esc_attr__('Arrow', 'barab').'">';
				echo '</button>';
            echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
            echo '<div class="row justify-content-center">';
                echo '<div class="col-xxl-10">';
                    echo '<div class="cate-2-wrap">';
                        foreach( $settings['category_list2'] as $key => $data ){
                            echo '<div class="item">';
                                if(!empty($data['title'])){
                                    echo '<h3 class="box-title"><a href="'.esc_url( $data['button_url']['url'] ).'">'.esc_html($data['title']).'</a></h3>';
                                }
                                if(!empty($data['choose_icon']['url'])){
                                    echo barab_img_tag( array(
                                        'url'   => esc_url( $data['choose_icon']['url'] ),
                                    ));
                                }
                            echo '</div>';
                        }
                    echo '</div>';
                echo '</div>';
            echo '</div>';

		}
		
			
	}
}