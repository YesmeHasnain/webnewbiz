<?php
// Registers the new post type 

function mancink_event_post_type() {
	register_post_type( 'event',
		array(
			'labels' => array(
				'name' => esc_html__( 'Event', 'mancink_plugin' ),
				'singular_name' => esc_html__( 'Event' , 'mancink_plugin'),
				'add_new' => esc_html__( 'Add New Event', 'mancink_plugin' ),
				'add_new_item' => esc_html__( 'Add New Event', 'mancink_plugin' ),
				'edit_item' => esc_html__( 'Edit Event', 'mancink_plugin' ),
				'new_item' => esc_html__( 'Add New Event', 'mancink_plugin' ),
				'view_item' => esc_html__( 'View Event', 'mancink_plugin' ),
				'search_items' => esc_html__( 'Search Event', 'mancink_plugin' ),
				'not_found' => esc_html__( 'No Event found', 'mancink_plugin' ),
				'not_found_in_trash' => esc_html__( 'No Event found in trash', 'mancink_plugin' )
			),
			'public' => true,
			'supports' => array( 'title','editor', 'thumbnail', 'comments' , 'excerpt'),
			'capability_type' => 'post',
			'rewrite' => array("slug" => "event"), // Permalinks format
			'menu_position' => 5,
			'menu_icon'           => 'dashicons-index-card',
			'exclude_from_search' => true 
		)
	);

}

add_action( 'init', 'mancink_event_post_type' );

//add taxonomies(event category)
function mancink_taxonomies_event() {
	$labels = array(
		'name'              => esc_html__( 'Event Categories', 'mancink_plugin' ),
		'singular_name'     => esc_html__( 'Event Category',  'mancink_plugin' ),
		'search_items'      => esc_html__( 'Search Event Categories', 'mancink_plugin' ),
		'all_items'         => esc_html__( 'All Event Categories' , 'mancink_plugin' ),
		'parent_item'       => esc_html__( 'Parent Event Category' , 'mancink_plugin' ),
		'parent_item_colon' => esc_html__( 'Parent Event Category:' , 'mancink_plugin' ),
		'edit_item'         => esc_html__( 'Edit Event Category' , 'mancink_plugin' ), 
		'update_item'       => esc_html__( 'Update Event Category' , 'mancink_plugin' ),
		'add_new_item'      => esc_html__( 'Add New Event Category' , 'mancink_plugin' ),
		'new_item_name'     => esc_html__( 'New Event Category' , 'mancink_plugin' ),
		'menu_name'         => esc_html__( 'Event Categories' , 'mancink_plugin' ),
	);
	$args = array(
		'labels' => $labels,
		'hierarchical' => true,
	);
	register_taxonomy( 'event_category', 'event', $args );
}
add_action( 'init', 'mancink_taxonomies_event', 0 );
