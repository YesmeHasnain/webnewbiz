<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Events Widget .
 *
 */
class Barab_Events extends Widget_Base {

	public function get_name() {
		return 'barabevents';
	}
	public function get_title() {
		return __( 'Events', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'arrow_section',
			[
				'label'     => __( 'Events', 'barab' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One'] );

		$repeater = new Repeater();

		barab_media_fields($repeater, 'image', 'Choose Image' );
		barab_general_fields($repeater, 'title', 'Title', 'TEXTAREA2', 'Baked Camembert Night');
		barab_general_fields($repeater, 'content', 'Content', 'TEXTAREA2', 'Friday, 21 Nov');
		barab_general_fields($repeater, 'content2', 'Content 2', 'TEXTAREA2', 'Reservations 10Am To 12.00Pm');
        barab_general_fields($repeater, 'button_text', 'Button Text', 'TEXT', 'Reservation Now');
		barab_url_fields($repeater, 'button_url', 'Button URL');

		$this->add_control(
			'event_list',
			[
				'label' 		=> __( 'Events Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'Baked Camembert Night', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['1']
				]
			]
		);

        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------
		barab_common_style_fields( $this, '011', 'Title', '{{WRAPPER}} .box-title2', ['1'] );
		barab_common_style_fields( $this, '012', 'Content', '{{WRAPPER}} .event-card_date', [ '1'] );
		barab_common_style_fields( $this, '013', 'Content 2', '{{WRAPPER}} .event-card_time', [ '1'] );
		//------Button Style-------
		barab_button_style_fields( $this, '10', 'Button Styling', '{{WRAPPER}} .th-btn', ['1'] );

	}

	protected function render() {

    $settings = $this->get_settings_for_display(); 

		if( $settings['layout_style'] == '1' ){
            echo '<div class="row gy-40">';
                foreach( $settings['event_list'] as $key => $data ){
                    $delay  = number_format(0.2 + ($key * 0.2), 1); 
                    echo '<div class="col-sm-6 col-xl-3 event-card-item wow fadeinleft" data-wow-delay="'.$delay.'s">';
                        echo '<div class="event-card">';
                            if($data['image']['url'] ){
								 echo '<div class="event-card_img global-img">';
									echo barab_img_tag( array(
										'url'   => esc_url( $data['image']['url'] ),
									)); 
								echo '</div>';
							}
                            if(!empty($data['title'])){
                                echo '<h3 class="box-title2">'.esc_html($data['title']).'</h3>';
                            }
                            if(!empty($data['content'])){
                                echo '<span class="event-card_date">'.esc_html($data['content']).'</span>';
                            }
                            if(!empty($data['content2'])){
                                echo '<span class="event-card_time">'.esc_html($data['content2']).'</span>';
                            };
                            if(!empty($data['button_text'])){
                                echo '<span class="line"></span>';
                                echo '<a '.barab_link_attrs($data['button_url']).' class="th-btn style6">'.wp_kses_post( $data['button_text'] ).'</a>';
                            }
                        echo '</div>';
                    echo '</div>';
                }
            echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
	

		}
		
			
	}
}