<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Product Widget .
 *
 */
class Barab_Product extends Widget_Base {

	public function get_name() {
		return 'barabproduct';
	}
	public function get_title() {
		return __( 'Product', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'arrow_section',
			[
				'label'     => __( 'Product', 'barab' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two', 'Style Three' ] ); 

        barab_media_fields( $this, 'image1', 'Choose Image', ['2'] );
		barab_media_fields( $this, 'image2', 'Choose Image', ['2'] );

        $this->add_control(
			'product_count',
			[
				'label' 		=> __( 'Product Count', 'barab' ),
				'type' 			=> Controls_Manager::NUMBER,
				'min' 			=> 1,
				'max' 			=> 50,
				'step' 			=> 1,
				'default' 		=> 4,
			]
		);
        $this->add_control(
            'order',
            [
                'label'   => __( 'Order', 'barab' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'DESC', // Default value
                'options' => [
                    'ASC'  => __( 'Ascending', 'barab' ),
                    'DESC' => __( 'Descending', 'barab' ),
                ],
            ]
        );
        $this->add_control(
            'orderby',
            [
                'label'   => __( 'Order By', 'barab' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'date', // Default value
                'options' => [
                    'title'        => __( 'Title', 'barab' ),
                    'date'         => __( 'Date', 'barab' ),
                    'ID'           => __( 'ID', 'barab' ),
                    'modified'     => __( 'Modified', 'barab' ),
                    'rand'         => __( 'Random', 'barab' ),
                ],
            ]
        );
        // Add a control to select either "Category" or "Tag"
        $this->add_control(
            'product_type',
            [
                'label'       => __( 'Product Show By', 'barab' ),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'default'     => 'all', // Default to show all products if none selected
                'options'     => [
                    'all'       => __( 'Show All Products', 'barab' ),
                    'category'  => __( 'Category', 'barab' ),
                    'tag'       => __( 'Tag', 'barab' ),
                ],
            ]
        );
        $this->add_control(
            'product_cats',
            [
                'label'       => __( 'Product Categories', 'barab' ),
                'type'        => \Elementor\Controls_Manager::SELECT2,
                'multiple'    => true,
                'label_block' => true,
                'options'     => $this->product_cats_get(),
                'condition'   => [
                    'product_type' => 'category',
                ],
            ]
        );

        $this->add_control(
            'product_tags',
            [
                'label'       => __( 'Product Tags', 'barab' ),
                'type'        => \Elementor\Controls_Manager::SELECT2,
                'multiple'    => true,
                'label_block' => true,
                'options'     => $this->product_tags_get(),
                'condition'   => [
                    'product_type' => 'tag',
                ],
            ]
        );
        // Get all registered image sizes
        $image_sizes = get_intermediate_image_sizes(); 

        $options = [];
        foreach ( $image_sizes as $size ) {
            $options[ $size ] = ucfirst( str_replace( '_', ' ', $size ) );
        }

        $this->add_control(
            'image_resolution',
            [
                'label'       => __( 'Image Resolution', 'barab' ),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'default'     => 'thumbnail',
                'options'     => $options,
            ]
        ); 

        barab_switcher_fields( $this, 'show_product_content', 'Show Product Content?', ['1', '2', '3'] );

        barab_general_fields($this, 'button_text', 'Button Text', 'TEXT', 'Order Now', ['2']);
		barab_url_fields($this, 'button_url', 'Button URL', ['2']);
        
        $this->end_controls_section();

        // Column Responsive controls
        if ( function_exists( 'barab_add_responsive_columns_controls' ) ) {
            barab_add_responsive_columns_controls( $this, ['layout_style' => ['1'] ] );
        }

        //---------------------------------------
			//Style Section Start
		//---------------------------------------
		barab_common2_style_fields( $this, '10', 'Product Title', '{{WRAPPER}} .box-title a', ['1', '2', '3'] );
		barab_common_style_fields( $this, '11', 'Product Price', '{{WRAPPER}} .woocommerce-Price-amount.amount', ['1', '2', '3'] );
		barab_common_style_fields( $this, '12', 'Product Content', '{{WRAPPER}} .box-text', ['1', '2'] );
        //------Button Style-------
		barab_button_style_fields( $this, '21', 'Button Styling', '{{WRAPPER}} .th-btn', ['2'] );

	}

    protected function product_cats_get() {
        $terms = get_terms( array( 'taxonomy' => 'product_cat' ) );
        $term_array = array();
        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
            foreach ( $terms as $term ) {
                $term_array[$term->slug] = $term->name;
            }
        }

        return $term_array;
    }

    protected function product_tags_get() {
        $terms = get_terms( array( 'taxonomy' => 'product_tag' ) );
        $term_array = array();
    
        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
            foreach ( $terms as $term ) {
                $term_array[$term->slug] = $term->name;
            }
        }
    
        return $term_array;
    }

	protected function render() {

    // ✅ WooCommerce check
    if ( ! class_exists( 'WooCommerce' ) ) {
        echo '<p>WooCommerce is not installed or activated.</p>';
        return;
    }

    $settings = $this->get_settings_for_display(); 

    $product_type = $settings['product_type'];
    
    // Default query arguments
    $args = array(
        'post_type'      => 'product',
        'posts_per_page' => esc_attr($settings['product_count']),
        'order'          => $settings['order'],
        'orderby'        => $settings['orderby'],
    );
    
    // Initialize arrays for tax_query
    $tax_query = array();
    
    // Handle Product Show By (Category/Tag) Logic
    if ($product_type === 'category') {
        $selected_cats = !empty($settings['product_cats']) ? $settings['product_cats'] : [];
        if (!empty($selected_cats)) {
            $tax_query[] = array(
                'taxonomy' => 'product_cat',
                'field'    => 'slug',
                'terms'    => $selected_cats,
            );
        }
    } elseif ($product_type === 'tag') {
        $selected_tags = !empty($settings['product_tags']) ? $settings['product_tags'] : [];
        if (!empty($selected_tags)) {
            $tax_query[] = array(
                'taxonomy' => 'product_tag',
                'field'    => 'slug',
                'terms'    => $selected_tags,
            );
        }
    }
    
    // Apply tax_query if it has conditions
    if (!empty($tax_query)) {
        $args['tax_query'] = $tax_query;
    }

    // Execute the query
    $prods = new WP_Query($args);

    // Get the dynamic image resolution setting
    $image_resolution = !empty($settings['image_resolution']) ? $settings['image_resolution'] : 'robor-shop-small-image';

		if( $settings['layout_style'] == '1' ){ 
            // Get Column Responsive controls Class
            if ( function_exists( 'barab_get_responsive_columns_class' ) ) {
                $column_class = barab_get_responsive_columns_class( $settings );
            } else {
                $column_class = 'col-xl-3 col-lg-6 col-md-6';
            }

            echo '<div class="row gy-30 gsap-card-animation-wrapper">';
                $x = 0;
                while( $prods->have_posts() ) { 
                $x++;
                $prods->the_post();
                $product = wc_get_product(get_the_ID());
                $count = $product->get_review_count();

                	$delay = number_format(0.2 * (($x - 1) % 4 + 1), 1);
					$animation = ( floor( (($x-1)/2) ) % 2 == 0 ) ? 'fadeinleft' : 'fadeinright';

                    echo '<div class="' . esc_attr( $column_class ) . '">';
                        echo '<div class="food-card-1 wow ' . esc_attr($animation) . '" data-wow-delay="' . $delay . 's">';
                            echo '<div class="thumb">';
                                echo '<div class="food-mask" data-mask-src="'.BARAB_ASSETS.'img/bg/menu-1-msk-bg.png"></div>';
                                if ( has_post_thumbnail() ) {
                                    the_post_thumbnail( $image_resolution );
                                }
                                echo '<div class="actions">';
                                    // Wishlist Button
                                    if ( class_exists( 'WPCleverWoosw' ) ) { 
                                        echo do_shortcode( '[woosw]' );
                                    }
                                    // Cart Button
                                    woocommerce_template_loop_add_to_cart();
                                    // Quick View Button
                                    if ( class_exists( 'WPCleverWoosq' ) ) {
                                        echo do_shortcode( '[woosq]' );
                                    }
                                echo '</div>';
                            echo '</div>';
                            echo '<div class="content">';
                                // Product Pricing
                                echo woocommerce_template_loop_price();

                                echo '<h4 class="box-title"><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h4>';
                                if(!empty( $settings['show_product_content'])){
                                    $short_description = barab_meta( 'extra_description' );
                                    echo '<p class="box-text">';
                                        woocommerce_new_short_description($short_description);
                                    echo '</p>';
                                }
                            echo '</div>';
                        echo '</div>';
                    echo '</div>';
                } wp_reset_postdata();
            echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
            echo '<div class="row gy-4 justify-content-center"> ';
                if($settings['image1']['url'] ){
                    echo '<div class="col-lg-3">';
                        echo '<div class="best-deal-img-1-1 global-img">';
                            echo barab_img_tag( array(
                                'url'   => esc_url( $settings['image1']['url'] ),
                            ));
                        echo '</div>';
                    echo '</div>';
                }

                echo '<div class="col-lg-6">';
                    echo '<div class="menu-1-content-wrap gsap-card-animation-wrapper style-2 ms-xl-5">';
                        $x = 0;
                        while( $prods->have_posts() ) { 
                            $x++;
                            $prods->the_post();
                            $product = wc_get_product(get_the_ID());
                            $count = $product->get_review_count();

                            $delay = number_format(0.2 * (($x - 1) % 4 + 1), 1);

                            echo '<div class="menu-item-1  wow fadeinup" data-wow-delay="' . $delay . 's">';
                                echo '<div class="thumb" data-mask-src="'.BARAB_ASSETS.'img/bg/menu-1-msk-bg.jpg">';
                                    if ( has_post_thumbnail() ) {
                                        the_post_thumbnail( $image_resolution );
                                    }
                                echo '</div>';
                                echo '<div class="content">';
                                    echo '<div class="left">';
                                        echo '<h3 class="box-title"><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h3>';
                                        if(!empty( $settings['show_product_content'])){
                                            $short_description = barab_meta( 'extra_description' );
                                            echo '<p class="box-text">';
                                                woocommerce_new_short_description($short_description);
                                            echo '</p>';
                                        }
                                    echo '</div>';
                                    echo '<div class="right">';
                                        // Product Pricing
                                        echo woocommerce_template_loop_price();
                                    echo '</div>';
                                echo '</div>';
                            echo '</div>';
                        } wp_reset_postdata();

                        if(!empty($settings['button_text'])){
                            echo '<div class="text-center mt-5 pt-xl-3">';
                                echo '<a '.barab_link_attrs($settings['button_url']).' class="th-btn btn-mask">'.wp_kses_post( $settings['button_text'] ).'</a>';
                            echo '</div>';
                        }
                    echo '</div>';
                echo '</div>';

                if($settings['image2']['url'] ){
                    echo '<div class="col-lg-3">';
                        echo '<div class="best-deal-img-1-2 gsap-scroll-float-up">';
                            echo barab_img_tag( array(
                                'url'   => esc_url( $settings['image2']['url'] ),
                            ));
                        echo '</div>';
                    echo '</div>';
                }
            echo '</div>';

		}elseif( $settings['layout_style'] == '3' ){
            echo '<div class="slider-area">';
                echo '<div class="swiper th-slider has-shadow menu4Slider" id="menu4Slider" data-slider-options=\'{"centeredSlides":true,"breakpoints":{"0":{"slidesPerView":1},"576":{"slidesPerView":1},"768":{"slidesPerView":2},"992":{"slidesPerView":2},"1200":{"slidesPerView":3,"spaceBetween":30}},"autoplay":false}\'>';
                    echo '<div class="swiper-wrapper">';
                        $x = 0;
                        while( $prods->have_posts() ) { 
                        $x++;
                        $prods->the_post();
                        $product = wc_get_product(get_the_ID());
                        $count = $product->get_review_count();

                            echo '<div class="swiper-slide">';
                                echo '<div class="menu-card4">';
                                    echo '<div class="menu-img4">';
                                        if ( has_post_thumbnail() ) {
                                            the_post_thumbnail( $image_resolution );
                                        }
                                        // Wishlist Button
                                        if ( class_exists( 'WPCleverWoosw' ) ) { 
                                            echo do_shortcode( '[woosw]' );
                                        }
                                    echo '</div>';
                                    echo '<div class="menu-card4-content">';
                                        echo '<h4 class="box-title2"><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h4>';
                                        if(!empty( $settings['show_product_content'])){
                                            $short_description = barab_meta( 'extra_description' );
                                            echo '<p class="box-text pe-xxl-4 ps-xxl-4">';
                                                woocommerce_new_short_description($short_description);
                                            echo '</p>';
                                        }
                                        // Cart Button
                                        woocommerce_template_loop_add_to_cart();
                                        // Product Pricing
                                        echo woocommerce_template_loop_price();
                                    echo '</div>';
                                echo '</div>';
                            echo '</div>';

                        } wp_reset_postdata();
                    echo '</div>';
                echo '</div>';
                echo '<button data-slider-prev="#menu4Slider" class="slider-arrow slider-prev menu4-arrow">
                        <img src="' . BARAB_ASSETS . 'img/icon/left-arrow.svg" alt="' . esc_attr__('Arrow Icon', 'barab') . '">
                    </button>';
                echo '<button data-slider-next="#menu4Slider" class="slider-arrow slider-next menu4-arrow">
                        <img src="' . BARAB_ASSETS . 'img/icon/right-arrow.svg" alt="' . esc_attr__('Arrow Icon', 'barab') . '">
                    </button>';
            echo '</div>';

        }
		
			
	}
}