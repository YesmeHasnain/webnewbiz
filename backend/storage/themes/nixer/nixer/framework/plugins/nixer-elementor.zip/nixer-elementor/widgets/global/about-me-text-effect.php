<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsAboutMeTextEffect extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-about-me-text-effect';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'About Me Text Effect', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-animation-text';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-global' ];
	}

	public function get_keywords() {
		return [ 'aboutmetexteffect', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_text_effect',
			[
				'label' => esc_html__( 'About Me Text Effect', 'bdevs-elementor' ),
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'text_item',
			[
				'label' 		=> esc_html__( 'Text Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( "Let's Work Together." , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'tabs',
			[
				'label' 		=> esc_html__( 'List Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
					],
					[
					],
				],
				'title_field' 	=> '{{{ text_item }}}',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-about-me-text-ptb pb-100">
	<div class="container-fluid tp-gx-0">
		<div class="row tp-gx-0">
			<div class="col-lg-12">
				<h3 class="tp-about-me-text-scrolling tp-text-effect" data-scrub="0.0001">
					<?php
					foreach ($settings['tabs'] as $item) :
					?>
						<?php if (!empty($item['text_item'])): ?>
							<span><?php echo wp_kses_post($item['text_item']); ?></span>
						<?php endif ?>
					<?php endforeach; ?>
				</h3>
			</div>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		if (jQuery('.tp-about-me-text-ptb, .tp-service-details-ptb').length > 0) {
			gsap.set('.tp-text-effect', {
				x: '25%'
			});
			gsap.timeline({
				scrollTrigger: {
					trigger: '.tp-text-effect ',
					start: '-1500 10%',
					end: 'bottom 10%',
					scrub: true,
					invalidateOnRefresh: true
				}
			})
			.to('.tp-text-effect ', {
				x: '-80%'
			});
		}
	</script>
<?php } ?>

<?php
}

}