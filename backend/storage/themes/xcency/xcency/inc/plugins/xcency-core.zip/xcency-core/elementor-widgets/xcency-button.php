<?php
namespace Elementor;

class Xcency_Core_Button_Widget extends Widget_Base {

	public function get_name() {

		return 'xcency_core_button_widget';
	}

	public function get_title() {
		return esc_html__( 'Xcency Button', 'xcency-core' );
	}

	public function get_icon() {

		return 'eicon-button';
	}

	public function get_categories() {
		return [ 'xcency_core_elements' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'button_one_option',
			[
				'label' => esc_html__( 'Button', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'btn_one_text',
			[
				'label'       => __( 'Text', 'xcency-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Get Started'
			]
		);

		$this->add_control(
			'btn_one_url',
			[
				'label'         => __( 'URL', 'xcency-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'xcency-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '#',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

        $this->add_responsive_control(
            'button_align',
            [
                'label'       => esc_html__('Button Align', 'xcency-core'),
                'description' => esc_html__('', 'xcency-core'),
                'type'        => Controls_Manager::CHOOSE,
                'label_block' => false,

                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'xcency-core'),
                        'icon'  => 'eicon-text-align-left',
                    ],

                    'center' => [
                        'title' => esc_html__('Center', 'xcency-core'),
                        'icon'  => 'eicon-text-align-center',
                    ],

                    'right' => [
                        'title' => esc_html__('Right', 'xcency-core'),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],

                'selectors' => [
                    '{{WRAPPER}} .xcency-button-wrapper.xcency-button-el-widget' => 'text-align: {{VALUE}};',
                ],

            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'button_one_style_options',
			[
				'label' => esc_html__( 'Button', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs('xcency_btn_one_style_tabs');

		//Default style tab start
		$this->start_controls_tab(
			'xcency_btn_one_style_default',
			[
				'label' => esc_html__('Default', 'xcency-core'),
			]
		);

		$this->add_control(
			'btn_one_default_bg',
			[
				'label'     => esc_html__('Background Color', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .xcency-button.xcency-button-one' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_one_default_border_color',
			[
				'label'     => esc_html__('Border Color', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .xcency-button.xcency-button-one' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'btn_one_default_text_color',
			[
				'label'     => esc_html__('Text Color', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .xcency-button.xcency-button-one' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();//Default style tab end

		//Hover style tab start
		$this->start_controls_tab(
			'xcency_btn_one_style_hover',
			[
				'label' => esc_html__('Hover', 'xcency-core'),
			]
		);

		$this->add_control(
			'btn_one_hover_bg',
			[
				'label'     => esc_html__('Background Color', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .xcency-button.xcency-button-one:hover' => 'background-color: {{VALUE}};border-color: {{VALUE}}',
					'{{WRAPPER}} .xcency-button.xcency-button-one:hover:before' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'btn_one_hover_border_color',
			[
				'label'     => esc_html__('Border Color', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .xcency-button.xcency-button-one:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'btn_one_hover_text_color',
			[
				'label'     => esc_html__('Text Color', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} a.xcency-button.xcency-button-one:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tabs();//Hover style tab end
		$this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();

		$btn_one_text = $settings['btn_one_text'];
		$btn_one_url   = $settings['btn_one_url']['url'];
		$btn_one_target   = $settings['btn_one_url']['is_external'] ? ' target="_blank"' : '';
		$btn_one_nofollow = $settings['btn_one_url']['nofollow'] ? ' rel="nofollow"' : '';
		?>

		<div class="xcency-button-wrapper xcency-button-el-widget">
			<a href="<?php echo esc_url($btn_one_url);?>" class="xcency-button xcency-button-one" <?php echo esc_attr($btn_one_target . $btn_one_nofollow);?>><?php echo esc_html($btn_one_text);?>
			</a>
		</div>
		<?php
	}
}

Plugin::instance()->widgets_manager->register( new Xcency_Core_Button_Widget );