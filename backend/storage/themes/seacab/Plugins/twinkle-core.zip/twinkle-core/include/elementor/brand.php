<?php
namespace TwinkleCore\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Twinkle Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Twinkle_Brand extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'twinkle_brand';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Brand', 'twinkle-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'twinkle-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'twinkle_core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'twinkle-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
            'twinkle_brand_section',
            [
                'label' => __( 'Brand Item', 'twinkle-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'twinkle_brand_image_one',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Before Image', 'twinkle-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater->add_control(
            'twinkle_brand_image_two',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'After Image', 'twinkle-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater->add_control(
            'twinkle_brand_url',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'label' => __( 'URL', 'twinkle-core' ),
                'default' => __( '#', 'twinkle-core' ),
                'placeholder' => __( 'Type url here', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->add_control(
            'twinkle_brand_slides',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => esc_html__( 'Brand Item', 'twinkle-core' ),
                'default' => [
                    [
                        'twinkle_brand_image_one' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'twinkle_brand_image_two' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'twinkle_brand_image_one' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'twinkle_brand_image_two' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'twinkle_brand_image_one' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'twinkle_brand_image_two' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'twinkle_brand_image_one' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'twinkle_brand_image_two' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'twinkle_brand_image_one' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'twinkle_brand_image_two' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                ]
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'twinkle_layout_style',
			[
				'label' => __( 'Layout', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
            'content_padding',
            [
                'label' => __( 'Content Padding', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .brand-one' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
            'content_background',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .brand-one' => 'background-color: {{VALUE}}',
                ],
            ]
        );

		$this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'label'    => esc_html__( 'Border', 'twinkle-core' ),
                'name'     => 'content_border',
                'selector' => '{{WRAPPER}} .brand-one',
            ]
        );

        $this->end_controls_section();
		
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

			<section class="brand-one">
				<div class="container">
					<div class="brand-one__carousel owl-theme owl-carousel">
						<?php foreach ($settings['twinkle_brand_slides'] as $item) : 
							if ( !empty($item['twinkle_brand_image_one']['url']) ) {
								$twinkle_brand_image_one_url = !empty($item['twinkle_brand_image_one']['id']) ? wp_get_attachment_image_url( $item['twinkle_brand_image_one']['id']) : $item['twinkle_brand_image_one']['url'];
								$twinkle_brand_image_one_alt = get_post_meta($item["twinkle_brand_image_one"]["id"], "_wp_attachment_image_alt", true);
								$twinkle_brand_image_two_url = !empty($item['twinkle_brand_image_two']['id']) ? wp_get_attachment_image_url( $item['twinkle_brand_image_two']['id']) : $item['twinkle_brand_image_two']['url'];
								$twinkle_brand_image_two_alt = get_post_meta($item["twinkle_brand_image_two"]["id"], "_wp_attachment_image_alt", true);
							}
						?>
						<div class="single-slide">
							<a href="<?php echo esc_url($item['twinkle_brand_url']); ?>">
								<img src="<?php echo esc_url($twinkle_brand_image_one_url); ?>" alt="<?php echo esc_url($twinkle_brand_image_one_alt); ?>">
							</a>
							<div class="brand-one__overly">
								<a href="<?php echo esc_url($item['twinkle_brand_url']); ?>">
									<img src="<?php echo esc_url($twinkle_brand_image_two_url); ?>" alt="<?php echo esc_url($twinkle_brand_image_two_alt); ?>">
								</a>
							</div>
						</div>
						<?php endforeach; ?>

					</div>
				</div>
			</section>

		<?php
	}


}

$widgets_manager->register( new Twinkle_Brand() );