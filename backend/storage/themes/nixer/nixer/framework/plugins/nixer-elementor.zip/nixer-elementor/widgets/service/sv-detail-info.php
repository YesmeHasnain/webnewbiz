<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsSVDetailInfo extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-sv-detail-info';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Service Detail Info', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-image';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-service' ];
	}

	public function get_keywords() {
		return [ 'servicedetailinfo', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_sv_detail_info',
			[
				'label' => esc_html__( 'Service Detail Info', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'img_sec',
			[
				'label'       	=> esc_html__( 'Image Service - If this field empty then use featured image service', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image service', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Service - If this field empty then use title service', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_sec',
			[
				'label' 		=> esc_html__( 'Text Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'show_text',
			[
				'label'   => esc_html__( 'Show Text Effect', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'text_item',
			[
				'label' 		=> esc_html__( 'Text Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( 'Text item' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'img_item',
			[
				'label'       	=> esc_html__( 'Image Icon Item', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image icon item', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'tab_text',
			[
				'label' 		=> esc_html__( 'List Text Service', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						
					],
				],
				'condition' 	=> [
					'show_text' 	=> 'yes',
				],
				'title_field' 	=> '{{{ text_item }}}',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-service-details-ptb pt-200 pb-140">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="tp-service-details-wrapper p-relative mb-100">
					<div class="tp-service-details-heading pb-120">
						<h3 class="tp-service-details-title">
							<?php if (!empty($settings['title_sec'])) { ?>
								<?php echo wp_kses_post($settings['title_sec']); ?>
							<?php } else { ?>
								<?php the_title(); ?>
							<?php } ?>
						</h3>
						<?php if (!empty($settings['text_sec'])): ?>
							<p><?php echo wp_kses_post($settings['text_sec']); ?></p>
						<?php endif ?>
					</div>
					<?php if (!empty($settings['img_sec']['url'])): ?>
						<div class="tp-service-details-thumb tp_img_reveal">
							<img src="<?php echo wp_kses_post($settings['img_sec']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_sec']['alt']); ?>">
						</div>
					<?php endif ?>
					<?php if (!empty($settings['show_text'])): ?>
						<div class="tp-service-details-text tp-text-effect">
							<?php
							foreach ($settings['tab_text'] as $item) :
							?>
								<?php if (!empty($item['text_item']) || !empty($item['img_item']['url'])): ?>
									<span>
										<?php echo wp_kses_post($item['text_item']); ?>
										<?php 
											$img_url = $item['img_item']['url']; 
										?>
										<?php if (strtolower(pathinfo($img_url, PATHINFO_EXTENSION)) === 'svg') { ?>
											<?php echo nixer_inline_svg_from_url($img_url); ?>
										<?php } else { ?>
											<img src="<?php echo esc_url($img_url); ?>" alt="<?php echo wp_kses_post($item['text_item']); ?>">
										<?php } ?>
									</span>
								<?php endif ?>
							<?php endforeach; ?>
						</div>
					<?php endif ?>
				</div>
			</div>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		var tp_img_reveal = document.querySelectorAll(".tp_img_reveal");
		tp_img_reveal.forEach((img_reveal) => {
			var image = img_reveal.querySelector("img");
			var tl = gsap.timeline({
				scrollTrigger: {
					trigger: img_reveal,
					start: "top 70%",
				}
			});

			tl.set(img_reveal, { autoAlpha: 1 });
			tl.from(img_reveal, 1.5, {
				xPercent: -100,
				ease: Power2.out
			});
			tl.from(image, 1.5, {
				xPercent: 100,
				scale: 1.5,
				duration: 3,
				delay: -1.5,
				ease: Power2.out
			});
		});

		if (jQuery('.tp-about-me-text-ptb, .tp-service-details-ptb').length > 0) {
			gsap.set('.tp-text-effect', {
				x: '25%'
			});
	
			gsap.timeline({
				scrollTrigger: {
					trigger: '.tp-text-effect ',
					start: '-1500 10%',
					end: 'bottom 10%',
					scrub: true,
					invalidateOnRefresh: true
				}
			})
			.to('.tp-text-effect ', {
				x: '-80%'
			});
		}
	</script>
<?php } ?>

<?php
}

}