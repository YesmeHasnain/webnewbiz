<?php

namespace Elementor;
class Xcency_Section_Title_One_Widget extends Widget_Base {

	public function get_name() {

		return 'xcency_section_title_one';
	}

	public function get_title() {
		return esc_html__( 'Section Title', 'xcency-core' );
	}

	public function get_icon() {

		return 'eicon-t-letter';
	}

	public function get_categories() {
		return [ 'xcency_core_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_title_options',
			[
				'label' => esc_html__( 'Section Title', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Subtitle', 'xcency-core' ),
				'label_block'       => true,
				'default'       => 'About Company',
				'type'        => Controls_Manager::TEXT,
			]
		);

        $this->add_control(
            'title',
            [
                'label'       => __( 'title', 'xcency-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'rows'        => 5,
                'default'     => 'Building the Future, One Startup at a Time',
            ]
        );


		$this->add_control(
			'desc',
			[
				'label'       => __( 'Description', 'xcency-core' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => 'Lorem ipsum dolor sit amet, con adipiscing elit tiam convallis elit impedie. Quisq commodo simply free ornare tortor. If you are going to use a passa sed ullam send lorem ipsum therapy for.',
				'label_block' => true,
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'subtitle_style',
			[
				'label' => esc_html__( 'Subtitle', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'subtitle!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'subtitle_typography',
				'label'    => esc_html__( 'Typography', 'xcency-core' ),
				'selector' => '{{WRAPPER}} .xcency-section-subtitle',
			]
		);

		$this->add_control(
			'subtitle_color',
			[
				'label'       => esc_html__('Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-section-subtitle' => 'color: {{VALUE}};',
					'{{WRAPPER}} .section-subtitle-dot' => 'background-color: {{VALUE}};',
				],
			]
		);

        $this->add_control(
            'subtitle_bg_color',
            [
                'label'       => esc_html__('Background Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .xcency-section-subtitle' => 'background-color: {{VALUE}};',
                ],
            ]
        );

		$this->add_responsive_control(
			'subtitle_margin',
			[
				'label'      => esc_html__( 'Margin', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .xcency-section-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'title_style',
			[
				'label'     => esc_html__( 'Title', 'xcency-core' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'title!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'label'    => esc_html__( 'Typography', 'xcency-core' ),
				'selector' => '{{WRAPPER}} .xcency-section-title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'xcency-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .xcency-section-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_margin',
			[
				'label'      => esc_html__( 'Margin', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .xcency-section-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'desc_style',
			[
				'label'     => esc_html__( 'Description', 'xcency-core' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'desc!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'desc_typography',
				'label'    => esc_html__( 'Typography', 'xcency-core' ),
				'selector' => '{{WRAPPER}} .xcency-section-desc',
			]
		);

		$this->add_control(
			'desc_color',
			[
				'label'     => esc_html__( 'Color', 'xcency-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .xcency-section-desc' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'desc_margin',
			[
				'label'      => esc_html__( 'Margin', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .xcency-section-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'wrapper_style',
			[
				'label' => esc_html__( 'Wrapper', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'content_width',
			[
				'label'      => esc_html__( 'Width (%)', 'xcency-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ '%' ],
				'range'      => [
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'    => [ 'desktop', 'tablet', 'mobile' ],
				'selectors'  => [
					'{{WRAPPER}} .xcency-section-title-content' => 'width: {{SIZE}}%;display:inline-block;',
				],
			]
		);

		$this->add_responsive_control(
			'wrapper_text_align',
			[
				'label'       => esc_html__( 'Text Align', 'xcency-core' ),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,

				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'xcency-core' ),
						'icon'  => 'eicon-text-align-left',
					],

					'center' => [
						'title' => esc_html__( 'Center', 'xcency-core' ),
						'icon'  => 'eicon-text-align-center',
					],

					'right' => [
						'title' => esc_html__( 'Right', 'xcency-core' ),
						'icon'  => 'eicon-text-align-right',
					],
				],

				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .xcency-section-title-wrapper' => 'text-align: {{VALUE}};',
				],

			]
		);

		$this->add_responsive_control(
			'wrapper_margin',
			[
				'label'      => esc_html__( 'Wrapper Margin', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .xcency-section-title-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'wrapper_padding',
			[
				'label'      => esc_html__( 'Wrapper Padding', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .xcency-section-title-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$subtitle       = $settings['subtitle'];
		$title       = $settings['title'];
		$desc      = $settings['desc'];
		?>

		<div class="xcency-section-title-wrapper">
			<div class="xcency-section-title-content d-inline-block">
				<?php if ( $subtitle ) : ?>
                    <div class="xcency-section-subtitle">
                        <span class="section-subtitle-dot section-subtitle-dot-one"></span>
                        <?php echo $subtitle; ?>
                        <span class="section-subtitle-dot section-subtitle-dot-two"></span>
                    </div>
				<?php endif; ?>

				<?php if ( $title ) : ?>
                    <h2 class="xcency-section-title"><?php echo wp_kses( $title, xcency_allow_html() ); ?></h2>
				<?php endif; ?>

				<?php if ( $desc ) : ?>
					<div class="xcency-section-desc xcency-last-p-0">
						<?php echo wp_kses( $desc, xcency_allow_html() ); ?>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}
}

Plugin::instance()->widgets_manager->register( new Xcency_Section_Title_One_Widget );