(function ($) {
    "use strict";

    var ajaxurl = $(".elementor-widget-mancink-event-ajax .rdn-port-val").data("url");
    var page = 2;
    var event_item = $(".elementor-widget-mancink-event-ajax .rdn-port-val").data("item");
    var port_column = $(".elementor-widget-mancink-event-ajax .rdn-port-val").data("col");
    var order_value = $(".elementor-widget-mancink-event-ajax .rdn-port-val").data("order");
    var security = $(".elementor-widget-mancink-event-ajax .rdn-port-val").data("nonce");
    var nomore = $(".elementor-widget-mancink-event-ajax .rdn-port-val").data("nomore");

    $(".elementor-widget-mancink-event-ajax .loadmore").on(
        "click",
        function () {
            $(".elementor-widget-mancink-event-ajax .loadmore").hide();
            $(".elementor-widget-mancink-event-ajax .port-load").show();
            $(".elementor-widget-mancink-event-ajax .new-rcol").removeClass(
                "new-rcol"
            );
            var data = {
                action: "load_posts_by_ajax",
                page: page,
                event_item: event_item,
                port_column: port_column,
                order_value: order_value,
                security: security,
                nomore: nomore
            };

            var $grid = $(
                ".elementor-widget-mancink-event-ajax .c-iso"
            ).isotope();

            $.post(ajaxurl, data, function (response) {
                $(".elementor-widget-mancink-event-ajax .c-iso").append(response);
                $grid
                    .append($(".new-rcol"))
                    // add and lay out newly appended elements
                    .isotope("appended", $(".new-rcol"));
                $(".elementor-widget-mancink-event-ajax .new-rcol").removeClass("new-rcol");
                page++;
                $(".elementor-widget-mancink-event-ajax .port-load").fadeOut("fast");
                setTimeout(function () {
                    $(".elementor-widget-mancink-event-ajax .loadmore").fadeIn();
                }, 400);
                if (
                    $(".elementor-widget-mancink-event-ajax .c-iso").find(".no-more").length > 0) {
                    $(".elementor-widget-mancink-event-ajax .load-more").remove();
                    $(".elementor-widget-mancink-event-ajax .box-load").slideUp(
                        "fast"
                    );
                    setTimeout(function () {
                        $(".elementor-widget-mancink-event-ajax .npsp").fadeOut();
                        $(".elementor-widget-mancink-event-ajax .npsp").remove();
                        $(".elementor-widget-mancink-event-ajax .event-body").isotope("layout");
                    }, 2000);
                }
            });
        }
    );
})(jQuery);
