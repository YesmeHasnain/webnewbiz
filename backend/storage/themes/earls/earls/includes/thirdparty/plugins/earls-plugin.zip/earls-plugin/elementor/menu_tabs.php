<?php namespace EARLSPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Menu_Tabs extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'earls_menu_tabs';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Earls Menu Tabs', 'earls' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-tabs';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'earls' ];
    }
	
	public function get_script_depends() {
		wp_register_script( 'menu-tab', YT_URL . 'assets/js/menu-tab.js', [ 'elementor-frontend' ], '1.0.0', true );
		return [ 'menu-tab' ];
	}
    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'menu_tabs',
            [
                'label' => esc_html__( 'Earls Menu Tabs', 'earls' ),
            ]
        );
				
		//Our Slider		
		$repeater = new Repeater();
		$repeater->add_control(
			'tab_btn_title',
			[
				'label'       => __( 'Tab Button Title', 'earls' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default' => esc_html__( 'Tab Button Title', 'earls' ),
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Tab Button Title', 'earls' ),
			]
		);
		$repeater->add_control(
			'feature_image',
			[
				'label' => esc_html__( 'Choose Image', 'earls' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'sub_heading',
			[
				'label'       => __( 'Main Title', 'earls' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default' => esc_html__( 'Main Title', 'earls' ),
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Starter.', 'earls' ),
			]
		);
		$repeater->add_control(
			'sub_heading2',
			[
				'label'       => __( 'Main Title V2', 'earls' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default' => esc_html__( 'Main Title V2', 'earls' ),
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Main dish', 'earls' ),
			]
		);
		
		$repeater->add_control(
			'text_limit',
			[
				'label'   => esc_html__( 'Text Limit', 'earls' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			]
		);
		$repeater->add_control(
			'query_number',
			[
				'label'   => esc_html__( 'Number of post', 'earls' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			]
		);
		$repeater->add_control(
			'query_orderby',
			[
				'label'   => esc_html__( 'Order By', 'earls' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => array(
					'date'       => esc_html__( 'Date', 'earls' ),
					'title'      => esc_html__( 'Title', 'earls' ),
					'menu_order' => esc_html__( 'Menu Order', 'earls' ),
					'rand'       => esc_html__( 'Random', 'earls' ),
				),
			]
		);
		$repeater->add_control(
			'query_order',
			[
				'label'   => esc_html__( 'Order', 'earls' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => array(
					'DESC' => esc_html__( 'DESC', 'earls' ),
					'ASC'  => esc_html__( 'ASC', 'earls' ),
				),
			]
		);
		$repeater->add_control(
            'query_category', 
			[
			  'type' => Controls_Manager::SELECT,
			  'label' => esc_html__('Category', 'earls'),
			  'label_block' => true,
			  'options' => get_menu_categories(),
			]
		);
		
		$this->add_control(
			'menu_tab',
			[
				'label'                 => __('Add Menu Item', 'earls'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
			]
		);
		
		$this->end_controls_section();
		
		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'earls' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'earls' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .name__price__shrtd.body__one li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
        $this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'earls' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .name__price__shrtd.body__one li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'earls' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
					{{WRAPPER}} .name__price__shrtd.body__one li',				
			]
		);
		$this->end_controls_section();
		
		//Title Style
		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'earls' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_responsive_control(
            'title__margin',
            [
                'label'      => esc_html__( 'Margin', 'earls' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .name__price__shrtd .name__price li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
        $this->add_responsive_control(
            'title_padding',
            [
                'label'      => esc_html__( 'Padding', 'earls' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .name__price__shrtd .name__price li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'title_bgtype',
				'label' => __( 'Background', 'earls' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .name__price__shrtd .name__price li',				
			]
		);
		
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Text Color', 'earls' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .name__price__shrtd .name__price li' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __('Typography', 'earls'),
				'selector' => '{{WRAPPER}} .name__price__shrtd .name__price li',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'title_text_shadow',
				'selector' => '{{WRAPPER}} .name__price__shrtd .name__price li',
			]
		);

		$this->end_controls_section();
		
		//Price Style
		$this->start_controls_section(
			'price_style',
			[
				'label' => esc_html__( 'Price', 'earls' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_responsive_control(
            'price__margin',
            [
                'label'      => esc_html__( 'Margin', 'earls' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .name__price__shrtd .name__price li+li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
        $this->add_responsive_control(
            'price_padding',
            [
                'label'      => esc_html__( 'Padding', 'earls' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .name__price__shrtd .name__price li+li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
		$this->add_control(
			'price_color',
			[
				'label' => esc_html__( 'Price Color', 'earls' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .name__price__shrtd .name__price li+li' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'price_typography',
				'label' => __('Typography', 'earls'),
				'selector' => '{{WRAPPER}} .name__price__shrtd .name__price li+li',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'price_text_shadow',
				'selector' => '{{WRAPPER}} .name__price__shrtd .name__price li+li',
			]
		);

		$this->end_controls_section();
		
		//Text Style
		$this->start_controls_section(
			'text_style',
			[
				'label' => esc_html__( 'Text', 'earls' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_responsive_control(
            'text__margin',
            [
                'label'      => esc_html__( 'Margin', 'earls' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .name__price__shrtd p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
        $this->add_responsive_control(
            'text_padding',
            [
                'label'      => esc_html__( 'Padding', 'earls' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .name__price__shrtd p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
		$this->add_control(
			'text_color',
			[
				'label' => esc_html__( 'Text Color', 'earls' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .name__price__shrtd p' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'label' => __('Typography', 'earls'),
				'selector' => '{{WRAPPER}} .name__price__shrtd p',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'text_text_shadow',
				'selector' => '{{WRAPPER}} .name__price__shrtd p',
			]
		);

		$this->end_controls_section();
		
	}
	
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
	?>
    
    <!-- our-choice-section --> 
    <section class="our__choice__section p-0 m-0">
        <div class="medium-container">
            
            <div class="tabs-box">
                <div class="tab-btn-box p_relative d_block mb_60 centred">
                    <ul class="tab-btns tab-buttons clearfix">
                        <?php foreach($settings['menu_tab'] as $key => $item):?>
                        <li class="tab-btn <?php if($key == 0) echo 'active-btn';?>" data-tab="#tab-<?php echo esc_attr($key);?>">
                            <div class="tab___all">
                                <h6><?php echo wp_kses($item['tab_btn_title'], true);?> </h6>
                            </div>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="tabs-content wow fadeInUp animated" data-wow-delay="00ms" data-wow-duration="3000ms">
                    <?php foreach($settings['menu_tab'] as $keys => $item):
					                                                
						$paged = earls_set($_POST, 'paged') ? esc_attr($_POST['paged']) : 1;
						$this->add_render_attribute( 'wrapper', 'class', 'templatepath-earls' );
						$args = array(
							'post_type'      => 'menu',
							'posts_per_page' => earls_set( $item, 'query_number' ),
							'orderby'        => earls_set( $item, 'query_orderby' ),
							'order'          => earls_set( $item, 'query_order' ),
							'paged'         => $paged
						);
						if( earls_set( $item, 'query_category' ) ) $args['menu_cat'] = earls_set( $item, 'query_category' );
						$query = new \WP_Query( $args );
						if ( $query->have_posts()):	
						
						$count = 1;
						$left_arr = array();
						$right_arr = array();
					?>
                    
                    <?php while ( $query->have_posts() ) : $query->the_post();
						if($count > 2) $count = 1;
					?>
					<?php if( ($count == 1)):
						$left_arr[get_the_id()] = ' <li>
														<ul class="name__price">
															<li>'.get_the_title(get_the_id()).'</li>
															<li>'.get_post_meta( get_the_id(), 'menu_price', true).'</li>
														</ul>
														<p>'.earls_trim(get_the_content(), $item['text_limit']).'</p>
													</li>';
					?>
					<?php else:
						$right_arr[get_the_id()] = ' <li>
														<ul class="name__price">
															<li>'.get_the_title(get_the_id()).'</li>
															<li>'.get_post_meta( get_the_id(), 'menu_price', true).'</li>
														</ul>
														<p>'.earls_trim(get_the_content(), $item['text_limit']).'</p>
													</li>';
					?>
					<?php endif; ?>
					<?php $count++; endwhile; ?>
                    
                    <div class="tab <?php if($keys == 0) echo 'active-tab';?>" id="tab-<?php echo esc_attr($keys);?>">
                        <div class="inner-box">
                            <div class="row clearfix">
                                <div class="col-lg-4 col-md-12 col-sm-12">
                                    <div class="tab__img" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($item['feature_image']['id'])); ?>);">
                                        <div class="tab__img_feature_image">
                                            <img class="d-block d-lg-none" src="<?php echo esc_url(wp_get_attachment_url($item['feature_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'earls'); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-12 col-sm-12">
                                    <div class="menu__text__block">
                                        <div class="sub____title">
                                            <span><?php echo wp_kses($item['sub_heading'], true);?></span>
                                        </div>
                                        <div class="menu__list">
                                            <ul class="name__price__shrtd body__one">
                                                <?php foreach($left_arr as $key => $content):?>
													<?php echo wp_kses_post($content);?>
                                                <?php endforeach;?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-12 col-sm-12">
                                    <div class="menu__text__block">
                                        <div class="sub____title">
                                            <span><?php echo wp_kses($item['sub_heading2'], true);?></span>
                                        </div>
                                        <div class="menu__list">
                                            <ul class="name__price__shrtd body__one">
                                                <?php foreach($right_arr as $key => $right_content):?>
													<?php echo wp_kses_post($right_content);?>
                                                <?php endforeach;?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif;?>
                    <?php endforeach;?>
                </div>
            </div>
            
        </div>
    </section>
    <!-- our-choice-section-end -->
    	
    <?php
    }
}