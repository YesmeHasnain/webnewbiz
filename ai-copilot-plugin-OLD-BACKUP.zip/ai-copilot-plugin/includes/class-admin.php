<?php
/**
 * Admin UI - Chat panel in WordPress admin
 */
class AICopilot_Admin
{
    public static function init()
    {
        add_action('admin_menu', [self::class, 'addMenu']);
        add_action('admin_enqueue_scripts', [self::class, 'enqueueAssets']);
        add_action('elementor/editor/after_enqueue_scripts', [self::class, 'enqueueElementorAssets']);
    }

    public static function addMenu()
    {
        add_menu_page(
            'AI Copilot',
            'AI Copilot',
            'edit_pages',
            'ai-copilot',
            [self::class, 'renderPage'],
            'dashicons-format-chat',
            3
        );
    }

    public static function enqueueAssets($hook)
    {
        if ($hook !== 'toplevel_page_ai-copilot') return;

        wp_enqueue_style('ai-copilot-css', AICOPILOT_URL . 'assets/css/copilot.css', [], AICOPILOT_VERSION);
        wp_enqueue_script('ai-copilot-js', AICOPILOT_URL . 'assets/js/copilot.js', ['jquery'], AICOPILOT_VERSION, true);
        wp_localize_script('ai-copilot-js', 'aiCopilot', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ai_copilot_nonce'),
            'siteUrl' => home_url(),
            'bridgeUrl' => AICOPILOT_URL . 'assets/js/preview-bridge.js',
        ]);
    }

    /**
     * Enqueue AI Copilot scripts inside Elementor editor
     */
    public static function enqueueElementorAssets()
    {
        wp_enqueue_script(
            'ai-copilot-elementor',
            AICOPILOT_URL . 'assets/js/elementor-panel.js',
            ['jquery', 'elementor-editor'],
            AICOPILOT_VERSION,
            true
        );
        wp_localize_script('ai-copilot-elementor', 'aicElementor', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ai_copilot_nonce'),
        ]);
    }

    public static function renderPage()
    {
        $cliAvailable = AICopilot_Settings::isCliAvailable();
        ?>
        <div id="ai-copilot-app">
            <?php if (!$cliAvailable): ?>
                <div class="aic-no-key">
                    <div class="aic-no-key-icon">⚡</div>
                    <h2>Claude CLI Required</h2>
                    <p>Install Claude Code CLI to start using AI Copilot.</p>
                    <code style="display:block;margin:16px 0;padding:12px;background:#f5f5f5;border-radius:8px;">npm install -g @anthropic-ai/claude-code</code>
                    <a href="<?php echo admin_url('options-general.php?page=ai-copilot-settings'); ?>" class="button button-primary button-hero">Check Status</a>
                </div>
            <?php else: ?>
                <div class="aic-layout">
                    <!-- Left: Chat Panel -->
                    <div class="aic-chat-panel">
                        <div class="aic-chat-header">
                            <div class="aic-logo">
                                <svg width="20" height="20" viewBox="0 0 24 24"><path d="M12 2L22 12L12 22L2 12Z" fill="#6366f1"/></svg>
                                <span>AI Copilot</span>
                            </div>
                            <button class="aic-collapse-btn" onclick="toggleChatPanel()" title="Collapse chat panel">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="11 17 6 12 11 7"/><polyline points="18 17 13 12 18 7"/></svg>
                            </button>
                            <div class="aic-header-actions">
                                <button id="aic-undo-btn" class="aic-undo-btn" onclick="aiUndo()" title="Undo last change" style="display:none;">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>
                                    Undo
                                </button>
                                <select id="aic-page-select">
                                    <option value="0">Select a page...</option>
                                </select>
                            </div>
                        </div>

                        <div class="aic-messages" id="aic-messages">
                            <div class="aic-welcome">
                                <div class="aic-welcome-icon">✨</div>
                                <h3>How can I help?</h3>
                                <p>I can edit text, change styles, add sections, update images, manage SEO, and more.</p>
                                <div class="aic-suggestions">
                                    <button onclick="aiSend('Change the hero heading text')">Change hero text</button>
                                    <button onclick="aiSend('Update the color scheme to blue')">Change colors</button>
                                    <button onclick="aiSend('Add a testimonials section')">Add testimonials</button>
                                    <button onclick="aiSend('Update SEO meta description')">Update SEO</button>
                                </div>
                            </div>
                        </div>

                        <!-- Options Bar: Tone, Language, SEO Keywords -->
                        <div class="aic-options-bar" id="aic-options-bar" style="display:none;">
                            <select id="aic-tone" title="Content Tone">
                                <option value="">Tone</option>
                                <option value="professional">Professional</option>
                                <option value="casual">Casual</option>
                                <option value="friendly">Friendly</option>
                                <option value="formal">Formal</option>
                                <option value="persuasive">Persuasive</option>
                                <option value="witty">Witty</option>
                            </select>
                            <select id="aic-language" title="Content Language">
                                <option value="">Language</option>
                                <option value="English">English</option>
                                <option value="Urdu">Urdu</option>
                                <option value="Hindi">Hindi</option>
                                <option value="Arabic">Arabic</option>
                                <option value="Spanish">Spanish</option>
                                <option value="French">French</option>
                                <option value="German">German</option>
                                <option value="Chinese">Chinese</option>
                                <option value="Japanese">Japanese</option>
                            </select>
                            <input type="text" id="aic-seo-keywords" placeholder="SEO keywords (comma separated)" title="SEO Keywords for content generation">
                        </div>

                        <div class="aic-input-area">
                            <button class="aic-options-toggle" onclick="toggleOptions()" title="Content options (tone, language, SEO)">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                            </button>
                            <textarea id="aic-input" placeholder="Ask AI to edit your website..." rows="1"></textarea>
                            <button id="aic-send" onclick="aiSendMessage()">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>
                            </button>
                        </div>
                    </div>

                    <!-- Right: Preview -->
                    <div class="aic-preview-panel">
                        <div class="aic-preview-header">
                            <button onclick="refreshPreview()" title="Refresh">↻</button>
                            <span id="aic-preview-url"><?php echo home_url(); ?></span>
                            <a href="<?php echo home_url(); ?>" target="_blank" title="Open in new tab">↗</a>
                        </div>
                        <iframe id="aic-preview" src="<?php echo home_url(); ?>"></iframe>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
}
