<?php
namespace Elementor;

class Xcency_Team_Rating_Widget extends Widget_Base {

	public function get_name() {
		return 'xcency_team_rating';
	}

	public function get_title() {
		return esc_html__( 'Team Ratting', 'xcency-core' );
	}

	public function get_icon() {
		return 'eicon-rating';
	}

	public function get_categories() {
		return [ 'xcency_elements' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'team_ratting_options',
			[
				'label' => esc_html__( 'Team Ratting', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
		    'team_image_title',
		    [
		        'label'       => esc_html__( 'Team Image Title', 'xcency-core' ),
		        'type'        => Controls_Manager::TEXTAREA,
		        'rows'        => 5,
		        'default'     => esc_html__( '8m+ Partner', 'xcency-core' ),
		    ]
		);

		$this->add_control(
		    'team_image',
		    [
		        'label'       => esc_html__( 'Team Image', 'xcency-core' ),
		        'type'        => Controls_Manager::MEDIA,
		        'label_block' => true,
		        'default'     => [
		            'url' => Utils::get_placeholder_image_src(),
		        ],
		    ]
		);

		$this->add_control(
		    'desc',
		    [
		        'label'       => esc_html__( 'Team Image Description', 'xcency-core' ),
		        'type'        => Controls_Manager::TEXTAREA,
		        'rows'        => 5,
		        'default'     => esc_html__( 'Team of seasoned experts excels', 'xcency-core' ),
		    ]
		);

		$this->add_control(
		    'rating_image',
		    [
		        'label'       => esc_html__( 'Rating Image', 'xcency-core' ),
		        'type'        => Controls_Manager::MEDIA,
		        'label_block' => true,
		        'default'     => [
		            'url' => Utils::get_placeholder_image_src(),
		        ],
		    ]
		);

		$this->add_control(
		    'rating_text',
		    [
		        'label'       => esc_html__( 'Rating Text', 'xcency-core' ),
		        'label_block'       => true,
		        'type'        => Controls_Manager::TEXT,
		        'default'     => esc_html__( '4.8 (125k reviews)', 'xcency-core' ),
		    ]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'image_team-_style',
		    [
		        'label' => esc_html__( 'Team Ratting', 'xcency-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_control(
		    'text_color',
		    [
		        'label'       => esc_html__('Color', 'xcency-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .xcency-team-rating-wrapper' => 'color: {{VALUE}};',
		        ],
		    ]
		);

		$this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$team_image_src = $settings['team_image']['url'];
		$team_image_alt = get_post_meta( $settings['team_image']['id'], '_wp_attachment_image_alt', true );

		$rating_image_src = $settings['rating_image']['url'];
		$rating_image_alt = get_post_meta( $settings['rating_image']['id'], '_wp_attachment_image_alt', true );
		?>

		<div class="xcency-team-rating-wrapper">
			<div class="xcecy-team-rating-left">
				<div class="team-image-and-title">
					<div class="xcecy-team-img">
						<img src="<?php echo $team_image_src;?>" alt="<?php echo $team_image_alt;?>">
					</div>

					<div class="xcency-team-text">
						<?php echo $settings['team_image_title'];?>
					</div>
				</div>

				<div class="xcency-team-image-desc">
					<?php echo $settings['desc'];?>
				</div>
			</div>

			<div class="xcecy-team-rating-right">
				<div class="rating-image">
					<img src="<?php echo $rating_image_src;?>" alt="<?php echo $rating_image_alt;?>">
				</div>

				<div class="rating-image-text">
					<?php echo $settings['rating_text'];?>
				</div>
			</div>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new Xcency_Team_Rating_Widget );