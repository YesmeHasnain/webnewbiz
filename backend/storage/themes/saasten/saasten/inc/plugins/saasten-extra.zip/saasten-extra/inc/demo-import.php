<?php 
/*
* @packge Saasten Extra
* @since 1.0.0
 */
function saasten_import() { 
  return array(
  
    array(
      'import_file_name'             => __('Main Demo','saasten-extra'),
      'page_title'                   => __('Import Demo Data','saasten-extra'),
      'local_import_file'            => SAASTEN_EXTRA_ROOT_PATH.'/demo/demo-data.xml',
      'local_import_widget_file'     => SAASTEN_EXTRA_ROOT_PATH.'/demo/widget.wie',
      'local_import_customizer_file' =>  SAASTEN_EXTRA_ROOT_PATH.'/demo/saasten-customizer.dat',
	  'import_preview_image_url'     => 'https://flawlessdigitalagency.com/demo-img/saasten.png',
      'import_notice'                => __( 'This import maybe finish on 2-3 minutes', 'saasten-extra' ),
	  'preview_url'                  => 'https://flawlessdigitalagency.com/saasten',

  ),    
  

);
}
add_filter( 'pt-ocdi/import_files', 'saasten_import' );


add_action( 'pt-ocdi/after_import',  'saasten_after_import' );

if(!function_exists( 'saasten_after_import')):
function saasten_after_import($selected_import) {
	
if ( 'Demo' === $selected_import['import_file_name'] ) {

	$main_menu = get_term_by('name', 'Main Nav', 'nav_menu');

    set_theme_mod( 'nav_menu_locations', array(
        'primary' => $main_menu->term_id,
     ) );

	//Set Front page

	$front_page_id = get_page_by_title( 'Home' );
	$blog_page_id  = get_page_by_title( 'Blog' );

	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $front_page_id->ID );
	update_option( 'page_for_posts', $blog_page_id->ID );
	
}}
endif;
