<?php

add_action( 'init', 'register_rival_Projects' );
function register_rival_Projects() {
    
$labels = array( 
    'name' => __( 'Projects', 'rival' ),
    'singular_name' => __( 'Projects', 'rival' ),
    'add_new' => __( 'Add New Projects', 'rival' ),
    'add_new_item' => __( 'Add New Projects', 'rival' ),
    'edit_item' => __( 'Edit Projects', 'rival' ),
    'new_item' => __( 'New Projects', 'rival' ),
    'view_item' => __( 'View Projects', 'rival' ),
    'search_items' => __( 'Search Projects', 'rival' ),
    'not_found' => __( 'No Projects found', 'rival' ),
    'not_found_in_trash' => __( 'No Projects found in Trash', 'rival' ),
    'parent_item_colon' => __( 'Parent Projects:', 'rival' ),
    'menu_name' => __( 'Projects', 'rival' ),
);

$args = array( 
    'labels' => $labels,
    'hierarchical' => true,
    'description' => 'List Projects',
    'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
    'taxonomies' => array( 'Projects', 'type1' ),
    'public' => true,
    'show_ui' => true,
    'show_in_menu' => true,
    'menu_position' => 5,
    'menu_icon' => 'dashicons-products', 
    'show_in_nav_menus' => true,
    'publicly_queryable' => true,
    'exclude_from_search' => false,
    'has_archive' => true,
    'query_var' => true,
    'can_export' => true,
    'rewrite' => true,
    'capability_type' => 'post'
);

register_post_type( 'Projects', $args );
}   

add_action( 'init', 'create_Type1_hierarchical_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

function create_Type1_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI

$labels = array(
    'name' => __( 'Type1', 'rival' ),
    'singular_name' => __( 'Type1', 'rival' ),
    'search_items' =>  __( 'Search Type1','rival' ),
    'all_items' => __( 'All Type1','rival' ),
    'parent_item' => __( 'Parent Type1','rival' ),
    'parent_item_colon' => __( 'Parent Type1:','rival' ),
    'edit_item' => __( 'Edit Type1','rival' ), 
    'update_item' => __( 'Update Type1','rival' ),
    'add_new_item' => __( 'Add New Type1','rival' ),
    'new_item_name' => __( 'New Type1 Name','rival' ),
    'menu_name' => __( 'Type1','rival' ),
  );     

// Now register the taxonomy

  register_taxonomy('type1',array('Projects'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type1' ),
  ));

}

?>