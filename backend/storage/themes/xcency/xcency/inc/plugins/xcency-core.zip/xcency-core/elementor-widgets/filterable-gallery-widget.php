<?php

namespace Elementor;

class Xcency_Filterable_Gallery_Widget extends Widget_Base {

	public function get_name() {

		return "xcency_filterable_gallery";
	}

	public function get_title() {
		return __( "Filterable Gallery", 'xcency-core' );
	}

	public function get_icon() {

		return "eicon-gallery-grid";
	}

	public function get_categories() {
		return [ 'xcency_core_elements' ];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'filter_button_section',
			[
				'label' => esc_html__( 'Filter Buttons', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'enable_filter_buttons',
			[
				'label'     => esc_html__( 'Enable Filter Buttons', 'xcency-core' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Yes', 'xcency-core' ),
				'label_off' => esc_html__( 'No', 'xcency-core' ),
				'default'   => 'yes',
			]
		);

		$this->add_control(
			'button_all_label',
			[
				'label'     => esc_html__( 'Button All Label', 'xcency-core' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => 'All',
				'condition' => [
					'enable_filter_buttons' => 'yes',
				],
			]
		);

		//Repeater Start
		$repeater = new Repeater();

		$repeater->add_control(
			'button_text',
			[
				'label'       => esc_html__( 'Button Label', 'xcency-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     =>  'Button Text',
				'label_block' => true,
			]
		);


		$this->add_control(
			'filter_buttons',
			[
				'label'       => esc_html__( 'Button List', 'xcency-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'button_text' => 'Button Text',
					],
				],
				'title_field' => '{{{ button_text }}}',
				'condition'   => [
					'enable_filter_buttons' => 'yes',
				],
			]
		);
		//Repeater End

		$this->add_responsive_control(
			'filter_button_align',
			[
				'label'   => esc_html__( 'Button Align', 'xcency-core' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'xcency-core' ),
						'icon'  => 'eicon-text-align-left',
					],

					'center' => [
						'title' => __( 'Center', 'xcency-core' ),
						'icon'  => 'eicon-text-align-center',
					],

					'right' => [
						'title' => __( 'Right', 'xcency-core' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .xcency-gallery-filter-button-wrapper' => 'text-align: {{VALUE}};',
				],

				'condition'   => [
					'enable_filter_buttons' => 'yes',
				],

			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'gallery_items_section',
			[
				'label' => esc_html__( 'Gallery Items', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		//Repeater Start
		$repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'       => __( 'Title', 'xcency-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 5,
				'default'     => 'Innovate Business Solutions',
			]
		);

		$repeater->add_control(
			'subtitle',
			[
				'label'       => __( 'Subtitle', 'xcency-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Digital Marketing',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'controls',
			[
				'label'       => esc_html__( 'Controls', 'xcency-core' ),
				'description' => esc_html__( 'Use buttons name from Filter Buttons settings. Separate multiple name with comma (e.g. Button Name 1, Button Name 2)', 'xcency-core' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'image',
			[
				'label'   => esc_html__( 'Image', 'xcency-core' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);


		$repeater->add_control(
			'link',
			[
				'label'         => esc_html__( 'Item Url', 'xcency-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_url( 'https://your-link.com' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'gallery_items',
			[
				'label'       => esc_html__( 'Gallery Lists', 'xcency-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title' => 'Innovate Business Solutions',
						'subtitle' => 'Digital Marketing',
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);
		//Repeater End

		$this->end_controls_section();

		$this->start_controls_section(
			'gallery_settings',
			[
				'label' => esc_html__( 'Column Settings', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'desktop_column',
			[
				'label'   => __( 'Desktop Column', 'xcency-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-xl-4',
				'options' => [
					'col-xl-12' => __( '1 Column', 'xcency-core' ),
					'col-xl-6'  => __( '2 Column', 'xcency-core' ),
					'col-xl-4'  => __( '3 Column', 'xcency-core' ),
					'col-xl-3'  => __( '4 Column', 'xcency-core' ),
				],
			]
		);

		$this->add_control(
			'ipad_pro_column',
			[
				'label'   => __( 'iPad Pro Column', 'xcency-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-lg-4',
				'options' => [
					'col-lg-12' => __( '1 Column', 'xcency-core' ),
					'col-lg-6'  => __( '2 Column', 'xcency-core' ),
					'col-lg-4'  => __( '3 Column', 'xcency-core' ),
					'col-lg-3'  => __( '4 Column', 'xcency-core' ),
				],
			]
		);

		$this->add_control(
			'ipad_column',
			[
				'label'   => __( 'iPad Column', 'xcency-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-md-6',
				'options' => [
					'col-md-12' => __( '1 Column', 'xcency-core' ),
					'col-md-6'  => __( '2 Column', 'xcency-core' ),
					'col-md-4'  => __( '3 Column', 'xcency-core' ),
				],
			]
		);

		$this->add_control(
			'mobile_column',
			[
				'label'   => __( 'Mobile Column', 'xcency-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-12',
				'options' => [
					'col-12' => __( '1 Column', 'xcency-core' ),
					'col-6'  => __( '2 Column', 'xcency-core' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'filter_button_style',
			[
				'label' => esc_html__( 'Filter Button', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'enable_filter_buttons' => 'yes',
				],
			]
		);

		$this->add_control(
			'button_bg_color',
			[
				'label'       => esc_html__('Background Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-gallery-filter-button-wrapper li' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_color',
			[
				'label'       => esc_html__('Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-gallery-filter-button-wrapper li' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_active_bg_color',
			[
				'label'       => esc_html__('Hover & Active Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-gallery-filter-button-wrapper li.active,{{WRAPPER}} .xcency-gallery-filter-button-wrapper li:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_active_color',
			[
				'label'       => esc_html__('Hover & Active Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-gallery-filter-button-wrapper li.active,{{WRAPPER}} .xcency-gallery-filter-button-wrapper li:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'mobile_filter_bg_color',
			[
				'label'       => esc_html__('Mobile Button Background', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-filter-mobile-title' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'item_style',
			[
				'label' => esc_html__( 'Gallery Item', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'overlay_bg_color',
			[
				'label'       => esc_html__('Overlay Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-project-item-details' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'top_link_bg',
			[
				'label'       => esc_html__('Details Arrow Background Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-project-item-details a' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	//Render In HTML
	protected function render() {
		$settings = $this->get_settings_for_display();
		$randId   = rand( 100, 10000 );
		$item_column = $settings['desktop_column'] . ' ' . $settings['ipad_pro_column'] . ' ' . $settings['ipad_column'] . ' ' . $settings['mobile_column'];
		?>

        <div class="xcency-gallery-items-main-container">

			<?php if ( $settings['enable_filter_buttons'] == 'yes' ) : ?>
                <div class="row">
                    <div class="col-lg-12 xcency-gallery-filter-button-wrapper">
                        <div class="xcency-filter-mobile-title mt-<?php echo $randId ?>"><?php echo $settings['button_all_label'] ?></div>
                        <ul class="xcency-list-style xcency-list-inline xcency-gallery-filter-button fbtn-<?php echo $randId ?>">
                            <li class="active" data-filter="*"><span
                                        class="title-text"> <?php echo $settings['button_all_label'] ?> </span></li>
							<?php
							if ( $settings['filter_buttons'] ) {
								foreach ( $settings['filter_buttons'] as $button ) {
									echo '<li data-filter=".' . xcency_core_class_sorter( $button['button_text'] ) . '"><span class="title-text">' . $button['button_text'] . '</span></li>';
								}
							}
							?>
                        </ul>
                    </div>
                </div>
			<?php endif; ?>


            <div class="row xcency-project-slider-two-wrapper xcency-gallery-item-wrapper xcency-gallery-grid-<?php echo $randId ?>">

				<?php if ( $settings['gallery_items'] ) {
					foreach ( $settings['gallery_items'] as $gallery_item ) {
						$controls_name = xcency_core_class_sorter( $gallery_item['controls'] );
						$target        = $gallery_item['link']['is_external'] ? ' target="_blank"' : '';
						$nofollow      = $gallery_item['link']['nofollow'] ? ' rel="nofollow"' : '';
						?>

                        <div class="<?php echo $item_column;?>  single-xcency-gallery-item <?php echo $controls_name; ?>">

                            <div class="xcency-single-project-item-wrapper">
                                <div class="xcency-single-project-item">
                                    <div class="xcency-project-image">
                                        <img src="<?php echo $gallery_item['image']['url']; ?>"
                                             alt="<?php echo get_post_meta( $gallery_item['image']['id'], '_wp_attachment_image_alt', true ); ?>">

                                        <div class="xcency-project-item-details">
                                            <a href="<?php echo esc_url( $gallery_item['link']['url'] ); ?>" <?php echo  $target . $nofollow?>><i class="fas fa-arrow-right"></i></a>
                                        </div>
                                    </div>

                                    <div class="xcency-project-content-wrapper">
                                        <div class="xcency-project-title-subtitle">
                                            <a href="<?php echo esc_url( $gallery_item['link']['url'] ); ?>" class="project-title" <?php echo  $target . $nofollow?>><?php echo $gallery_item['title'];?></a>
                                            <p class="project-subtitle"><?php echo $gallery_item['subtitle'];?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
						<?php
					}
				} ?>
            </div>
        </div>

        <script>
            jQuery(window).on('load',function ($) {

                jQuery(".xcency-gallery-grid-<?php echo $randId?>").imagesLoaded(function () {
                    jQuery(".mt-<?php echo $randId ?>").on("click", function () {
                        jQuery(this).toggleClass("active").next(".fbtn-<?php echo $randId?>").slideToggle();
                        return false;
                    });

                    jQuery(".fbtn-<?php echo $randId?> li").on("click", function () {
                        if (jQuery(this).hasClass("active")) return false;
                        jQuery(".mt-<?php echo $randId?>, .fbtn-<?php echo $randId?> li").removeClass("active");
                        jQuery(this).addClass("active");
                        jQuery(".mt-<?php echo $randId?>").text(jQuery(this).find(".title-text").text());
                        if (jQuery(".mt-<?php echo $randId?>").is(":visible")) jQuery(".fbtn-<?php echo $randId?>").slideUp();
                        var filterValue = jQuery(this).attr("data-filter");
                        $grid.isotope({filter: filterValue});
                    });

                    var $grid = jQuery(".xcency-gallery-grid-<?php echo $randId?>").isotope({
                        itemSelector: ".single-xcency-gallery-item",
                        percentPosition: true,
                        transitionDuration: '.8s',
                        masonry: {
                            columnWidth: 1
                        }
                    });
                });
            });
        </script>
		<?php
	}
}

Plugin::instance()->widgets_manager->register( new Xcency_Filterable_Gallery_Widget );