<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsTeamGrid extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-team-grid';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Team Grid', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-posts-grid';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-team' ];
	}

	public function get_keywords() {
		return [ 'teamgrid', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}
	

	protected function _register_controls() {		
		$this->start_controls_section(
			'section_content_team_grid',
			[
				'label' => esc_html__( 'Team Grid', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'img_bg_sec',
			[
				'label'       	=> esc_html__( 'Image Background Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image background section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'heading_sec',
			[
				'label' 		=> esc_html__( 'Heading Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Our Team' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Expert team' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_sec',
			[
				'label' 		=> esc_html__( 'Text Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Meet our dynamic team...' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'img_icon_share',
			[
				'label'       	=> esc_html__( 'Image Icon Share', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image icon share', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'post_number',
			[
				'label'       => __( 'Post Number', 'bdevs-elementor' ),
				'type'        => Controls_Manager::NUMBER,
				'placeholder' => __( 'Enter your post number', 'bdevs-elementor' ),
				'min'		  => 0,
				'default'     => __( '9', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order_by',
			[
				'label'       => __( 'Post Order By', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text post order by', 'bdevs-elementor' ),
				'default'     => __( 'ID', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
				],
				'default'   => 'desc',
			]
		);
		$this->add_control(
			'show_pagi',
			[
				'label'   => esc_html__( 'Show Pagination', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-team-ptb pt-200 p-relative">
	<?php if (!empty($settings['img_bg_sec']['url'])): ?>
		<div class="tp-about-me-bg" data-background="<?php echo wp_kses_post($settings['img_bg_sec']['url']); ?>"></div>
	<?php endif ?>
	<?php if (!empty($settings['heading_sec']) || !empty($settings['title_sec']) || !empty($settings['text_sec'])): ?>
		<div class="container container-1720">
			<div class="tp-team-top-border">
				<div class="row">
					<div class="col-lg-7">
						<?php if (!empty($settings['heading_sec']) || !empty($settings['title_sec'])): ?>
							<div class="tp-team-heading pl-200 mb-40">
								<?php if (!empty($settings['heading_sec'])): ?>
									<span class="tp-breadcrumb-subtitle"><?php echo wp_kses_post($settings['heading_sec']); ?></span>
								<?php endif ?>
								<?php if (!empty($settings['title_sec'])): ?>
									<h3 class="tp-breadcrumb-title tp-title-anim"><?php echo wp_kses_post($settings['title_sec']); ?></h3>
								<?php endif ?>
							</div>
						<?php endif ?>
					</div>
					<?php if (!empty($settings['text_sec'])): ?>
						<div class="col-lg-5">
							<div class="tp-team-us-heading pt-150">
								<p><?php echo wp_kses_post($settings['text_sec']); ?></p>
							</div>
						</div>
					<?php endif ?>
				</div>
			</div>
		</div>
	<?php endif ?>
	<div class="tp-team-inner-wrap pt-120 pb-70">
		<div class="container">
			<div class="row">
				<?php
				$paged = max(1, get_query_var('paged', get_query_var('page', 1)));
				$wp_query = new \WP_Query(array(
					'post_type' => 'team',
					'paged' => $paged,
					'posts_per_page' => wp_kses_post($settings['post_number']),
					'orderby' => wp_kses_post($settings['post_order_by']),
					'order' => wp_kses_post($settings['post_order']),
				));

				while($wp_query->have_posts()): $wp_query->the_post();
				?>
					<div class="col-lg-4 col-md-6">
						<div class="tp-team-inner-item mb-80">
							<div class="tp-team-inner-item-thumb">
								<?php if (has_post_thumbnail()) { ?>
									<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title_attribute(); ?>">
								<?php } else { ?>
									<img src="<?php echo get_template_directory_uri(); ?>/assets/img/team/team/team-thumb-1.jpg" alt="<?php the_title_attribute(); ?>">
								<?php } ?>
								<div class="tp-team-inner-item-social">
									<button class="tp-team-inner-item-social-icon">
										<img src="<?php echo wp_kses_post($settings['img_icon_share']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_icon_share']['alt']); ?>">
									</button>
									<div class="tp-team-inner-item-social-icons">
										<?php 
										$social_links = [
											['link' => get_post_meta(get_the_ID(), '_cmb_link_social_1', true), 'icon' => get_post_meta(get_the_ID(), '_cmb_icon_social_1', true)],
											['link' => get_post_meta(get_the_ID(), '_cmb_link_social_2', true), 'icon' => get_post_meta(get_the_ID(), '_cmb_icon_social_2', true)],
											['link' => get_post_meta(get_the_ID(), '_cmb_link_social_3', true), 'icon' => get_post_meta(get_the_ID(), '_cmb_icon_social_3', true)],
											['link' => get_post_meta(get_the_ID(), '_cmb_link_social_4', true), 'icon' => get_post_meta(get_the_ID(), '_cmb_icon_social_4', true)],
										]; ?>
										<?php foreach ($social_links as $social) :
											if (!empty($social['link']) && !empty($social['icon'])) : ?>
												<a href="<?php echo esc_url($social['link']); ?>">
													<span><?php echo nixer_inline_svg_from_url($social['icon']); ?></span>
												</a>
											<?php endif;
										endforeach; ?>
									</div>
								</div>
							</div>
							<div class="tp-team-inner-item-content">
								<h4 class="tp-team-inner-item-title">
									<a class="textline" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
								</h4>
								<span>
									<?php
									$terms = get_the_terms(get_the_ID(), 'team-job');
									if ($terms && !is_wp_error($terms)) {
									    echo esc_html($terms[0]->name);
									} ?>
								</span>
							</div>
						</div>
					</div>
				<?php endwhile; ?>
				<?php if (!empty($settings['show_pagi'])): ?>
					<?php 
					$big = 999999999;
					$pagination = array(
						'base'      	=> str_replace($big, '%#%', get_pagenum_link($big)),
						'format'    	=> '',
						'current'   	=> $paged,
						'total'     	=> $wp_query->max_num_pages,
						'prev_text'     => wp_specialchars_decode('<i class="fa-regular fa-arrow-left icon"></i>', ENT_QUOTES),
						'next_text'     => wp_specialchars_decode('<i class="fa-regular fa-arrow-right icon"></i>', ENT_QUOTES),
						'type'      	=> 'list',
						'end_size'    	=> 3,
						'mid_size'    	=> 3
					);
					$pagination_links = paginate_links($pagination);
					if (!empty($pagination_links)): ?>
						<div class="basic-pagination text-center mt-80">
							<nav>
								<?php 
								echo str_replace("<ul class='page-numbers'>", '<ul class="page-pagination">', $pagination_links); 
								?>
							</nav>
						</div>
					<?php endif; ?>
				<?php endif ?>
			</div>
		</div>
	</div>
</section>

<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-background]").each(function () {
			jQuery(this).css("background-image", "url( " + $(this).attr("data-background") + "  )");
		});
	</script>
<?php } ?>

<?php
}

}