<?php
return array(
	'title'      => 'Earls Menu Setting',
	'id'         => 'earls_meta_menu',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'menu' ),
	'sections'   => array(
		array(
			'id'     => 'earls_menu_meta_setting',
			'fields' => array(
				
				array(
					'id'    => 'menu_price',
					'type'  => 'text',
					'title' => esc_html__( 'Enter The Price', 'earls' ),
				),
			),
		),
	),
);