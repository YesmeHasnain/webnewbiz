<?php
namespace Elementor;

class Xcency_Video_Popup_Widget extends Widget_Base {

	public function get_name() {

		return 'xcency_video_popup';
	}

	public function get_title() {
		return esc_html__( 'Video Popup', 'xcency-core' );
	}

	public function get_icon() {

		return 'eicon-youtube';
	}

	public function get_categories() {
		return [ 'xcency_core_elements' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'video_popup_options',
			[
				'label' => esc_html__( 'Video Popup', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
		    'video_url',
		    [
		        'label'       => __( 'Video URL', 'xcency-core' ),
		        'label_block'       => true,
		        'type'        => Controls_Manager::TEXT,
		        'default'     => 'https://vimeo.com/100902001',
		    ]
		);

        $this->add_control(
            'enable_caption',
            [
                'label'     => esc_html__( 'Enable Caption', 'xcency-core' ),
                'type'      => Controls_Manager::SWITCHER,
                'label_on'  => esc_html__( 'Yes', 'xcency-core' ),
                'label_off' => esc_html__( 'No', 'xcency-core' ),
                'default'   => 'no',
            ]
        );

        $this->add_control(
            'caption_text',
            [
                'label'       => esc_html__( 'Caption Text', 'xcency-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'rows'        => 5,
                'default'     => esc_html__( 'Trusted By 25,880+ Worldwide Brand & Customers', 'xcency-core' ),
                'condition' => [
                    'enable_caption' => 'yes',
                ],
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
		    'video_popup_style',
		    [
		        'label' => esc_html__( 'Video Popup', 'xcency-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_responsive_control(
		    'video_height',
		    [
		        'label' => esc_html__( 'Height', 'xcency-core' ),
		        'type' => Controls_Manager::SLIDER,
		        'size_units' => ['px'],
		        'range' => [
		            'px' => [
		                'min' => 0,
		                'max' => 1000,
		            ],
		        ],
		        'devices' => [ 'desktop', 'tablet', 'mobile' ],

		        'selectors' => [
		            '{{WRAPPER}} .xcency-img-with-video .xcency-video-image' => 'height: {{SIZE}}px;',
		        ],
		    ]
		);

        $this->add_control(
            'video_btn_bg',
            [
                'label'       => esc_html__('Button Background', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .xcency-video-button-two:before,{{WRAPPER}} .xcency-video-button-two:after' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'video_btn_color',
            [
                'label'       => esc_html__('Button Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .xcency-video-button-two i' => 'color: {{VALUE}};',
                ],
            ]
        );


		$this->add_responsive_control(
			'btn_size',
			[
				'label' => esc_html__( 'Button Size', 'xcency-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .xcency-video-button-two:before,{{WRAPPER}} .xcency-video-button-two:after' => 'height: {{SIZE}}px;width: {{SIZE}}px;',
				],
			]
		);

		$this->add_responsive_control(
		    'wrapper_margin',
		    [
		        'label'      => esc_html__( 'Margin', 'xcency-core' ),
		        'type'       => Controls_Manager::DIMENSIONS,
		        'size_units' => [ 'px', '%', 'em' ],
		        'selectors'  => [
		            '{{WRAPPER}} .xcency-img-with-video' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
		        ],
		    ]
		);

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'wrapper_background',
                'label' => esc_html__( 'Wrapper Background', 'xcency-core' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .xcency-video-image',
            ]
        );

        $this->add_responsive_control(
            'video_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'xcency-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],

                'selectors' => [
                    '{{WRAPPER}} .xcency-video-image' => 'border-radius: {{SIZE}}px;',
                ],
            ]
        );

        $this->add_control(
            'caption_bg_color',
            [
                'label'       => esc_html__('Caption Background', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .video-caption-wrapper' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'caption_color',
            [
                'label'       => esc_html__('Caption Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .video-caption-wrapper' => 'color: {{VALUE}};',
                ],
            ]
        );

		$this->add_control(
			'close_icon_color',
			[
				'label'       => esc_html__('Popup Close Background', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
			]
		);

		$this->add_control(
			'close_icon_cross_color',
			[
				'label'       => esc_html__('Popup Close Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
			]
		);

		$this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<div class="xcency-img-with-video">
			<div class="xcency-video-image xcency-cover-bg">
				<a href="<?php echo $settings['video_url'];?>" class="xcency-video-button-two mfp-iframe">
					<i class="fas fa-play"></i>
				</a>
                
                <?php if ($settings['enable_caption'] == 'yes') :?>
                    <div class="video-caption-wrapper">
                        <?php echo $settings['caption_text'];?>
                    </div>
                <?php endif; ?>
			</div>
		</div>

        <script>
            jQuery(document).ready(function ($) {
                $(".xcency-video-button-two").magnificPopup({
                    type: 'video',
                    mainClass: 'xcency-mfp-<?php echo $this->get_id();?>',
                });
            });
        </script>

		<?php if ($settings['close_icon_color']) :?>
            <style>
                .xcency-mfp-<?php echo $this->get_id();?> .mfp-close{
                    background-color: <?php echo $settings['close_icon_color'];?>;
                    color: <?php echo $settings['close_icon_cross_color'];?>;

                }
            </style>
		<?php endif; ?>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new Xcency_Video_Popup_Widget );