<?php
/**
* 
* @version  1.0
* @package  barab
* @author   Themeholy ( themeholy@gmail.com )
*
**/

/**************************************
* Creating Offer Banner Widget
***************************************/

class barab_offer_banner_widget extends WP_Widget {

    function __construct() {
        parent::__construct(
            'barab_offer_banner_widget',
            esc_html__( 'Barab :: Offer Banner Widget', 'barab' ),
            array(
                'customize_selective_refresh' => true,
                'description'                 => esc_html__( 'Add Offer Banner Widget', 'barab' ),
                'classname'                   => 'no-banner-widget',
            )
        );
    }

    // Front-end display
    public function widget( $args, $instance ) {
        $banner_title = apply_filters( 'widget_banner_title', $instance['banner_title'] );
        $button_text  = apply_filters( 'widget_button_text', $instance['button_text'] );

        $banner_img_url = isset( $instance['banner_img_url'] ) ? $instance['banner_img_url'] : '';
        $button_url     = isset( $instance['button_url'] ) ? $instance['button_url'] : '#';

        echo $args['before_widget'];

        echo '<div class="widget widget_banner  " data-bg-src="'.esc_url($banner_img_url ).'">';
            echo '<div class="widget-banner text-center">';
                if(!empty($button_text)){
                    echo '<a href="'.esc_url( $button_url ).'" class="th-btn btn-mask btn-sm style3">'.esc_html( $button_text ).' <i class="far fa-long-arrow-right ms-2"></i></a>';
                }
                if(!empty($button_text)){
                    echo '<p class="text-des">'.esc_html( $banner_title ).'</p>';
                }
            echo '</div>';
        echo '</div>';

        echo $args['after_widget'];
    }

    // Backend form
    public function form( $instance ) {
        $banner_img_url = isset( $instance['banner_img_url'] ) ? $instance['banner_img_url'] : '';
        $banner_title   = isset( $instance['banner_title'] ) ? $instance['banner_title'] : '';
        $button_text    = isset( $instance['button_text'] ) ? $instance['button_text'] : '';
        $button_url     = isset( $instance['button_url'] ) ? $instance['button_url'] : '';

        ?>
        <p>
            <label for="<?php echo $this->get_field_id( 'banner_img_url' ); ?>"><?php _e( 'Image URL:', 'barab' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'banner_img_url' ); ?>" name="<?php echo $this->get_field_name( 'banner_img_url' ); ?>" type="text" value="<?php echo esc_attr( $banner_img_url ); ?>" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'button_text' ); ?>"><?php _e( 'Button Text:', 'barab' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'button_text' ); ?>" name="<?php echo $this->get_field_name( 'button_text' ); ?>" type="text" value="<?php echo esc_attr( $button_text ); ?>" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'button_url' ); ?>"><?php _e( 'Button URL:', 'barab' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'button_url' ); ?>" name="<?php echo $this->get_field_name( 'button_url' ); ?>" type="text" value="<?php echo esc_attr( $button_url ); ?>" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'banner_title' ); ?>"><?php _e( 'Banner Title:', 'barab' ); ?></label>
            <textarea class="widefat" id="<?php echo $this->get_field_id( 'banner_title' ); ?>" name="<?php echo $this->get_field_name( 'banner_title' ); ?>" rows="2"><?php echo esc_html( $banner_title ); ?></textarea>
        </p>

        <?php
    }

    // Updating widget instance
    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['banner_img_url'] = ( ! empty( $new_instance['banner_img_url'] ) ) ? strip_tags( $new_instance['banner_img_url'] ) : '';
        $instance['banner_icon_url']     = ( ! empty( $new_instance['banner_icon_url'] ) ) ? strip_tags( $new_instance['banner_icon_url'] ) : '';
        $instance['banner_title']   = ( ! empty( $new_instance['banner_title'] ) ) ? strip_tags( $new_instance['banner_title'] ) : '';
        $instance['button_text']    = ( ! empty( $new_instance['button_text'] ) ) ? strip_tags( $new_instance['button_text'] ) : '';
        $instance['button_url']     = ( ! empty( $new_instance['button_url'] ) ) ? strip_tags( $new_instance['button_url'] ) : '';
        return $instance;
    }

} // Class ends


// Register the widget
function barab_offer_banner_load_widget() {
    register_widget( 'barab_offer_banner_widget' );
}
add_action( 'widgets_init', 'barab_offer_banner_load_widget' );
