<?php

namespace EARLSPLUGIN\Element;


class Elementor {
	static $widgets = array(
		//Home Page One
		'banner',
		'hero_title',
		'about_image',
		'animation_image',
		'button',
		'features',
		'float_image',
		'menus',
		'video_section',
		'accordian',
		'image_widget',
		'table_booking_tab',
		'portfolio_carousel',
		'testimonials_carousel',
		'blog_grid',
		
		//Home Page Two
		'reservation_form', 
		'menu_full',
		'team_carousel',
		'newsletter_form',
		
		//Home Page Three
		'feature_image_box',
		'client_section',
		'menu_tabs',
		'menu_tabs_v2',
		'product_grid',
		'team_grid',
		'about_us',
		'coming_soon',
		'portfolio_grid',
		'product_tabs',
		'contact_info_box',
		'form'
	);

	static function init() {
		add_action( 'elementor/init', array( __CLASS__, 'loader' ) );
		add_action( 'elementor/elements/categories_registered', array( __CLASS__, 'register_cats' ) );
	}

	static function loader() {

		foreach ( self::$widgets as $widget ) {

			$file = EARLSPLUGIN_PLUGIN_PATH . '/elementor/' . $widget . '.php';
			if ( file_exists( $file ) ) {
				require_once $file;
			}

			add_action( 'elementor/widgets/widgets_registered', array( __CLASS__, 'register' ) );
		}
	}

	static function register( $elemntor ) {
		foreach ( self::$widgets as $widget ) {
			$class = '\\EARLSPLUGIN\\Element\\' . ucwords( $widget );

			if ( class_exists( $class ) ) {
				$elemntor->register_widget_type( new $class );
			}
		}
	}

	static function register_cats( $elements_manager ) {

		$elements_manager->add_category(
			'earls',
			[
				'title' => esc_html__( 'Earls', 'earls' ),
				'icon'  => 'fa fa-plug',
			]
		);
		$elements_manager->add_category(
			'templatepath',
			[
				'title' => esc_html__( 'Template Path', 'earls' ),
				'icon'  => 'fa fa-plug',
			]
		);

	}
}

Elementor::init();