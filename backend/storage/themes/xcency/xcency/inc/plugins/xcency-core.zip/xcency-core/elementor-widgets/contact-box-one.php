<?php

namespace Elementor;
class Xcency_Contact_Box_One_Widget extends Widget_Base {

    public function get_name() {

        return "xcency_contact_box_one";
    }

    public function get_title() {
        return __( "Contact Box One", "xcency-core" );
    }

    public function get_icon() {

        return "flaticon-map-1";
    }

    public function get_categories() {
        return [ 'xcency_core_elements' ];
    }


    protected function register_controls() {
        //Content tab start
        $this->start_controls_section(
            'contact_box_settings',
            [
                'label' => __( 'Contact Box', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'title',
            [
                'label'       => __( 'Title', 'xcency-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => 'Office Address',
                'label_block' => true,
            ]
        );

	    $repeater->add_control(
		    'desc', [
			    'label' => esc_html__( 'Description', 'xcency-core' ),
			    'type' => Controls_Manager::WYSIWYG,
			    'default' => '
                                <ul>
                                <li><a href="mailto:support@quintexbd.com">support@quintexbd.com</a></li>
                                <li><a href="tel: 123456">+000 (123) 444 55 88</a></li>
                                </ul>
                            ',
			    'label_block' => true,
		    ]
	    );

        $repeater->add_control(
            'selected_icon',
            [
                'label'            => esc_html__( 'Select Icon', 'xcency-core' ),
                'type'             => Controls_Manager::ICONS,
                'fa4compatibility' => 'icon',
                'label_block'      => true,
                'default'          => [
                    'value'   => 'flaticon-maps-and-flags',
                    'library' => 'xcency-icon',
                ],
            ]
        );

        $this->add_control(
            'contacts',
            [
                'label'       => __( 'Contact List', 'xcency-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [
                    [
                        'title' => 'Office Address',
                        'desc' => '
                            <ul>
                                <li><a href="mailto:support@quintexbd.com">support@quintexbd.com</a></li>
                                <li><a href="tel: 123456">+000 (123) 444 55 88</a></li>
                                </ul>
                        ',
                    ],
                ],
                'title_field' => '{{{ title }}}',
            ]
        );

        $this->end_controls_section();



        $this->start_controls_section(
            'contact_layout_settings',
            [
                'label' => __( 'Contact Column', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'desktop_col',
            [
                'label'   => __( 'Columns On Desktop', 'xcency-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'col-xl-4',
                'options' => [
                    'col-xl-12' => __( '1 Column', 'xcency-core' ),
                    'col-xl-6'  => __( '2 Column', 'xcency-core' ),
                    'col-xl-4'  => __( '3 Column', 'xcency-core' ),
                    'col-xl-3'  => __( '4 Column', 'xcency-core' ),
                ],
            ]
        );

        $this->add_control(
            'iPad_pro_col',
            [
                'label'   => __( 'Columns On iPad Pro', 'xcency-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'col-lg-4',
                'options' => [
                    'col-lg-12' => __( '1 Column', 'xcency-core' ),
                    'col-lg-6'  => __( '2 Column', 'xcency-core' ),
                    'col-lg-4'  => __( '3 Column', 'xcency-core' ),
                    'col-lg-3'  => __( '4 Column', 'xcency-core' ),
                ],
            ]
        );

        $this->add_control(
            'tab_col',
            [
                'label'   => __( 'Columns On Tablet', 'xcency-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'col-md-6',
                'options' => [
                    'col-md-12' => __( '1 Column', 'xcency-core' ),
                    'col-md-6'  => __( '2 Column', 'xcency-core' ),
                    'col-md-4'  => __( '3 Column', 'xcency-core' ),
                    'col-md-3'  => __( '4 Column', 'xcency-core' ),
                ],
            ]
        );

        $this->end_controls_section();
    }


    //Render In HTML
    protected function render() {
        $settings = $this->get_settings_for_display();
	    $column = $settings['desktop_col'] . ' ' . $settings['iPad_pro_col'] . ' ' . $settings['tab_col'];
        ?>

        <div class="xcency-contact-box-wrapper">
            <div class="row">
                <?php if ( $settings['contacts'] ) {
                    foreach ( $settings['contacts'] as $contact ) {
                        ?>
                        <div class="<?php echo $column;?>">
                            <div class="contact-box-one-item">

                                <div class="contact-one-icon">
                                    <?php xcency_custom_icon_render($contact, 'icon', 'selected_icon'); ?>
                                </div>

                                <div class="contact-one-content">
                                    <h4 class="xcency-contact-one-title"><?php echo $contact['title'];?></h4>

                                    <div class="xcency-contact-one-desc xcency-last-p-0">
                                        <?php echo $contact['desc'];?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php }
                } ?>
            </div>
        </div>
        <?php

    }
}

Plugin::instance()->widgets_manager->register( new Xcency_Contact_Box_One_Widget );