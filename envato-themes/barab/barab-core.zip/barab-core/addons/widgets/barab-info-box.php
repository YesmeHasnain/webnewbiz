<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Info Box Widget .
 *
 */
class barab_Info_Box extends Widget_Base {

	public function get_name() {
		return 'barabinfobox';
	}
	public function get_title() {
		return __( 'Info Box', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		 $this->start_controls_section(
			'section_title_section',
			[
				'label'		 	=> __( 'Info Box', 'barab' ),
				'tab' 			=> Controls_Manager::TAB_CONTENT,
				
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two' ] ); 

		barab_media_fields($this, 'image', 'Choose Image', ['2'] );
		barab_media_fields($this, 'image2', 'Choose Image 2', ['2'] );

		barab_general_fields( $this, 'subtitle', 'Subtitle', 'TEXTAREA2', 'Restaurant Location', ['1', '2'] );
		barab_media_fields($this, 'shape', 'Choose Subtitle Shape', ['2'] );
		barab_general_fields( $this, 'title', 'Title', 'TEXTAREA2', 'Visit Our restaurant', ['1', '2'] );
		barab_general_fields( $this, 'title2', 'Title 2', 'TEXTAREA2', '', ['2'] );
		barab_general_fields( $this, 'desc', 'Description', 'TEXTAREA', 'Content', ['1'] );
		barab_general_fields( $this, 'content', 'Content', 'TEXTAREA', '', ['1'] );

		$repeater = new Repeater();

		barab_media_fields($repeater, 'image', 'Choose Image' );
		barab_general_fields($repeater, 'title', 'Title', 'TEXTAREA2', 'Initial process');
		barab_url_fields($repeater, 'button_url', 'Button URL');

		$this->add_control(
			'feature_list',
			[
				'label' 		=> __( 'Features Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'Initial Consultation', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['2']
				]
			]
		);
		
		barab_general_fields($this, 'button_text', 'Button Text', 'TEXT', 'Viw All List', ['2']);
		barab_url_fields($this, 'button_url', 'Button URL', ['2']);


		barab_social_fields($this, 'social_icon_list', 'Social List', ['1']);

		$this->end_controls_section();

        //---------------------------------------
			//Style Section Start 
		//---------------------------------------
		barab_common_style_fields( $this, '01', 'Subtitle', '{{WRAPPER}} .sub-title', ['1'] );
		barab_common_style_fields( $this, '011', 'Subtitle', '{{WRAPPER}} .top-title', ['2'] );
		barab_common_style_fields( $this, '02', 'Title', '{{WRAPPER}} .sec-title', ['1'] );
		barab_common_style_fields( $this, '022', 'Title', '{{WRAPPER}} .box-title', ['2'] );
		barab_common_style_fields( $this, '03', 'Description', '{{WRAPPER}} .box-text', ['1'] );
		barab_common_style_fields( $this, '021', 'Content', '{{WRAPPER}} .opening p', ['1'] );

	}

	protected function render() {

        $settings = $this->get_settings_for_display();

			if( $settings['layout_style'] == '1' ){
				echo '<div class="title-area location-content">';
					if(!empty($settings['subtitle'])){
						echo '<span class="sub-title style-2 text-anime-style-1">'.esc_html($settings['subtitle']).'</span>';
					}
					if(!empty($settings['title'])){
						echo '<h2 class="sec-title text-anime-style-2">'.esc_html($settings['title']).'</h2>';
					}
					if(!empty($settings['desc'])){
						echo '<p class="box-text pe-xl-5 ps-xl-5 text-anime-style-3">'.esc_html($settings['desc']).'</p>';
					}
					if(!empty($settings['content'])){
						echo '<div class="line"></div>';
						echo '<div class="opening ow fadeinup" data-wow-delay=".3s">'.wp_kses_post($settings['content']).'</div>';
					}
					echo '<div class="th-social ow fadeinup" data-wow-delay=".5s">';
						foreach( $settings['social_icon_list'] as $social_icon ){
							$social_target    = $social_icon['icon_link']['is_external'] ? ' target="_blank"' : '';
							$social_nofollow  = $social_icon['icon_link']['nofollow'] ? ' rel="nofollow"' : '';
		
							echo '<a '.wp_kses_post( $social_target.$social_nofollow ).' href="'.esc_url( $social_icon['icon_link']['url'] ).'">';
		
							\Elementor\Icons_Manager::render_icon( $social_icon['social_icon'], [ 'aria-hidden' => 'true' ] );
		
							echo '</a> ';
						}
					echo '</div>';
				echo '</div>';
				 
			}elseif( $settings['layout_style'] == '2' ){
				echo '<div class="row gy-4">';
					echo '<div class="col-lg-2">';
						if($settings['image']['url'] ){
							echo '<div class="since-1-left wow fadeinleft">';
								echo barab_img_tag( array(
									'url'   => esc_url( $settings['image']['url'] ),
								)); 
							echo '</div>';
						}
					echo '</div>';
					echo '<div class="col-lg-8">';
						echo '<div class="since-1-content wow fadeinleft">';
							if(!empty($settings['subtitle'])){
								echo '<div class="top-wrap">';
									echo '<div class="top-title">';
										echo '<img src="'.BARAB_ASSETS.'img/icon/star-small.svg" alt="'.esc_attr__('Shape', 'barab').'"> ';
										echo wp_kses_post($settings['subtitle']);
										echo '<img src="'.BARAB_ASSETS.'img/icon/star-small.svg" alt="'.esc_attr__('Shape', 'barab').'">';
									echo '</div>';
									if($settings['shape']['url'] ){
										echo barab_img_tag( array(
											'url'   => esc_url( $settings['shape']['url'] ),
										)); 
									}
								echo '</div>';
							}
							if(!empty($settings['title'])){
								echo '<h4 class="box-title">'.wp_kses_post($settings['title']).'</h4>';
							}
							if(!empty($settings['title2'])){
								echo '<h4 class="box-title">'.wp_kses_post($settings['title2']).'</h4>';
							}
						echo '</div>';
					echo '</div>';
					echo '<div class="col-lg-2">';
						if($settings['image2']['url'] ){
							echo '<div class="since-1-right fadeinleft">';
								echo barab_img_tag( array(
									'url'   => esc_url( $settings['image2']['url'] ),
								)); 
							echo '</div>';
						}
					echo '</div>';
				echo '</div>';

			}


	}

}