<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Choose Us Widget .
 *
 */
class barab_Choose_Us extends Widget_Base {

	public function get_name() {
		return 'barabchooseus';
	}
	public function get_title() {
		return __( 'Choose Us', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		 $this->start_controls_section(
			'section_title_section',
			[
				'label'		 	=> __( 'Choose Us', 'barab' ),
				'tab' 			=> Controls_Manager::TAB_CONTENT,
				
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two' ] );

		
		barab_general_fields( $this, 'subtitle', 'Subtitle', 'TEXTAREA2', 'WHY CHOOSE US', ['1'] );
		barab_general_fields( $this, 'title', 'Title', 'TEXTAREA2', 'Our goal is to build a world where technology serves humanity.', ['1'] );

		barab_media_fields( $this, 'image', 'Choose Image', ['1', '2'] );

		$repeater = new Repeater();

		barab_media_fields($repeater, 'image', 'Choose Image');
		barab_general_fields($repeater, 'title', 'Title', 'TEXTAREA2', 'Technology Integration');
		barab_general_fields($repeater, 'description', 'Description', 'TEXTAREA', 'We bring a team of experienced AI specialists, data scientists, and industry experts committed to pushing.'); 

		$this->add_control(
			'feature_list',
			[
				'label' 		=> __( 'Features Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'Technology Integration', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['1']
				]
			]
		);

		$repeater = new Repeater();

		barab_general_fields($repeater, 'title', 'Title', 'TEXTAREA2', 'Technology Integration');
		barab_general_fields($repeater, 'description', 'Description', 'TEXTAREA', 'We bring a team of experienced AI specialists, data scientists, and industry experts committed to pushing.'); 

		$this->add_control(
			'feature_list2',
			[
				'label' 		=> __( 'Features Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'Technology Integration', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['2']
				]
			]
		);

		barab_media_fields( $this, 'section_curve_shape', 'Section Curve Shape', ['1'] );
		barab_switcher_fields($this, 'show_shape', 'Show Shape?', ['1']);

        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------

		barab_common_style_fields( $this, '1', 'Section Subtitle', '{{WRAPPER}} .sub-title', ['1'] );
		barab_common_style_fields( $this, '2', 'Section Title', '{{WRAPPER}} .sec-title', ['1'] );

		barab_common_style_fields($this, '21', 'Feature Title', '{{WRAPPER}} .feature-title', ['1'] );
		barab_common_style_fields($this, '22', 'Feature Content', '{{WRAPPER}} .feature-text', ['1'] );

		barab_common_style_fields($this, '31', 'Feature Title', '{{WRAPPER}} .box-title3', ['2'] );
		barab_common_style_fields($this, '32', 'Feature Content', '{{WRAPPER}} .box-text', ['2'] );

	}


	protected function render() {


        $settings = $this->get_settings_for_display();

			if( $settings['layout_style'] == '1' ){
				echo '<div class="why-sec-1 space overflow-hidden shape-mockup-wrap">';
					echo barab_img_tag( array(
						'url'   => esc_url( $settings['section_curve_shape']['url'] ),
						'class' => 'round-shape-bottom'
					));
					if(!empty( $settings['show_shape'])){
						echo '<div class="shape-mockup  d-xl-block d-none" data-bottom="18%" data-left="0%">';
							echo '<img src="'.BARAB_ASSETS.'img/why-shape-1.png" alt="'.esc_attr('Shape', 'barab').'">';
						echo '</div>';
						echo '<div class="shape-mockup moving  d-xl-block d-none" data-top="0%" data-left="40%">';
							echo '<img src="'.BARAB_ASSETS.'img/why-shape-2.png" alt="'.esc_attr('Shape', 'barab').'">';
						echo '</div>';
						echo '<div class="shape-mockup d-xl-block d-none" data-top="10%" data-left="40%">';
							echo '<img src="'.BARAB_ASSETS.'img/why-shape-3.png" alt="'.esc_attr('Shape', 'barab').'">';
						echo '</div>';
						echo '<div class="shape-mockup jump d-xl-block d-none" data-bottom="3%" data-left="0%">';
							echo '<img src="'.BARAB_ASSETS.'img/why-shape-4.png" alt="'.esc_attr('Shape', 'barab').'">';
						echo '</div>';
						echo '<div class="why-1-shape-trangle"></div>';
					}
					echo '<div class="container">';
						echo '<div class="row gy-30 gx-80 align-items-center justify-content-center">';
							echo '<div class="col-xl--5 col-lg-5">';
								echo '<div class="title-area mb-0">';
									if(!empty($settings['subtitle'])){
										echo '<span class="sub-title style2 text-anime-style-1">'.esc_html($settings['subtitle']).'</span>';
									}
									if(!empty($settings['title'])){
										echo '<h2 class="sec-title text-anime-style-1 mb-4">'.esc_html($settings['title']).'</h2>';
									}
									echo '<ul class="why-feature-list">';
										foreach( $settings['feature_list'] as $key => $data ){
											$delay  = number_format(0.2 + ($key * 0.2), 1); 
											echo '<li class="why-feature-list-wrap wow fadeinup" data-wow-delay="'.$delay.'s">';
												if(!empty($data['image']['url'])){
													echo '<div class="icon">';
														echo '<div class="feat-mask bg-mask" style="mask-image: url('.BARAB_ASSETS.'img/bg/about-feat-bg.png);"></div>';
														echo barab_img_tag( array(
															'url'   => esc_url( $data['image']['url'] ),
														)); 
													echo '</div>';
												}
												echo '<div class="why-feature-list-details">';
													if(!empty($data['title'])){
														echo '<h4 class="feature-title">'.esc_html($data['title']).'</h4>';
													}
													if(!empty($data['description'])){
														echo '<p class="feature-text">'.esc_html($data['description']).'</p>';
													}
												echo '</div>';
											echo '</li>';
										}
									echo '</ul>';
								echo '</div>';
							echo '</div>';
							echo '<div class="col-lg-7">';
								if($settings['image']['url'] ){
									echo '<div class="why-img-box wow fadeinright">';
										echo barab_img_tag( array(
											'url'   => esc_url( $settings['image']['url'] ),
										)); 
									echo '</div>';
								}
							echo '</div>';
						echo '</div>';
					echo '</div>';
				echo '</div>';

			}elseif( $settings['layout_style'] == '2' ){
				echo '<div class="row gy-30 align-items-center justify-content-center">';
					// LEFT SIDE: show first item (key=0) + all items from 4th onwards (key>=3)
					echo '<div class="col-xl-3 col-lg-3">';
						foreach ( $settings['feature_list2'] as $key => $data ) {
							if ( $key == 0 || $key >= 3 ) {
								echo '<div class="wy-choose-item left-style pe-xxl-5 me-xxl-3">';
									if ( !empty($data['title']) ) {
										echo '<h4 class="box-title3">'.esc_html($data['title']).'</h4>';
									}
									if ( !empty($data['description']) ) {
										echo '<p class="box-text">'.esc_html($data['description']).'</p>';
									}
								echo '</div>';
							}
						}
					echo '</div>';

					// CENTER: show image
					if ( !empty($settings['image']['url']) ) {
						echo '<div class="col-xl-6 col-lg-6">';
							echo '<div class="wy-choose-img-1 ps-xxl-5 ms-xxl-5">';
								echo barab_img_tag( array(
									'url' => esc_url( $settings['image']['url'] ),
								));
							echo '</div>';
						echo '</div>';
					}

					// RIGHT SIDE: show only 2nd and 3rd items
					echo '<div class="col-xl-3 col-lg-3">';
						echo '<div class="wy-choose-item-wrap ps-xxl-5 ms-xxl-3">';
							foreach ( $settings['feature_list2'] as $key => $data ) {
								if ( $key == 1 || $key == 2 ) {
									echo '<div class="wy-choose-item">';
										if ( !empty($data['title']) ) {
											echo '<h4 class="box-title3">'.esc_html($data['title']).'</h4>';
										}
										if ( !empty($data['description']) ) {
											echo '<p class="box-text">'.esc_html($data['description']).'</p>';
										}
									echo '</div>';
								}
							}
						echo '</div>';
					echo '</div>';
				echo '</div>'; // end row

			}


	}

}