<?php



/**

 * Seacab Sidebar Blog Posts

 *

 *

 * @author 		TwinkleTheme

 * @category 	Widgets

 * @package 	Seacab/Widgets

 * @version 	1.0.0

 * @extends 	WP_Widget

*/



add_action('widgets_init', function(){

	register_widget('Twinkle_sidebar_blog_posts');

});



Class Twinkle_sidebar_blog_posts extends WP_Widget{



	public function __construct(){

		parent::__construct('Twinkle_sidebar_blog_posts',esc_html__('Seacab Sidebar Blog Posts', 'twinkle-core'), array(

			'description'	=> esc_html__('Show Latest Post by Seacab', 'twinkle-core'),

		));

	}



	public function widget($args, $instance){

		extract($args);

		extract($instance);

		

		?>



			<?php echo $before_widget;

				if($instance['title']):

				echo $before_title; ?>

					<?php echo apply_filters( 'widget_title', $instance['title'] ); 

				echo $after_title; ?>

			<?php endif; ?>

			

			<div class="sidebar__post-box">

				<?php

				$q = new WP_Query( array(

					'post_type'     => 'post',

					'posts_per_page'=> ($instance['count']) ? $instance['count'] : '3',

					'order'			=> ($instance['posts_order']) ? $instance['posts_order'] : 'DESC',

					'orderby' => 'date'

				));



				if( $q->have_posts() ):

				while( $q->have_posts() ):$q->the_post();

				?>

				<div class="sidebar__post-single">

					<div class="sidebar__post-single">

						<?php if(has_post_thumbnail()): ?>

						<div class="sidebar-post__img">

							<img src="<?php print esc_url(get_the_post_thumbnail_url(get_the_ID(),'full')); ?>" alt="">

						</div>

						<?php endif; ?>

						<div class="sidebar__post-content-box">

							<h3><a href="<?php the_permalink(); ?>"><?php print wp_trim_words(get_the_title(), 6, ''); ?></a></h3>

						</div>

					</div>

				</div>

				<?php endwhile; endif; ?>

			</div>



		<?php echo $after_widget; ?>



		<?php

	}



	public function form($instance){

		$title = ! empty( $instance['title'] ) ? $instance['title'] : '';

		$count = ! empty( $instance['count'] ) ? $instance['count'] : esc_html__( '3', 'twinkle-core' );

		$posts_order = ! empty( $instance['posts_order'] ) ? $instance['posts_order'] : esc_html__( 'DESC', 'twinkle-core' );

		$choose_style = ! empty( $instance['choose_style'] ) ? $instance['choose_style'] : esc_html__( 'style_1', 'twinkle-core' );

		

		?>

			<p>

				<label for="<?php echo $this->get_field_id('title'); ?>">Title</label>

				<input type="text" name="<?php echo $this->get_field_name('title'); ?>" id="<?php echo $this->get_field_id('title'); ?>" value="<?php echo esc_attr( $title ); ?>" class="widefat">

			</p>



			<p>

				<label for="<?php echo $this->get_field_id('count'); ?>">How many posts you want to show ?</label>

				<input type="number" name="<?php echo $this->get_field_name('count'); ?>" id="<?php echo $this->get_field_id('count'); ?>" value="<?php echo esc_attr( $count ); ?>" class="widefat">

			</p>



			<p>

				<label for="<?php echo $this->get_field_id('posts_order'); ?>">Posts Order</label>

				<select name="<?php echo $this->get_field_name('posts_order'); ?>" id="<?php echo $this->get_field_id('posts_order'); ?>" class="widefat">

					<option value="" disabled="disabled">Select Post Order</option>

					<option value="ASC" <?php if($posts_order === 'ASC'){ echo 'selected="selected"'; } ?>>ASC</option>

					<option value="DESC" <?php if($posts_order === 'DESC'){ echo 'selected="selected"'; } ?>>DESC</option>

				</select>

			</p>



		<?php 

	}



}