(function($) {
    "use strict";
    $(".rdn-tab-link").on("click", function () {
        var tablinkcurrent = $(this).attr("data-id");
        var tabid = $(this).attr("data-tab");
        $(tablinkcurrent).find(".rdn-tab-link").removeClass("active");
        $(tablinkcurrent).find(".rdn-tab-ct").removeClass("active");
        $(this).addClass("active");
        $(tablinkcurrent).find(tabid).addClass("active")
        return false;
        
    });
})(jQuery);