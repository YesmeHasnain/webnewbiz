<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Contact Info Widget .
 *
 */
class Barab_Contact_Info extends Widget_Base {

	public function get_name() {
		return 'barabcontactinfo';
	}
	public function get_title() {
		return __( 'Contact Info', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() { 

		$this->start_controls_section(
			'title_section',
			[
				'label' 	=> __( 'Contact Info', 'barab' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two', 'Style Three' ] );

		barab_general_fields($this, 'title', 'Title', 'TEXT', 'Contact info' , ['1', '2', '3'] );
		barab_general_fields($this, 'desc', 'Content', 'TEXTAREA', '' , ['2'] );
		barab_media_fields( $this, 'title_shape', 'Choose Title Shape', ['1'] );

		$repeater = new Repeater();

		barab_general_fields($repeater, 'title', 'Label', 'TEXTAREA2', 'Label');
		barab_general_fields($repeater, 'desc', 'Content', 'TEXTAREA', 'Content');
		
		$this->add_control(
			'contact_lists',
			[
				'label' 		=> __( 'Contact Info', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'Label', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => [ '1', '3' ]
				]
			]
		);

		$repeater = new Repeater();

		barab_media_fields($repeater, 'icon', 'Choose Image');
		barab_general_fields($repeater, 'title', 'Label', 'TEXTAREA2', 'Label');
		barab_general_fields($repeater, 'desc', 'Content', 'TEXTAREA', 'Content');
		
		$this->add_control(
			'contact_lists2',
			[
				'label' 		=> __( 'Contact Info', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'Label', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => [ '2' ]
				]
			]
		);

		barab_media_fields($this, 'shape', 'Choose Shape', ['2']);

        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------


		barab_common_style_fields( $this, '1', 'Title', '{{WRAPPER}} .widget_title', ['1', '3'] );
		barab_common_style_fields( $this, '2', 'Title', '{{WRAPPER}} .sec-title', ['2'] );
		barab_common_style_fields( $this, '3', 'Content', '{{WRAPPER}} .box-text', ['2'] );

		barab_common_style_fields( $this, '11', 'Info Label', '{{WRAPPER}} .contact-feature_label', ['2'] );
		barab_common_style_fields( $this, '12', 'Info Content', '{{WRAPPER}} .media-body a, {{WRAPPER}} .media-body span', ['2'] );
		
	}

	protected function render() {

        $settings = $this->get_settings_for_display(); 
			
		if( $settings['layout_style'] == '1' ){ 
			echo '<div class="widget footer-widget bg">'; 
				if(!empty($settings['title'])){
					echo '<h3 class="widget_title">'.esc_html($settings['title']).'</h3>';
				}
				if(!empty($settings['title_shape']['url'])){
					echo '<div class="icon">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['title_shape']['url'] ),
						));
					echo '</div>';
				}
				echo '<div class="th-widget-contact">';
					foreach( $settings['contact_lists'] as $data ){
						echo '<div class="info-box">';
							echo '<p class="info-box_text">';
								if(!empty($data['title'])){
									echo '<span>'.esc_html($data['title']).'</span>';
								}
								echo wp_kses_post($data['desc']);
							echo '</p>';
						echo '</div>';
					}
				echo '</div>';
            echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
			echo '<div class="contact-info-wrap shape-mockup-wrap">';
				if($settings['shape']['url'] ){
					echo '<div class="shape-mockup d-xxl-block d-none" data-top="20%" data-left="78%">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['shape']['url'] ),
						));
					echo '</div>';
				}
				echo '<div class="mb-30">';
					if(!empty($settings['title'])){
						echo '<h2 class="sec-title text-anime-style-2 mb-2">'.wp_kses_post($settings['title']).'</h2>';
					}
					if(!empty($settings['desc'])){
						echo '<p class="box-text">'.esc_html($settings['desc']).'</p>';
					}
				echo '</div>';

				echo '<div class="contact-feature-wrap">';
					$bg_classes = [ 'bg-theme', 'bg-theme2', 'bg-theme3' ];
					foreach( $settings['contact_lists2'] as $key => $data ){
						$bg_class = $bg_classes[ $key % 3 ];
						echo '<div class="contact-feature2">';
							if($data['icon']['url'] ){
								echo '<div class="box-icon '.esc_attr( $bg_class ).'">';
									echo barab_img_tag( array(
										'url'   => esc_url( $data['icon']['url'] ),
									));
								echo '</div>';
							}
							echo '<div class="media-body">';
								if(!empty($data['title'])){
									echo '<p class="contact-feature_label">'.esc_html($data['title']).'</p>';
								}
								echo wp_kses_post($data['desc']);
							echo '</div>';
						echo '</div>';
					}
				echo '</div>';
			echo '</div>';

		}elseif( $settings['layout_style'] == '3' ){
			echo '<div class="widget footer-widget wow fadeinup">';
				if(!empty($settings['title'])){
					echo '<h3 class="widget_title">'.esc_html($settings['title']).'</h3>';
				}
				echo '<div class="th-widget-contact">';
					foreach( $settings['contact_lists'] as $data ){
						echo '<div class="info-box">';
							echo '<p class="info-box_text">';
								if(!empty($data['title'])){
									echo '<span>'.esc_html($data['title']).'</span>';
								}
								echo wp_kses_post($data['desc']);
							echo '</p>';
						echo '</div>';
					}
				echo '</div>';
            echo '</div>';

		}
       

	}

}
