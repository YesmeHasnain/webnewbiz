<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsFooterSection4 extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-footer-4';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Footer Section 4', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-footer';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-footer' ];
	}

	public function get_keywords() {
		return [ 'footer4', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_footer_section',
			[
				'label' => esc_html__( 'Footer Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'bg_color',
			[
				'label' 		=> esc_html__( 'Background Color (Default: #1E1E1E)', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::COLOR,
				'default'		=> '#1E1E1E',
			]
		);
		$this->add_control(
			'ft_logo',
			[
				'label'       	=> esc_html__( 'Footer Logo', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image logo', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'ft_copyright',
			[
				'label'       => __( 'Footer Copyright', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your text footer copyright', 'bdevs-elementor' ),
				'default'     => __( '©2025 - All Rights Reserved', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$rp_social = new \Elementor\Repeater();
		$rp_social->add_control(
			'text_sc_item',
			[
				'label' 		=> esc_html__( 'Text Social Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Text Social' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_social->add_control(
			'link_sc_item',
			[
				'label' 		=> esc_html__( 'Link Social Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '#' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'tab_sc',
			[
				'label' 		=> esc_html__( 'List Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $rp_social->get_controls(),
				'default' 		=> [
					[
					],
				],
				'title_field' 	=> '{{{ text_sc_item }}}',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_wrapper_footer',
			[
				'label' => esc_html__( 'Wrapper Footer Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'switch_wrapper_footer',
			[
				'label'   		=> esc_html__( 'Switch Show/Hide Wrapper Footer', 'bdevs-elementor' ),
				'type'    		=> Controls_Manager::SWITCHER,
				'label_on' 		=> esc_html__( 'Show', 'bdevs-elementor' ),
				'label_off' 	=> esc_html__( 'Hide', 'bdevs-elementor' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);
		$this->add_control(
			'ft_text_wp',
			[
				'label' 		=> esc_html__( 'Fotoer Text Wrapper', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'For professional projects and <br> collaboration opportunities, feel free to <br> get in touch with me.' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'ft_text_btn',
			[
				'label' 		=> esc_html__( 'Wrapper Text Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Schedule a Meeting' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'ft_link_btn',
			[
				'label' 		=> esc_html__( 'Wrapper Link Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '#' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>

<?php if (!empty($settings['switch_wrapper_footer'])) { ?>
	<footer class="tp-footer-6-ptb pt-100" data-bg-color="<?php echo wp_kses_post($settings['bg_color']); ?>">
<?php } else { ?>
	<footer class="tp-footer-6-ptb pt-50" data-bg-color="<?php echo wp_kses_post($settings['bg_color']); ?>">
<?php } ?>
		<?php if (!empty($settings['switch_wrapper_footer'])): ?>
			<div class="tp-footer-6-top pb-120">
				<div class="container container-1520">
					<div class="row">
						<div class="col-lg-12">
							<div class="tp-footer-6-text pb-180">
								<?php if (!empty($settings['ft_text_wp'])): ?>
									<h3 class="tp-footer-6-text-title tp-char-animation">
										<?php echo wp_kses_post($settings['ft_text_wp']); ?>
									</h3>
								<?php endif ?>
							</div>
							<?php if (!empty($settings['ft_link_btn']) && !empty($settings['ft_text_btn'])): ?>
								<div class="tp-footer-6-btn">
									<a href="<?php echo wp_kses_post($settings['ft_link_btn']); ?>">
										<?php echo wp_kses_post($settings['ft_text_btn']); ?> 
										<span>
											<svg xmlns="http://www.w3.org/2000/svg" width="19" height="16" viewBox="0 0 19 16" fill="none">
												<path d="M0 7.68652H17.6902M10.7148 0C10.7148 4.25031 14.4168 7.68957 18.9917 7.68957M18.9917 7.68652C14.4168 7.68652 10.7148 11.1258 10.7148 15.3761" stroke="white" stroke-width="2" stroke-miterlimit="10"/>
											</svg>
										</span>
									</a>
								</div>
							<?php endif ?>
						</div>
					</div>
				</div>
			</div>
		<?php endif ?>
		<div class="container container-1520">
			<div class="tp-footer-6-copyright pb-35">
				<div class="row">
					<div class="col-lg-3">
						<div class="tp-footer-copyright-logo">
							<?php if (!empty($settings['ft_logo']['url'])): ?>
								<a href="<?php echo esc_url(home_url('/')); ?>">
									<img data-width="90" src="<?php echo wp_kses_post($settings['ft_logo']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
								</a>
							<?php endif ?>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="tp-footer-copyright-social text-start text-lg-center">
							<?php
							foreach ($settings['tab_sc'] as $items) :
							?>
								<?php if (!empty($items['link_sc_item']) && !empty($items['text_sc_item'])): ?>
									<a href="<?php echo wp_kses_post($items['link_sc_item']); ?>">
										<?php echo wp_kses_post($items['text_sc_item']); ?>
									</a>
								<?php endif ?>
							<?php endforeach; ?>
						</div>
					</div>
					<div class="col-lg-3">
						<div class="tp-footer-copyright-text text-start text-lg-end">
							<?php if (!empty($settings['ft_copyright'])): ?>
								<p><?php echo wp_kses_post($settings['ft_copyright']); ?></p>
							<?php endif ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-bg-color]").each(function () {
			jQuery(this).css("background-color", jQuery(this).attr("data-bg-color"));
		});

		if (jQuery('.tp-footer-6-text .tp-char-animation').length > 0) {
			var char_come = gsap.utils.toArray(".tp-footer-6-text .tp-char-animation");
			char_come.forEach(splitTextLine => {
				var tl = gsap.timeline({
					scrollTrigger: {
						trigger: splitTextLine,
						start: 'top 90%',
						end: 'bottom 60%',
						scrub: false,
						markers: false,
						toggleActions: 'play none none none'
					}
				});

				var itemSplitted = new SplitText(splitTextLine, { type: "chars, words" });
				gsap.set(splitTextLine, { perspective: 300 });
				itemSplitted.split({ type: "chars, words" })
				tl.from(itemSplitted.chars,
					{
						duration: 1,
						delay: 0.5,
						x: 100,
						autoAlpha: 0,
						stagger: 0.05
					});
			});
		}
	</script>
<?php } ?>

<?php
}

}