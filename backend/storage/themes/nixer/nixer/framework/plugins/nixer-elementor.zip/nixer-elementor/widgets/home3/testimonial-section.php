<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome3TestimonialSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home3-testimonial-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 3 - Testimonial Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-testimonial-carousel';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home3' ];
	}

	public function get_keywords() {
		return [ 'home3testimonialsection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_testimonial_section',
			[
				'label' => esc_html__( 'Testimonial Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'img_bg_sec',
			[
				'label'       	=> esc_html__( 'Image Background Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image Background section', 'bdevs-elementor' ),
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'img_user_item',
			[
				'label'       	=> esc_html__( 'Image User Item', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image user item', 'bdevs-elementor' ),
			]
		);
		$repeater->add_control(
			'user_title',
			[
				'label' 		=> esc_html__( 'User Title', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'user_subtitle',
			[
				'label' 		=> esc_html__( 'User SubTitle', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'text_item',
			[
				'label' 		=> esc_html__( 'Text Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'tabs',
			[
				'label' 		=> esc_html__( 'List Testimonial Content', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						
					],
				],
				'title_field' 	=> '{{{ user_title }}}',
			]
		);
		$this->add_control(
			'show_btn_testi',
			[
				'label'   => esc_html__( 'Show Button Next/Previous', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-testimonial-3-ptb p-relative fix">
	<?php if (!empty($settings['img_bg_sec']['url'])): ?>
		<div class="tp-testimonial-3-thumb">
			<img data-speed=".8" src="<?php echo wp_kses_post($settings['img_bg_sec']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_bg_sec']['alt']); ?>">
		</div>
	<?php endif ?>
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-10">
				<div class="tp-testimonial-3-wrapper p-relative">
					<div class="tp-testimonial-3-active swiper">
						<div class="swiper-wrapper">
							<?php
							foreach ($settings['tabs'] as $item) :
							?>
								<div class="swiper-slide">
									<div class="tp-testimonial-3-item text-center">
										<?php if (!empty($item['text_item'])): ?>
											<span class="tp-testimonial-3-item-title"><?php echo wp_kses_post($item['text_item']); ?></span>
										<?php endif ?>
										<div class="tp-testimonial-3-user d-flex align-items-center justify-content-center">
											<?php if (!empty($item['img_user_item']['url'])): ?>
												<div class="tp-testimonial-3-user-thumb">
													<img src="<?php echo wp_kses_post($item['img_user_item']['url']); ?>" alt="<?php echo wp_kses_post($item['img_user_item']['alt']); ?>">
												</div>
											<?php endif ?>
											<div class="tp-testimonial-3-user-content">
												<?php if (!empty($item['user_title'])): ?>
													<h5 class="tp-testimonial-3-user-title"><?php echo wp_kses_post($item['user_title']); ?></h5>
												<?php endif ?>
												<?php if (!empty($item['user_subtitle'])): ?>
													<span><?php echo wp_kses_post($item['user_subtitle']); ?></span>
												<?php endif ?>
											</div>
										</div>
									</div>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
					<?php if (!empty($settings['show_btn_testi'])): ?>
						<div class="tp-testimonial-dot"></div>
					<?php endif ?>
				</div>
			</div>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		if (jQuery('.tp-testimonial-3-active').length > 0) {
			var slider = new Swiper('.tp-testimonial-3-active', {
				slidesPerView: 1,
				speed:1500,
				loop: true,
				spaceBetween: 30,
				pagination: {
					el: ".tp-testimonial-dot",
					clickable: true,
				},
				autoplay: {
				delay: 4000,
				},
			});
		}

		gsap.registerPlugin(ScrollTrigger, ScrollSmoother);
		var smoother = ScrollSmoother.create({
			smooth: 2,
			effects: true,
			smoothTouch: true
		});
		
	</script>
<?php } ?>

<?php
}

}