<?php
// Registers the new post type 

function mancink_header_post_type() {
	register_post_type( 'header',
		array(
			'labels' => array(
				'name' => __( 'Custom Header', 'mancink_plugin' ),
				'singular_name' => __( 'Custom Header' , 'mancink_plugin'),
				'add_new' => __( 'Add New Custom Header', 'mancink_plugin' ),
				'add_new_item' => __( 'Add New Custom Header', 'mancink_plugin' ),
				'edit_item' => __( 'Edit Custom Header', 'mancink_plugin' ),
				'new_item' => __( 'Add New Custom Header', 'mancink_plugin' ),
				'view_item' => __( 'View Custom Header', 'mancink_plugin' ),
				'search_items' => __( 'Search Custom Header', 'mancink_plugin' ),
				'not_found' => __( 'No Custom Header found', 'mancink_plugin' ),
				'not_found_in_trash' => __( 'No Custom Header found in trash', 'mancink_plugin' )
			),
			'public' => true,
			'supports' => array( 'title'),
			'capability_type' => 'post',
			'rewrite' => array("slug" => "header"), // Permalinks format
			'menu_position' => 5,
			'menu_icon'           => 'dashicons-menu',
			'exclude_from_search' => true 
		)
	);

}

add_action( 'init', 'mancink_header_post_type' );


//add background in elementor editor
add_filter( 'body_class','my_body_classes' );

function my_body_classes( $classes ) {
 	if ( is_singular('header') ) {
	global $post;
    $classes[] = get_post_meta($post->ID, 'mancink_dark_bg', true);  
    }  
    return $classes;

}


//function custom header output elementor css
function mancink_header_css() {
    global $post;
    if (is_singular()) { //if single page/post
        global $post;
        if (get_post_meta($post->ID, 'mancink_header_option', true) == 'custom' && get_post_meta($post->ID, 'mancink_meta_choose_header', true)) {

            //if page setting choose header custom
            $header_id = get_post_meta(get_the_ID(), 'mancink_meta_choose_header', true);
        }

        //if page setting choose header global
        else if (get_post_meta($post->ID, 'mancink_header_option', true) == 'global') {

            //if custom header & list are selected in theme options
            if (get_theme_mod('custom_header_setting_value') == 'custom' && get_theme_mod('mancink_select_header') != '') {

                $header_id = get_theme_mod('mancink_select_header');
            } 
        }

    } else { //if not single page/post

        //if custom header & list are selected in theme options
        if (get_theme_mod('custom_header_setting_value') == 'custom' && get_theme_mod('mancink_select_header') != '') {

            $header_id = get_theme_mod('mancink_select_header');
        } 
    }
    if ( did_action( 'elementor/loaded' ) ) {
        if (! empty( $header_id)){
            if ( class_exists( '\Elementor\Core\Files\CSS\Post' ) ) {
                $css_file = new \Elementor\Core\Files\CSS\Post( $header_id );
            } elseif ( class_exists( '\Elementor\Post_CSS_File' ) ) {
                $css_file = new \Elementor\Post_CSS_File( $header_id );
            }
            $css_file->enqueue();
         }
    }
}

//custom header css call
add_action( 'wp_enqueue_scripts', 'mancink_header_css' );