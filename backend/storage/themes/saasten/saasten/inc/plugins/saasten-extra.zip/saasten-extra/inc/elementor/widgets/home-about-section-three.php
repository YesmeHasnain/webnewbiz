<?php

/**
 * Elementor Widget
 * @package Saasten
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_home_about_three extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'theme-about-three';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Home About 3', 'saasten-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saasten_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {


        $this->start_controls_section( 'section_content_about_inner_three', [
            'label' => esc_html__( 'About Content', 'saasten-extra' ),
        ] ); 


        $this->add_control( 'subtitle', [
            'label'       => __( 'Sub Title', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => __( 'About Us', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type section subtitle here.", 'saasten-extra' ),
        ] );

        $this->add_control( 'title', [
            'label'       => __( 'Title', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Invest in Startup', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type section title here.", 'saasten-extra' ),

        ] );


        $this->add_control( 'description', [
            'label'       => __( 'Description', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Our Sustainable Construction Advisors provide sustainable construction expertise', 'saasten-extra' ),
            'label_block' => true,
        ] );


        $this->add_control( 'feature_image_bg', [
            'label'   => __( 'Choose Image Background', 'saasten-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        
        $this->add_control( 'about_feature_image1', [
            'label'   => __( 'Choose Image 1', 'saasten-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        $this->add_control( 'about_feature_image2', [
            'label'   => __( 'Choose Image 2', 'saasten-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        $this->add_control( 'about_feature_image3', [
            'label'   => __( 'Choose Image 3', 'saasten-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        $this->add_control( 'about_feature_image4', [
            'label'   => __( 'Choose Image 4', 'saasten-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );


        $this->add_control( 'btn_text', [
            'label'       => __( 'Button Label', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'placeholder' => __( 'Type your button label here', 'saasten-extra' ),
            'default'     => __( 'Read More', 'saasten-extra' ),
        ] );

        $this->add_control( 'btn_link', [
            'label'       => __( 'Button Link', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::URL,
            'placeholder' => __( 'https://your-link.com', 'saasten-extra' ),
            'default'     => [
                'url' => '#',
            ],
        ] );



        $this->end_controls_section();


        $this->start_controls_section( 'section_content_about3_featurelist', [
            'label' => esc_html__( 'About Skill List', 'saasten-extra' ),
        ] ); 

        $this->add_control( 'featureItems', [
            'label'       => esc_html__( 'About features items', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'default'     => [
                [
                    'feature-title'        => esc_html__( 'Website design', 'saasten-extra' ),
                ]
            ],

            'fields'      => [
                [
                    'name'        => 'feature-title',
                    'label'       => esc_html__( 'Skill Title', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'description' => esc_html__( 'Enter Skill Title', 'saasten-extra' )
                ],
                

            ],
            'title_field' => "{{name}}"
        ] );



        $this->end_controls_section();


        // ===================== Title ======================//

        $this->start_controls_section( 'title_style', [
            'label' => __( 'Title', 'saasten-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_typography',
            'label'    => __( 'Typography', 'saasten-extra' ),
            'selector' => '
                {{WRAPPER}} .theme-banner-startup-wrapper h1.banner-heading,
                {{WRAPPER}} .__title
            ',
        ] );


        $this->add_control( 'title_color', [
            'label'     => __( 'Color', 'saasten-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-startup-wrapper h1.banner-heading' => 'color: {{VALUE}}',
                '{{WRAPPER}} .__title' => 'color: {{VALUE}}',
            ],
        ] );

        $this->end_controls_section(); //End Title Style


        // ===================== Subtitle Style ========================//
        $this->start_controls_section( 'sub_title_style', [
            'label' => __( 'Sub Title', 'saasten-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_sub_typography',
            'label'    => __( 'Typography', 'saasten-extra' ),
            'selector' => '{{WRAPPER}} .theme-banner-startup-wrapper h4.banner-sub-heading',
        ] );

        $this->add_control( 'sub_title_color', [
            'label'     => __( 'Sub Title Color', 'saasten-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-startup-wrapper h4.banner-sub-heading' => 'color: {{VALUE}}',
            ],

        ] );

        $this->end_controls_section(); //End Subtitle Style

		
	}
	


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

        $featureItems = $settings['featureItems'];

        extract($settings); 


		
		?>


    <!-- Advancements area start -->
    <section
      class="features-list-area ov-hidden saastain-bg__cover"
      style="background-image: url(<?php echo esc_url( $settings['feature_image_bg']['url'] ); ?>);"
    >
      <div class="container">
        <div class="row">
          <div class="col-lg-6 col-12">
            <div class="features-img-card rr-mg-50">


              <div class="features-img-card__thumb">
                <img src="<?php echo esc_url( $settings['about_feature_image1']['url'] ); ?>" alt="#" />
              </div>

              <div
                class="features-img-card__img features-img-card__img-1 saastain-anim-shape3"
              >
                <img
                  data-aos="zoom-in"
                  src="<?php echo esc_url( $settings['about_feature_image2']['url'] ); ?>"
                  alt="#"
                />
              </div>

              <div
                class="features-img-card__img features-img-card__img-2 saastain-anim-shape4"
              >
                <img
                  data-aos="zoom-in"
                  src="<?php echo esc_url( $settings['about_feature_image3']['url'] ); ?>"
                  alt="#"
                />
              </div>

              <div
                class="features-img-card__img features-img-card__img-3 saastain-anim-shape5"
              >
                <img
                  data-aos="zoom-in"
                  src="<?php echo esc_url( $settings['about_feature_image4']['url'] ); ?>"
                  alt="#"
                />
              </div>



            </div>
          </div>
          <div class="col-lg-6 col-12">
            <div class="features-list-content">
              <!-- Section Title -->
              <div
                class="section-title-v3 text-left aos-init aos-animate"
                data-aos="fade-in"
              >
                <p
                  class="section-title-v3__label mg-btm-20 text-white m-0 saastain-gsap-anim1"
                >
                  <?php echo $settings['subtitle']; ?>
                </p>
                <h2
                  class="section-title-v3__title text-white m-0 saastain-gsap-anim3"
                >
                  <?php echo wp_kses_post( $settings['title'] ); ?>

                </h2>
                <p
                  class="section-title-v3__text text-white mg-top-30 mb-0"
                  data-aos="fade-in"
                >
                 <?php echo wp_kses_post( $settings['description'] ); ?>
                </p>
              </div>


              <ul class="list-features m-0 mg-top-50">


                <?php
                    foreach ( $featureItems as $item ):
                ?>


                <li data-aos="fade-left" data-aos-delay="100">
                  <span class="flex-shrink-0"
                    ><img src="<?php echo SAASTEN_IMG ."/check-icon-v3.svg"; ?>"
                  /></span>
                  <span class="text-white"
                    ><?php echo esc_html( $item['feature-title'] ); ?></span
                  >
                </li>

                 <?php endforeach; ?> 



              </ul>
              <a
                href="<?php echo esc_url( $settings['btn_link']['url'] ) ?>"
                class="saastain-btn mg-top-50 saastain-btn__v4 border-radius-31"
                ><?php echo $settings['btn_text'] ?></a
              >
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Advancements area end -->






	

	<?php 


	}
				

}

