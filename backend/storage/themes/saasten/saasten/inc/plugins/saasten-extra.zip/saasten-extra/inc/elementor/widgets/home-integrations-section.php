<?php

/**
 * Elementor Widget
 * @package Saasten
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_home_integrations extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'theme-integrations';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Home Integrations', 'saasten-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saasten_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {



        $this->start_controls_section( 'section_content_integrations', [
            'label' => esc_html__( 'Integration Items', 'saasten-extra' ),
        ] ); 

        $this->add_control( 'serItems', [
            'label'       => esc_html__( 'Service Items', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'default'     => [
                [
                    'service-title'        => esc_html__( 'Web Development', 'saasten-extra' ),
                ]
            ],

            'fields'      => [


              [
                    'name'        => 'service-title',
                    'label'       => esc_html__( 'Title', 'deaxautt-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'default'     => __( 'Web Development', 'deaxautt-extra' ),
                    'description' => esc_html__( 'Enter Title', 'deaxautt-extra' )
                ],

                [
                    'name'        => 'service-des',
                    'label'       => esc_html__( 'Short Description', 'deaxautt-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'default'     => __( 'Our Sustainable Construction Advisors', 'deaxautt-extra' ),
                    'label_block' => true,
                    'description' => esc_html__( 'Enter Description', 'deaxautt-extra' )
                ],


                [
                    'name'        => 'service-icon',
                    'label'       => esc_html__( 'Service Icon', 'deaxautt-extra' ),
                    'type'        => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                    ],

                    'description' => esc_html__( 'Upload service icon', 'deaxautt-extra' )
                ],

                [
                    'name'        => 'btn-text',
                    'label'       => esc_html__( 'Button Text', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXT,
                    'default'     => __( 'Read More', 'saasten-extra' ),
                    'description' => esc_html__( 'Enter button text', 'saasten-extra' )
                ],


                [
                    'name'        => 'btn-link',
                    'label'       => esc_html__( 'Button Link', 'deaxautt-extra' ),
                    'type'        => \Elementor\Controls_Manager::URL,
                    'placeholder' => __( 'https://your-link.com', 'deaxautt-extra' ),
                    'default'     => [
                        'url' => '#',
                    ],
                ],


                

            ],
            'title_field' => "{{name}}"
        ] );



        $this->end_controls_section();


		
	}
	


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

    $serItems = $settings['serItems'];

    extract($settings); 


		
		?>




    <!-- Integration -->
    <section
      class="integration-area integration-area-archive pd-top-100 pd-btm-130"
    >
      <div class="container">
        <div class="row">


            <?php
                foreach ( $serItems as $item ):
            ?>


          <div class="col-lg-4 col-md-6 col-12 mg-top-30" data-aos="fade-up">
            <!-- Integration Single -->
            <div class="integration-single">
              <div class="integration-single__head mg-btm-30 bg-green">
                <img src="<?php echo esc_url( $item['service-icon']['url'] ); ?>" alt="#" />
              </div>
              <h4 class="integration-single__title">
                <a href="<?php echo esc_url( $item['btn-link']['url'] ) ?>"><?php echo wp_kses_post( $item['service-title'] ); ?></a>
              </h4>
              <p><?php echo wp_kses_post( $item['service-des'] ); ?></p>
              <a
                href="<?php echo esc_url( $item['btn-link']['url'] ) ?>"
                class="more-btu more-hover"
                tabindex="0"
                ><?php echo esc_html( $item['btn-text'] ); ?>
                <span class="svg-current">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="18"
                    height="12"
                    viewBox="0 0 18 12"
                    fill="none"
                  >
                    <path
                      opacity="0.4"
                      d="M5.20248 7.19043L1.50325 7.51758C0.673083 7.51758 0 6.83794 0 5.99968C0 5.16142 0.673083 4.48178 1.50325 4.48178L5.20248 4.80893C5.85375 4.80893 6.38174 5.34207 6.38174 5.99968C6.38174 6.65839 5.85375 7.19043 5.20248 7.19043Z"
                    ></path>
                    <path
                      d="M17.6247 7.13016C17.5669 7.18854 17.3509 7.43529 17.148 7.64017C15.9644 8.92344 12.8739 11.0218 11.2572 11.664C11.0117 11.7665 10.391 11.9846 10.0583 12C9.74083 12 9.43756 11.9262 9.14847 11.7808C8.78739 11.577 8.49939 11.2554 8.34012 10.8764C8.23866 10.6143 8.07939 9.82669 8.07939 9.81237C7.92121 8.95208 7.83503 7.55315 7.83503 6.00661C7.83503 4.53497 7.92121 3.19332 8.05103 2.31871C8.06521 2.30329 8.22448 1.32623 8.39794 0.991371C8.71539 0.378924 9.33611 0 10.0005 0H10.0583C10.4914 0.0143194 11.4012 0.394346 11.4012 0.407564C12.9317 1.04975 15.9491 3.04681 17.1622 4.37415C17.1622 4.37415 17.5047 4.71562 17.6531 4.92822C17.8844 5.23444 18 5.61337 18 5.99229C18 6.41527 17.8702 6.80852 17.6247 7.13016Z"
                    ></path>
                  </svg>
                </span>
              </a>
            </div>
            <!-- End Integration Single -->
          </div>

 <?php endforeach; ?>



        </div>
      </div>
    </section>
    <!-- End Integration -->






	<?php 


	}
				

}

