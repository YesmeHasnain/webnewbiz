<?php

/**
 * Elementor Widget
 * @package Knor
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_team_members extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'custom-team-wid';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Team Members V.1', 'knor-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'knor_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {

	    //Content tab start
        $this->start_controls_section(
            'theme_team_member_options',
            [
                'label' => esc_html__( 'Team Members V1', 'knor-extra' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
		
        $this->add_responsive_control(
            'theme_team_select_style',
            [
                'label' => esc_html__( 'Select Style', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'one',
                'options' => [
                    'one'  => esc_html__( 'One', 'knor-extra' ),
                    'two'  => esc_html__( 'Two', 'knor-extra' )
                ],
            ]
        );
		
        $this->add_control(
            'theme_team_stitle_enable',
            [
                'label' => esc_html__( 'Enable Sub Tilte', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'knor-extra' ),
                'label_off' => esc_html__( 'Hide', 'knor-extra' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
		
        $this->add_control(
            'theme_team_item_show',
            [
                'label' => esc_html__( 'Display Item', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 4
            ]
        );
		
        $this->end_controls_section();
		
        $this->start_controls_section(
            'theme_team_member_slide_options',
            [
                'label' => esc_html__( 'Slide Options', 'knor-extra' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
		
        $this->add_control(
            'theme_team_enable_slide',
            [
                'label' => esc_html__( 'Enable Slide', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'knor-extra' ),
                'label_off' => esc_html__( 'Hide', 'knor-extra' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );
		
        $this->add_control(
            'theme_team_loop',
            [
                'label'        => esc_html__( 'Enable Loop ', 'knor-extra' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'On', 'knor-extra' ),
                'label_off'    => esc_html__( 'Off', 'knor-extra' ),
                'return_value' => 'yes',
                'default'      => 'no',
                'condition'    => [
                    'theme_team_enable_slide' => 'yes',
                ],
            ]
        );
		
        $this->add_control(
            'theme_team_speed',
            [
                'label'     => esc_html__( 'Slide Speed', 'knor-extra' ),
                'type'      => \Elementor\Controls_Manager::NUMBER,
                'min'       => 500,
                'max'       => 8000,
                'step'      => 10,
                'default'   => 4000,
                'condition' => array(
                    'theme_team_enable_slide' => 'yes',
                    'theme_team_loop'                => 'yes',

                ),
            ]
        );
		
        $this->add_control(
            'theme_team_aloop',
            [
                'label'        => esc_html__( 'Enable Auto Loop ', 'knor-extra' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'On', 'knor-extra' ),
                'label_off'    => esc_html__( 'Off', 'knor-extra' ),
                'return_value' => 'yes',
                'default'      => 'no',
                'condition'    => [
                    'theme_team_enable_slide' => 'yes',
                    'theme_team_loop' => 'yes',
                ],
            ]
        );
		
        $this->add_control(
            'theme_team_aspeed',
            [
                'label'     => esc_html__( 'Slide auto Speed', 'knor-extra' ),
                'type'      => \Elementor\Controls_Manager::NUMBER,
                'min'       => 500,
                'max'       => 8000,
                'step'      => 50,
                'default'   => 3000,
                'condition' => array(
                    'theme_team_aloop'               => 'yes',
                    'theme_team_loop'                => 'yes',
                    'theme_team_enable_slide' => 'yes',
                ),
            ]
        );
		
        $this->add_control(
            'theme_team_dot',
            [
                'label'        => esc_html__( 'Enable Dots ', 'knor-extra' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'On', 'knor-extra' ),
                'label_off'    => esc_html__( 'Off', 'knor-extra' ),
                'return_value' => 'yes',
                'default'      => 'no',
                'condition'    => [
                    'theme_team_enable_slide' => 'yes',
                ],
            ]
        );
		
		$this->add_control(
            'theme_team_navv',
            [
                'label'        => esc_html__( 'Enable Navs', 'knor-extra' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'On', 'knor-extra' ),
                'label_off'    => esc_html__( 'Off', 'knor-extra' ),
                'return_value' => 'yes',
                'default'      => 'no',
                'condition'    => [
                    'theme_team_enable_slide' => 'yes',
                ],
            ]
        );
		
        $this->end_controls_section();
		
		
		$this->start_controls_section(
            'theme_team_css_img_options',
            [
                'label' => esc_html__( 'Team Image Styling', 'knor-extra' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		
		$this->add_responsive_control(
			'team_img_height',
			[
				'label' =>esc_html__( 'Set Member Image Height', 'knor-extra' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 400,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 400,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 400,
					'unit' => 'px',
				],
				
				'default'  => [
					'unit' => 'px',
					'size' => 400,
				],
				
				'selectors' => [
					'{{WRAPPER}} .team-section-wrap .team-member-img img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'theme_portfolio_menu_img_box_border',
                'label' => esc_html__( 'Border', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .team-section-wrap .team-member-img',
            ]
        );
		
        $this->add_responsive_control(
            'theme_portfolio_menu_CSS_box_radius',
            [
                'label' => esc_html__( 'Border Radius', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ]
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 5,
                ],
                'selectors' => [
                    '{{WRAPPER}} .team-section-wrap .team-member-img img' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
		
        $this->add_responsive_control(
            'theme_portfolio_menu_CSS_box_margin',
            [
                'label' => esc_html__( 'Margin', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .team-section-wrap .team-member-img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		
        $this->add_responsive_control(
            'theme_portfolio_menu_CSS_box_padding',
            [
                'label' => esc_html__( 'Padding', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .team-section-wrap .team-member-img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		
	
		$this->end_controls_section();
	
	
        $this->start_controls_section(
            'theme_team_box_CSS_options',
            [
                'label' => esc_html__( 'Team Content Box Styling', 'knor-extra' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		
        $this->start_controls_tabs(
            'theme_team_box_tabs'
        );
		
        $this->start_controls_tab(
            'theme_team_box_tabs_normal',
            [
                'label' => __( 'Normal', 'knor-extra' ),
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'theme_team_box_normal_bg',
                'label' => esc_html__( 'Background', 'knor-extra' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .team-section-wrap .team-member-content',
            ]
        );
		
		
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'theme_team_box_normal_border',
                'label' => esc_html__( 'Border', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .team-section-wrap .team-member-content',
            ]
        );
		
		
        $this->add_responsive_control(
            'theme_team_box_normal_radisu',
            [
                'label' => esc_html__( 'Border Radius', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 5,
                ],
                'selectors' => [
                    '{{WRAPPER}} .team-section-wrap .team-member-content' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
		
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'theme_team_box_normal__shadow',
                'label' => esc_html__( 'Box Shadow', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .team-section-wrap .team-member-content',
            ]
        );
        $this->end_controls_tab();
        
        $this->start_controls_tab(
            'theme_team_box_tabs_hover',
            [
                'label' => __( 'Hover', 'knor-extra' ),
            ]
        );
		
        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'theme_team_box_hover_bg',
                'label' => esc_html__( 'Background', 'knor-extra' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .team-section-wrap .team-member-content',
            ]
        );
		
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'theme_team_box_hover_border',
                'label' => esc_html__( 'Border', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .team-section-wrap .team-member-content',
            ]
        );
		
        $this->add_responsive_control(
            'theme_team_box_hover_radisu',
            [
                'label' => esc_html__( 'Border Radius', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 5,
                ],
                'selectors' => [
                    '{{WRAPPER}} .team-section-wrap .team-member-content' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
		
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'theme_team_box_hover_shadow',
                'label' => esc_html__( 'Box Shadow', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .team-section-wrap .team-member-content',
            ]
        );
		
        $this->end_controls_tab();
		
        $this->end_controls_tabs();
		
		
		
        $this->add_control(
            'theme_team_box_CSS__align',
            [
                'label' => __( 'Alignment', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'knor-extra' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'knor-extra' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'knor-extra' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'default' => 'center',
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .team-section-wrap .team-member-content' => 'text-align: {{VALUE}}',
                ],
            ]
        );
		
		
        $this->add_responsive_control(
            'theme_team_box_CSS__margin',
            [
                'label' => esc_html__( 'Margin', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .team-section-wrap .team-member-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		
        $this->add_responsive_control(
            'theme_team_box_CSS__padding',
            [
                'label' => esc_html__( 'Padding', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .team-section-wrap .team-member-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		
        $this->end_controls_section();
		
        $this->start_controls_section(
            'theme_team_content_CSS_options',
            [
                'label' => esc_html__( 'Content Styling', 'knor-extra' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->start_controls_tabs(
            'theme_team_content_css_tabs'
        );
        $this->start_controls_tab(
            'theme_team_content_css_title',
            [
                'label' => __( 'Title', 'knor-extra' ),
            ]
        );
        $this->add_responsive_control(
            'theme_team_content_css_title_color',
            [
                'label' => esc_html__( 'Color', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-section-wrap .team-member-content h3 a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'theme_team_content_css_title_typo',
                'label' => esc_html__( 'Typography', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .team-section-wrap .team-member-content h3',
            ]
        );
		
        $this->add_responsive_control(
            'theme_team_content_css_title_margin',
            [
                'label' => esc_html__( 'Margin', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .team-section-wrap .team-member-content h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_tab();
        
        $this->start_controls_tab(
            'theme_team_content_css_stitle',
            [
                'label' => __( 'Position', 'knor-extra' ),
            ]
        );
        $this->add_responsive_control(
            'theme_team_content_css_stitle_color',
            [
                'label' => esc_html__( 'Color', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-section-wrap .team-member-content h4' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'theme_team_content_css_stitle_typo',
                'label' => esc_html__( 'Typography', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .team-section-wrap .team-member-content h4',
            ]
        );
		
        $this->add_responsive_control(
            'theme_team_content_css_stitle_margin',
            [
                'label' => esc_html__( 'Margin', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .team-section-wrap .team-member-content h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();
		


		
	}
	


	protected function render() {
		
		$settings = $this->get_settings_for_display();
		
        $dynamic_id = rand(1241, 3256);
		
		
        if($settings['theme_team_enable_slide'] == 'yes' ){
			
            $class_row = 'no-row';
			
            $theme_team_class = 'team-slide-yes';
			
            $theme_team_show_item = -1;
			
			
            if($settings['theme_team_dot'] == 'yes' ){
				$dots = 'true';
			}else{
				$dots = 'false';
			}
			
			if($settings['theme_team_navv'] == 'yes' ){
				$navss = 'true';
			}else{
				$navss = 'false';
			}
			
			
			
			if($settings['theme_team_aloop'] == 'yes' ){
				$aloop = 'true';
			}else{
				$aloop = 'false';
			}
			
			if($settings['theme_team_loop'] == 'yes' ){
				$loop = 'true';
			}else{
				$loop = 'false';
			}
			
			
			
			?>
			
			
	<script type="text/javascript">
	
		jQuery(document).ready(function ($) {
			
			"use strict";

			/* Team Slider */
			$('.team-slide-new').slick({
				
				slidesToShow: 4,
				slidesToScroll: 4,
					
				arrows: true,

				dots: '<?php echo esc_attr($dots); ?>',
					
				infinite: true,
				
				autoplay: false,
				
				//focusOnSelect : true,
				
				speed: 1500,
				

				prevArrow: '<div class="slide-arrow-left"><i class="las la-long-arrow-alt-left"></i></div>',
				nextArrow: '<div class="slide-arrow-right"><i class="las la-long-arrow-alt-right"></i></div>',
				
				responsive: [
					{
					breakpoint: 1366,
						settings: {
							slidesToShow: 3,
							slidesToScroll: 3,
						}
					},
					{
						breakpoint: 1024,
						settings: {
							slidesToShow: 2,
							slidesToScroll: 2
						}
					},
					{
						breakpoint: 767,
						settings: {
							slidesToShow: 1,
							slidesToScroll: 1
						}
					}
				]	

			 });

		});
    </script>
	
	<?php } else {
			
            $class_row = 'row';
            $theme_team_class = 'col-sm-12 col-md-6 col-lg-4 team_member_custom__Column';
            $theme_team_show_item = $settings['theme_team_item_show'];
			
        }
		
        if($settings['theme_team_select_style'] == 'one'){
            $theme_team_style = 'team-style-one';
        }else{
            $theme_team_style = 'team-style-two';
        }
		
        global $post;
		
        $paged = get_query_var('paged') ? get_query_var('paged') : 1;
		
        $p = new \WP_Query(array(
            'posts_per_page' => esc_attr($theme_team_show_item),
            'post_type' => 'theme_team',
            'order' => 'ASC',
            'paged' => $paged
        ));
        ob_start();
		
		?>


        <div class="theme_team_custom__Wrapper team-section-wrap team_carousel_single_box_section__Main">
            <div class="team_stye_boxx__Single <?php echo esc_attr($theme_team_style); ?>">
			
                <div class="<?php echo esc_attr($class_row); ?> team_carousel_New team-slide-new">
				
                    <?php 
                    
                    while($p->have_posts()) : $p->the_post();
	
                    ?>

                    <div class="<?php echo esc_attr($theme_team_class); ?>">
					
                     <div class="team_carousel_single_box__innerWrapp">

                        <div class="team_carousel_single_box__Inner">
						
                            <div class="team-member-img team_carousel_single_box__Thumbnail">
                                <?php the_post_thumbnail('full',array('class' => 'theme-team-thumbnail')); ?> 
                            </div>
							
                            <div class="team-member-content team_carousel_single_box__innerContent">
                                <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
								
								<h4>

                                    <?php 
                                    
                                    if(get_post_meta( get_the_ID(), 'knor_team_meta', true)) {
                                        $team_member_position = get_post_meta( get_the_ID(), 'knor_team_meta', true );
                                    } else {
                                        $team_member_position = array();
                                    }

                                    if(array_key_exists('team_subtitle', $team_member_position) && !empty($team_member_position['team_subtitle'])){
                                        $team_member_position_item = $team_member_position['team_subtitle'];
                                    }else{
                                        $team_member_position_item = 'Full Stack Developer';
                                    }

									echo esc_html( $team_member_position_item );

                                    
								    ?>
                                    
                                </h4>

                            </div>
							
                        </div>

                    </div>
						
						
                    </div>
                    <?php endwhile; 
					wp_reset_postdata(); 
					wp_reset_query();?>
					
                </div>
            </div>
        </div>


	

	<?php echo ob_get_clean();


	}
				

}

