<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome5AwardSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home5-award-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 5 - Award Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-featured-image';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home5' ];
	}

	public function get_keywords() {
		return [ 'home5awardsection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_award_section',
			[
				'label' => esc_html__( 'Award Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'img_bg_sec',
			[
				'label'       	=> esc_html__( 'Image Background Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image Background section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'show_wrap',
			[
				'label'   		=> esc_html__( 'Show Award Wrap', 'bdevs-elementor' ),
				'type'    		=> Controls_Manager::SWITCHER,
				'label_on' 		=> esc_html__( 'Show', 'bdevs-elementor' ),
				'label_off' 	=> esc_html__( 'Hide', 'bdevs-elementor' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);
		$this->add_control(
			'img_icon',
			[
				'label'       	=> esc_html__( 'Image Icon', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image icon', 'bdevs-elementor' ),
				'condition' 	=> [
					'show_wrap' 	=> 'yes',
				],
			]
		);
		$this->add_control(
			'title_first_char',
			[
				'label' 		=> esc_html__( 'First Char Title', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'w.' , 'bdevs-elementor' ),
				'show_label' 	=> true,
				'condition' 	=> [
					'show_wrap' 	=> 'yes',
				],
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Best award lawyer <br> of the year -2024' , 'bdevs-elementor' ),
				'show_label' 	=> true,
				'condition' 	=> [
					'show_wrap' 	=> 'yes',
				],
			]
		);
		$this->add_control(
			'text_sec',
			[
				'label' 		=> esc_html__( 'Text Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'We believe in <br> quality, not <br> quantity' , 'bdevs-elementor' ),
				'show_label' 	=> true,
				'condition' 	=> [
					'show_wrap' 	=> 'yes',
				],
			]
		);
		$this->add_control(
			'text_btn',
			[
				'label' 		=> esc_html__( 'Text Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Get started now' , 'bdevs-elementor' ),
				'show_label' 	=> true,
				'condition' 	=> [
					'show_wrap' 	=> 'yes',
				],
			]
		);
		$this->add_control(
			'link_btn',
			[
				'label' 		=> esc_html__( 'Link Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '#' , 'bdevs-elementor' ),
				'show_label' 	=> true,
				'condition' 	=> [
					'show_wrap' 	=> 'yes',
				],
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<div class="tp-awerd-5-ptb p-relative">
	<?php if (!empty($settings['img_bg_sec']['url'])): ?>
		<div class="tp-awerd-5-thumb">
			<img class="w-100" data-speed=".8" src="<?php echo wp_kses_post($settings['img_bg_sec']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_bg_sec']['alt']); ?>">
		</div>
	<?php endif ?>
	<?php if (!empty($settings['show_wrap'])): ?>
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="tp-awerd-5-wrap">
						<div class="tp-awerd-5-item">
							<?php if (!empty($settings['img_icon'])): ?>
								<div class="tp-awerd-5-item-icon">
									<img src="<?php echo wp_kses_post($settings['img_icon']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_icon']['alt']); ?>">
								</div>
							<?php endif ?>
							<?php if (!empty($settings['title_first_char']) || !empty($settings['title_sec'])): ?>
								<div class="tp-awerd-5-item-text">
									<?php if (!empty($settings['title_first_char'])): ?>
										<span><?php echo wp_kses_post($settings['title_first_char']); ?></span>
									<?php endif ?>
									<?php if (!empty($settings['title_sec'])): ?>
										<p><?php echo wp_kses_post($settings['title_sec']); ?></p>
									<?php endif ?>
								</div>
							<?php endif ?>
							<?php if (!empty($settings['text_sec'])): ?>
								<div class="tp-awerd-5-item-content">
									<p><?php echo wp_kses_post($settings['text_sec']); ?></p>
								</div>
							<?php endif ?>
							<?php if (!empty($settings['link_btn']) && !empty($settings['text_btn'])): ?>
								<div class="tp-awerd-5-item-btn">
									<a class="tp-btn-5" href="<?php echo wp_kses_post($settings['link_btn']); ?>">
										<?php echo wp_kses_post($settings['text_btn']); ?>
									</a>
								</div>
							<?php endif ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php endif ?>
</div>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		gsap.registerPlugin(ScrollTrigger, ScrollSmoother);
		var smoother = ScrollSmoother.create({
			smooth: 2,
			effects: true,
			smoothTouch: true
		});
	</script>
<?php } ?>

<?php
}

}