<?php
if ( ! defined( 'ABSPATH' ) ) exit;







add_action('widgets_init','knor_category_widget_new');


function knor_category_widget_new(){
		register_widget("knor_category_list_widget_imgg");
}

class knor_category_list_widget_imgg extends WP_Widget {


	function __construct() {
        $widget_opt = array(
            'classname'		 => 'knor-category-list',
            'description'	 => esc_html__('Theme Category List','knor-extra')
        );

        parent::__construct( 'knor_category_list_widget_imgg', esc_html__( 'Knor Category List', 'knor-extra' ), $widget_opt );
    }

	
	public function widget( $args, $instance ) {
		echo $args['before_widget'];
		$theme_cat_markup ='<div class="category_image_wrapper"><div class="theme_cat_custom_list">';
		
		//if ( ! empty( $instance['knor_title'] ) ) {
			//echo $args['before_title'] . apply_filters( 'widget_title', $instance['knor_title'] ) . $args['after_title'];
		//}
		
		if(isset($instance['knor_taxonomy_itemm'])){
			$theme_cat_markup .='<div class="theme-custom-category-lists theme_img_cat_Itemlist cat-custom-wrap-slider">';
				$args_val = array( 'hide_empty=0' );				
				$excludeCat= $instance['knor_selected_categories'] ? $instance['knor_selected_categories'] : '';
				$knor_select_cat_item= $instance['knor_select_cat_item'] ? $instance['knor_select_cat_item'] : '';
				if($excludeCat && $knor_select_cat_item!='')
				$args_val[$knor_select_cat_item] = $excludeCat;
				
				$terms = get_terms( $instance['knor_taxonomy_itemm'], $args_val );
				
				if ( !empty($terms) ) {	

					foreach ( $terms as $term ) {
						$term_link = get_term_link( $term );
						
						if ( is_wp_error( $term_link ) ) {
						continue;
						}
						
					$active_cat_class='';	
					$category_image = '';
					if($term->taxonomy=='category' && is_category())
					{
                 $thisCat = get_category(get_query_var('cat'),false);
              
                
					  if($thisCat->term_id == $term->term_id)
						$active_cat_class='class="active-cat img_cat_item_list_Single"';
				    }
					 
					if(is_tax())
					{
					    $currentTermType = get_query_var( 'taxonomy' );
					    $termId= get_queried_object()->term_id;
						 if(is_tax($currentTermType) && $termId==$term->term_id)
                    $active_cat_class='class="active-cat img_cat_item_list_Single"';
                    
					}
                  
				$category_featured_thumbnail = get_term_meta($term->term_id, 'knor', true);
				$catImg = !empty( $category_featured_thumbnail['cat-bg'] )? $category_featured_thumbnail['cat-bg'] : '';
				$category_image = 'style="background-image:url('.esc_url( $catImg ).');"';
				 
						$theme_cat_markup .='<div class="cat-custom-wrap-box"><div class="cat-custom-wrap"><a '.wp_kses_post($category_image).' href="' . esc_url( $term_link ) . '" class="category_image_single"></a><div class="cat-inner-list cat-list-inner-content"><a href="' . esc_url( $term_link ) . '"><span class="cat-name-single">' . $term->name ;

						$theme_cat_markup .='</a></span><span class="category-number">'.$term->count.' Articles</span></div>';
						
						
						$theme_cat_markup .='</div></div>';
					}
				}
			$theme_cat_markup .='</div>';
			
			}	
		$theme_cat_markup .='</div></div>';

		echo wp_kses_post($theme_cat_markup);
		echo $args['after_widget'];
	}


	public function form( $instance ) {
		//$knor_title 				= ! empty( $instance['knor_title'] ) ? $instance['knor_title'] : esc_html__( 'Theme Categories List', 'knor-extra' );

		$knor_taxonomy_itemm 			= ! empty( $instance['knor_taxonomy_itemm'] ) ? $instance['knor_taxonomy_itemm'] : esc_html__( 'category', 'knor-extra' );
		$knor_selected_categories 	= (! empty( $instance['knor_selected_categories'] ) && ! empty( $instance['knor_select_cat_item'] ) ) ? $instance['knor_selected_categories'] : array();
		$knor_select_cat_item 			= ! empty( $instance['knor_select_cat_item'] ) ? $instance['knor_select_cat_item'] : '';
		?>
		
		

		
		
		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'knor_taxonomy_itemm' ) ); ?>"><?php _e( esc_attr( 'Select Taxonomy Type:' ) ); ?></label> 
		<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'knor_taxonomy_itemm' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'knor_taxonomy_itemm' ) ); ?>">
					<?php 
					$args = array(
					  'public'   => true,
					  '_builtin' => false
					  
					); 
					$output = 'names'; 
					$operator = 'and';
					$taxonomies = get_taxonomies( $args, $output, $operator ); 
					array_push($taxonomies,'category');
					if ( !empty($taxonomies) ) {
					foreach ( $taxonomies as $taxonomy ) {

						echo '<option value="'.$taxonomy.'" '.selected($taxonomy,$knor_taxonomy_itemm).'>'.$taxonomy.'</option>';
					}
					}

				?>    
		</select>
		</p>
		
		<p>
		<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'knor_select_cat_item' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'knor_select_cat_item' ) ); ?>">
           <option value="" <?php selected($knor_select_cat_item,'' )?> > <?php echo esc_html__('Show All Category','knor-extra').' :'; ?> </option>       
           <option value="include" <?php selected($knor_select_cat_item,'include' )?> > <?php echo esc_html__("Choose Category:","knor-extra"); ?> </option>       
           <option value="exclude" <?php selected($knor_select_cat_item,'exclude' )?> > <?php echo esc_html__("Exclude Category","knor-extra").' :'; ?> </option>
		</select> 
		<select class="widefat knor-category-widget" id="<?php echo esc_attr( $this->get_field_id( 'knor_selected_categories' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'knor_selected_categories' ) ); ?>[]" multiple>
					<?php 			
					if($knor_taxonomy_itemm){
					$args = array( 'hide_empty=0' );
					$terms = get_terms( $knor_taxonomy_itemm, $args );
			        echo '<option value="" '.selected(true, in_array('',$knor_selected_categories), false).'>'.esc_html('None ','knor-extra').'</option>';
					if ( !empty($terms) ) {
					foreach ( $terms as $term ) {
						echo '<option value="'.$term->term_id.'" '.selected(true, in_array($term->term_id,$knor_selected_categories), false).'>'.$term->name.'</option>';
					}
				    	
					}
				}

				?>    
		</select>
		</p>
		
		
		<?php 
	}

	
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		//$instance['knor_title'] 					= ( ! empty( $new_instance['knor_title'] ) ) ? strip_tags( $new_instance['knor_title'] ) : '';

		$instance['knor_taxonomy_itemm'] 			= ( ! empty( $new_instance['knor_taxonomy_itemm'] ) ) ? strip_tags( $new_instance['knor_taxonomy_itemm'] ) : '';
		$instance['knor_selected_categories'] 	= ( ! empty( $new_instance['knor_selected_categories'] ) ) ? $new_instance['knor_selected_categories'] : '';
		$instance['knor_select_cat_item'] 			= ( ! empty( $new_instance['knor_select_cat_item'] ) ) ? $new_instance['knor_select_cat_item'] : '';
		
		
		return $instance;
		
		
	}
}





