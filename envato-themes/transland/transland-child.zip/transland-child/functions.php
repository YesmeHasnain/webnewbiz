<?php 

	add_action('wp_enqueue_scripts', 'transland_child_scripts');

	function transland_child_scripts() {
		wp_enqueue_style('parent-theme', get_template_directory_uri() . '/style.css');
	}

?>

