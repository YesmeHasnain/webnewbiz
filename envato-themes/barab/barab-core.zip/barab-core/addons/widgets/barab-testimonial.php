<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Repeater;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
/**
 *
 * Testimonial Slider Widget .
 *
 */
class barab_Testimonial extends Widget_Base{

	public function get_name() {
		return 'barabtestimonialslider';
	}
	public function get_title() {
		return __( 'Testimonials', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'testimonial_slider_section',
			[
				'label' 	=> __( 'Testimonial Slider', 'barab' ), 
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
		);

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two', 'Style Three', 'Style Four', 'Style Five' ] );
		
		barab_media_fields( $this, 'quote', 'Quote Icon', ['1'] );
		barab_media_fields( $this, 'image', 'Choose Image', ['3'] );
		barab_media_fields( $this, 'image2', 'Choose Image 2', ['3'] );

		$repeater = new Repeater();

		barab_media_fields( $repeater, 'client_image', 'Client Image' );
		barab_general_fields( $repeater, 'client_name', 'Client Name', 'TEXT', 'Alex Michel' );
		barab_general_fields( $repeater, 'client_desig', 'Client Designation', 'TEXT', 'Ui/Ux Designer' );
		barab_general_fields( $repeater, 'client_feedback', 'Client Feedback', 'TEXTAREA', 'Our knowledgeable technicians are happy to provide tips' );
		barab_select_field( $repeater, 'client_rating', 'Client Rating', [ 'One Star', 'Two Star', 'Three Star', 'Four Star', 'Five Star' ] );

		$this->add_control(
			'slides',
			[
				'label' 		=> __( 'Slides', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'client_image'	=> Utils::get_placeholder_image_src(),
					],
				],
				'title_field' 	=> '{{{ client_name }}}',
				'condition'		=> [ 
					'layout_style' => [ '1', '3' ],
				],
			]
		);

		$repeater = new Repeater();

		barab_general_fields( $repeater, 'client_name', 'Client Name', 'TEXT', 'Alex Michel' );
		barab_general_fields( $repeater, 'client_desig', 'Client Designation', 'TEXT', 'Ui/Ux Designer' );
		barab_general_fields( $repeater, 'client_feedback', 'Client Feedback', 'TEXTAREA', 'Our knowledgeable technicians are happy to provide tips' );
		barab_select_field( $repeater, 'client_rating', 'Client Rating', [ 'One Star', 'Two Star', 'Three Star', 'Four Star', 'Five Star' ] );

		$this->add_control(
			'slides2',
			[
				'label' 		=> __( 'Slides', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'client_image'	=> Utils::get_placeholder_image_src(),
					],
				],
				'title_field' 	=> '{{{ client_name }}}',
				'condition'		=> [ 
					'layout_style' => [ '2', '4' ],
				],
			]
		);

		$repeater = new Repeater();

		barab_general_fields( $repeater, 'client_name', 'Client Name', 'TEXT', 'Alex Michel' );
		barab_general_fields( $repeater, 'client_desig', 'Client Designation', 'TEXT', 'Ui/Ux Designer' );
		barab_general_fields( $repeater, 'client_feedback', 'Client Feedback', 'TEXTAREA', 'Our knowledgeable technicians are happy to provide tips' );

		$this->add_control(
			'slides3',
			[
				'label' 		=> __( 'Slides', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'client_image'	=> Utils::get_placeholder_image_src(),
					],
				],
				'title_field' 	=> '{{{ client_name }}}',
				'condition'		=> [ 
					'layout_style' => [ '5' ],
				],
			]
		);

		barab_switcher_fields( $this, 'show_direction_left_right', 'Slider Direction Left or Right', ['4'] );

		$this->end_controls_section();

		// Column Responsive controls
		if ( function_exists( 'barab_add_responsive_columns_controls' ) ) {
			barab_add_responsive_columns_controls( $this, ['layout_style' => ['1'] ] );
		}

        //---------------------------------------
			//Style Section Start
		//---------------------------------------
		barab_common_style_fields( $this, '01', 'Name', '{{WRAPPER}} .box-title', ['1'] );
		barab_common_style_fields( $this, '011', 'Name', '{{WRAPPER}} .testi-card_name', ['2', '3', '4', '5'] );
		barab_common_style_fields( $this, '02', 'Designation', '{{WRAPPER}} .desig', ['1', '2', '3', '4', '5'] );
		barab_common_style_fields( $this, '03', 'Feedback', '{{WRAPPER}} .box-text', ['1'] );
		barab_common_style_fields( $this, '032', 'Feedback', '{{WRAPPER}} .testi-card_text', ['2', '3', '4', '5'] );
		
	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		if( $settings['layout_style'] == '1' ){
			// Get Column Responsive controls Class
			if ( function_exists( 'barab_get_responsive_columns_class' ) ) {
				$column_class = barab_get_responsive_columns_class( $settings );
			} else {
				$column_class = 'col-xl-6';
			}

            echo '<div class="row gy-40 gx-30">';
				foreach( $settings['slides'] as $key => $data ){
					$delay = number_format(0.3 + (floor($key / 2) * 0.2), 1);
					$animation = ($key % 2 == 0) ? 'fadeinleft' : 'fadeinright';
					echo '<div class="' . esc_attr( $column_class ) . '">';
						echo '<div class="testi-1-item wow ' . esc_attr($animation) . '" data-wow-delay="' . $delay . 's">';
							if(!empty($data['client_image']['url'])){
								echo '<div class="client-thumb">';
									echo barab_img_tag( array(
										'url'	=> esc_url( $data['client_image']['url'] ),
									) );
								echo '</div>';
							}
							echo '<div class="content">';
								echo barab_img_tag( array(
									'url'   => esc_url( $settings['quote']['url'] ),
									'class' => 'testi-1-quote'
								)); 
								if(!empty($data['client_feedback'])){
									echo '<p class="box-text">'.esc_html( $data['client_feedback'] ).'</p>';
								}
							echo '</div>';
							echo '<div class="bottom">';
								if(!empty($data['client_name'])){
									echo '<h3 class="box-title">'.esc_html( $data['client_name'] ).'</h3>';
								}
								if(!empty($data['client_desig'])){
									echo '<p class="desig">'.esc_html( $data['client_desig'] ).'</p>';
								}
								echo '<div class="th-social">';
									if( $data['client_rating'] == '1' ){
										echo '<i class="fa-sharp fa-solid fa-star"></i>';
										echo '<i class="far fa-star"></i>';
										echo '<i class="far fa-star"></i>';
										echo '<i class="far fa-star"></i>';
										echo '<i class="far fa-star"></i>';
									}elseif( $data['client_rating'] == '2' ){
										echo '<i class="fa-sharp fa-solid fa-star"></i>';
										echo '<i class="fa-sharp fa-solid fa-star"></i>';
										echo '<i class="far fa-star"></i>';
										echo '<i class="far fa-star"></i>';
										echo '<i class="far fa-star"></i>';
									}elseif( $data['client_rating'] == '3' ){
										echo '<i class="fa-sharp fa-solid fa-star"></i>';
										echo '<i class="fa-sharp fa-solid fa-star"></i>';
										echo '<i class="fa-sharp fa-solid fa-star"></i>';
										echo '<i class="far fa-star"></i>';
										echo '<i class="far fa-star"></i>';
									}elseif( $data['client_rating'] == '4' ){
										echo '<i class="fa-sharp fa-solid fa-star"></i>';
										echo '<i class="fa-sharp fa-solid fa-star"></i>';
										echo '<i class="fa-sharp fa-solid fa-star"></i>';
										echo '<i class="fa-sharp fa-solid fa-star"></i>';
										echo '<i class="far fa-star"></i>';
									}else{
										echo '<i class="fa-sharp fa-solid fa-star"></i>';
										echo '<i class="fa-sharp fa-solid fa-star"></i>';
										echo '<i class="fa-sharp fa-solid fa-star"></i>';
										echo '<i class="fa-sharp fa-solid fa-star"></i>';
										echo '<i class="fa-sharp fa-solid fa-star"></i>';
									}
								echo '</div>';
							echo '</div>';
						echo '</div>';
					echo '</div>';
				}
            echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
			echo '<div class="testi-slider2">';
				echo '<div class="swiper th-slider testiSlide2" id="testiSlide2" data-slider-options=\'{"autoplay":false,"effect":"fade", "autoHeight": "true"}\'>';
					echo '<div class="swiper-wrapper">';
						foreach( $settings['slides2'] as $key => $data ){
							echo '<div class="swiper-slide">';
								echo '<div class="testi-card2">';
									echo '<div class="media-body">';
										echo '<div class="testi-card_profile">';
											echo '<div class="testi-card_content">';
												echo '<div class="reating">';
													echo '<ul>';
														if( $data['client_rating'] == '1' ){
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="far fa-star"></i>';
															echo '<i class="far fa-star"></i>';
															echo '<i class="far fa-star"></i>';
															echo '<i class="far fa-star"></i>';
														}elseif( $data['client_rating'] == '2' ){
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="far fa-star"></i>';
															echo '<i class="far fa-star"></i>';
															echo '<i class="far fa-star"></i>';
														}elseif( $data['client_rating'] == '3' ){
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="far fa-star"></i>';
															echo '<i class="far fa-star"></i>';
														}elseif( $data['client_rating'] == '4' ){
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="far fa-star"></i>';
														}else{
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
														}
													echo '</ul>';
												echo '</div>';
												if(!empty($data['client_feedback'])){
													echo '<p class="testi-card_text">'.esc_html( $data['client_feedback'] ).'</p>';
												}
												if(!empty($data['client_name'])){
													echo '<h3 class="testi-card_name">'.esc_html( $data['client_name'] ).'</h3>';
												}
												if(!empty($data['client_desig'])){
													echo '<p class="testi-card_desig desig">'.esc_html( $data['client_desig'] ).'</p>';
												}
											echo '</div>';
										echo '</div>';
									echo '</div>';
								echo '</div>';
							echo '</div>';
						}
					echo '</div>';
					echo '<div class="slider-2-pag-wrap">';
						echo '<div class="slider-pagination"></div>';
						echo '<div class="slider-pagination2"></div>';
					echo '</div>';
				echo '</div>';
			echo '</div>';

		}elseif( $settings['layout_style'] == '3' ){
            echo '<div class="row gy-40">';
                echo '<div class="col-xl-3"> ';
                    echo '<div class="testi-3-left-1">';
						if(!empty($settings['image']['url'])){
							echo barab_img_tag( array(
								'url'	=> esc_url( $settings['image']['url'] ),
							) );
						}
                        echo '<div class="slider-3-pag-wrap">';
                            echo '<button data-slider-prev="#testiSlide3 " class="sin-menu-arrow slider-arrow slider-prev"><i class="far fa-arrow-left"></i></button>';
                            echo '<button data-slider-next="#testiSlide3 " class="sin-menu-arrow slider-arrow slider-next"><i class="far fa-arrow-right"></i></button>';
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
                echo '<div class="col-xl-6">';
                    echo '<div class="testi-slider3">';
                        echo '<div class="swiper th-slider testiSlide3" id="testiSlide3" data-slider-options=\'{"autoplay":true,"effect":"slide", "autoHeight": "true"}\'>';
                            echo '<div class="swiper-wrapper">';
								foreach( $settings['slides'] as $key => $data ){
									echo '<div class="swiper-slide">';
										echo '<div class="testi-card2 style2">';
											if(!empty($data['client_image']['url'])){
												echo '<div class="test-3-thumb">';
													echo barab_img_tag( array(
														'url'	=> esc_url( $data['client_image']['url'] ),
													) );
												echo '</div>';
											}
											echo '<div class="media-body">';
												echo '<div class="testi-card_profile">';
													echo '<div class="testi-card_content">';
														echo '<div class="reating">';
															echo '<ul>';
																if( $data['client_rating'] == '1' ){
																	echo '<li><i class="fa-sharp fa-solid fa-star"></i></li>';
																	echo '<li><i class="far fa-star"></i></li>';
																	echo '<li><i class="far fa-star"></i></li>';
																	echo '<li><i class="far fa-star"></i></li>';
																	echo '<li><i class="far fa-star"></i></li>';
																}elseif( $data['client_rating'] == '2' ){
																	echo '<li><i class="fa-sharp fa-solid fa-star"></i></li>';
																	echo '<li><i class="fa-sharp fa-solid fa-star"></i></li>';
																	echo '<li><i class="far fa-star"></i></li>';
																	echo '<li><i class="far fa-star"></i></li>';
																	echo '<li><i class="far fa-star"></i></li>';
																}elseif( $data['client_rating'] == '3' ){
																	echo '<li><i class="fa-sharp fa-solid fa-star"></i></li>';
																	echo '<li><i class="fa-sharp fa-solid fa-star"></i></li>';
																	echo '<li><i class="fa-sharp fa-solid fa-star"></i></li>';
																	echo '<li><i class="far fa-star"></i></li>';
																	echo '<li><i class="far fa-star"></i></li>';
																}elseif( $data['client_rating'] == '4' ){
																	echo '<li><i class="fa-sharp fa-solid fa-star"></i></li>';
																	echo '<li><i class="fa-sharp fa-solid fa-star"></i></li>';
																	echo '<li><i class="fa-sharp fa-solid fa-star"></i></li>';
																	echo '<li><i class="fa-sharp fa-solid fa-star"></i></li>';
																	echo '<li><i class="far fa-star"></i></li>';
																}else{
																	echo '<li><i class="fa-sharp fa-solid fa-star"></i></li>';
																	echo '<li><i class="fa-sharp fa-solid fa-star"></i></li>';
																	echo '<li><i class="fa-sharp fa-solid fa-star"></i></li>';
																	echo '<li><i class="fa-sharp fa-solid fa-star"></i></li>';
																	echo '<li><i class="fa-sharp fa-solid fa-star"></i></li>';
																}
															echo '</ul>';
														echo '</div>';
														if(!empty($data['client_feedback'])){
															echo '<p class="testi-card_text">'.esc_html( $data['client_feedback'] ).'</p>';
														}
														if(!empty($data['client_name'])){
															echo '<h3 class="testi-card_name">'.esc_html( $data['client_name'] ).'</h3>';
														}
														if(!empty($data['client_desig'])){
															echo '<p class="testi-card_desig desig">'.esc_html( $data['client_desig'] ).'</p>';
														}
													echo '</div>';
												echo '</div>';
											echo '</div>';
										echo '</div>';
									echo '</div>';
								}
                            echo '</div>';
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
                echo '<div class="col-xl-3">';
					if(!empty($settings['image2']['url'])){
						echo '<div class="testi-3-right-1">';
							echo barab_img_tag( array(
								'url'	=> esc_url( $settings['image2']['url'] ),
							) );
						echo '</div>';
					}
                echo '</div>';
            echo '</div>';

		}elseif( $settings['layout_style'] == '4' ){
	        echo '<div class="testi-slider4">';
				if(!empty( $settings['show_direction_left_right'])){
					echo '<div class="swiper th-slider testiSlide4" id="testiSlide4" data-slider-options=\'{"centeredSlides":false,"breakpoints":{"0":{"slidesPerView":1},"576":{"slidesPerView":"1"},"768":{"slidesPerView":"2"},"992":{"slidesPerView":"2"},"1200":{"slidesPerView":"3"},"1500":{"slidesPerView":"4"}}}\'>';
				}else{
					echo '<div class="swiper th-slider testiSlide5" id="testiSlide5" data-slider-options=\'{"centeredSlides":true, "autoplay": { "delay": 3000, "reverseDirection": true}, "breakpoints":{"0":{"slidesPerView":1},"576":{"slidesPerView":"1"},"768":{"slidesPerView":"2"},"992":{"slidesPerView":"2"},"1200":{"slidesPerView":"2.2"},"1500":{"slidesPerView":"3.5"}}}\'>';
				}
                    echo '<div class="swiper-wrapper">';
						foreach( $settings['slides2'] as $key => $data ){
							echo '<div class="swiper-slide">';
								echo '<div class="testi-card2 style2 style3">';
									echo '<div class="media-body">';
										echo '<div class="testi-card_profile">';
											echo '<div class="testi-card_content">';
												echo '<div class="reating">';
													echo '<ul>';
														if( $data['client_rating'] == '1' ){
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="far fa-star"></i>';
															echo '<i class="far fa-star"></i>';
															echo '<i class="far fa-star"></i>';
															echo '<i class="far fa-star"></i>';
														}elseif( $data['client_rating'] == '2' ){
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="far fa-star"></i>';
															echo '<i class="far fa-star"></i>';
															echo '<i class="far fa-star"></i>';
														}elseif( $data['client_rating'] == '3' ){
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="far fa-star"></i>';
															echo '<i class="far fa-star"></i>';
														}elseif( $data['client_rating'] == '4' ){
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="far fa-star"></i>';
														}else{
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
															echo '<i class="fa-sharp fa-solid fa-star"></i>';
														}
													echo '</ul>';
												echo '</div>';
												if(!empty($data['client_feedback'])){
													echo '<p class="testi-card_text">'.esc_html( $data['client_feedback'] ).'</p>';
												}
												if(!empty($data['client_name'])){
													echo '<h3 class="testi-card_name">'.esc_html( $data['client_name'] ).'</h3>';
												}
												if(!empty($data['client_desig'])){
													echo '<span class="testi-card_desig desig">'.esc_html( $data['client_desig'] ).'</span>';
												}
											echo '</div>';
										echo '</div>';
									echo '</div>';
								echo '</div>';
							echo '</div>';
						}
                    echo '</div>';
                echo '</div>';
            echo '</div>';
 
		}elseif( $settings['layout_style'] == '5' ){
            echo '<div class="testi-slider5">';
                echo '<div class="swiper th-slider testiSlide5" id="testiSlide5" data-slider-options=\'{"spaceBetween":40,"autoplay":true, "loop": true, "centeredSlides":true,"breakpoints":{"0":{"slidesPerView":1},"576":{"slidesPerView":"1"},"768":{"slidesPerView":"1"},"992":{"slidesPerView":"1"},"1200":{"slidesPerView":"2"},"1300":{"slidesPerView":"3"}}}\'>';
                    echo '<div class="swiper-wrapper">';
						foreach( $settings['slides3'] as $key => $data ){
							echo '<div class="swiper-slide">';
								echo '<div class="testi-card5">';
									echo '<div class="testi-card_content">';
										if(!empty($data['client_feedback'])){
											echo '<p class="testi-card_text">'.esc_html( $data['client_feedback'] ).'</p>';
										}
										if(!empty($data['client_name'])){
											echo '<h3 class="testi-card_name">'.esc_html( $data['client_name'] ).'</h3>';
										}
										if(!empty($data['client_desig'])){
											echo '<span class="testi-card_desig desig">'.esc_html( $data['client_desig'] ).'</span>';
										}
									echo '</div>';
								echo '</div>';
							echo '</div>';
						}
                    echo '</div>';
                echo '</div>';
                echo '<div class="sec-btn mb-1">';
                    echo '<div class="food2-icon-arrow style-2">';
                        echo '<button data-slider-prev="#testiSlide5" class="slider-arrow style3 default slider-prev"><img src="'.BARAB_ASSETS.'img/icon/left-arrow.svg" alt="'.esc_attr__('Arrow Icon', 'barab').'"></button>';
                        echo '<button data-slider-next="#testiSlide5" class="slider-arrow style3 default slider-next"><img src="'.BARAB_ASSETS.'img/icon/right-arrow.svg" alt="'.esc_attr__('Arrow Icon', 'barab').'"></button>';
                    echo '</div>';
                echo '</div>';
            echo '</div>';

		}


	}

}