<?php
namespace TwinkleCore\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Twinkle_Slider extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'twinkle_slider';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Slider', 'twinkle-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'twinkle-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'twinkle_core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'twinkle-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        // layout Panel
        $this->start_controls_section(
            'twinkle_layout',
            [
                'label' => esc_html__('Design Layout', 'twinkle-core'),
            ]
        );
        $this->add_control(
            'twinkle_design_style',
            [
                'label' => esc_html__('Select Layout', 'twinkle-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'twinkle-core'),
                    'layout-2' => esc_html__('Layout 2', 'twinkle-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();
		
		$this->start_controls_section(
            'twinkle_main_slider',
            [
                'label' => esc_html__('Main Slider', 'twinkle-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'twinkle-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

	        $repeater->add_control(
	            'twinkle_slider_image',
	            [
	                'label' => esc_html__('Upload Image', 'twinkle-core'),
	                'type' => Controls_Manager::MEDIA,
	                'default' => [
	                    'url' => Utils::get_placeholder_image_src(),
	                ]
	            ]
	        );

            $repeater->add_control(
	            'twinkle_video_switcher',
	            [
	                'label' => esc_html__( 'Add Button link', 'twinkle-core' ),
	                'type' => Controls_Manager::SWITCHER,
	                'label_on' => esc_html__( 'Yes', 'twinkle-core' ),
	                'label_off' => esc_html__( 'No', 'twinkle-core' ),
	                'return_value' => 'yes',
	                'default' => 'yes',
	                'separator' => 'before',
	            ]
	        );

            $repeater->add_control(
                'twinkle_video_url',
                [
                    'label' => esc_html__('Video URL', 'twinkle-core'),
                    'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => 'https://www.youtube.com/watch?v=06dV9txztKY',
                    'condition' => [
                        'twinkle_video_switcher' => 'yes',
                    ],
                ]
            );

            $repeater->add_control(
                'twinkle_top_big_title',
                [
                    'label' => esc_html__('Top Big Title', 'twinkle-core'),
                    'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => esc_html__('Business', 'twinkle-core'),
                ]
            );

            $repeater->add_control(
                'twinkle_bottom_big_title',
                [
                    'label' => esc_html__('Bottom Big Title', 'twinkle-core'),
                    'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => esc_html__('Consulting', 'twinkle-core'),
                ]
            );

            $repeater->add_control(
                'twinkle_slider_title',
                [
                    'label' => esc_html__('Title', 'twinkle-core'),
                    'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('The Best Business <br> for Agency', 'twinkle-core'),
                    'label_block' => true,
                ]
            );

            $repeater->add_control(
                'twinkle_slider_title_tag',
                [
                    'label' => esc_html__('Title HTML Tag', 'twinkle-core'),
                    'type' => Controls_Manager::CHOOSE,
                    'options' => [
                        'h1' => [
                            'title' => esc_html__('H1', 'twinkle-core'),
                            'icon' => 'eicon-editor-h1'
                        ],
                        'h2' => [
                            'title' => esc_html__('H2', 'twinkle-core'),
                            'icon' => 'eicon-editor-h2'
                        ],
                        'h3' => [
                            'title' => esc_html__('H3', 'twinkle-core'),
                            'icon' => 'eicon-editor-h3'
                        ],
                        'h4' => [
                            'title' => esc_html__('H4', 'twinkle-core'),
                            'icon' => 'eicon-editor-h4'
                        ],
                        'h5' => [
                            'title' => esc_html__('H5', 'twinkle-core'),
                            'icon' => 'eicon-editor-h5'
                        ],
                        'h6' => [
                            'title' => esc_html__('H6', 'twinkle-core'),
                            'icon' => 'eicon-editor-h6'
                        ]
                    ],
                    'default' => 'h2',
                    'toggle' => false,
                ]
            );

            $repeater->add_control(
                'twinkle_slider_description',
                [
                    'label' => esc_html__('Description', 'twinkle-core'),
                    'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => __('There are many variations of passages of Lorem Ipsum available, but <br> the majority have suffered ulla pharetra magna etia.', 'twinkle-core'),
                ]
            );

			$repeater->add_control(
	            'twinkle_btn_link_switcher',
	            [
	                'label' => esc_html__( 'Add Button link', 'twinkle-core' ),
	                'type' => Controls_Manager::SWITCHER,
	                'label_on' => esc_html__( 'Yes', 'twinkle-core' ),
	                'label_off' => esc_html__( 'No', 'twinkle-core' ),
	                'return_value' => 'yes',
	                'default' => 'yes',
	                'separator' => 'before',
	            ]
	        );

	        $repeater->add_control(
	            'twinkle_btn_btn_text',
	            [
	                'label' => esc_html__('Button Text', 'twinkle-core'),
	                'type' => Controls_Manager::TEXT,
	                'default' => esc_html__('Button Text', 'twinkle-core'),
	                'title' => esc_html__('Enter button text', 'twinkle-core'),
	                'label_block' => true,
	                'condition' => [
	                    'twinkle_btn_link_switcher' => 'yes'
	                ],
	            ]
	        );

	        $repeater->add_control(
	            'twinkle_btn_link_type',
	            [
	                'label' => esc_html__( 'Button Link Type', 'twinkle-core' ),
	                'type' => Controls_Manager::SELECT,
	                'options' => [
	                    '1' => 'Custom Link',
	                    '2' => 'Internal Page',
	                ],
	                'default' => '1',
	                'condition' => [
	                    'twinkle_btn_link_switcher' => 'yes'
	                ]
	            ]
	        );
	        $repeater->add_control(
	            'twinkle_btn_link',
	            [
	                'label' => esc_html__( 'Button Link link', 'twinkle-core' ),
	                'type' => Controls_Manager::URL,
	                'dynamic' => [
	                    'active' => true,
	                ],
	                'placeholder' => esc_html__( 'https://your-link.com', 'twinkle-core' ),
	                'show_external' => true,
	                'default' => [
	                    'url' => '#',
	                    'is_external' => false,
	                    'nofollow' => false,
	                ],
	                'condition' => [
	                    'twinkle_btn_link_type' => '1',
	                    'twinkle_btn_link_switcher' => 'yes',
	                ]
	            ]
	        );
	        $repeater->add_control(
	            'twinkle_btn_page_link',
	            [
	                'label' => esc_html__( 'Select Button Link Page', 'twinkle-core' ),
	                'type' => Controls_Manager::SELECT2,
	                'label_block' => true,
	                'options' => twinkle_get_all_pages(),
	                'condition' => [
	                    'twinkle_btn_link_type' => '2',
	                    'twinkle_btn_link_switcher' => 'yes',
	                ]
	            ]
	        );


        $this->add_control(
            'slider_list',
            [
                'label' => esc_html__('Slider List', 'twinkle-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'twinkle_slider_title' => __('The Best Business <br> for Agency', 'twinkle-core')
                    ],
                    [
                        'twinkle_slider_title' => __('The Best Business <br> for Agency', 'twinkle-core')
                    ],
                    [
                        'twinkle_slider_title' => __('The Best Business <br> for Agency', 'twinkle-core')
                    ],
                ],
                'title_field' => '{{{ twinkle_slider_title }}}',
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
            '_main_slider_style',
            [
                'label' => __( 'Main Slider', 'twinkle-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // Top Big Title
        $this->add_control(
            '_heading_top_big_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Top Big Title', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'top_big_title_color',
            [
                'label' => __( 'Text', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .top-big-title' => '-webkit-text-stroke-color: {{VALUE}}',
                ],
            ]
        );

        // Bottom Big Title
        $this->add_control(
            '_heading_bottom_big_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Bottom Big Title', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'bottom_big_title_color',
            [
                'label' => __( 'Text', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bottom-big-title' => '-webkit-text-stroke-color: {{VALUE}}',
                ],
            ]
        );

        // Dots    
        $this->add_control(
            '_heading_dots',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Dots', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'dots_color',
            [
                'label' => __( 'Dots', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .main-slider .owl-theme .owl-dots .owl-dot span' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'dots_color_active',
            [
                'label' => __( 'Dots Active', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .main-slider .owl-theme .owl-dots .owl-dot:hover span' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider .owl-theme .owl-dots .owl-dot.active span' => 'border-color: {{VALUE}}',
                ],
            ]
        );

        // Title    
        $this->add_control(
            '_heading_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Title', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'title_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .main-slider__title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .main-slider__title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .main-slider__title',
            ]
        );

        // Description
        $this->add_control(
            '_content_description',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Description', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'description_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .main-slider__sub-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'description_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .main-slider__sub-title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'selector' => '{{WRAPPER}} .main-slider__sub-title',
            ]
        );

        $this->start_controls_tabs( 'tabs_video_style' );

        $this->start_controls_tab(
            'video_tab',
            [
                'label' => esc_html__( 'Normal', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'video_color',
            [
                'label'     => esc_html__( 'Text', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .slider-play-btn .video-popup span::before'    => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'video_background',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .slider-play-btn' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'video_border',
            [
                'label'     => esc_html__( 'Border', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .slider-play-btn .border-round' => 'border-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'video_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'video_color_hover',
            [
                'label'     => esc_html__( 'Text', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .slider-play-btn:hover .video-popup span::before' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'video_background_hover',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .slider-play-btn:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'video_border_hover',
            [
                'label'     => esc_html__( 'Border', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .slider-play-btn:hover .border-round' => 'border-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        $this->start_controls_section(
			'twinkle_button_style',
			[
				'label' => __( 'Button', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->start_controls_tabs( 'tabs_button_style' );

        $this->start_controls_tab(
            'button_tab',
            [
                'label' => esc_html__( 'Normal', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'button_color',
            [
                'label'     => esc_html__( 'Text', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thm-btn'    => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_background',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thm-btn' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'button_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'button_color_hover',
            [
                'label'     => esc_html__( 'Text', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thm-btn:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_background_hover',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thm-btn:after, .thm-btn:before' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_control(
            'button_border_radius',
            [
                'label'     => esc_html__( 'Border Radius', 'twinkle-core' ),
                'type'      => Controls_Manager::SLIDER,
                'selectors' => [
                    '{{WRAPPER}} .thm-btn' => 'border-radius: {{SIZE}}px;',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'label'    => esc_html__( 'Typography', 'twinkle-core' ),
                'name'     => 'button_typography',
                'selector' => '{{WRAPPER}} .thm-btn',
            ]
        );

        $this->add_control(
            'button_padding',
            [
                'label'      => esc_html__( 'Padding', 'twinkle-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .thm-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'button_margin',
            [
                'label'      => esc_html__( 'Margin', 'twinkle-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .thm-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<?php if ( $settings['twinkle_design_style']  == 'layout-1' ): ?>

            <section class="main-slider main-slider--one">
                <div class="main-slider__carousel owl-carousel owl-theme thm-owl__carousel"
                    data-owl-options='{"loop": true, "items": 1, "navText": ["<span class=\"icon-left-arrow\"></span>","<span class=\"icon-right-arrow\"></span>"], "margin": 0, "dots": true, "nav": true, "animateOut": "slideOutDown", "animateIn": "fadeIn", "active": true, "smartSpeed": 1000, "autoplay": true, "autoplayTimeout": 7000, "autoplayHoverPause": false}'>

                <?php foreach ($settings['slider_list'] as $item) :
                    $this->add_render_attribute('title_args', 'class', 'main-slider__title');

                    if ( !empty($item['twinkle_slider_image']['url']) ) {
                        $twinkle_slider_image_url = !empty($item['twinkle_slider_image']['id']) ? wp_get_attachment_image_url( $item['twinkle_slider_image']['id'], 'full') : $item['twinkle_slider_image']['url'];
                        $twinkle_slider_image_alt = get_post_meta($item["twinkle_slider_image"]["id"], "_wp_attachment_image_alt", true);
                    }

                    // btn Link
                    if ('2' == $item['twinkle_btn_link_type']) {
                        $link = get_permalink($item['twinkle_btn_page_link']);
                        $target = '_self';
                        $rel = 'nofollow';
                    } else {
                        $link = !empty($item['twinkle_btn_link']['url']) ? $item['twinkle_btn_link']['url'] : '';
                        $target = !empty($item['twinkle_btn_link']['is_external']) ? '_blank' : '';
                        $rel = !empty($item['twinkle_btn_link']['nofollow']) ? 'nofollow' : '';
                    }
                ?>
                <div class="item main-slider__slide-1">
                    <div class="main-slider__bg" style="background-image: url(<?php echo esc_url($twinkle_slider_image_url); ?>);"></div>
                    <div class="container">
                        <div class="main-slider__content">
                            <div class="top-big-title"><?php echo twinkle_kses( $item['twinkle_top_big_title'] ); ?></div>
                            <?php
                                if ($item['twinkle_slider_title_tag']) :
                                    printf('<%1$s %2$s>%3$s</%1$s>',
                                        tag_escape($item['twinkle_slider_title_tag']),
                                        $this->get_render_attribute_string('title_args'),
                                        twinkle_kses($item['twinkle_slider_title'])
                                    );
                                endif;
                            ?>
                            <?php if (!empty($item['twinkle_slider_description'])) : ?>
                                <p class="main-slider__sub-title"><?php echo twinkle_kses( $item['twinkle_slider_description'] ); ?></p>
                            <?php endif; ?>
                            <?php if (!empty($link)) : ?>
                                <div class="main-slider__btn-box">
                                    <a target="<?php echo esc_attr($target); ?>" rel="<?php echo esc_attr($rel); ?>" href="<?php echo esc_url($link); ?>" class="main-slider__btn thm-btn">
                                        <?php echo twinkle_kses($item['twinkle_btn_btn_text']); ?>
                                    </a>
                                </div>
                            <?php endif; ?>
                            
                            <div class="bottom-big-title"><?php echo twinkle_kses( $item['twinkle_bottom_big_title'] ); ?></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?> 

            </div>
        </section>
         
           		
        <?php elseif ( $settings['twinkle_design_style']  == 'layout-2' ): ?>

            <section class="main-slider main-slider--two">
				<div class="main-slider__carousel owl-carousel owl-theme thm-owl__carousel"
					data-owl-options='{"loop": true, "items": 1, "navText": ["<span class=\"icon-left-arrow\"></span>","<span class=\"icon-right-arrow\"></span>"], "margin": 0, "dots": true, "nav": true, "animateOut": "slideOutDown", "animateIn": "fadeIn", "active": true, "smartSpeed": 1000, "autoplay": true, "autoplayTimeout": 7000, "autoplayHoverPause": false}'>

					<?php foreach ($settings['slider_list'] as $item) :
						$this->add_render_attribute('title_args', 'class', 'main-slider__title');

						if ( !empty($item['twinkle_slider_image']['url']) ) {
							$twinkle_slider_image_url = !empty($item['twinkle_slider_image']['id']) ? wp_get_attachment_image_url( $item['twinkle_slider_image']['id'], 'full') : $item['twinkle_slider_image']['url'];
							$twinkle_slider_image_alt = get_post_meta($item["twinkle_slider_image"]["id"], "_wp_attachment_image_alt", true);
						}

						// btn Link
						if ('2' == $item['twinkle_btn_link_type']) {
							$link = get_permalink($item['twinkle_btn_page_link']);
							$target = '_self';
							$rel = 'nofollow';
						} else {
							$link = !empty($item['twinkle_btn_link']['url']) ? $item['twinkle_btn_link']['url'] : '';
							$target = !empty($item['twinkle_btn_link']['is_external']) ? '_blank' : '';
							$rel = !empty($item['twinkle_btn_link']['nofollow']) ? 'nofollow' : '';
						}
					?>
					<div class="item main-slider__slide-1 text-center">
						<div class="main-slider__bg" style="background-image: url(<?php echo esc_url($twinkle_slider_image_url); ?>);"></div>
						<div class="container">
							<div class="main-slider__content">
								<div class="top-big-title"><?php echo twinkle_kses( $item['twinkle_top_big_title'] ); ?></div>
								<?php
									if ($item['twinkle_slider_title_tag']) :
										printf('<%1$s %2$s>%3$s</%1$s>',
											tag_escape($item['twinkle_slider_title_tag']),
											$this->get_render_attribute_string('title_args'),
											twinkle_kses($item['twinkle_slider_title'])
										);
									endif;
								?>
								<?php if (!empty($item['twinkle_slider_description'])) : ?>
									<p class="main-slider__sub-title"><?php echo twinkle_kses( $item['twinkle_slider_description'] ); ?></p>
								<?php endif; ?>
								<?php if (!empty($link)) : ?>
									<div class="main-slider__btn-box">
										<a target="<?php echo esc_attr($target); ?>" rel="<?php echo esc_attr($rel); ?>" href="<?php echo esc_url($link); ?>" class="main-slider__btn thm-btn">
											<?php echo twinkle_kses($item['twinkle_btn_btn_text']); ?>
										</a>
									</div>
								<?php endif; ?>
								<div class="bottom-big-title"><?php echo twinkle_kses( $item['twinkle_bottom_big_title'] ); ?></div>
								<div class="slider-play-btn">
									<a class="video-popup" title="Video Gallery" href="<?php echo esc_url($item['twinkle_video_url']); ?>">
										<div class="border-round"></div>
										<span class="icon-play"></span>
									</a>
								</div>
							</div>
						</div>
					</div>
					<?php endforeach; ?> 

				</div>
			</section>
        
         <?php endif; ?>


		<?php 
	}
}

$widgets_manager->register( new Twinkle_Slider() );