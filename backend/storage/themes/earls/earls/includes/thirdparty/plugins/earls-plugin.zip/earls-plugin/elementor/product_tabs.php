<?php

namespace EARLSPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Product_Tabs extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'earls_product_tabs';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Earls Product Tabs', 'earls' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-tabs';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'earls' ];
	}
	
	public function get_script_depends() {
		wp_register_script( 'product-tab', YT_URL . 'assets/js/product-tabs.js', [ 'elementor-frontend' ], '1.0.0', true );
		return [ 'product-tab' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'product_tabs',
			[
				'label' => esc_html__( 'General', 'earls' ),
				'tab' => Controls_Manager::TAB_LAYOUT,
			]
		);
		$this->add_control(
			'sidebar_slug',
			[
				'label'   => esc_html__( 'Choose Sidebar', 'fuzze' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'Choose Sidebar',
				'options'  => earls_get_sidebars(),
			]
		);
		$this->add_control(
			'show_pagination',
			[
				'label'       => __( 'Enable/Disable Pagination', 'earls' ),
                'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'earls' ),
				'label_off' => __( 'Hide', 'earls' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->end_controls_section();
		
		//Product List View
		$this->start_controls_section(
            'list_view',
            [
                'label' => esc_html__( 'Product List View', 'earls' ),
				'tab' => Controls_Manager::TAB_LAYOUT,
            ]
        );
		$this->add_control(
			'query_number',
			[
				'label'   => esc_html__( 'Number of post', 'earls' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			]
		);
		$this->add_control(
			'query_orderby',
			[
				'label'   => esc_html__( 'Order By', 'earls' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => array(
					'date'       => esc_html__( 'Date', 'earls' ),
					'title'      => esc_html__( 'Title', 'earls' ),
					'menu_order' => esc_html__( 'Menu Order', 'earls' ),
					'rand'       => esc_html__( 'Random', 'earls' ),
				),
			]
		);
		$this->add_control(
			'query_order',
			[
				'label'   => esc_html__( 'Order', 'earls' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => array(
					'DESC' => esc_html__( 'DESC', 'earls' ),
					'ASC'  => esc_html__( 'ASC', 'earls' ),
				),
			]
		);
		$this->add_control(
            'query_category', 
			[
			  'type' => Controls_Manager::SELECT,
			  'label' => esc_html__('Category', 'earls'),
			  'options' => get_product_categories(),
			  'label_block' => true,
			]
		);
		$this->end_controls_section();
		
		
		//Product Grid View
		$this->start_controls_section(
            'grid_view',
            [
                'label' => esc_html__( 'Product Grid View', 'earls' ),
				'tab' => Controls_Manager::TAB_LAYOUT,
            ]
        );
		$this->add_control(
            'query_numbers',
            [
                'label'   => esc_html__( 'Number of post', 'earls' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 5,
                'min'     => 1,
                'max'     => 100,
                'step'    => 1,
            ]
        );
        $this->add_control(
            'query_orderbys',
            [
                'label'   => esc_html__( 'Order By', 'earls' ),
				'label_block' => true,
                'type'    => Controls_Manager::SELECT,
                'default' => 'date',
                'options' => array(
                    'date'       => esc_html__( 'Date', 'earls' ),
                    'title'      => esc_html__( 'Title', 'earls' ),
                    'menu_order' => esc_html__( 'Menu Order', 'earls' ),
                    'rand'       => esc_html__( 'Random', 'earls' ),
                ),
            ]
        );
        $this->add_control(
            'query_orders',
            [
                'label'   => esc_html__( 'Order', 'earls' ),
				'label_block' => true,
                'type'    => Controls_Manager::SELECT,
                'default' => 'ASC',
                'options' => array(
                    'DESC' => esc_html__( 'DESC', 'earls' ),
                    'ASC'  => esc_html__( 'ASC', 'earls' ),
                ),
            ]
        );
        $this->add_control(
            'query_categorys',
            [
                'type' => Controls_Manager::SELECT,
                'label' => esc_html__('Category', 'earls'),
				'label_block' => true,
                'options' => get_product_categories(),
            ]
        );
		$this->end_controls_section();
		
	}
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');
		
        $paged = get_query_var('paged');
		$paged = earls_set($_REQUEST, 'paged') ? esc_attr($_REQUEST['paged']) : $paged;

		$this->add_render_attribute( 'wrapper', 'class', 'templatepath-earls' );
		$args = array(
			'post_type'      => 'product',
			'posts_per_page' => earls_set( $settings, 'query_number' ),
			'orderby'        => earls_set( $settings, 'query_orderby' ),
			'order'          => earls_set( $settings, 'query_order' ),
			'paged'         => $paged
		);
		
		if( earls_set( $settings, 'query_category' ) ) $args['product_cat'] = earls_set( $settings, 'query_category' );
		$query = new \WP_Query( $args );
		
		//Second Query
		$args2 = array(
            'post_type'      => 'product',
            'posts_per_page' => earls_set( $settings, 'query_numbers' ),
            'orderby'        => earls_set( $settings, 'query_orderbys' ),
            'order'          => earls_set( $settings, 'query_orders' ),
            'paged'         => $paged
        );

        if( earls_set( $settings, 'query_categorys' ) ) $args2['product_cat'] = earls_set( $settings, 'query_categorys' );
        $query2 = new \WP_Query( $args2 );

		if ( $query->have_posts() ) 
	{ ?>
		
    <!-- shop-page-section -->
    <section class="shop-page-section sidebar-page-container shop-page-1 woocommerce">
        <div class="medium-container">
            <div class="row clearfix">
                <div class="<?php if( is_active_sidebar( $settings['sidebar_slug'])) echo 'col-lg-9 col-md-12 col-sm-12'; else  echo 'col-lg-12 col-md-12 col-sm-12'; ?> content-side">
                    <div class="tabs-box">
                        <div class="sidebar-content">
                            <div class="item-shorting ">
                                
                                <div class="right-column pull-right">
                                    <div class="menu-box">
                                        <div class="list__button">
                                            <div class="tab-btn-box p_relative">
                                                <ul class="tab-btns tab-buttons">
                                                    <li class="tab-btn active-btn" data-tab="#tab-5">
                                                        <span class="grid__button"> <span class="icon-list"></span> </span>
                                                    </li>
                                                    <li class="tab-btn" data-tab="#tab-6">
                                                        <span class="grid__button"> <span class="icon-grid"></span> </span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>                                        
                                </div>
                                
                            </div>
                            <div class="our-shop">
                                <div class="tabs-content wow fadeInUp animated animated" data-wow-delay="00ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInUp;">
                                    <div class="tab active-tab" id="tab-5">
                                        <div class="row">
                                            <?php 
												global $post;
												while ( $query->have_posts() ) : $query->the_post(); 
												$post_thumbnail_id = get_post_thumbnail_id($post->ID);
												$post_thumbnail_url = wp_get_attachment_url( $post_thumbnail_id );
											?>
                                            <div class="col-lg-6 col-md-12 col-sm-12">
                                                <div class="shop__content">
                                                    <div class="shop__left">
                                                        <div class="inner-box">
                                                            <figure class="image-box">
                                                                <?php the_post_thumbnail('earls_238x146'); ?>
                                                            </figure>
                                                            <div class="lower-content">
                                                                <div class="product__icon">
                                                                    <ul>
                                                                        <?php
																			$cart_url = wc_get_cart_url();
																			if ($cart_url) :
																		?>
																		<li><a href="<?php echo esc_url($cart_url); ?>"><span class="icon-shopping-bag"></span></a></li>
																		<?php endif; ?>
																		<li><a href="<?php echo esc_url($post_thumbnail_url); ?>" class="lightbox-image" data-fancybox="gallery"><span class="icon-quick-view"></span></a></li>
																		<li> <a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><span class="fa fa-link"></span></a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="shop__right">
                                                        <div class="product__content">
                                                            <h5><a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h5>
                                                            <div class="rating">
                                                                <ul>
                                                                    <li><?php woocommerce_template_loop_rating();?></li>
                                                                </ul>
                                                            </div>
                                                            <div class="price">
                                                                <span class="discount__price"><?php woocommerce_template_loop_price();?></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php endwhile; ?>
                                        </div>
                                    </div>
                                    <div class="tab" id="tab-6">
                                        <div class="row">
                                            <?php 
												global $post;
												while ( $query2->have_posts() ) : $query2->the_post();
												$post_thumbnail_id = get_post_thumbnail_id($post->ID);
												$post_thumbnail_url = wp_get_attachment_url( $post_thumbnail_id );
											?>
                                            <div class="col-lg-4 col-md-6 col-sm-12">
                                                <div class="shop__content two d-block">
                                                    <div class="shop__left">
                                                        <div class="inner-box">
                                                            <figure class="image-box">
                                                                <?php the_post_thumbnail('earls_288x391'); ?>
                                                            </figure>
                                                            <div class="lower-content">
                                                                <div class="product__icon">
                                                                    <ul>
                                                                        <?php
																			$cart_url = wc_get_cart_url();
																			if ($cart_url) :
																		?>
																		<li><a href="<?php echo esc_url($cart_url); ?>"><span class="icon-shopping-bag"></span></a></li>
																		<?php endif; ?>
																		<li><a href="<?php echo esc_url($post_thumbnail_url); ?>" class="lightbox-image" data-fancybox="gallery"><span class="icon-quick-view"></span></a></li>
																		<li> <a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><span class="fa fa-link"></span></a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="shop__right">
                                                        <div class="product__content text-center">
                                                            <h5><a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title(); ?> </a></h5>
                                                            <div class="rating">
                                                                <ul>
                                                                    <li><?php woocommerce_template_loop_rating();?></li>
                                                                </ul>
                                                            </div>
                                                            <div class="price">
                                                                <span class="discount__price"><?php woocommerce_template_loop_price();?></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php endwhile; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
							<?php if($settings['show_pagination']) {?>
                            <div class="pagination-wrapper centred">
                                <?php earls_the_pagination2(array('total'=>$query->max_num_pages, 'next_text' => '<i class="fas fa-angle-double-right"></i>', 'prev_text' => '<i class="fas fa-angle-double-left"></i>')); ?>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <?php if ( is_active_sidebar( $settings['sidebar_slug'] ) ) : ?>
                <div class="col-lg-3 col-md-12 col-sm-12 sidebar-side">
                    <div class="sidebar shop-sidebar blog-sidebar">
                    	<?php dynamic_sidebar( $settings['sidebar_slug'] ); ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- shop-page-section end -->
           
    <?php }
	wp_reset_postdata();
	}
}