<?php

/**
 * Elementor Widget
 * @package Saasten
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_home_team_one extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'theme-team-onee';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Home Team 1', 'saasten-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saasten_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {


        $this->start_controls_section( 'section_content_team_inner_one', [
            'label' => esc_html__( 'Team Top Content', 'saasten-extra' ),
        ] ); 


        $this->add_control( 'title', [
            'label'       => __( 'Title', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Invest in Startup', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type section title here.", 'saasten-extra' ),

        ] );


        $this->add_control( 'description', [
            'label'       => __( 'Description', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Our Sustainable Construction Advisors provide sustainable construction expertise', 'saasten-extra' ),
            'label_block' => true,
        ] );


        $this->end_controls_section();


        $this->start_controls_section( 'section_content_team_featurelist', [
            'label' => esc_html__( 'Team Member List', 'saasten-extra' ),
        ] ); 

        $this->add_control( 'featureItems', [
            'label'       => esc_html__( 'Team Member', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'default'     => [
                [
                    'team-title'        => esc_html__( 'Ronald Richards', 'saasten-extra' ),
                ]
            ],

            'fields'      => [
                [
                    'name'        => 'team-title',
                    'label'       => esc_html__( 'Title', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'description' => esc_html__( 'Enter Title', 'saasten-extra' )
                ],

                [
                    'name'        => 'team-position',
                    'label'       => esc_html__( 'Position', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'description' => esc_html__( 'Enter Position', 'saasten-extra' )
                ],

                [
                    'name'        => 'team-image',
                    'label'       => esc_html__( 'Image', 'deaxautt-extra' ),
                    'type'        => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                    ],

                    'description' => esc_html__( 'Upload member image', 'deaxautt-extra' )
                ],

                [
                    'name'        => 'btn-link',
                    'label'       => esc_html__( 'Team Button Link', 'deaxautt-extra' ),
                    'type'        => \Elementor\Controls_Manager::URL,
                    'placeholder' => __( 'https://your-link.com', 'deaxautt-extra' ),
                    'default'     => [
                        'url' => '#',
                    ],
                ],

                

            ],
            'title_field' => "{{name}}"
        ] );



        $this->end_controls_section();


        // ===================== Title ======================//

        $this->start_controls_section( 'title_style', [
            'label' => __( 'Title', 'saasten-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_typography',
            'label'    => __( 'Typography', 'saasten-extra' ),
            'selector' => '
                {{WRAPPER}} .theme-banner-startup-wrapper h1.banner-heading,
                {{WRAPPER}} .__title
            ',
        ] );


        $this->add_control( 'title_color', [
            'label'     => __( 'Color', 'saasten-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-startup-wrapper h1.banner-heading' => 'color: {{VALUE}}',
                '{{WRAPPER}} .__title' => 'color: {{VALUE}}',
            ],
        ] );

        $this->end_controls_section(); //End Title Style


        // ===================== Subtitle Style ========================//
        $this->start_controls_section( 'sub_title_style', [
            'label' => __( 'Sub Title', 'saasten-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_sub_typography',
            'label'    => __( 'Typography', 'saasten-extra' ),
            'selector' => '{{WRAPPER}} .theme-banner-startup-wrapper h4.banner-sub-heading',
        ] );

        $this->add_control( 'sub_title_color', [
            'label'     => __( 'Sub Title Color', 'saasten-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-startup-wrapper h4.banner-sub-heading' => 'color: {{VALUE}}',
            ],

        ] );

        $this->end_controls_section(); //End Subtitle Style

		
	}
	


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

        $featureItems = $settings['featureItems'];

        extract($settings); 


		
		?>


    <!-- Our Team -->
    <section class="our-team-area pd-top-130 pd-btm-130">
      <div class="container">
        <div class="row">
          <div class="col-12 mg-btm-30">
            <!-- Section Title -->
            <div class="section-title-area text-center" data-aos="fade-in">
              <h2 class="section-title saastain-gsap-anim1">
                <?php echo $settings['title']; ?>
              </h2>
              <p class="section-text m-0 mg-top-25 team-subtitle">
                <?php echo $settings['description']; ?>
              </p>
            </div>
          </div>
        </div>
        <div class="row">



        <?php
            foreach ( $featureItems as $item ):
        ?>

          <div class="col-lg-3 col-md-6 col-12 mg-top-30" data-aos="fade-up">
            <!-- Single Team -->
            <div class="single-member text-center">
              <div class="single-member__img">
                <img src="<?php echo esc_url( $item['team-image']['url'] ); ?>" alt="#" />
              </div>
              <div class="single-member__content mg-top-20">
                <h3 class="single-member__name">
                  <a href="<?php echo esc_url( $item['btn-link']['url'] ) ?>"><?php echo $item['team-title']; ?></a>
                </h3>
                <p class="single-member__position m-0"><?php echo $item['team-position']; ?></p>
              </div>
            </div>
            <!-- End Single Team -->
          </div>

        <?php endforeach; ?>





        </div>
      </div>
    </section>
    <!-- End Our Team -->




	<?php 


	}
				

}

