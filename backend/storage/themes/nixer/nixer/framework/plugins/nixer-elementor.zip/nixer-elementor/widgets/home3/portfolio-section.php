<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome3PortfolioSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home-3-portfolio-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 3 - Portfolio Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-posts-grid';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home3' ];
	}

	public function get_keywords() {
		return [ 'home3portfoliosection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}
	

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_portfolio_section',
			[
				'label' => esc_html__( 'Portfolio Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'bg_color',
			[
				'label' 		=> esc_html__( 'Background Color (Default: #FFFFFF)', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::COLOR,
				'default'		=> '#FFFFFF',
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Projects to see <br> through' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_btn',
			[
				'label' 		=> esc_html__( 'Text Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( 'View All' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'link_btn',
			[
				'label' 		=> esc_html__( 'Link Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( '#' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'item_column',
			[
				'label'     	=> esc_html__( 'Item Column', 'bdevs-elementor' ),
				'type'      	=> Controls_Manager::SELECT,
				'options'   	=> [
					'type1'  		=> esc_html__( 'Two Columns', 'bdevs-elementor' ),
					'type2'  		=> esc_html__( 'Three Columns', 'bdevs-elementor' ),
					'type3'  		=> esc_html__( 'Four Columns', 'bdevs-elementor' ),
				],
				'default'   	=> 'type1',
			]
		);
		$this->add_control(
			'post_number',
			[
				'label'       => __( 'Post Number', 'bdevs-elementor' ),
				'type'        => Controls_Manager::NUMBER,
				'placeholder' => __( 'Enter your post number', 'bdevs-elementor' ),
				'min'		  => 0,
				'default'     => __( '6', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order_by',
			[
				'label'       => __( 'Post Order By', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text post order by', 'bdevs-elementor' ),
				'default'     => __( 'ID', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
				],
				'default'   => 'desc',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-project-3-ptb pt-130 pb-160" data-bg-color=<?php echo wp_kses_post($settings['bg_color']); ?>>
	<div class="container container-1660">
		<?php if (!empty($settings['title_sec'])): ?>
			<div class="row">
				<div class="col-lg-12">
					<div class="tp-project-3-heading text-center mb-90">
						<h3 class="tp-section-title tp-char-animation"><?php echo wp_kses_post($settings['title_sec']); ?></h3>
					</div>
				</div>
			</div>
		<?php endif ?>
		<div class="tp-project-3-wrap mb-40">
			<div class="row tp-gx-80">
				<?php
				$wp_query = new \WP_Query([
					'post_type'      => 'portfolio',
					'posts_per_page' => intval($settings['post_number']),
					'orderby'        => sanitize_text_field($settings['post_order_by']),
					'order'          => sanitize_text_field($settings['post_order']),
				]);
				$i = 0;
				while($wp_query->have_posts()): $wp_query->the_post();
					$i++;

					$port_title = get_post_meta(get_the_ID(),'_cmb_port_title_home_3', true);
					$img_id = get_post_meta(get_the_ID(),'_cmb_port_thumb_home_3', true);

					$title = !empty($port_title) ? $port_title : get_the_title();
					if (!empty($img_id)) {
						$img_url = wp_get_attachment_url($img_id);
					} else {
						$img_url = get_the_post_thumbnail_url();
					}
				?>
					<?php if ($settings['item_column'] === 'type2') { ?>
						<div class="col-lg-4">
					<?php } elseif ($settings['item_column'] === 'type3') { ?>
						<div class="col-lg-3">
					<?php } else { ?>
						<div class="col-lg-6">
					<?php } ?>
						<div class="tp-project-3-item anim-zoomin-wrap mb-80">
							<?php if (!empty($img_url)): ?>
								<div class="tp-project-3-item-thumb anim-zoomin">
									<a href="<?php the_permalink(); ?>">
										<img src="<?php echo esc_url($img_url) ?>" alt="<?php the_title_attribute(); ?>">
									</a>
								</div>
							<?php endif ?>
							<div class="tp-project-3-item-content">
								<h3 class="tp-project-3-item-title">
									<a href="<?php the_permalink(); ?>" data-tha>
										<?php echo wp_kses_post($title); ?>
									</a>
								</h3>
								<div class="tp-project-3-item-btn-box d-flex justify-content-between">
									<div class="tp-project-3-item-date">
										<?php 
										$terms = get_the_terms( get_the_ID(), 'portfolio-cat' );
										if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
										    foreach ( $terms as $term ) {
										        echo '<span>' . esc_html( $term->name ) . '</span><span class="dot">.</span>';
										    }
										} ?>
										<span><?php echo get_the_time('M j, Y'); ?></span>
									</div>
									<div class="tp-project-3-item-btn">
										<a href="<?php the_permalink(); ?>">
											<span>
												<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" fill="none">
													<path d="M1 11L11 1M11 1H1M11 1V11" stroke="#121212" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
												</svg>
											</span>
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php endwhile; ?>
			</div>
		</div>
		<?php if (!empty($settings['text_btn']) && !empty($settings['link_btn'])): ?>
			<div class="row">
				<div class="col-lg-12">
					<div class="tp-project-3-btn text-center">
						<a class="tp-btn-2" href="<?php echo wp_kses_post($settings['link_btn']); ?>">
							<?php echo wp_kses_post($settings['text_btn']); ?>
							<span>
								<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
									<path d="M15.7767 7.42864C15.9198 7.58033 16 7.78521 16 7.99872C16 8.21223 15.9198 8.41711 15.7767 8.56882L8.92138 15.77C8.77516 15.9169 8.58094 15.9992 8.37867 16C8.27759 15.9995 8.17746 15.9793 8.08351 15.9399C7.94489 15.8789 7.8266 15.7759 7.74358 15.6441C7.66056 15.5124 7.61651 15.3579 7.61698 15.1999V8.79885H0.761697C0.559684 8.79885 0.365942 8.71456 0.223096 8.5645C0.0802502 8.41444 0 8.21094 0 7.99872C0 7.78652 0.0802502 7.583 0.223096 7.43295C0.365942 7.28289 0.559684 7.1986 0.761697 7.1986H7.61698V0.797552C7.61651 0.639587 7.66056 0.485009 7.74358 0.3533C7.8266 0.22159 7.94489 0.118642 8.08351 0.0574314C8.2242 -0.00021391 8.37756 -0.0148385 8.52585 0.0152518C8.67412 0.0453405 8.81125 0.118914 8.92138 0.22746L15.7767 7.42864Z" fill="currentColor"/>
								</svg>
							</span>
						</a>
					</div>
				</div>
			</div>
		<?php endif ?>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-bg-color]").each(function () {
			jQuery(this).css("background-color", jQuery(this).attr("data-bg-color"));
		});

		if (jQuery('.tp-project-3-heading .tp-char-animation').length > 0) {
			var char_come = gsap.utils.toArray(".tp-project-3-heading .tp-char-animation");
			char_come.forEach(splitTextLine => {
				var tl = gsap.timeline({
					scrollTrigger: {
						trigger: splitTextLine,
						start: 'top 90%',
						end: 'bottom 60%',
						scrub: false,
						markers: false,
						toggleActions: 'play none none none'
					}
				});

				var itemSplitted = new SplitText(splitTextLine, { type: "chars, words" });
				gsap.set(splitTextLine, { perspective: 300 });
				itemSplitted.split({ type: "chars, words" })
				tl.from(itemSplitted.chars,
					{
						duration: 1,
						delay: 0.5,
						x: 100,
						autoAlpha: 0,
						stagger: 0.05
					});
			});
		}

		jQuery(".anim-zoomin").each(function() {

			// Add wrap <div>.
			jQuery(this).wrap('<div class="anim-zoomin-wrap"></div>');

			// Add overflow hidden.
			jQuery(".anim-zoomin-wrap").css({ "overflow": "hidden" })

			var $this = $(this);
			var $asiWrap = $this.parents(".anim-zoomin-wrap");

			var tp_ZoomIn = gsap.timeline({
				scrollTrigger: {
					trigger: $asiWrap,
					start: "top 100%",
					markers: false,
				}
			});
			tp_ZoomIn.from($this, { duration: 1.5, autoAlpha: 0, scale: 1.2, ease: Power2.easeOut, clearProps:"all" });

		});
	</script>
	<script type="text/javascript">

		var style = document.createElement('style');
		style.setAttribute('type', 'text/css');
		style.innerHTML = `
		[data-tha] {
			/* border: 1px solid red; */
			display: inline-block;
			position: relative;
			overflow: hidden;
		}

		[data-tha-span-1],
		[data-tha-span-2] {
			display: inline-block;
		}

		[data-tha-span-2] {
			position: absolute;
			top: 100%;
			left: 0;
		}
		`;
		document.querySelector('head').append(style);

		var aaa = document.querySelectorAll('[data-tha]');

		aaa.forEach((a) => {
			var html = a.innerHTML;
			a.innerHTML = '';

			var span1 = document.createElement('span');
			var span2 = document.createElement('span');
			span1.setAttribute('data-tha-span-1', '');
			span2.setAttribute('data-tha-span-2', '');
			span1.innerHTML = html;
			span2.innerHTML = html;

			a.append(span1);
			a.append(span2);

			a.addEventListener('mouseenter', (e) => {
				var span1 = e.target.querySelector('[data-tha-span-1');
				var span2 = e.target.querySelector('[data-tha-span-2');
				gsap.to([span1, span2], { yPercent: -100 });
			});
			a.addEventListener('mouseleave', (e) => {
				var span1 = e.target.querySelector('[data-tha-span-1');
				var span2 = e.target.querySelector('[data-tha-span-2');
				gsap.to([span1, span2], { yPercent: 0 });
			});
		});
	</script>
<?php } ?>

<?php
}

}