<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Menu Select Widget .
 *
 */
class Barab_Menu extends Widget_Base {

	public function get_name() {
		return 'barabmenuselect';
	}
	public function get_title() {
		return __( 'Menu Select', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		 $this->start_controls_section(
			'section_title_section',
			[
				'label'		 	=> __( 'Navigation Menu', 'barab' ),
				'tab' 			=> Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style',['Style One', 'Style Two', 'Style Three'] );

		barab_general_fields($this, 'title', 'Title', 'TEXT', 'Download' , ['1', '3'] );
		barab_media_fields( $this, 'title_shape', 'Choose Title Shape', ['1'] );

		$menus = $this->barab_menu_select();

		if( !empty( $menus ) ){
	        $this->add_control(
				'barab_menu_select',
				[
					'label'     	=> __( 'Select Barab Menu', 'barab' ),
					'type'      	=> Controls_Manager::SELECT,
					'options'   	=> $menus,
					'description' 	=> sprintf( __( 'Go to the <a href="%s" target="_blank">Menus screen</a> to manage your menus.', 'barab' ), admin_url( 'nav-menus.php' ) ),
				]
			);
		}else {
			$this->add_control(
				'no_menu',
				[
					'type' 				=> Controls_Manager::RAW_HTML,
					'raw' 				=> '<strong>' . __( 'There are no menus in your site.', 'barab' ) . '</strong><br>' . sprintf( __( 'Go to the <a href="%s" target="_blank">Menus screen</a> to create one.', 'barab' ), admin_url( 'nav-menus.php?action=edit&menu=0' ) ),
					'separator' 		=> 'after',
					'content_classes' 	=> 'elementor-panel-alert elementor-panel-alert-info',
				]
			);
		}

        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------
		//-------General Style-------
		 $this->start_controls_section(
			'general_styling',
			[
				'label'     => __( 'Background Color', 'barab' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition'	=> [
					'layout_style' => ['1']
				]
			]
        );

		barab_color_fields( $this, '001', 'Background', 'background', '{{WRAPPER}} .footer-widget.bg' );             

		$this->end_controls_section();
		//-------Title Style-------
		barab_common_style_fields( $this, 'title', 'Title', '{{WRAPPER}} .widget_title', ['1', '3'] );
		barab_common_style_fields( $this, 'menu', 'Menu', '{{WRAPPER}} .widget.widget_nav_menu.footer-widget a', ['1'], '--white-color' );

	}

    public function barab_menu_select(){ 
	    $barab_menu = wp_get_nav_menus();
	    $menu_array  = array();
		$menu_array[''] = __( 'Select A Menu', 'barab' );
	    foreach( $barab_menu as $menu ){
	        $menu_array[ $menu->slug ] = $menu->name;
	    }
	    return $menu_array;
	}

	protected function render() {

	$settings = $this->get_settings_for_display();

        //Menu by menu select
        $barab_avaiable_menu   = $this->barab_menu_select();

        if( ! $barab_avaiable_menu ){
            return;
        }

		$args = [
			'menu' 		=> $settings['barab_menu_select'],
			'menu_class' 	=> 'menu',
			'container' 	=> '',
		];

		if( $settings['layout_style'] == '1' ){
			echo '<div class="widget widget_nav_menu footer-widget bg">';
				if(!empty($settings['title'])){
					echo '<h3 class="widget_title">'.esc_html($settings['title']).'</h3>';
				}
				if(!empty($settings['title_shape']['url'])){
					echo '<div class="icon">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['title_shape']['url'] ),
						));
					echo '</div>';
				}
				echo '<div class="menu-all-pages-container">';
						if( ! empty( $settings['barab_menu_select'] ) ){
							wp_nav_menu( $args );
						} 
				echo '</div>';
            echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
			echo '<div class="footer-links">';
				if( ! empty( $settings['barab_menu_select'] ) ){
					wp_nav_menu( $args );
				} 
			echo '</div>';

		}elseif( $settings['layout_style'] == '3' ){
			echo '<div class="widget widget_nav_menu footer-widget wow fadeinup">';
				if(!empty($settings['title'])){
					echo '<h3 class="widget_title">'.esc_html($settings['title']).'</h3>';
				}
				if(!empty($settings['title_shape']['url'])){
					echo '<div class="icon">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['title_shape']['url'] ),
						));
					echo '</div>';
				}
				echo '<div class="menu-all-pages-container">';
						if( ! empty( $settings['barab_menu_select'] ) ){
							wp_nav_menu( $args );
						} 
				echo '</div>';
            echo '</div>';

		}


	}

}