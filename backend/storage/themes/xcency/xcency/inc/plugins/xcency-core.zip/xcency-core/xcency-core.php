<?php
/*
Plugin Name: Xcency Core
Author: Xcency
Author URI: https://quintexbd.com/
Version: 1.0.0
Description: This plugin is required for Xcency WordPress theme
Text Domain: xcency-core
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

define( 'XCENCY_CORE_VERSION', '1.0.0' );

define( 'XCENCY_CORE', WP_PLUGIN_URL . '/' . plugin_basename( dirname( __FILE__ ) ) .'/');

define( 'XCENCY_CORE_ASSETS', trailingslashit( XCENCY_CORE . 'elementor-widgets/assets' ) );

/*
 * Translate direction
 */
add_action( 'init', function () {
	load_plugin_textdomain( 'xcency-core', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
} );

/*
 * Xcency core functions
 */
require_once('inc/xcency-core-functions.php' );


/*
 * Load CSF Framework
 */
add_action('plugins_loaded', 'xcency_core_add_csf');
function xcency_core_add_csf() {
	// Ensure CSF is loaded after plugins are initialized
	if ( ! class_exists( 'CSF' ) ) {
		require_once('inc/library/codestar-framework/codestar-framework.php' );
		require_once('inc/widgets/custom-wp-widgets.php');
	}
}

//Register Custom Posts
require_once('inc/register-custom-posts.php' );

//Header Footer Builder
require_once('inc/header-footer-builder/header-footer-builder.php' );

//Register Custom Elementor Widget
if('elementor/elementor.php') {
	define( 'XCENCY_CORE_ELEMENTOR_ASSETS', trailingslashit( XCENCY_CORE . 'elementor-widgets/assets' ) );
	require_once( 'elementor-widgets/custom-elementor-widgets.php' );
}