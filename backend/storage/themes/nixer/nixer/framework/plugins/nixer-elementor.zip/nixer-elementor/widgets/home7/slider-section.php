<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome7SliderSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home-7-slider-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 7 - Slider Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-slider-full-screen';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home7' ];
	}

	public function get_keywords() {
		return [ 'home7slidersection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_slider_section',
			[
				'label' => esc_html__( 'Slider Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'img_pattern',
			[
				'label'       	=> esc_html__( 'Image Pattern', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image pattern', 'bdevs-elementor' ),
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'heading_item',
			[
				'label' 		=> esc_html__( 'Heading Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'title_item_1',
			[
				'label' 		=> esc_html__( 'Title Item 1', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'title_item_2',
			[
				'label' 		=> esc_html__( 'Title Item 2', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'img_thumb_item',
			[
				'label'       	=> esc_html__( 'Image Thumbnail Item', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image thumbnail item', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'tabs',
			[
				'label' 		=> esc_html__( 'Content Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						
					],
				],
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<div id="showcase-slider-wrappper" class="showcase-slider-wrappper p-relative">
	<div class="port-showcase-slider-spaces">
		<?php if (!empty($settings['img_pattern']['url'])) { ?>
			<div class="port-showcase-slider-wrap tp-slider-parallax fix" id="showcase-slider-holder" data-pattern-img="<?php echo wp_kses_post($settings['img_pattern']['url']); ?>">
		<?php } else { ?>
			<div class="port-showcase-slider-wrap tp-slider-parallax fix" id="showcase-slider-holder">
		<?php } ?>
				<div class="swiper-container parallax-slider-active" id="showcase-slider">
					<div class="swiper-wrapper" id="trigger-slides">
						<div class="tp-line-wrapper d-none d-md-block">
							<div class="tp-line-item"></div>
						</div>
						<?php
						$i = -1;
						foreach ( $settings['tabs'] as $item ) :
							$i++;
						?>
							<div class="swiper-slide">
								<?php if ($i == 0) { ?>
									<div class="slide-wrap active overlay" data-slide="<?php echo esc_attr($i);?>"></div>
								<?php } else { ?>
									<div class="slide-wrap overlay" data-slide="<?php echo esc_attr($i);?>"></div>
								<?php } ?>
									<div class="tp-hero-7-slider-wrap">
										<div class="container">
											<div class="row">
												<div class="col-lg-12">
													<div class="tp-hero-7-slider-content p-relative z-index">
														<?php if (!empty($item['heading_item'])): ?>
															<span class="tp-hero-7-slider-subtitle"><?php echo wp_kses_post($item['heading_item']); ?></span>
														<?php endif ?>
														<?php if (!empty($item['title_item_1']) || !empty($item['title_item_2'])): ?>
															<div class="tp-hero-7-slider-title">
																<?php if (!empty($item['title_item_1'])): ?>
																	<div><span><?php echo wp_kses_post($item['title_item_1']); ?> </span></div>
																<?php endif ?>
																<?php if (!empty($item['title_item_2'])): ?>
																	<div><span><?php echo wp_kses_post($item['title_item_2']); ?></span></div>
																<?php endif ?>
															</div>
														<?php endif ?>
													</div>
												</div>
											</div>
										</div>
									</div>
							</div>
						<?php endforeach; ?>
					</div>
					<div class="tp-slider-dot d-md-none"></div>
					<div class="tp-hero-7-slider-arrow">
						<button class="tp-hero-prev"><i class="fa-light fa-angle-left"></i></button>
						<button class="tp-hero-next"><i class="fa-light fa-angle-right"></i></button>
						<div class="slider-line"></div>
					</div>
					<div class="tp-hero-7-slider-numbers"></div>
				</div>
			</div>
	</div>

	<div id="canvas-slider" class="canvas-slider">
		<?php
		$j = -1;
		foreach ( $settings['tabs'] as $item ) :
			$j++;
		?>
			<?php if (!empty($item['img_thumb_item']['url'])): ?>
				<div class="slider-img" data-slide="<?php echo esc_attr($j);?>">
					<img class="slide-img" src="<?php echo wp_kses_post($item['img_thumb_item']['url']); ?>" alt="<?php echo wp_kses_post($item['img_thumb_item']['alt']); ?>" >
				</div>
			<?php endif ?>
		<?php endforeach; ?>
	</div>
</div>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		if (jQuery('#showcase-slider-wrappper').length > 0) {
			// Function to update the active slide
			var updateActiveSlide = () => {
					jQuery('.tp-slider-dot').find('.swiper-pagination-bullet').each(function () {
							if (!jQuery(this).hasClass("swiper-pagination-bullet-active")) {
								handleActiveSlideClick('#trigger-slides .swiper-slide-active');
								handleActiveSlideClick('#trigger-slides .swiper-slide-duplicate-active');
							}
					});
			};
	
			// Function to handle slide click events
			var handleActiveSlideClick = (selector) => {
					$(selector).find('div').first().each(function () {
							if (!jQuery(this).hasClass("active")) {
								jQuery(this).trigger('click');
							}
					});
			};
	
			// WebGL Shader Configuration
			var vertex = `
					varying vec2 vUv;
					void main() {
							vUv = uv;
							gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
					}
			`;
			var fragment = `
					varying vec2 vUv;
					uniform sampler2D currentImage;
					uniform sampler2D nextImage;
					uniform sampler2D disp;
					uniform float dispFactor;
					uniform float effectFactor;
					uniform vec4 resolution;
					void main() {
							vec2 uv = (vUv - vec2(0.5)) * resolution.zw + vec2(0.5);
							vec4 disp = texture2D(disp, uv);
							vec2 distortedPosition = vec2(uv.x + dispFactor * (disp.r * effectFactor), uv.y);
							vec2 distortedPosition2 = vec2(uv.x - (1.0 - dispFactor) * (disp.r * effectFactor), uv.y);
							vec4 _currentImage = texture2D(currentImage, distortedPosition);
							vec4 _nextImage = texture2D(nextImage, distortedPosition2);
							vec4 finalTexture = mix(_currentImage, _nextImage, dispFactor);
							gl_FragColor = finalTexture;
					}
			`;
	
			var gl_canvas = new WebGL({
				vertex: vertex,
				fragment: fragment,
			});

			// Add events for the slide triggers
			var addEvents = () => {
				var triggerSlide = Array.from(document.getElementById('trigger-slides').querySelectorAll('.slide-wrap'));
				gl_canvas.isRunning = false;

				triggerSlide.forEach((el) => {
					el.addEventListener('click', function () {
						if (!gl_canvas.isRunning) {
							gl_canvas.isRunning = true;

							document.getElementById('trigger-slides').querySelectorAll('.active')[0].className = '';
							this.className = 'active';

							var slideId = parseInt(this.dataset.slide, 10);

							gl_canvas.material.uniforms.nextImage.value = gl_canvas.textures[slideId];
							gl_canvas.material.uniforms.nextImage.needsUpdate = true;

							gsap.to(gl_canvas.material.uniforms.dispFactor, {
									duration: 1,
									value: 1,
									ease: 'Sine.easeInOut',
									onComplete: function () {
											gl_canvas.material.uniforms.currentImage.value = gl_canvas.textures[slideId];
											gl_canvas.material.uniforms.currentImage.needsUpdate = true;
											gl_canvas.material.uniforms.dispFactor.value = 0.0;
											gl_canvas.isRunning = false;
									},
							});
						}
					});
				});
			};

			// Initialize Swiper
			var showcaseSwiper = new Swiper('#showcase-slider', {
				direction: "horizontal",
				loop: true,
				slidesPerView: 'auto',
				touchStartPreventDefault: false,
				speed: 1000,
				mousewheel: true,
				autoplay: {
					delay: 5000,
				},
				effect: 'fade',
				simulateTouch: true,
				parallax: true,
				navigation: {
					clickable: true,
					prevEl: '.tp-hero-prev',
					nextEl: '.tp-hero-next',
				},
				pagination: {
					el: '.tp-slider-dot',
					clickable: true,
				},
				on: {
					slidePrevTransitionStart: function () {
						updateActiveSlide();
					},
					slideNextTransitionStart: function () {
						updateActiveSlide();
					},
					init: function () {
						updateSlideNumbers(this); // Update numbers on initial load
					},
					slideChange: function () {
						updateSlideNumbers(this); // Update numbers when slide changes
					}
				},
			});

			// Function to update slide numbers
			function updateSlideNumbers(swiper) {
				var current = swiper.realIndex + 1; // Get the real index of the current slide
				var numbers = document.querySelector('.tp-hero-7-slider-numbers');
				var formattedCurrent = current < 10 ? `0${current}` : current; // Add leading zero for single digits
				numbers.innerHTML = `${formattedCurrent}`;
			}

			addEvents();
		}
	</script>

<?php } ?>
<?php
}

}