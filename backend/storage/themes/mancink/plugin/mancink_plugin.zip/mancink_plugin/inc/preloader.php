<?php
//preloader custom setting
function mancink_preloader_set()
{

	$pr_color =  get_theme_mod('mancink_bg_preloader');
	$loader_bg = "
		#preloader{background-color: $pr_color;}";
	if ($pr_color != '') {
		wp_add_inline_style('mancink-styles', $loader_bg);
	}
}
//CSS ouput script
add_action('wp_enqueue_scripts', 'mancink_preloader_set', 11);

function mancink_preloader()
{
	if (get_theme_mod('mancink_preloader_show') == 'home' ||  get_theme_mod('mancink_preloader_show') == 'all') {
		wp_enqueue_script('preloader', plugin_dir_url(__FILE__) . 'js/loader.js', array('jquery'), '1.0.0', false);
	}
}

//CSS ouput script
add_action('wp_enqueue_scripts', 'mancink_preloader');