<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome5FAQSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-hom5-faq-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 5 - FAQ Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-accordion';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home5' ];
	}

	public function get_keywords() {
		return [ 'home5faqsection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_faq_section',
			[
				'label' => esc_html__( 'FAQ Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'bg_color',
			[
				'label' 		=> esc_html__( 'Background Color (Default: #1E1E1E)', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::COLOR,
				'default'		=> '#1E1E1E',
			]
		);
		$this->add_control(
			'img_left_sec',
			[
				'label'       	=> esc_html__( 'Image Left Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image left section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Frequently asked <br> questions' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'question_item',
			[
				'label' 		=> esc_html__( 'Question Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Question Text' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'answer_item',
			[
				'label' 		=> esc_html__( 'Answer Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Answer Text' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'tabs',
			[
				'label' 		=> esc_html__( 'List Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
					],
					[
					],
				],
				'title_field' 	=> '{{{ question_item }}}',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-faq-ptb p-relative pt-120 pb-120" data-bg-color="<?php echo wp_kses_post($settings['bg_color']); ?>">
	<div class="container container-1610">
		<div class="row">
			<div class="col-lg-6 order-2 order-lg-1">
				<?php if (!empty($settings['img_left_sec']['url'])): ?>
					<div class="tp-faq-thumb p-relative tp_img_reveal">
						<img src="<?php echo wp_kses_post($settings['img_left_sec']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_left_sec']['alt']); ?>">
					</div>
				<?php endif ?>
			</div>
			<div class="col-lg-6 order-1 order-lg-2">
				<div class="tp-faq-wrap">
					<?php if (!empty($settings['title_sec'])): ?>
						<div class="tp-faq-heading mb-45">
							<h4 class="tp-section-5-title"><?php echo wp_kses_post($settings['title_sec']); ?></h4>
						</div>
					<?php endif ?>
					<div class="tp-faq-wrapper">
						<div class="accordion accordion-flush" id="accordionFlushExample">
							<?php
							$i = 0;
							foreach ($settings['tabs'] as $item) :
								$i++;
							?>
								<?php if ($i == 2) { ?>
									<?php if (!empty($item['question_item']) && !empty($item['answer_item'])): ?>
										<div class="accordion-item active">
											<h2 class="accordion-header">
												<button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse-<?php echo esc_attr($i);?>" aria-expanded="false" aria-controls="flush-collapse-<?php echo esc_attr($i);?>">
													<?php echo wp_kses_post($item['question_item']); ?>
													<span class="accordion-btn"></span>
												</button>
											</h2>
											<div id="flush-collapse-<?php echo esc_attr($i);?>" class="accordion-collapse collapse show" data-bs-parent="#accordionFlushExample">
												<div class="accordion-body"><?php echo wp_kses_post($item['answer_item']); ?></div>
											</div>
										</div>
									<?php endif ?>
								<?php } else { ?>
									<?php if (!empty($item['question_item']) && !empty($item['answer_item'])): ?>
										<div class="accordion-item">
											<h2 class="accordion-header">
												<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse-<?php echo esc_attr($i);?>" aria-expanded="false" aria-controls="flush-collapse-<?php echo esc_attr($i);?>">
													<?php echo wp_kses_post($item['question_item']); ?>
													<span class="accordion-btn"></span>
												</button>
											</h2>
											<div id="flush-collapse-<?php echo esc_attr($i);?>" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
												<div class="accordion-body "><?php echo wp_kses_post($item['answer_item']); ?></div>
											</div>
										</div>
									<?php endif ?>
								<?php } ?>
							<?php endforeach; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-bg-color]").each(function () {
			jQuery(this).css("background-color", jQuery(this).attr("data-bg-color"));
		});

		var tp_img_reveal = document.querySelectorAll(".tp_img_reveal");

		tp_img_reveal.forEach((img_reveal) => {
			var image = img_reveal.querySelector("img");
			var tl = gsap.timeline({
				scrollTrigger: {
					trigger: img_reveal,
					start: "top 70%",
				}
			});

			tl.set(img_reveal, { autoAlpha: 1 });
			tl.from(img_reveal, 1.5, {
				xPercent: -100,
				ease: Power2.out
			});
			tl.from(image, 1.5, {
				xPercent: 100,
				scale: 1.5,
				duration: 3,
				delay: -1.5,
				ease: Power2.out
			});
		});

		document.querySelectorAll(".accordion-header").forEach((header) => {
			header.addEventListener("click", function () {
				document.querySelectorAll(".accordion-item").forEach((item) => {
					item.classList.remove("active");
				});
		
				this.closest(".accordion-item").classList.add("active");
			});
		});
	</script>
<?php } ?>

<?php
}

}