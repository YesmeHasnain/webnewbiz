<?php
/**
 * Plugin Name: Nixer Elementor
 * Description: Create unlimited widgets with Elementor Page Builder.
 * Plugin URI:  http://bdevs.net/plugins/bdevs-elementor/
 * Version:     1.0.0
 * Author:      Nasir Uddin Mandal
 * Author URI:  http://bdevs.net
 * Text Domain: bdevs-elementor
 * Domain Path: /languages/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Main Bdevs Elementor Class
 *
 * The main class that initiates and runs the plugin.
 *
 * @since 1.0.0
 */
final class BdevsElementor {

	/**
	 * Plugin Version
	 *
	 * @since 1.0.0
	 *
	 * @var string The plugin version.
	 */
	const VERSION = '1.0.0';

	/**
	 * Minimum Elementor Version
	 *
	 * @since 1.0.0
	 *
	 * @var string Minimum Elementor version required to run the plugin.
	 */
	const MINIMUM_ELEMENTOR_VERSION = '2.0.0';

	/**
	 * Minimum PHP Version
	 *
	 * @since 1.0.0
	 *
	 * @var string Minimum PHP version required to run the plugin.
	 */
	const MINIMUM_PHP_VERSION = '5.5';

	/**
	 * Instance
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 * @static
	 *
	 * @var BdevsElementor The single instance of the class.
	 */
	private static $_instance = null;

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 * @static
	 *
	 * @return BdevsElementor An instance of the class.
	 */
	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;

	}

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function __construct() {

		add_action( 'init', [ $this, 'i18n' ] );
		add_action( 'plugins_loaded', [ $this, 'init' ] );

	}

	/**
	 * Load Textdomain
	 *
	 * Load plugin localization files.
	 *
	 * Fired by `init` action hook.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function i18n() {

		load_plugin_textdomain( 'bdevs-elementor' );

	}

	/**
	 * Initialize the plugin
	 *
	 * Load the plugin only after Elementor (and other plugins) are loaded.
	 * Checks for basic plugin requirements, if one check fail don't continue,
	 * if all check have passed load the files required to run the plugin.
	 *
	 * Fired by `plugins_loaded` action hook.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function init() {

		// Check if Elementor installed and activated
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );
			return;
		}

		// Check for required Elementor version
		if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );
			return;
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );
			return;
		}

		add_action( 'elementor/init', [ $this, 'add_elementor_category' ], 1 );

		// Add Plugin actions
		add_action( 'elementor/frontend/after_register_scripts', [ $this, 'register_frontend_scripts' ], 10 );

		// Register Widget Styles
		add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'register_frontend_styles' ] );

		add_action( 'elementor/widgets/widgets_registered', [ $this, 'init_widgets' ] );

		// Register controls
		//add_action( 'elementor/controls/controls_registered', [ $this, 'register_controls' ] );
	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have Elementor installed or activated.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_missing_main_plugin() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor */
			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'bdevs-elementor' ),
			'<strong>' . esc_html__( 'Nixer Elementor', 'bdevs-elementor' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'bdevs-elementor' ) . '</strong>'
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required Elementor version.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_minimum_elementor_version() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'bdevs-elementor' ),
			'<strong>' . esc_html__( 'Nixer Elementor', 'bdevs-elementor' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'bdevs-elementor' ) . '</strong>',
			 self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required PHP version.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_minimum_php_version() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'bdevs-elementor' ),
			'<strong>' . esc_html__( 'Nixer Elementor', 'bdevs-elementor' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'bdevs-elementor' ) . '</strong>',
			 self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Add Elementor category.
	 */
	public function add_elementor_category() {
		\Elementor\Plugin::instance()->elements_manager->add_category('nixer-service',
			array(
					'title' => __( 'Nixer Service', 'bdevs-elementor' ),
					'icon'  => 'fa fa-plug',
			) 
		);
		\Elementor\Plugin::instance()->elements_manager->add_category('nixer-portfolio',
			array(
					'title' => __( 'Nixer Portfolio', 'bdevs-elementor' ),
					'icon'  => 'fa fa-plug',
			) 
		);
		\Elementor\Plugin::instance()->elements_manager->add_category('nixer-team',
			array(
					'title' => __( 'Nixer Team', 'bdevs-elementor' ),
					'icon'  => 'fa fa-plug',
			) 
		);
		\Elementor\Plugin::instance()->elements_manager->add_category('nixer-global',
			array(
					'title' => __( 'Nixer Widget', 'bdevs-elementor' ),
					'icon'  => 'fa fa-plug',
			) 
		);
		\Elementor\Plugin::instance()->elements_manager->add_category('nixer-home1',
			array(
					'title' => __( 'Nixer Home 1', 'bdevs-elementor' ),
					'icon'  => 'fa fa-plug',
			) 
		);
		\Elementor\Plugin::instance()->elements_manager->add_category('nixer-home2',
			array(
					'title' => __( 'Nixer Home 2', 'bdevs-elementor' ),
					'icon'  => 'fa fa-plug',
			) 
		);
		\Elementor\Plugin::instance()->elements_manager->add_category('nixer-home3',
			array(
					'title' => __( 'Nixer Home 3', 'bdevs-elementor' ),
					'icon'  => 'fa fa-plug',
			) 
		);
		\Elementor\Plugin::instance()->elements_manager->add_category('nixer-home4',
			array(
					'title' => __( 'Nixer Home 4', 'bdevs-elementor' ),
					'icon'  => 'fa fa-plug',
			) 
		);
		\Elementor\Plugin::instance()->elements_manager->add_category('nixer-home5',
			array(
					'title' => __( 'Nixer Home 5', 'bdevs-elementor' ),
					'icon'  => 'fa fa-plug',
			) 
		);
		\Elementor\Plugin::instance()->elements_manager->add_category('nixer-home6',
			array(
					'title' => __( 'Nixer Home 6', 'bdevs-elementor' ),
					'icon'  => 'fa fa-plug',
			) 
		);
		\Elementor\Plugin::instance()->elements_manager->add_category('nixer-home7',
			array(
					'title' => __( 'Nixer Home 7', 'bdevs-elementor' ),
					'icon'  => 'fa fa-plug',
			) 
		);
		\Elementor\Plugin::instance()->elements_manager->add_category('nixer-home8',
			array(
					'title' => __( 'Nixer Home 8', 'bdevs-elementor' ),
					'icon'  => 'fa fa-plug',
			) 
		);
		\Elementor\Plugin::instance()->elements_manager->add_category('nixer-footer',
			array(
					'title' => __( 'Nixer Footer', 'bdevs-elementor' ),
					'icon'  => 'fa fa-plug',
			) 
		);

	}

	/**
	* Register Frontend Scripts
	*
	*/
	public function register_frontend_scripts() {
	wp_register_script( 'bdevs-elementor', plugin_dir_url( __FILE__ ) . 'assets/js/bdevs-elementor.js', array( 'jquery' ), self::VERSION );
	}

	/**
	* Register Frontend styles
	*
	*/
	public function register_frontend_styles() {
	wp_register_style( 'bdevs-elementor', plugin_dir_url( __FILE__ ) . 'assets/css/bdevs-elementor.css', self::VERSION );
	}




	/**
	 * Init Widgets
	 *
	 * Include widgets files and register them
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function init_widgets() {

		// Include Widget files

		// Service
		require_once plugin_dir_path( __FILE__ ) . 'widgets/service/sv-detail-info.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/service/sv-detail-content.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/service/sv-detail-instragram.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/service/service-about.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/service/service-section.php';

		// Portfolio
		require_once plugin_dir_path( __FILE__ ) . 'widgets/portfolio/portfolio-detail.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/portfolio/portfolio-detail-counter.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/portfolio/portfolio-random.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/portfolio/portfolio-2-columns.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/portfolio/portfolio-3-columns.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/portfolio/portfolio-4-columns.php';

		// Team
		require_once plugin_dir_path( __FILE__ ) . 'widgets/team/team-detail.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/team/team-grid.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/team/team-section.php';

		// Global
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/faq-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/brand-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/text-effect.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/text-effect-2.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/counter-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/testimonial-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/about-me-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/about-me-img-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/about-me-exp.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/about-me-text-effect.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/about-us-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/fun-fact-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/counter-section-2.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/brand-section-2.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/about-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/pricing-breadcrumb.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/pricing-table.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/faq-breadcrumb.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/faq-section-2.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/faq-section-3.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/contact-breadcrumb.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/contact-form.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/contact-breadcrumb2.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/contact-form-2.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/contact-info.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/contact-map.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/contact-location.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/login-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/register-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/myaccount-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/global/blockquote-section.php';

		// Home 1
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home1/hero-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home1/portfolio-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home1/about-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home1/service-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home1/team-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home1/testimonial-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home1/blog-section.php';

		// Home 2
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home2/hero-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home2/about-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home2/experience-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home2/portfolio-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home2/counter-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home2/service-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home2/team-section.php';

		// Home 3
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home3/hero-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home3/slider-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home3/about-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home3/brand-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home3/portfolio-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home3/blog-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home3/contact-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home3/testimonial-section.php';

		// Home 4
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home4/hero-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home4/service-cat-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home4/award-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home4/portfolio-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home4/award-section-2.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home4/blog-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home4/brand-section.php';

		// Home 5
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home5/hero-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home5/about-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home5/practice-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home5/award-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home5/team-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home5/blog-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home5/faq-section.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home5/testimonial-section.php';

		// Home 6
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home6/portfolio-section.php';

		// Home 7
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home7/slider-section.php';

		// Home 8
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home8/portfolio-carousel.php';

		// Footer
		require_once plugin_dir_path( __FILE__ ) . 'widgets/footer/footer-1.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/footer/footer-2.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/footer/footer-3.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/footer/footer-4.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/footer/footer-5.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/footer/footer-6.php';


		// Register widget

		// Service
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsSVDetailInfo() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsSVDetailContent() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsSVDetailInstagram() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsSVAbout() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsServiceSection() );

		// Portfolio
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsPortfolioDetail() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsPortfolioDetailCounter() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsPortfolioRandom() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsPortfolio2Columns() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsPortfolio3Columns() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsPortfolio4Columns() );

		// Team
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsTeamDetail() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsTeamGrid() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsTeamSection() );

		// Global
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsFAQSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsBrandSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsTextEffect() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsTextEffect2() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsCounterSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsTestimonialSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsAboutMeSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsAboutMeImgSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsAboutMeExperience() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsAboutMeTextEffect() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsAboutUsSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsFunFactSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsCounterSection2() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsBrandSection2() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsAboutSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsPricingBreadCrumb() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsPricingTable() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsFAQBreadCrumb() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsFAQSection2() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsFAQSection3() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsContactBreadCrumb() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsContactForm() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsContactBreadCrumb2() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsContactForm2() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsContactInfo() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsContactMap() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsContactLocation() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsLoginSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsRegisterSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsMyAccountSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsBlockquoteSection() );

		// Home 1
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome1HeroSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome1PortfolioSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome1AboutSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome1ServiceSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome1TeamSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome1TestimonialSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome1BlogSection() );

		// Home 2
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome2HeroSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome2AboutSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome2ExpSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome2PortfolioSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome2CounterSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome2ServiceSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome2TeamSection() );

		// Home 3
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome3HeroSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome3SliderSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome3AboutSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome3BrandSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome3PortfolioSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome3BlogSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome3ContactSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome3TestimonialSection() );

		// Home 4
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome4HeroSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome4ServiceCatSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome4AwardSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome4PortfolioSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome4AwardSection2() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome4BlogSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome4BrandSection() );

		// Home 5
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome5HeroSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome5AboutSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome5PracticeSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome5AwardSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome5TeamSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome5BlogSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome5FAQSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome5TestimonialSection() );

		// Home 6
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome6PortfolioSection() );

		// Home 7
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome7SliderSection() );

		// Home 8
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsHome8PortfolioCarousel() );

		// Footer
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsFooterSection1() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsFooterSection2() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsFooterSection3() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsFooterSection4() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsFooterSection5() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\BdevsFooterSection6() );

	}

	/** 
	 * register_controls description
	 * @return [type] [description]
	 */
	public function register_controls() {

		$controls_manager = \Elementor\Plugin::$instance->controls_manager;
		$controls_manager->register_control( 'slider-widget', new Test_Control1() );
	
	}

	/**
	 * Prints the Elementor Page content.
	 */
	public static function get_content( $id = 0 ) {
		if ( class_exists( '\ElementorPro\Plugin' ) ) {
			echo do_shortcode( '[elementor-template id="' . $id . '"]' );
		} else {
			echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $id );
		}
	}

}

BdevsElementor::instance();
