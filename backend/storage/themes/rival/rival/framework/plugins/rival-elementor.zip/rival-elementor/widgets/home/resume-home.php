<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsResumeHome extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-resume-home';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Resume Home', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Slider widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-info-circle';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Slider widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'home-elementor' ];
	}

	public function get_keywords() {
		return [ 'resumehome', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_resume_home',
			[
				'label' => esc_html__( 'Resume Home', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
	        'heading_employment',
	        [
	            'label'       => __( 'Heading Employment', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your Heading', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

	   	$this->add_control(
        'tabs',
        [
            'label' => esc_html__( 'Resume Home Section Item', 'bdevs-elementor' ),
            'type' => Controls_Manager::REPEATER,
            'default' => [
                [
                    'tab_title'   => esc_html__( 'Slide #1', 'bdevs-elementor' ),
                    'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),
                ]
            ],
            'fields' => [
                [
                    'name'        => 'title1',
                    'label'       => esc_html__( 'Title 1', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'desc1',
                    'label'       => esc_html__( 'Description 1', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXTAREA,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'year1',
                    'label'       => esc_html__( 'Year 1', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'title2',
                    'label'       => esc_html__( 'Title 2', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'desc2',
                    'label'       => esc_html__( 'Description 2', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXTAREA,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'year2',
                    'label'       => esc_html__( 'Year 2', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
            ],
        ]
  	);

	   	$this->add_control(
	        'title_employment',
	        [
	            'label'       => __( 'Title Employment', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

	   	$this->add_control(
	        'desc_employment',
	        [
	            'label'       => __( 'Description Employment', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXTAREA,
	            'placeholder' => __( 'Enter your description', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

	   	$this->add_control(
	        'year_employment',
	        [
	            'label'       => __( 'Year Employment', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

	   	$this->add_control(
	        'heading_education',
	        [
	            'label'       => __( 'Heading Education', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your Heading', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

	   	$this->add_control(
        'tabs2',
        [
            'label' => esc_html__( 'Resume Home Section Item', 'bdevs-elementor' ),
            'type' => Controls_Manager::REPEATER,
            'default' => [
                [
                    'tab_title'   => esc_html__( 'Slide #1', 'bdevs-elementor' ),
                    'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),
                ]
            ],
            'fields' => [
            	[
                    'name'        => 'type',
                    'label'       => esc_html__( 'Type', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'title1',
                    'label'       => esc_html__( 'Title 1', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'desc1',
                    'label'       => esc_html__( 'Description 1', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXTAREA,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'year1',
                    'label'       => esc_html__( 'Year 1', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'title2',
                    'label'       => esc_html__( 'Title 2', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'desc2',
                    'label'       => esc_html__( 'Description 2', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXTAREA,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'year2',
                    'label'       => esc_html__( 'Year 2', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
            ],
        ]
  	);

	   	$this->add_control(
	        'heading_skill',
	        [
	            'label'       => __( 'Heading Skill', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

	   	$this->add_control(
	        'subheading_skill',
	        [
	            'label'       => __( 'Subheading Skill', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

	   	$this->add_control(
        'tabs3',
        [
            'label' => esc_html__( 'Resume Home Section Item', 'bdevs-elementor' ),
            'type' => Controls_Manager::REPEATER,
            'default' => [
                [
                    'tab_title'   => esc_html__( 'Slide #1', 'bdevs-elementor' ),
                    'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),
                ]
            ],
            'fields' => [
            	[
                    'name'        => 'title',
                    'label'       => esc_html__( 'Title', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'skillbarTitle1',
                    'label'       => esc_html__( 'skillbarTitle 1', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'percent1',
                    'label'       => esc_html__( 'percent 1', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'skillbarTitle2',
                    'label'       => esc_html__( 'skillbarTitle 2', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'percent2',
                    'label'       => esc_html__( 'percent 2', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'skillbarTitle3',
                    'label'       => esc_html__( 'skillbarTitle 3', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'percent3',
                    'label'       => esc_html__( 'percent 3', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'skillbarTitle4',
                    'label'       => esc_html__( 'skillbarTitle 4', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'percent4',
                    'label'       => esc_html__( 'percent 4', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
            ],
        ]
  	);

		$this->add_control(
        'tabs4',
        [
            'label' => esc_html__( 'Resume Home Section Item', 'bdevs-elementor' ),
            'type' => Controls_Manager::REPEATER,
            'default' => [
                [
                    'tab_title'   => esc_html__( 'Slide #1', 'bdevs-elementor' ),
                    'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),
                ]
            ],
            'fields' => [
                [
                    'name'        => 'tg1',
                    'label'       => esc_html__( 'Tg 1', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'title1',
                    'label'       => esc_html__( 'Title 1', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'tg2',
                    'label'       => esc_html__( 'Tg 2', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'title2',
                    'label'       => esc_html__( 'Title 2', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'tg3',
                    'label'       => esc_html__( 'Tg 3', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'title3',
                    'label'       => esc_html__( 'Title 3', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'tg4',
                    'label'       => esc_html__( 'Tg 4', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'title4',
                    'label'       => esc_html__( 'Title 4', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'tg5',
                    'label'       => esc_html__( 'Tg 5', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'title5',
                    'label'       => esc_html__( 'Title 5', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
            ],
        ]
  	);

	    $this->add_control(
	        'link_doubleLeft',
	        [
	            'label'       => __( 'Link doubleLeft', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your link', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

	   	$this->add_control(
	        'doubleLeft',
	        [
	            'label'       => __( 'doubleLeft', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

	   	$this->add_control(
	        'choose',
	        [
	            'label'       => __( 'Choose', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

	   	$this->add_control(
	        'link_doubleRight',
	        [
	            'label'       => __( 'Link doubleRight', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your link', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

	   	$this->add_control(
	        'doubleRight',
	        [
	            'label'       => __( 'doubleRight', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

        $this->add_control(
            'testi_image',
            [
                'label'       => esc_html__( 'Testimonial Image Section', 'bdevs-elementor' ),
                'type'        => Controls_Manager::MEDIA,
                'dynamic'     => [ 'active' => true ],
                'label_block' => true,
                'description' => esc_html__( 'Upload image section', 'bdevs-elementor' ),
            ]   
        );

		$this->add_control(
        'tabs5',
        [
            'label' => esc_html__( 'Resume Home Section Item', 'bdevs-elementor' ),
            'type' => Controls_Manager::REPEATER,
            'default' => [
                [
                    'tab_title'   => esc_html__( 'Slide #1', 'bdevs-elementor' ),
                    'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),
                ]
            ],
            'fields' => [
                [
                    'name'        => 'desc',
                    'label'       => esc_html__( 'Description', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXTAREA,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'name',
                    'label'       => esc_html__( 'Name', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'job',
                    'label'       => esc_html__( 'Job', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
            ],
        ]
  	);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>
<section id="resume">
	<div class="employment tCenter ofsInTop  ofsBottom">
		<div class="container clearfix">
			<h1 class="title"><?php echo wp_kses_post($settings['heading_employment']); ?></h1>
			<div class="employmentHolder  ofsTop">
				<?php
			       $idd = 0;
			       foreach ( $settings['tabs'] as $item ) :
			       $idd++;
			    ?>
					<div class="emInner clearfix">
						<div class="seven columns ">
							<div class="detRight">
								<h3><?php echo wp_kses_post($item['title1']); ?></h3>
								<p><?php echo wp_kses_post($item['desc1']); ?> </p>
								<span class="date"><i class="icon-calendar"></i><?php echo wp_kses_post($item['year1']); ?></span>
							</div>
						</div>
						<div class="three columns timeLineIco  ">
							<span class="ico"><i class="icon-suitcase"></i></span>
						</div>
						<div class="seven columns ">
							<div class="detLeft">
								<h3><?php echo wp_kses_post($item['title2']); ?></h3>
								<p><?php echo wp_kses_post($item['desc2']); ?> </p>
									<span class="date"><i class="icon-calendar"></i><?php echo wp_kses_post($item['year2']); ?></span>
							</div>
						</div>
					</div>	
				<?php endforeach; ?>
				<div class="emInner clearfix">
					<div class="seven columns ">
						<div class="detRight current last">
							<h3><?php echo wp_kses_post($settings['title_employment']); ?> </h3>
							<p><?php echo wp_kses_post($settings['desc_employment']); ?> </p>
							<span class="date"><i class="icon-calendar"></i><?php echo wp_kses_post($settings['year_employment']); ?></span>
						</div>
					</div>
					<div class="three columns timeLineIco">
						<span class="ico"><i class="icon-suitcase"></i></span>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="education tCenter  ofsInBottom ofsBottom">
		<div class="container clearfix">
			<h1 class="title"><?php echo wp_kses_post($settings['heading_education']); ?></h1>	
			<div class="educationtHolder  ofsTop">
				<?php
			       $idd = 0;
			       foreach ( $settings['tabs2'] as $item ) :
			       $idd++;
			    ?>
					<div class="<?php echo wp_kses_post($item['type']); ?> clearfix">
						<div class="seven columns ">
							<div class="detRight">
								<h3><?php echo wp_kses_post($item['title1']); ?> </h3>
								<p><?php echo wp_kses_post($item['desc1']); ?> </p>
								<span class="date"><i class="icon-calendar"></i><?php echo wp_kses_post($item['year1']); ?></span>
							</div>
						</div>
						<div class="three columns timeLineIco  ">
							<span class="ico"><i class="icon-graduation-cap"></i></span>
						</div>
						<div class="seven columns ">
							<div class="detLeft">
								<h3><?php echo wp_kses_post($item['title2']); ?> </h3>
								<p><?php echo wp_kses_post($item['desc2']); ?> </p>
								<span class="date"><i class="icon-calendar"></i><?php echo wp_kses_post($item['year2']); ?></span>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
	<div class="tCenter ofsTSmall bgGrey skills">
		<div class="container clearfix ">
			<h1 class="title"><?php echo wp_kses_post($settings['heading_skill']); ?></h1>
			<p class="introShort"><?php echo wp_kses_post($settings['subheading_skill']); ?></p>
		</div>
		<div class=" skillsHolder">
			<div class="container clearfix">
				<?php
			       $idd = 0;
			       foreach ( $settings['tabs3'] as $item ) :
			       $idd++;
			    ?>
					<div class="eight columns skill">
						<h1><?php echo wp_kses_post($item['title']); ?></h1>
						<div class=" skillsBarHolder">
							<div class="skillBar">            
							    <div class="skillbarHolder">
							      	<div class="skillbarTitle"><?php echo wp_kses_post($item['skillbarTitle1']); ?></div>
							      	<div class="percentage <?php echo wp_kses_post($item['percent1']); ?>"></div>    
							     </div>              
							</div>
							<div class="skillBar">            
							    <div class="skillbarHolder">
							      	<div class="skillbarTitle"><?php echo wp_kses_post($item['skillbarTitle2']); ?></div>
							      	<div class="percentage <?php echo wp_kses_post($item['percent2']); ?>"></div>     
							    </div>              
							</div>
							<div class="skillBar">            
							    <div class="skillbarHolder">
							      	<div class="skillbarTitle"><?php echo wp_kses_post($item['skillbarTitle3']); ?></div>
							      	<div class="percentage <?php echo wp_kses_post($item['percent3']); ?>"></div>    
							    </div>              
							</div>
							<div class="skillBar">            
							    <div class="skillbarHolder">
							      	<div class="skillbarTitle"><?php echo wp_kses_post($item['skillbarTitle4']); ?></div>
							      	<div class="percentage <?php echo wp_kses_post($item['percent4']); ?>"></div>     
							    </div>              
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="extraSkills">
			<div class="container clearfix">
				<?php
			       $idd = 0;
			       foreach ( $settings['tabs4'] as $item ) :
			       $idd++;
			    ?>
					<ul class="tagsCloud">
						<li class="<?php echo wp_kses_post($item['tg1']); ?>"><?php echo wp_kses_post($item['title1']); ?></li>
						<li class="<?php echo wp_kses_post($item['tg2']); ?>"><?php echo wp_kses_post($item['title2']); ?></li>
						<li class="<?php echo wp_kses_post($item['tg3']); ?>"><?php echo wp_kses_post($item['title3']); ?></li>
						<li class="<?php echo wp_kses_post($item['tg4']); ?>"><?php echo wp_kses_post($item['title4']); ?></li>
						<li class="<?php echo wp_kses_post($item['tg5']); ?>"><?php echo wp_kses_post($item['title5']); ?></li>
					</ul>
				<?php endforeach; ?>
			</div>
		</div>

		<div class="personalBtnHolder">
			<div class="doubleBtn personalBtn">
				<a class="doubleLeft" href="<?php echo wp_kses_post($settings['link_doubleLeft']); ?>"><?php echo wp_kses_post($settings['doubleLeft']); ?></a>
				<span class="choose"><i><?php echo wp_kses_post($settings['choose']); ?></i></span>
				<a class="doubleRight" href="<?php echo wp_kses_post($settings['link_doubleRight']); ?>"><?php echo wp_kses_post($settings['doubleRight']); ?></a>
			</div>
		</div>
		<div class="testimonials" style="background-image: url(<?php echo esc_url($settings['testi_image']['url']); ?>);">
			<div class="overlay">
				<div class="container clearfix">
					<div class="sixteen columns">
						<div class="testiSlider clearfix flexslider">
							<ul class="slides">
								<?php
							       $idd = 0;
							       foreach ( $settings['tabs5'] as $item ) :
							       $idd++;
							    ?>
									<li>
										<blockquote><?php echo wp_kses_post($item['desc']); ?></blockquote>
										<h3 class="testiProfile"><i class="icon-circle "></i><?php echo wp_kses_post($item['name']); ?><i class="icon-circle "></i> <span><?php echo wp_kses_post($item['job']); ?></span></h3>
									</li>
								 <?php endforeach; ?>	
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
<script>
    $('.testiSlider').flexslider({
        animation: "slide",
        slideshow: true,
        directionNav:false,
        controlNav: false
    });
</script>
<?php } ?>
<?php
}

}