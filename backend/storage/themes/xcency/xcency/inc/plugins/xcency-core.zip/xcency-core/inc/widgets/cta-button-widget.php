<?php

// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

	CSF::createWidget( 'xcency_cta_button_two_wp_widget', array(
		'title'       => esc_html__('Xcency : CTA Button Widget', 'xcency-core'),
		'classname'   => 'widget_xcency_cta_button_two_wp_widget',
		'description' => esc_html__('Xcency CTA button widget', 'xcency-core'),
		'fields'      => array(

			array(
				'id'           => 'image',
				'type'         => 'media',
				'title'        => esc_html__('Background Image', 'xcency-core'),
				'library'      => 'image',
				'url'          => false,
				'button_title' => esc_html__('Upload Image', 'xcency-core'),

			),

			array(
				'id'      => 'main_title',
				'type'    => 'textarea',
				'default'    => esc_html__('Book Your Appointment', 'xcency-core'),
				'title'   => esc_html__('Main Title' , 'xcency-core'),
			),

			array(
				'id'      => 'btn_text',
				'type'    => 'text',
				'default'    => esc_html__('Make an Appointment', 'xcency-core'),
				'title'   => esc_html__('Button Text' , 'xcency-core'),
			),

			array(
				'id'      => 'btn_url',
				'type'    => 'text',
				'title'   => esc_html__('Button URL' , 'xcency-core'),
			),
		)
	) );

	//
	// Front-end display of widget
	// Attention: This function named considering above widget base id.
	//
	if( ! function_exists( 'xcency_cta_button_two_wp_widget' ) ) {
		function xcency_cta_button_two_wp_widget( $args, $instance ) {

			echo $args['before_widget']; ?>

			<div class="xcency-cta-btn-two-wp-widget-wrapper xcency-cover-bg" style="background-image: url(<?php echo $instance['image']['url'];?>)">
                <div class="cta-widget-overlay"></div>
				<div class="xcency-cta-btn-two-wp-widget-content">
					<h4 class="xcency-cta-widget-title"><?php echo $instance['main_title'];?></h4>

					<div class="xcency-cta-two-wp-widget-btn-wrapper">

						<a class="xcency-button" href="<?php echo $instance['btn_url'];?>"><?php echo $instance['btn_text'];?></a>
					</div>
				</div>
			</div>


			<?php
			echo $args['after_widget'];
		}
	}
}