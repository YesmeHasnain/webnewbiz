<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsServiceSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-service-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Service Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-editor-list-ol';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-service' ];
	}

	public function get_keywords() {
		return [ 'servicesection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}
	

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_service_section',
			[
				'label' => esc_html__( 'Service Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Services' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'post_number',
			[
				'label'       => __( 'Post Number', 'bdevs-elementor' ),
				'type'        => Controls_Manager::NUMBER,
				'placeholder' => __( 'Enter your post number', 'bdevs-elementor' ),
				'min'		  => 0,
				'default'     => __( '3', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order_by',
			[
				'label'       => __( 'Post Order By', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text post order by', 'bdevs-elementor' ),
				'default'     => __( 'ID', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
				],
				'default'   => 'desc',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-service-2-ptb pt-100 pb-120">
	<div class="container container-1520">
		<div class="row">
			<?php if (!empty($settings['title_sec'])): ?>
				<div class="col-lg-12">
					<div class="tp-project-2-heading tp-service-inner-heading mb-60">
						<h3 class="tp-section-title tp-char-animation"><?php echo wp_kses_post($settings['title_sec']); ?></h3>
					</div>
				</div>
			<?php endif ?>
			<div class="col-lg-12">
				<div class="tp-service-2-wrapper service-inner p-relative z-index-1">
					<?php
					$wp_query = new \WP_Query([
						'post_type'      => 'service',
						'posts_per_page' => intval($settings['post_number']),
						'orderby'        => sanitize_text_field($settings['post_order_by']),
						'order'          => sanitize_text_field($settings['post_order']),
					]);
					$i = 0;
					while($wp_query->have_posts()): $wp_query->the_post();
						$i++;
						$img_url='';
						$sv_title = get_post_meta(get_the_ID(),'_cmb_sv_title_home_2', true);
						$img_id = get_post_meta(get_the_ID(),'_cmb_sv_thumb_home_2', true);
						if (!empty($img_id)) {
							$img_url = wp_get_attachment_url($img_id);
						} else {
							$img_url = get_the_post_thumbnail_url();
						}
					?>
						<div class="tp-service-2-item p-relative z-index-1 d-flex align-items-center">
							<div class="tp-service-2-item-list">
								<span><?php echo esc_attr(str_pad($i, 2, '0', STR_PAD_LEFT)); ?></span>
							</div>
							<div class="tp-service-2-item-thumb">
								<a href="<?php the_permalink(); ?>">
									<img src="<?php echo esc_url($img_url); ?>" alt="<?php the_title_attribute(); ?>">
								</a>
							</div>
							<div class="tp-service-2-item-text">
								<h2 class="tp-service-2-item-text-title">
									<a href="<?php the_permalink(); ?>">
										<?php if (!empty($sv_title)) { ?>
											<?php print wp_specialchars_decode($sv_title); ?>
										<?php } else { ?>
											<?php the_title(); ?>
										<?php } ?>
									</a>
								</h2>
							</div>
							<div class="tp-service-2-item-point">
								<ul>
									<?php 
									$terms = get_the_terms(get_the_ID(), 'service-cat');
									if (!empty($terms) && !is_wp_error($terms)) {
										$terms = array_slice($terms, 0, 5);
										foreach ($terms as $term) {
											$term_link = get_term_link($term);
											echo '<li><a href="' . esc_url($term_link) . '">. ' . esc_html($term->name) . '</a></li>';
										}
									} ?>
								</ul>
							</div>
							<div class="tp-service-2-item-btn">
								<a href="<?php the_permalink(); ?>">
									<span>
										<svg xmlns="http://www.w3.org/2000/svg" width="15" height="16" viewBox="0 0 15 16" fill="none">
											<path d="M0.980469 14.7205L13.487 2.21396M3.03906 1.61919C6.08974 4.67214 11.1754 4.52536 14.4098 1.29102C11.1754 4.52536 11.0271 9.61301 14.0778 12.666" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10"/>
										</svg>
									</span>
								</a>
							</div>
						</div>
					<?php endwhile; ?>
				</div>
			</div>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		if (jQuery('.tp-project-2-heading .tp-char-animation').length > 0) {
			var char_come = gsap.utils.toArray(".tp-project-2-heading .tp-char-animation");
			char_come.forEach(splitTextLine => {
				var tl = gsap.timeline({
					scrollTrigger: {
						trigger: splitTextLine,
						start: 'top 90%',
						end: 'bottom 60%',
						scrub: false,
						markers: false,
						toggleActions: 'play none none none'
					}
				});

				var itemSplitted = new SplitText(splitTextLine, { type: "chars, words" });
				gsap.set(splitTextLine, { perspective: 300 });
				itemSplitted.split({ type: "chars, words" })
				tl.from(itemSplitted.chars,
					{
						duration: 1,
						delay: 0.5,
						x: 100,
						autoAlpha: 0,
						stagger: 0.05
					});
			});
		}
	</script>
<?php } ?>

<?php
}

}