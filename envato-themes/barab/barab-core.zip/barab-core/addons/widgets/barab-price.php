<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Price Widget .
 *
 */
class Barab_Price extends Widget_Base {

	public function get_name() {
		return 'barabprice';
	}
	public function get_title() {
		return __( 'Price Box', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'price_section',
			[
				'label' 	=> __( 'Price Box', 'barab' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One' ] );

		barab_media_fields( $this, 'image1', 'Choose Image', ['1'] );

		$repeater = new Repeater();

		barab_general_fields($repeater, 'title', 'Title', 'TEXTAREA2', 'Basic Plan');
		barab_general_fields($repeater, 'price', 'Price', 'TEXTAREA', '$99.00'); 
		barab_code_fields($repeater, 'features', 'Features', ''); 
		barab_general_fields($repeater, 'button_text', 'Button Text', 'TEXT', 'Get Started');
		barab_url_fields($repeater, 'button_url', 'Button URL');

		$this->add_control(
			'price_lists',
			[
				'label' 		=> __( 'Price Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'Basic Plan', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['1', '2']
				]
			]
		);

		$this->end_controls_section();

		// Column Responsive controls
		if ( function_exists( 'barab_add_responsive_columns_controls' ) ) {
			barab_add_responsive_columns_controls( $this, ['layout_style' => ['1', '2'] ] );
		}

        //---------------------------------------
			//Style Section Start
		//---------------------------------------

		barab_common_style_fields( $this, '02', 'Title', '{{WRAPPER}} .box-title' );
		barab_common_style_fields( $this, '04', 'Price', '{{WRAPPER}} .box-price' );
		barab_common_style_fields( $this, '06', 'Features', '{{WRAPPER}} .available-list li' );

		//------Button Style-------
		barab_button_style_fields( $this, '11', 'Button Styling', '{{WRAPPER}} .th-btn', ['1'] );

	}

	protected function render() {

	$settings = $this->get_settings_for_display();

		if( $settings['layout_style'] == '1' ){
			// Get Column Responsive controls Class
			if ( function_exists( 'barab_get_responsive_columns_class' ) ) {
				$column_class = barab_get_responsive_columns_class( $settings );
			} else {
				$column_class = 'col-md-6 col-lg-4 col-xxl-3';
			}

			echo '<div class="row gy-4 gx-0 justify-content-center">';
				if($settings['image1']['url'] ){
					echo '<div class="' . esc_attr( $column_class ) . '">';
						echo '<div class="price-image wow fadeInUp global-img" data-wow-delay=".2s">';
							echo barab_img_tag( array(
								'url'   => esc_url( $settings['image1']['url'] ),
							)); 
						echo '</div>';
					echo '</div>';
				}
				foreach( $settings['price_lists'] as $key => $data ){
					$delay = 0.1 + ($key * 0.2);
    				$delay = number_format($delay, 1);
					
					$active = ($key == 1) ? 'active' : '';
					echo '<div class="' . esc_attr( $column_class ) . '">';
						echo '<div class="price-card  wow fadeInUp" data-wow-delay="'.$delay.'s">';
							echo '<div class="box-content">';
								if(!empty($data['title'])){
									echo '<h3 class="box-title">'.esc_html($data['title']).'</h3>';
								}
								if(!empty($data['price'])){
									echo '<h4 class="box-price">'.wp_kses_post($data['price']).'</h4>';
								}
							echo '</div>';
							if(!empty($data['features'])){
								echo '<div class="available-list">';
									echo wp_kses_post($data['features']);
									if(!empty($data['button_text'])){
										echo '<a href="'.esc_url( $data['button_url']['url'] ).'" class="th-btn black-border">'.esc_attr($data['button_text']).'</a>';
									}
								echo '</div>';
							}
						echo '</div>';
					echo '</div>';
				}
            echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){


		}elseif( $settings['layout_style'] == '3' ){


		}


	}

}