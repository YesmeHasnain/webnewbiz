<?php

/**
 * Plugin Name: Mancink WordPress Theme Plugin Bundle
 * Plugin URI: http://themeforest.net/user/ridianur
 * Description: This is plugin bundle for Mancink WordPress Theme.
 * Author: ridianur
 * Author URI: http://themeforest.net/user/ridianur
 * Version: 1.1
 */

define('MANCINK__FILE__', __FILE__);
define('MANCINK_URL', plugins_url('/', MANCINK__FILE__));

function mancink_plugin_load()
{
    // Require the main elementor widget plugin file
    require __DIR__ . '/plugin.php';



    //only include the files if cmb2 plugin is installed & activated
    if (defined('CMB2_LOADED')) {
        //post metabox
        include 'inc/post-metabox.php';
        //page metabox
        include 'inc/metabox.php';
        //header metabox
        include 'inc/header-metabox.php';
        //footer metabox
        include 'inc/footer-metabox.php';
        //ajax function
        include 'inc/ajax-function.php';
        include 'inc/ajax-metro.php';

        //include single event function
        include 'inc/single-event.php';
    }
}
add_action('plugins_loaded', 'mancink_plugin_load');


//plugin translation
function rdn_mancink_plugin_init()
{
    load_plugin_textdomain('mancink_plugin', false, dirname(plugin_basename(__FILE__)) . '/lang/');
    //only include the files if kirki plugin is installed & activated
    if (class_exists('Kirki')) {
        include 'inc/customizer.php';
        include 'inc/preloader.php';
        include 'inc/output-css.php';
    }
} // end custom_theme_setup
add_action('init', 'rdn_mancink_plugin_init');

//include function to removing default customizer
include 'inc/removing.php';


//include breadcrumb
include 'inc/breadcrumb.php';

//CUSTOM POST TYPE
//include  event post type
include 'inc/event.php';
//include  event metabox
include 'inc/event-metabox.php';
//include  custom post type (header)
include 'inc/header.php';
//include  custom post type (footer)
include 'inc/footer.php';

//include elementor addon
include 'inc/elementor-addon.php';



//custom widget
//include about us widget
include 'inc/about-us.php';
//flickrfeed widget & shortcode
include 'inc/flickr-feed.php';
include 'inc/flickr-widget.php';

//included sharing
include 'inc/sharebox.php';

//included one click importer
include 'inc/one-click.php';


//disable elementor getting start
add_action('admin_init', function () {
    if (did_action('elementor/loaded')) {
        remove_action('admin_init', [\Elementor\Plugin::$instance->admin, 'maybe_redirect_to_getting_started']);
    }
}, 1);
