<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome1HeroSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home1-hero-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 1 - Hero Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-featured-image';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home1' ];
	}

	public function get_keywords() {
		return [ 'home1herosection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_hero_section',
			[
				'label' => esc_html__( 'Hero Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'img_left_sec',
			[
				'label'       	=> esc_html__( 'Image Left Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image left section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'img_right_sec',
			[
				'label'       	=> esc_html__( 'Image Right Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image right section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'hero_text_box_left',
			[
				'label' 		=> esc_html__( 'Hero Text Box Left', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXT,
				'default' 		=> __( 'Green' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'hero_text_box_right',
			[
				'label' 		=> esc_html__( 'Hero Text Box Right', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXT,
				'default' 		=> __( 'Agency' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'show_popup_video',
			[
				'label'   => esc_html__( 'Show Popup Video', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'link_popup_video',
			[
				'label' 		=> esc_html__( 'Link Popup Video', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'https://www.youtube.com/watch?v=go7QYaQR494' , 'bdevs-elementor' ),
				'show_label' 	=> true,
				'condition' 	=> [
					'show_popup_video' 	=> 'yes',
				],
			]
		);
		$this->add_control(
			'img_bg_btn_popup_video',
			[
				'label'       	=> esc_html__( 'Image Background Button Spin Popup Video', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload your image background button video', 'bdevs-elementor' ),
				'condition' 	=> [
					'show_popup_video' 	=> 'yes',
				],
			]
		);
		$this->add_control(
			'show_user_client',
			[
				'label'   => esc_html__( 'Show User Client', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'img_user_client',
			[
				'label'       	=> esc_html__( 'Image User Client', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload your image user client', 'bdevs-elementor' ),
				'condition' 	=> [
					'show_user_client' 	=> 'yes',
				],
			]
		);
		$this->add_control(
			'title_user_client',
			[
				'label' 		=> esc_html__( 'Title User Client', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '7k+ Clients' , 'bdevs-elementor' ),
				'show_label' 	=> true,
				'condition' 	=> [
					'show_user_client' 	=> 'yes',
				],
			]
		);
		$this->add_control(
			'text_user_client',
			[
				'label' 		=> esc_html__( 'Text User Client', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Approaches are prominently featured on <br> many architect websites.' , 'bdevs-elementor' ),
				'show_label' 	=> true,
				'condition' 	=> [
					'show_user_client' 	=> 'yes',
				],
			]
		);
		$this->end_controls_section();


		$this->start_controls_section(
			'section_content_hero_down',
			[
				'label' => esc_html__( 'Hero Down Smooth', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'show_hero_down_smooth',
			[
				'label'   => esc_html__( 'Show Hero Down Smooth', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'text_btn',
			[
				'label' 		=> esc_html__( 'Text Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Keep <br> Scrolling' , 'bdevs-elementor' ),
				'show_label' 	=> true,
				'condition' 	=> [
					'show_hero_down_smooth' 	=> 'yes',
				],
			]
		);
		$this->add_control(
			'link_btn',
			[
				'label' 		=> esc_html__( 'Link Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '#down' , 'bdevs-elementor' ),
				'show_label' 	=> true,
				'condition' 	=> [
					'show_hero_down_smooth' 	=> 'yes',
				],
			]
		);
		$this->end_controls_section();


		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-hero-area tp-btn-trigger fix pb-140 p-relative">
	<?php if (!empty($settings['show_hero_down_smooth'])): ?>
		<div class="tp-hero-down smooth">
			<?php if (!empty($settings['link_btn']) && !empty($settings['text_btn'])): ?>
				<a href="<?php echo wp_kses_post($settings['link_btn']); ?>" class="d-flex align-items-center show">
					<div class="tp-hero-down-icon">
						<span>
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="72" viewBox="0 0 16 72" fill="none">
								<path d="M16 63C11.578 63 7.99989 66.5781 7.99989 71C7.99989 66.5781 4.42196 63 0 63M7.30078 1H8.80078V71H7.30078V1Z" stroke="#F5F7F5" stroke-width="1.5" stroke-miterlimit="10"/>
							</svg>
						</span>
					</div>
					<div class="tp-hero-down-text">
						<span><?php echo wp_kses_post($settings['text_btn']); ?></span>
					</div>
				</a>
			<?php endif ?>
		</div>
	<?php endif ?>
	<div class="container">
		<div class="row">
			<div class="col-lg-6 order-1 order-lg-0">
				<div class="tp-hero-leftside p-relative">
					<div class="tp-hero-thumb-1 fix mb-100">
						<div class="tp_img_reveal">
							<?php if (!empty($settings['img_left_sec']['url'])): ?>
								<img src="<?php echo wp_kses_post($settings['img_left_sec']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_left_sec']['alt']); ?>">
							<?php endif ?>
						</div>
					</div>
					<?php if (!empty($settings['show_popup_video'])): ?>
						<?php if (!empty($settings['link_popup_video'])): ?>
							<div class="tp-hero-icon">
								<a href="<?php echo wp_kses_post($settings['link_popup_video']); ?>" class="tp-hero-icon-space p-relative d-inline-block popup-video">
									<?php if (!empty($settings['img_bg_btn_popup_video']['url'])): ?>
										<img class="tp-rotate-infinite" src="<?php echo wp_kses_post($settings['img_bg_btn_popup_video']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_bg_btn_popup_video']['alt']); ?>">
									<?php endif ?>
									<span class="">
										<svg xmlns="http://www.w3.org/2000/svg" width="23" height="24" viewBox="0 0 23 24" fill="none">
											<path d="M4.16705 0.52918C1.86575 -0.711967 0 0.304796 0 2.79837V21.1998C0 23.6959 1.86575 24.7113 4.16705 23.4714L21.2734 14.2474C23.5755 13.0058 23.5755 10.9943 21.2734 9.75298L4.16705 0.52918Z" fill="white"/>
										</svg>
									</span>
								</a>
							</div>
						<?php endif ?>
					<?php endif ?>
					<?php if (!empty($settings['show_user_client'])): ?>
						<div class="tp-hero-user tp-btn-bounce">
							<div class="tp-hero-user-thumb">
								<?php if (!empty($settings['img_user_client']['url'])): ?>
									<img src="<?php echo wp_kses_post($settings['img_user_client']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_user_client']['alt']); ?>">
								<?php endif ?>
								<span>
									<svg width="15" height="16" viewBox="0 0 15 16" fill="none" xmlns="http://www.w3.org/2000/svg">
										<path d="M0.867188 14.7378L13.3761 2.22891M3.14453 1.85278C6.07591 4.78416 11.0656 4.53852 14.3005 1.30357M14.3018 1.30304C11.0669 4.53799 10.8212 9.52765 13.7526 12.459" stroke="#121212" stroke-width="1.5" stroke-miterlimit="10"/>
									</svg>
								</span>
							</div>
							<div class="tp-hero-user-content">
								<?php if (!empty($settings['title_user_client'])): ?>
									<span><?php echo wp_kses_post($settings['title_user_client']); ?></span>
								<?php endif ?>
								<?php if (!empty($settings['text_user_client'])): ?>
									<p><?php echo wp_kses_post($settings['text_user_client']); ?></p>
								<?php endif ?>
							</div>
						</div>
					<?php endif ?>
				</div>
			</div>
			<div class="col-lg-6 order-0 order-lg-1">
				<div class="tp-hero-rightside p-relative z-index-1">
					<div class="tp-hero-text-box">
						<?php if (!empty($settings['hero_text_box_left'])): ?>
							<h3 class="tp-hero-text-1 tp_fade_right"><?php echo wp_kses_post($settings['hero_text_box_left']); ?></h3>
						<?php endif ?>
						<?php if (!empty($settings['hero_text_box_right'])): ?>
							<h3 class="tp-hero-text-2 tp_fade_left"><?php echo wp_kses_post($settings['hero_text_box_right']); ?></h3>
						<?php endif ?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php if (!empty($settings['img_right_sec']['url'])): ?>
		<div class="tp-hero-shape-thumb anim-zoomin-wrap">
			<div class="anim-zoomin">
				<img src="<?php echo wp_kses_post($settings['img_right_sec']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_right_sec']['alt']); ?>">
			</div>
		</div>
	<?php endif ?>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		function smoothScroll() {
			jQuery('.smooth a').on('click', function (event) {
				if ($(this).is('#respond')) return;
				var target = $(this.getAttribute('href'));
				if (target.length) {
					event.preventDefault();
					$('html, body').stop().animate({
						scrollTop: target.offset().top - -60
					}, 1500);
				}
			});
		}
		smoothScroll();

		if (jQuery('.tp-btn-trigger').length > 0) {
			gsap.set(".tp-btn-bounce", { y: -100, opacity: 0 });
			var mybtn = gsap.utils.toArray(".tp-btn-bounce");
			mybtn.forEach((btn) => {
				var $this = $(btn);
				gsap.to(btn, {
					scrollTrigger: {
						trigger: $this.closest('.tp-btn-trigger'),
						start: "top center",
						markers: false
					},
					duration: 1,
					ease: "bounce.out",
					y: 0,
					opacity: 1,
				})
			});
	
		}

		var tp_img_reveal = document.querySelectorAll(".tp_img_reveal");
		tp_img_reveal.forEach((img_reveal) => {
			var image = img_reveal.querySelector("img");
			var tl = gsap.timeline({
				scrollTrigger: {
					trigger: img_reveal,
					start: "top 70%",
				}
			});
			tl.set(img_reveal, { autoAlpha: 1 });
			tl.from(img_reveal, 1.5, {
				xPercent: -100,
				ease: Power2.out
			});
			tl.from(image, 1.5, {
				xPercent: 100,
				scale: 1.5,
				duration: 3,
				delay: -1.5,
				ease: Power2.out
			});
		});

		jQuery(".popup-video").magnificPopup({
			type: "iframe",
		});

		gsap.set(".tp_fade_left", { x: -100, opacity: 0 });
		var fadeleftArray = gsap.utils.toArray(".tp_fade_left")
		fadeleftArray.forEach((item, i) => {
			var fadeTl = gsap.timeline({
				scrollTrigger: {
					trigger: item,
					start: "top center+=100",
				}
			})
			fadeTl.to(item, {
				x: 0,
				opacity: 1,
				ease: "power2.out",
				duration: 2.5,
			})
		})

		gsap.set(".tp_fade_right", { x: 100, opacity: 0 });
		var faderightArray = gsap.utils.toArray(".tp_fade_right")
		faderightArray.forEach((item, i) => {
			var fadeTl = gsap.timeline({
				scrollTrigger: {
					trigger: item,
					start: "top center+=100",
				}
			})
			fadeTl.to(item, {
				x: 0,
				opacity: 1,
				ease: "power2.out",
				duration: 2.5,
			})
		})
	</script>
<?php } ?>

<?php
}

}