<?php

/**
 * Elementor Widget
 * @package Saasten
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_home_contact_one extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'theme-contact-onee';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Home Contact Boxes', 'saasten-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saasten_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {


        $this->start_controls_section( 'section_content_contact_inner_one', [
            'label' => esc_html__( 'Address Content', 'saasten-extra' ),
        ] ); 


        $this->add_control( 'email', [
            'label'       => __( 'Email', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'zohapp@gmail.com', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type email here.", 'saasten-extra' ),

        ] );

        $this->add_control( 'number', [
            'label'       => __( 'Number', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( '+984 (492) 372 5810', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type number here.", 'saasten-extra' ),

        ] );

        $this->add_control( 'address', [
            'label'       => __( 'Address', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( '410 Sandtown, California', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type address here.", 'saasten-extra' ),

        ] );




        $this->end_controls_section();




        // ===================== Title ======================//

        $this->start_controls_section( 'title_style', [
            'label' => __( 'Title', 'saasten-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_typography',
            'label'    => __( 'Typography', 'saasten-extra' ),
            'selector' => '
                {{WRAPPER}} .theme-banner-startup-wrapper h1.banner-heading,
                {{WRAPPER}} .__title
            ',
        ] );


        $this->add_control( 'title_color', [
            'label'     => __( 'Color', 'saasten-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-startup-wrapper h1.banner-heading' => 'color: {{VALUE}}',
                '{{WRAPPER}} .__title' => 'color: {{VALUE}}',
            ],
        ] );

        $this->end_controls_section(); //End Title Style


        // ===================== Subtitle Style ========================//
        $this->start_controls_section( 'sub_title_style', [
            'label' => __( 'Sub Title', 'saasten-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_sub_typography',
            'label'    => __( 'Typography', 'saasten-extra' ),
            'selector' => '{{WRAPPER}} .theme-banner-startup-wrapper h4.banner-sub-heading',
        ] );

        $this->add_control( 'sub_title_color', [
            'label'     => __( 'Sub Title Color', 'saasten-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-startup-wrapper h4.banner-sub-heading' => 'color: {{VALUE}}',
            ],

        ] );

        $this->end_controls_section(); //End Subtitle Style

		
	}
	


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

        extract($settings); 


		
		?>



    <!-- Contact -->
    <section class="section-padding">
      <div class="container">
        <div class="row contact-box-group">


          <div class="col-lg-12">
            <div class="contact-box flex-wrap d-flex justify-content-center">
              <div class="single-contact-box" data-aos="fade-right">
                <div class="contact-img bg-email">
                  <img src="<?php echo SAASTEN_IMG ."/email.png"; ?>" class="rounded-circle" alt="#" />
                </div>
                <h5 class="contact-title saastain-gsap-anim2">Send us email</h5>
                <p>
                  <a href="mailto:<?php echo wp_kses_post( $settings['email'] ); ?>" class="saastain-gsap-anim3">
                    <?php echo wp_kses_post( $settings['email'] ); ?>
                  </a>
                </p>
              </div>
              <div
                class="single-contact-box"
                data-aos="fade-right"
                data-aos-delay="200"
              >
                <div class="contact-img bg-phon">
                  <img src="<?php echo SAASTEN_IMG ."/phon.png"; ?>" class="rounded-circle" alt="#" />
                </div>
                <h5 class="contact-title saastain-gsap-anim2">Call us now</h5>
                <p>
                  <a href="tel:<?php echo wp_kses_post( $settings['number'] ); ?>" class="saastain-gsap-anim3"
                    ><?php echo wp_kses_post( $settings['number'] ); ?></a
                  >
                </p>
              </div>
              <div
                class="single-contact-box"
                data-aos="fade-right"
                data-aos-delay="400"
              >
                <div class="contact-img bg-location">
                  <img
                    src="<?php echo SAASTEN_IMG ."/location.png"; ?>"
                    class="rounded-circle"
                    alt="#"
                  />
                </div>
                <h5 class="contact-title saastain-gsap-anim2">
                  Office location
                </h5>
                <p class="saastain-gsap-anim3"><?php echo wp_kses_post( $settings['address'] ); ?></p>
              </div>
            </div>
          </div>
        </div>




      </div>
    </section>
    <!-- End Contact -->




	<?php 


	}
				

}

