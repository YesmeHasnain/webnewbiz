(function($) {
	
	"use strict";
	var team_carousel_js = function($scope, $) {
		
		var design_one = $('.team-carousel'); 
        if(design_one.length){
            var slider_attr = $('#yt-team-slider').data('slider');
            $('.team-carousel').owlCarousel({
                autoplay:slider_attr.autoplay,
                loop:slider_attr.infinite,
                margin:slider_attr.item_gap,
                nav: slider_attr.arrows,
                dots: slider_attr.dots,
                dotsEach: true,
                autoplaySpeed: slider_attr.autoplaySpeed,
                infinite: slider_attr.infinite,
				"navText": ["<span class=\"left icon-arrowLeft\"></span>","<span class=\"right icon-arrowRight\"></span>"],
                responsive:{
                    0: {
                        items: 1
                    },
					480:{
						items: 1
					},
					600:{
						items: 2
					},
					800:{
						items: 3
					},			
					1200:{
						items:slider_attr.item_show
					}
                }
            });
        }
		
	};
	$(window).on('elementor/frontend/init', function () {
            elementorFrontend.hooks.addAction('frontend/element_ready/earls_team_carousel.default', team_carousel_js);
    });	

})(window.jQuery);