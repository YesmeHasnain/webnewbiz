<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

function xcency_core_register_custom_posts() {
	// service
	if(function_exists('xcency_option')){
		$service_slug = xcency_option('service_url_slug');
	}else{
		$service_slug = 'service';
	}

	register_post_type( 'xcency_service',
		array(
			'labels'       => array(
				'name'                  => esc_html__( 'Services', 'xcency-core' ),
				'singular_name'         => esc_html__( 'Service', 'xcency-core' ),
				'add_new_item'          => esc_html__( 'Add New Service', 'xcency-core' ),
				'all_items'             => esc_html__( 'All Services', 'xcency-core' ),
				'add_new'               => esc_html__( 'Add New', 'xcency-core' ),
				'edit_item'             => esc_html__( 'Edit Service', 'xcency-core' ),
				'featured_image'        => esc_html__( 'Service Image', 'xcency-core' ),
				'set_featured_image'    => esc_html__( 'Set Service Image', 'xcency-core' ),
				'remove_featured_image' => esc_html__( 'Remove Service Image', 'xcency-core' ),
				'use_featured_image'    => esc_html__( 'Use as services image', 'xcency-core' ),
			),
			'rewrite'      => array(
				'slug'       => $service_slug,
				'with_front' => true,
			),
			'hierarchical' => true,
			'public'       => true,
			'menu_icon'    => 'dashicons-schedule',
			'show_in_rest'    => true,
			'supports'     => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
		)
	);

	register_taxonomy(
		'xcency_service_cat',
		'xcency_service',
		array(
			'hierarchical'      => true,
			'label'             => esc_html__( 'Service Categories', 'xcency-core' ),
			'query_var'         => true,
			'show_admin_column' => true,
			'show_in_rest'    => true,
			'rewrite'           => array(
				'slug'       => ''.$service_slug.'-category',
				'with_front' => true,
			)
		)
	);

	register_taxonomy(
		'xcency_service_tag',
		'xcency_service',
		array(
			'hierarchical'      => false,
			'label'             => esc_html__( 'Service Tags', 'xcency-core' ),
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'show_in_rest'    => true,
			'rewrite'           => array(
				'slug'       => ''.$service_slug.'-tag',
				'with_front' => true,
			),
		)
	);

	// Portfolio
	if(function_exists('xcency_option')){
		$portfolio_slug = xcency_option('portfolio_url_slug');
	}else{
		$portfolio_slug = 'portfolio';
	}

	register_post_type( 'xcency_portfolio',
		array(
			'labels'       => array(
				'name'                  => esc_html__( 'Portfolios', 'xcency-core' ),
				'singular_name'         => esc_html__( 'Portfolio', 'xcency-core' ),
				'add_new_item'          => esc_html__( 'Add New Portfolio', 'xcency-core' ),
				'all_items'             => esc_html__( 'All Portfolios', 'xcency-core' ),
				'add_new'               => esc_html__( 'Add New', 'xcency-core' ),
				'edit_item'             => esc_html__( 'Edit Portfolio', 'xcency-core' ),
				'featured_image'        => esc_html__( 'Portfolio Image', 'xcency-core' ),
				'set_featured_image'    => esc_html__( 'Set Portfolio Image', 'xcency-core' ),
				'remove_featured_image' => esc_html__( 'Remove Portfolio Image', 'xcency-core' ),
				'use_featured_image'    => esc_html__( 'Use as Portfolio image', 'xcency-core' ),
			),
			'rewrite'      => array(
				'slug'       => $portfolio_slug,
				'with_front' => true,
			),
			'hierarchical' => true,
			'public'       => true,
			'menu_icon'    => 'dashicons-portfolio',
			'show_in_rest'    => true,
			'supports'     => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
		)
	);

	register_taxonomy(
		'xcency_portfolio_cat',
		'xcency_portfolio',
		array(
			'hierarchical'      => true,
			'label'             => esc_html__( 'Portfolio Categories', 'xcency-core' ),
			'query_var'         => true,
			'show_admin_column' => true,
			'show_in_rest'    => true,
			'rewrite'           => array(
				'slug'       => ''.$portfolio_slug.'-category',
				'with_front' => true,
			)
		)
	);

	register_taxonomy(
		'xcency_portfolio_tag',
		'xcency_portfolio',
		array(
			'hierarchical'      => false,
			'label'             => esc_html__( 'Portfolio Tags', 'xcency-core' ),
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'show_in_rest'    => true,
			'rewrite'           => array(
				'slug'       => ''.$portfolio_slug.'-tag',
				'with_front' => true,
			),
		)
	);

	//Team Members
	if(function_exists('xcency_option')){
		$team_slug = xcency_option('team_url_slug');
	}else{
		$team_slug = 'team';
	}

	register_post_type('xcency_team',
		array(
			'labels'       => array(
				'name'                  => esc_html__('Team Members', 'xcency-core'),
				'singular_name'         => esc_html__('Team Member', 'xcency-core'),
				'add_new_item'          => esc_html__('Add New Member', 'xcency-core'),
				'all_items'             => esc_html__('All Members', 'xcency-core'),
				'add_new'               => esc_html__('Add New', 'xcency-core'),
				'edit_item'             => esc_html__('Edit Member', 'xcency-core'),
				'featured_image'        => esc_html__('Member Image', 'xcency-core'),
				'set_featured_image'    => esc_html__('Set member image', 'xcency-core'),
				'remove_featured_image' => esc_html__('Remove member image', 'xcency-core'),
				'use_featured_image'    => esc_html__('Use as member image', 'xcency-core'),
			),
			'rewrite'      => array(
				'slug'       => $team_slug,
				'with_front' => true,
			),
			'hierarchical' => true,
			'public'       => true,
			'menu_icon'    => 'dashicons-businessman',
			'show_in_rest'    => true,
			'supports'     => array('title', 'editor', 'thumbnail', 'page-attributes'),
		)
	);

	register_taxonomy(
		'xcency_team_cat',
		'xcency_team',
		array(
			'hierarchical'      => true,
			'label'             => esc_html__('Team Categories', 'xcency-core'),
			'query_var'         => true,
			'show_admin_column' => true,
			'show_in_rest'    => true,
			'rewrite'           => array(
				'slug'       => ''.$team_slug.'-category',
				'with_front' => true,
			)
		)
	);

	register_taxonomy(
		'xcency_team_tag',
		'xcency_team',
		array(
			'hierarchical'          => false,
			'label'                 => esc_html__( 'Team Tags', 'xcency-core' ),
			'show_ui'               => true,
			'show_admin_column'          => true,
			'query_var'             => true,
			'show_in_rest'    => true,
			'rewrite'               => array(
				'slug'       => ''.$team_slug.'-tag',
				'with_front' => true,
			),
		)
	);
}

add_action( 'init', 'xcency_core_register_custom_posts' );