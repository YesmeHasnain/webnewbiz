<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome4BlogSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home4-blog-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 4 - Blog Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-posts-grid';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home4' ];
	}

	public function get_keywords() {
		return [ 'home4blogsection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}
	

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_blog_section',
			[
				'label' => esc_html__( 'Home 4 Blog Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'item_column',
			[
				'label'     	=> esc_html__( 'Item Column', 'bdevs-elementor' ),
				'type'      	=> Controls_Manager::SELECT,
				'options'   	=> [
					'type1'  		=> esc_html__( 'Two Columns', 'bdevs-elementor' ),
					'type2'  		=> esc_html__( 'Three Columns', 'bdevs-elementor' ),
					'type3'  		=> esc_html__( 'Four Columns', 'bdevs-elementor' ),
				],
				'default'   	=> 'type2',
			]
		);
		$this->add_control(
			'post_number',
			[
				'label'       => __( 'Post Number', 'bdevs-elementor' ),
				'type'        => Controls_Manager::NUMBER,
				'placeholder' => __( 'Enter your post number', 'bdevs-elementor' ),
				'min'		  => 0,
				'default'     => __( '3', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order_by',
			[
				'label'       => __( 'Post Order By', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text post order by', 'bdevs-elementor' ),
				'default'     => __( 'ID', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
				],
				'default'   => 'desc',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-blog-4-ptb tp-blog-4-bg pt-170 pb-140">
	<div class="container container-1520">
		<div class="row tp-gx-40">
			<?php
			$wp_query = new \WP_Query([
				'post_type'      => 'post',
				'posts_per_page' => intval($settings['post_number']),
				'orderby'        => sanitize_text_field($settings['post_order_by']),
				'order'          => sanitize_text_field($settings['post_order']),
			]);

			while ($wp_query->have_posts()) : $wp_query->the_post();

				$post_id         = get_the_ID();
				$custom_title    = get_post_meta($post_id, '_cmb_post_title_home_4', true);
				$img_id          = get_post_meta($post_id, '_cmb_post_thumb_home_4', true);
				$post_link       = get_permalink();
				$title_attribute = the_title_attribute(['echo' => false]);

				$title = !empty($custom_title) ? $custom_title : get_the_title();
				if (!empty($img_id)) {
					$img_url = wp_get_attachment_url($img_id);
				} elseif (has_post_thumbnail()) {
					$img_url = get_the_post_thumbnail_url();
				} else {
					$img_url = get_template_directory_uri() . '/assets/img/blog/home-4/blog-4-1.jpg';
				}
			?>
				<?php if ($settings['item_column'] === 'type1') { ?>
					<div class="col-lg-6 col-md-6">
				<?php } elseif ($settings['item_column'] === 'type3') { ?>
					<div class="col-lg-3 col-md-6">
				<?php } else { ?>
					<div class="col-lg-4 col-md-6">
				<?php } ?>
		 				<div class="tp-blog-4-item mb-30">
		 					<div class="tp-blog-4-item-thumb mb-20">
		 						<a href="<?php the_permalink(); ?>">
		 							<img class="ratio-81x100" src="<?php echo esc_url($img_url); ?>" alt="<?php the_title_attribute(); ?>">
		 						</a>
		 					</div>
		 					<div class="tp-blog-4-item-content">
		 						<h4 class="tp-blog-4-item-title">
		 							<a href="<?php the_permalink(); ?>">
		 								<?php echo wp_kses_post($title); ?>
		 							</a>
		 						</h4>
		 						<span><?php echo get_the_time('F j, Y'); ?></span>
		 					</div>
		 				</div>
		 			</div>
	 		<?php endwhile; ?>
		</div>
	</div>
</section>



<?php
}

}