<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Main Barab Core Class
 *
 * The main class that initiates and runs the plugin.
 *
 * @since 1.0.0
 */

final class Barab_Extension {

	/**
	 * Plugin Version
	 *
	 * @since 1.0.0
	 *
	 * @var string The plugin version.
	 */
	const VERSION = '1.0.0';

	/**
	 * Minimum Elementor Version
	 *
	 * @since 1.0.0
	 *
	 * @var string Minimum Elementor version required to run the plugin.
	 */

	const MINIMUM_ELEMENTOR_VERSION = '2.0.0';

	/**
	 * Minimum PHP Version
	 *
	 * @since 1.0.0
	 *
	 * @var string Minimum PHP version required to run the plugin.
	 */
	const MINIMUM_PHP_VERSION = '7.0';


	/**
	 * Instance
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 * @static
	 *
	 * @var Elementor_Test_Extension The single instance of the class.
	 */

	private static $_instance = null;

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 * @static
	 *
	 * @return Elementor_Test_Extension An instance of the class.
	 */
	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;

	}

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function __construct() {
		add_action( 'plugins_loaded', [ $this, 'init' ] );
	}

	/**
	 * Initialize the plugin
	 *
	 * Load the plugin only after Elementor (and other plugins) are loaded.
	 * Checks for basic plugin requirements, if one check fail don't continue,
	 * if all check have passed load the files required to run the plugin.
	 *
	 * Fired by `plugins_loaded` action hook.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function init() {

		// Check if Elementor installed and activated

		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );
			return;
		}

		// Check for required Elementor version

		if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );
			return;
		}

		// Check for required PHP version

		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );
			return;
		}


		// Add Plugin actions

		add_action( 'elementor/widgets/register', [ $this, 'init_widgets' ] );


        // Register widget scripts

		add_action( 'elementor/frontend/after_enqueue_scripts', [ $this, 'widget_scripts' ]);


		// Specific Register widget scripts

		// add_action( 'elementor/frontend/after_register_scripts', [ $this, 'barab_regsiter_widget_scripts' ] );
		// add_action( 'elementor/frontend/before_register_scripts', [ $this, 'barab_regsiter_widget_scripts' ] );


        // category register

		add_action( 'elementor/elements/categories_registered',[ $this, 'barab_elementor_widget_categories' ] );
	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have Elementor installed or activated.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_missing_main_plugin() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor */
			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'barab' ),
			'<strong>' . esc_html__( 'Barab Core', 'barab' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'barab' ) . '</strong>'
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required Elementor version.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_minimum_elementor_version() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */

			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'barab' ),
			'<strong>' . esc_html__( 'Barab Core', 'barab' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'barab' ) . '</strong>',
			 self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
	}
	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required PHP version.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_minimum_php_version() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(

			/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'barab' ),
			'<strong>' . esc_html__( 'Barab Core', 'barab' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'barab' ) . '</strong>',
			 self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
	}

	/**
	 * Init Widgets
	 *
	 * Include widgets files and register them
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */

	public function init_widgets() {

		$widget_register = \Elementor\Plugin::instance()->widgets_manager;

		// Header Include file & Widget Register
		// require_once( BARAB_ADDONS . '/header/header.php' );
		require_once( BARAB_ADDONS . '/header/header2.php' );

		// $widget_register->register ( new \Barab_Header() );
		$widget_register->register ( new \Barab_Header2() );


		// Include All Widget Files
		foreach($this->Barab_Include_File() as $widget_file_name){
			require_once( BARAB_ADDONS . '/widgets/barab-'."$widget_file_name".'.php' );
		}
		// All Widget Register
		foreach($this->Barab_Register_File() as $name){
			$widget_register->register ( $name );
		}
		
	}

	public function Barab_Include_File(){
		return [
			'banner', 
			'banner2', 
			'section-title', 
			'button', 
			'blog', 
			'blog-page', 
			'service', 
			'testimonial', 
			'team', 
			'team-info', 
			'image', 
			'contacts-info', 
			'contact-form', 
			'counterup', 
			'faq', 
			'client-logo', 
			'cta', 
			'gallery', 
			'info-box', 
			'newsletter', 
			'menu-select',
			'footer-widgets',
			'footer-copyright',
			'animated-shape',
			'social',
			'arrows', 
			'megamenu',
			'video', 
			'features', 
			'tab-builder', 
			'load-more-widgets',

			'product', 
			'product2', 
			'product-tab',

			'event',
			'menu-list',
			'marquee',

			'choose-us',
			'category',
			'about',
			'step', 
			'download',
		];
	}

	public function Barab_Register_File(){
		return [
			new \Barab_Banner1(),
			new \Barab_Banner2(),
			new \Barab_Section_Title(),
			new \Barab_Button(),
			new \Barab_Blog(),
			new \Barab_Blog_Page(),
			new \Barab_Service(),
			new \Barab_Testimonial(),
			new \Barab_Team(),
			new \Barab_Team_info(),
			new \Barab_Image(),
			new \Barab_Contact_Info(),
			new \Barab_Contact_Form(),
			new \Barab_Counterup(),
			new \Barab_Faq(),
			new \Barab_Client_Logos(), 
			new \Barab_Cta(),
			new \Barab_Gallery(),
			new \Barab_Info_Box(),
			new \barab_Newsletter(),
			new \Barab_Menu(),
			new \Barab_Footer_Widgets(),
			new \Barab_Copyright(),
			new \Barab_Animated_Shape(),
			new \Barab_Social(),
			new \Barab_Arrows(),
			new \Barab_Megamenu(),
			new \barab_Video(),
			new \Barab_Features(),
			new \Barab_Tab_Builder(),
			new \Barab_Load_More_Widget(),

			new \Barab_Product(),
			new \Barab_Product2(),
			new \Barab_Product_Tab(),
			
			new \Barab_Events(),
			new \Barab_Menu_List(),
			new \Barab_Marquee(),

			new \barab_Choose_Us(),
			new \Barab_Category(),
			new \Barab_About_Us(),
			new \barab_Step(),
			new \Barab_Download(),
		];
	}

    public function widget_scripts() {

        // wp_enqueue_script(
        //     'barab-frontend-script',
        //     BARAB_PLUGDIRURI . 'assets/js/barab-frontend.js',
        //     array('jquery'),
        //     false,
        //     true
		// );

	}


    function barab_elementor_widget_categories( $elements_manager ) {

        $elements_manager->add_category(
            'barab',
            [
                'title' => __( 'Barab', 'barab' ),
                'icon' 	=> 'fa fa-plug',
            ]
        );

        $elements_manager->add_category(
            'barab_footer_elements',
            [
                'title' => __( 'Barab Footer Elements', 'barab' ),
                'icon' 	=> 'fa fa-plug',
            ]
		);
 
		$elements_manager->add_category(
            'barab_header_elements',
            [
                'title' => __( 'Barab Header Elements', 'barab' ),
                'icon' 	=> 'fa fa-plug',
            ]
        );
	}
}

Barab_Extension::instance();