<?php
namespace EARLSPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Css_Filter;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Animation_Image extends Widget_Base {
	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'earls_animation_image';
	}
	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Earls Animation Image', 'earls' );
	}
	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-image-rollover';
	}
	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'earls' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'animation_image',
			[
				'label' => esc_html__( 'Earls Animation Image', 'earls' ),
			]
		);
				
		$this->add_control(
			'image',
			[
				'label' => esc_html__( 'Choose Image', 'earls' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		
		$this->add_control(
			'image_two',
			[
				'label' => esc_html__( 'Choose Image', 'earls' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		
		$this->add_control(
			'image_three',
			[
				'label' => esc_html__( 'Choose Image', 'earls' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		
		$this->end_controls_section();
		
		/************************************************************************
								Tab Style Start
		*************************************************************************/
		
		$this->start_controls_section(
			'section_style_image',
			[
				'label' => esc_html__( 'Image Setting', 'earls' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label' => esc_html__( 'Alignment', 'earls' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'earls' ),
						'icon' => 'eicon-text-align-left',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'earls' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} img' => 'float: {{VALUE}};',
				],
			]
		);
		
		$this->add_responsive_control(
			'width',
			[
				'label' => esc_html__( 'Width', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'unit' => '%',
				],
				'tablet_default' => [
					'unit' => '%',
				],
				'mobile_default' => [
					'unit' => '%',
				],
				'size_units' => [ '%', 'px', 'vw' ],
				'range' => [
					'%' => [
						'min' => 1,
						'max' => 100,
					],
					'px' => [
						'min' => 1,
						'max' => 1000,
					],
					'vw' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'space',
			[
				'label' => esc_html__( 'Max Width', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'unit' => '%',
				],
				'tablet_default' => [
					'unit' => '%',
				],
				'mobile_default' => [
					'unit' => '%',
				],
				'size_units' => [ '%', 'px', 'vw' ],
				'range' => [
					'%' => [
						'min' => 1,
						'max' => 100,
					],
					'px' => [
						'min' => 1,
						'max' => 1000,
					],
					'vw' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} img' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'height',
			[
				'label' => esc_html__( 'Height', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'unit' => 'px',
				],
				'tablet_default' => [
					'unit' => 'px',
				],
				'mobile_default' => [
					'unit' => 'px',
				],
				'size_units' => [ 'px', 'vh' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 500,
					],
					'vh' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'object-fit',
			[
				'label' => esc_html__( 'Object Fit', 'earls' ),
				'type' => Controls_Manager::SELECT,
				'condition' => [
					'height[size]!' => '',
				],
				'options' => [
					'' => esc_html__( 'Default', 'earls' ),
					'fill' => esc_html__( 'Fill', 'earls' ),
					'cover' => esc_html__( 'Cover', 'earls' ),
					'contain' => esc_html__( 'Contain', 'earls' ),
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} img' => 'object-fit: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'separator_panel_style',
			[
				'type' => Controls_Manager::DIVIDER,
				'style' => 'thick',
			]
		);

		$this->start_controls_tabs( 'image_effects' );

		$this->start_controls_tab( 'normal',
			[
				'label' => esc_html__( 'Normal', 'earls' ),
			]
		);

		$this->add_control(
			'opacity',
			[
				'label' => esc_html__( 'Opacity', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 1,
						'min' => 0.10,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} img' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			[
				'name' => 'css_filters',
				'selector' => '{{WRAPPER}} img',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab( 'hover',
			[
				'label' => esc_html__( 'Hover', 'earls' ),
			]
		);

		$this->add_control(
			'opacity_hover',
			[
				'label' => esc_html__( 'Opacity', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 1,
						'min' => 0.10,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}}:hover img' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			[
				'name' => 'css_filters_hover',
				'selector' => '{{WRAPPER}}:hover img',
			]
		);

		$this->add_control(
			'background_hover_transition',
			[
				'label' => esc_html__( 'Transition Duration', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 3,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} img' => 'transition-duration: {{SIZE}}s',
				],
			]
		);

		$this->add_control(
			'hover_animation',
			[
				'label' => esc_html__( 'Hover Animation', 'earls' ),
				'type' => Controls_Manager::HOVER_ANIMATION,
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'image_border',
				'selector' => '{{WRAPPER}} img',
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'image_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'earls' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'image_box_shadow',
				'exclude' => [
					'box_shadow_position',
				],
				'selector' => '{{WRAPPER}} img',
			]
		);

		$this->end_controls_section();
		
		/**Image Position Style**/
		$this->start_controls_section(
			'image_position_style',
			[
				'label' => esc_html__('Image Position Setting', 'earls'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'image_position',
			[
				'label' => esc_html__( 'Position', 'earls' ),
				'type' => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					'' => esc_html__( 'Default', 'earls' ),
					'absolute' => esc_html__( 'Absolute', 'earls' ),
					'fixed' => esc_html__( 'Fixed', 'earls' ),
				],
				'selectors' => [
					'{{WRAPPER}} .te-img-position' => 'position: {{VALUE}};',
				],
				'separator' => 'before',
			]
		);
		
		$this->add_responsive_control(
			'image_offset_width_size',
			[
				'label' => __( 'Width', 'cleanex' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', '%', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .te-img-position' => 'width: {{SIZE}}{{UNIT}};'
				],
				'condition' => [
					'image_position!' => '',
				],
			]
		);
		$this->add_responsive_control(
			'image_offset_height_size',
			[
				'label' => __( 'Height', 'cleanex' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', '%', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .te-img-position' => 'height: {{SIZE}}{{UNIT}};'
				],
				'condition' => [
					'image_position!' => '',
				],
			]
		);
		
		$this->add_control(
			'image_offset_orientation_h',
			[
				'label' => esc_html__( 'Horizontal Orientation', 'earls' ),
				'type' => Controls_Manager::CHOOSE,
				'toggle' => false,
				'default' => 'end',
				'options' => [
					'start' => [
						'title' => 'left',
						'icon' => 'eicon-h-align-left',
					],
					'end' => [
						'title' => 'right',
						'icon' => 'eicon-h-align-right',
					],
				],
				'classes' => 'earls-control-start-end',
				'render_type' => 'ui',
				'condition' => [
					'image_position!' => '',
				],
			]
		);
		
		$this->add_responsive_control(
			'image_offset_x',
			[
				'label' => esc_html__( 'Offset', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'default' => [
					'size' => '0',
				],
				'size_units' => [ 'px', '%', 'vw', 'vh', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .te-img-position' => 'left: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'image_offset_orientation_h!' => 'end',
					'image_position!' => '',
				],
			]
		);
		
		$this->add_responsive_control(
			'image_offset_x_end',
			[
				'label' => esc_html__( 'Offset', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 0.1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'default' => [
					'size' => '0',
				],
				'size_units' => [ 'px', '%', 'vw', 'vh', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .te-img-position' => 'right: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'image_offset_orientation_h' => 'end',
					'image_position!' => '',
				],
			]
		);
		
		$this->add_control(
			'image_offset_orientation_v',
			[
				'label' => esc_html__( 'Vertical Orientation', 'earls' ),
				'type' => Controls_Manager::CHOOSE,
				'toggle' => false,
				'default' => 'start',
				'options' => [
					'start' => [
						'title' => esc_html__( 'Top', 'earls' ),
						'icon' => 'eicon-v-align-top',
					],
					'end' => [
						'title' => esc_html__( 'Bottom', 'earls' ),
						'icon' => 'eicon-v-align-bottom',
					],
				],
				'render_type' => 'ui',
				'condition' => [
					'image_position!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'image_offset_y',
			[
				'label' => esc_html__( 'Offset', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'size_units' => [ 'px', '%', 'vh', 'vw', 'custom' ],
				'default' => [
					'size' => '0',
				],
				'selectors' => [
					'{{WRAPPER}} .te-img-position' => 'top: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'image_offset_orientation_v!' => 'end',
					'image_position!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'image_offset_y_end',
			[
				'label' => esc_html__( 'Offset', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'size_units' => [ 'px', '%', 'vh', 'vw', 'custom' ],
				'default' => [
					'size' => '0',
				],
				'selectors' => [
					'{{WRAPPER}} .te-img-position' => 'bottom: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'image_offset_orientation_v' => 'end',
					'image_position!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'image_z_index',
			[
				'label' => esc_html__( 'Z-Index', 'earls' ),
				'type' => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .te-img-position' => 'z-index: {{VALUE}};',
				],
			]
		);
		
		$this->end_controls_section();
		
		/**Image V2 Icon Style**/
		$this->start_controls_section(
			'image_v2_position_style',
			[
				'label' => esc_html__('Image 2 Position Setting', 'earls'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'image_v2_position',
			[
				'label' => esc_html__( 'Position', 'earls' ),
				'type' => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					'' => esc_html__( 'Default', 'earls' ),
					'absolute' => esc_html__( 'Absolute', 'earls' ),
					'fixed' => esc_html__( 'Fixed', 'earls' ),
				],
				'selectors' => [
					'{{WRAPPER}} .te-img-position-v2' => 'position: {{VALUE}};',
				],
				'separator' => 'before',
			]
		);
		
		$this->add_responsive_control(
			'image_v2_offset_width_size',
			[
				'label' => __( 'Width', 'cleanex' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', '%', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .te-img-position-v2' => 'width: {{SIZE}}{{UNIT}};'
				],
				'condition' => [
					'image_v2_position!' => '',
				],
			]
		);
		$this->add_responsive_control(
			'image_v2_offset_height_size',
			[
				'label' => __( 'Height', 'cleanex' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', '%', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .te-img-position-v2' => 'height: {{SIZE}}{{UNIT}};'
				],
				'condition' => [
					'image_v2_position!' => '',
				],
			]
		);
		
		$this->add_control(
			'image_v2_offset_orientation_h',
			[
				'label' => esc_html__( 'Horizontal Orientation', 'earls' ),
				'type' => Controls_Manager::CHOOSE,
				'toggle' => false,
				'default' => 'end',
				'options' => [
					'start' => [
						'title' => 'left',
						'icon' => 'eicon-h-align-left',
					],
					'end' => [
						'title' => 'right',
						'icon' => 'eicon-h-align-right',
					],
				],
				'classes' => 'earls-control-start-end',
				'render_type' => 'ui',
				'condition' => [
					'image_v2_position!' => '',
				],
			]
		);
		
		$this->add_responsive_control(
			'image_v2_offset_x',
			[
				'label' => esc_html__( 'Offset', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'default' => [
					'size' => '0',
				],
				'size_units' => [ 'px', '%', 'vw', 'vh', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .te-img-position-v2' => 'left: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'image_v2_offset_orientation_h!' => 'end',
					'image_v2_position!' => '',
				],
			]
		);
		
		$this->add_responsive_control(
			'image_v2_offset_x_end',
			[
				'label' => esc_html__( 'Offset', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 0.1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'default' => [
					'size' => '0',
				],
				'size_units' => [ 'px', '%', 'vw', 'vh', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .te-img-position-v2' => 'right: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'image_v2_offset_orientation_h' => 'end',
					'image_v2_position!' => '',
				],
			]
		);
		
		$this->add_control(
			'image_v2_offset_orientation_v',
			[
				'label' => esc_html__( 'Vertical Orientation', 'earls' ),
				'type' => Controls_Manager::CHOOSE,
				'toggle' => false,
				'default' => 'start',
				'options' => [
					'start' => [
						'title' => esc_html__( 'Top', 'earls' ),
						'icon' => 'eicon-v-align-top',
					],
					'end' => [
						'title' => esc_html__( 'Bottom', 'earls' ),
						'icon' => 'eicon-v-align-bottom',
					],
				],
				'render_type' => 'ui',
				'condition' => [
					'image_v2_position!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'image_v2_offset_y',
			[
				'label' => esc_html__( 'Offset', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'size_units' => [ 'px', '%', 'vh', 'vw', 'custom' ],
				'default' => [
					'size' => '0',
				],
				'selectors' => [
					'{{WRAPPER}} .te-img-position-v2' => 'top: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'image_v2_offset_orientation_v!' => 'end',
					'image_v2_position!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'image_v2_offset_y_end',
			[
				'label' => esc_html__( 'Offset', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'size_units' => [ 'px', '%', 'vh', 'vw', 'custom' ],
				'default' => [
					'size' => '0',
				],
				'selectors' => [
					'{{WRAPPER}} .te-img-position-v2' => 'bottom: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'image_v2_offset_orientation_v' => 'end',
					'image_v2_position!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'image_v2_z_index',
			[
				'label' => esc_html__( 'Z-Index', 'earls' ),
				'type' => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .te-img-position-v2' => 'z-index: {{VALUE}};',
				],
			]
		);
		
		$this->end_controls_section();
		
		
		/**Image V3 Icon Style**/
		$this->start_controls_section(
			'image_v3_position_style',
			[
				'label' => esc_html__('Image 3 Position Setting', 'earls'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'image_v3_position',
			[
				'label' => esc_html__( 'Position', 'earls' ),
				'type' => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					'' => esc_html__( 'Default', 'earls' ),
					'absolute' => esc_html__( 'Absolute', 'earls' ),
					'fixed' => esc_html__( 'Fixed', 'earls' ),
				],
				'selectors' => [
					'{{WRAPPER}} .te-img-position-v3' => 'position: {{VALUE}};',
				],
				'separator' => 'before',
			]
		);
		
		$this->add_responsive_control(
			'image_v3_offset_width_size',
			[
				'label' => __( 'Width', 'cleanex' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', '%', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .te-img-position-v3' => 'width: {{SIZE}}{{UNIT}};'
				],
				'condition' => [
					'image_v3_position!' => '',
				],
			]
		);
		$this->add_responsive_control(
			'image_v3_offset_height_size',
			[
				'label' => __( 'Height', 'cleanex' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', '%', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .te-img-position-v3' => 'height: {{SIZE}}{{UNIT}};'
				],
				'condition' => [
					'image_v3_position!' => '',
				],
			]
		);
		
		$this->add_control(
			'image_v3_offset_orientation_h',
			[
				'label' => esc_html__( 'Horizontal Orientation', 'earls' ),
				'type' => Controls_Manager::CHOOSE,
				'toggle' => false,
				'default' => 'end',
				'options' => [
					'start' => [
						'title' => 'left',
						'icon' => 'eicon-h-align-left',
					],
					'end' => [
						'title' => 'right',
						'icon' => 'eicon-h-align-right',
					],
				],
				'classes' => 'earls-control-start-end',
				'render_type' => 'ui',
				'condition' => [
					'image_v3_position!' => '',
				],
			]
		);
		
		$this->add_responsive_control(
			'image_v3_offset_x',
			[
				'label' => esc_html__( 'Offset', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'default' => [
					'size' => '0',
				],
				'size_units' => [ 'px', '%', 'vw', 'vh', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .te-img-position-v3' => 'left: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'image_v3_offset_orientation_h!' => 'end',
					'image_v3_position!' => '',
				],
			]
		);
		
		$this->add_responsive_control(
			'image_v3_offset_x_end',
			[
				'label' => esc_html__( 'Offset', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 0.1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'default' => [
					'size' => '0',
				],
				'size_units' => [ 'px', '%', 'vw', 'vh', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .te-img-position-v3' => 'right: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'image_v3_offset_orientation_h' => 'end',
					'image_v3_position!' => '',
				],
			]
		);
		
		$this->add_control(
			'image_v3_offset_orientation_v',
			[
				'label' => esc_html__( 'Vertical Orientation', 'earls' ),
				'type' => Controls_Manager::CHOOSE,
				'toggle' => false,
				'default' => 'start',
				'options' => [
					'start' => [
						'title' => esc_html__( 'Top', 'earls' ),
						'icon' => 'eicon-v-align-top',
					],
					'end' => [
						'title' => esc_html__( 'Bottom', 'earls' ),
						'icon' => 'eicon-v-align-bottom',
					],
				],
				'render_type' => 'ui',
				'condition' => [
					'image_v3_position!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'image_v3_offset_y',
			[
				'label' => esc_html__( 'Offset', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'size_units' => [ 'px', '%', 'vh', 'vw', 'custom' ],
				'default' => [
					'size' => '0',
				],
				'selectors' => [
					'{{WRAPPER}} .te-img-position-v3' => 'top: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'image_v3_offset_orientation_v!' => 'end',
					'image_v3_position!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'image_v3_offset_y_end',
			[
				'label' => esc_html__( 'Offset', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'size_units' => [ 'px', '%', 'vh', 'vw', 'custom' ],
				'default' => [
					'size' => '0',
				],
				'selectors' => [
					'{{WRAPPER}} .te-img-position-v3' => 'bottom: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'image_v3_offset_orientation_v' => 'end',
					'image_v3_position!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'image_v3_z_index',
			[
				'label' => esc_html__( 'Z-Index', 'earls' ),
				'type' => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .te-img-position-v3' => 'z-index: {{VALUE}};',
				],
			]
		);
		
		$this->end_controls_section();
		
	}
	/**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post'); 
	?>
	
    <!-- menu-from --> 
    <section class="animation-style p_relative p-0 m-0">
        <div class="anim-icon" >
            <?php if($settings['image']['id']){ ?><div class="icon icons-1 te-img-position " data-parallax='{"y": -100}' style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>);"></div><?php } ?>
            <?php if($settings['image_two']['id']){ ?><div class="icon icons-2 te-img-position-v2 "  data-parallax='{"y": -100}' style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['image_two']['id'])); ?>);"></div><?php } ?>
            <?php if($settings['image_three']['id']){ ?><div class="icon icons-3 te-img-position-v3 " data-parallax='{"y": -50}' style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['image_three']['id'])); ?>);"></div><?php } ?>
        </div>
    </section>
        
    <?php
	}
}