<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Group_Control_Border;
/**
 *
 * Banner Slider Widget.
 *
 */
class Barab_Banner1 extends Widget_Base {

	public function get_name() {
		return 'barabbanner1';
	}
	public function get_title() {
		return __( 'Banner Slider', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab_header_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'banner_section',
			[
				'label' 	=> __( 'Banner Slider', 'barab' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        ); 

		barab_select_field( $this, 'layout_style', 'Layout Style', ['Style One', 'Style Two', 'Style Three', 'Style Four'] ); 

		barab_media_fields( $this, 'bg_shape', 'Choose Background Shape', ['4'] );
		barab_media_fields( $this, 'text_shape', 'Choose Text Shape', ['4'] );

		$repeater = new Repeater();

		barab_general_fields($repeater, 'subtitle', 'Subtitle', 'TEXTAREA2', 'welcome to barab food');
		barab_general_fields($repeater, 'title', 'Title', 'TEXTAREA', 'Delicious Pizza in the city');
		barab_general_fields($repeater, 'number', 'Number', 'TEXTAREA2', 'Only $45');
		barab_general_fields($repeater, 'button_text', 'Button Text', 'TEXT', 'RESERVE A TABLE');
		barab_url_fields($repeater, 'button_url', 'Button URL');

		barab_media_fields($repeater, 'image', 'Choose Image' );
		
		$this->add_control(
			'banner_slides',
			[
				'label' 		=> __( 'Banners', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'Delicious Pizza in the city', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['1']
				]
			]
		);

		$repeater = new Repeater();

		barab_general_fields($repeater, 'subtitle', 'Subtitle', 'TEXTAREA2', 'Dine. Delight. Discover.');
		barab_general_fields($repeater, 'title', 'Title', 'TEXTAREA', 'Dining Elevated to Perfection');
		barab_general_fields($repeater, 'desc', 'Description', 'TEXTAREA', '');
		barab_general_fields($repeater, 'button_text', 'Button Text', 'TEXT', 'Brows Our Menu');
		barab_url_fields($repeater, 'button_url', 'Button URL');

		barab_media_fields($repeater, 'image', 'Choose Image' );
		
		$this->add_control(
			'banner_slides2',
			[
				'label' 		=> __( 'Banners', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'Dining Elevated to Perfection', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['2']
				]
			]
		);

		$repeater = new Repeater();

		barab_general_fields($repeater, 'subtitle', 'Subtitle', 'TEXTAREA2', 'Dine. Delight. Discover.');
		barab_general_fields($repeater, 'title', 'Title', 'TEXTAREA', 'Dining Elevated to Perfection');
		barab_general_fields($repeater, 'button_text', 'Button Text', 'TEXT', 'Brows Our Menu');
		barab_url_fields($repeater, 'button_url', 'Button URL');

		barab_media_fields($repeater, 'image', 'Choose Image' );
		
		$this->add_control(
			'banner_slides3',
			[
				'label' 		=> __( 'Banners', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'Dining Elevated to Perfection', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['3']
				]
			]
		);

		$repeater = new Repeater();

		barab_general_fields($repeater, 'title', 'Title', 'TEXTAREA', 'Burger Love’s Always');
		barab_media_fields($repeater, 'image', 'Choose Image' );
		
		$this->add_control(
			'banner_slides4',
			[
				'label' 		=> __( 'Banners', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'Burger Love’s Always', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['4']
				]
			]
		);


		barab_switcher_fields($this, 'show_social', 'Show Social?', ['2', '3']);

		$repeater = new Repeater();

		barab_general_fields($repeater, 'social_text', 'social Text', 'TEXT', 'Social name');
		barab_url_fields($repeater, 'social_url', 'social URL');
		
		$this->add_control(
			'social_list',
			[
				'label' 		=> __( 'Social List', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'social_text' 	=> __( 'Facebook', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['2', '3']
				]
			]
		);

		barab_general_fields($this, 'circle_text', 'Circle Text', 'TEXTAREA2', 'MAKE FRESH EAT REFRESH MAKE FRESH EAT REFRESH', ['4'] ); 
		barab_general_fields($this, 'circle_middle_text', 'Circle Middle Text', 'TEXTAREA2', 'ORDER YOUR BURGER', ['4'] ); 
		barab_url_fields($this, 'circle_url', 'Circle Middle Text URL', ['4']);

		barab_media_fields( $this, 'shape1', 'Choose Shape', ['1', '2', '3'] );
		barab_media_fields( $this, 'shape2', 'Choose Shape', ['1', '2'] );
		barab_media_fields( $this, 'shape3', 'Choose Shape', ['1'] );
		barab_media_fields( $this, 'section_curve_shape', 'Section Curve Shape', ['1'] );
		barab_switcher_fields($this, 'show_shape', 'Show Shape?', ['3', '4']);

		$this->end_controls_section();

        //---------------------------------------
			//Style Section Start 
		//---------------------------------------

		barab_common_style_fields( $this, '01', 'Subtitle', '{{WRAPPER}} .sub-title', ['1', '2', '3'] );
		barab_common_style_fields( $this, '02', 'Title', '{{WRAPPER}} .hero-title', ['1', '2', '3', '4'] );
		barab_common_style_fields( $this, '03', 'Description', '{{WRAPPER}} .hero-text', ['2'] );
		barab_common_style_fields( $this, '04', 'Number', '{{WRAPPER}} .price', ['1'] );
		//------Button Style-------
		barab_button_style_fields( $this, '10', 'Button Styling', '{{WRAPPER}} .th_btn', ['1', '2', '3'] );

    }
 
	protected function render() {

    $settings = $this->get_settings_for_display();

		if( $settings['layout_style'] == '1' ){
			echo '<div class="th-hero-wrapper hero-2" id="hero">';
				echo barab_img_tag( array(
					'url'   => esc_url( $settings['section_curve_shape']['url'] ),
					'class' => 'round-shape-bottom'
				));
				if($settings['shape1']['url'] ){
					echo '<div class="shape-mockup d-none d-xl-block movingX" data-top="4%" data-left="5%">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['shape1']['url'] ),
						)); 
					echo '</div>';
				}
				if($settings['shape2']['url'] ){
					echo '<div class="shape-mockup d-none d-xl-block jump" data-top="8%" data-right="5%">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['shape2']['url'] ),
						)); 
					echo '</div>';
				}
				if($settings['shape3']['url'] ){
					echo '<div class="shape-mockup d-none d-xl-block jump" data-top="36%" data-left="16%">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['shape3']['url'] ),
						)); 
					echo '</div>';
				}

				echo '<div class="hero-inner">';
					echo '<div class="hero-style2">';
						echo '<div class="container">';
							echo '<div class="row justify-content-center">';
								echo '<div class="col-xl-7 col-lg-10">';
									echo '<div class="hero-2-content-slider">';
										echo '<div class="swiper th-slider hero2ThumbSlide" id="hero2Content" data-slider-options=\'{"effect":"fade","autoplay": false,"spaceBetween":60,"loop":true, "autoHeight":false,"allowTouchMove": false, "simulateTouch": true}\'>';
											echo '<div class="swiper-wrapper">';
												foreach( $settings['banner_slides'] as $key => $data ){
													echo '<div class="swiper-slide">';
														echo '<div class="hero-2-content-slider">';
															if(!empty($data['subtitle'])){
																echo '<span class="sub-title" data-ani="slideinup" data-ani-delay="0.2s">'.wp_kses_post($data['subtitle']).'</span>';
															} 
															if(!empty($data['title'])){
																echo '<h1 class="hero-title" data-ani="slideinup" data-ani-delay="0.4s">'.wp_kses_post($data['title']).'</h1>';
															}
															echo '<div class="size-top-wrap style-2" data-ani="slideinup" data-ani-delay="0.6s">';
																echo '<div class="size-item-wrap box-social">';
																	echo '<div class="box-btn">';
																		echo '<a '.barab_link_attrs($data['button_url']).'><i class="far fa-plus"></i></a>';
																	echo '</div>';
																echo '</div>';
															echo '</div>';
															echo '<div class="slider-bottom" data-ani="slideinup" data-ani-delay="0.8s">';
																if(!empty($data['number'])){
																	echo '<div class="price">'.wp_kses_post($data['number']).'</div>';
																}
																if(!empty($data['button_text'])){
																	echo '<a '.barab_link_attrs($data['button_url']).' class="th-btn btn-mask th_btn">'.wp_kses_post( $data['button_text'] ).'</a>';
																}
															echo '</div>';
														echo '</div>';
													echo '</div>';
												}
											echo '</div>';
										echo '</div>';
									echo '</div>';
								echo '</div>';
							echo '</div>';
						echo '</div>';

						echo '<div class="container-fluid">';
							echo '<div class="hero-2-img-slider">';
								echo '<div class="swiper th-slider " data-slider-options=\'{"centeredSlides":true,"spaceBetween":80,"loop":true,"autoplay": false,"autoHeight": "false","allowTouchMove": true, "simulateTouch": true,"breakpoints":{"0":{"slidesPerView":1},"576":{"slidesPerView":"1"},"768":{"slidesPerView":"2"},"992":{"slidesPerView":"2"},"1200":{"slidesPerView":"3"}},"thumbs":{"swiper":".hero2ThumbSlide"}}\'>';
									echo '<div class="swiper-wrapper">';
										foreach( $settings['banner_slides'] as $key => $data ){
											echo '<div class="swiper-slide">';
												if($data['image']['url'] ){
													echo '<div class="hero-2-thumb-slider" data-ani="spinCenter" data-ani-delay="0.3s">>';
														echo barab_img_tag( array(
															'url'   => esc_url( $data['image']['url'] ),
														)); 
													echo '</div>';
												}
											echo '</div>';
										}
									echo '</div>';
									echo '<button data-slider-prev="#hero2Content" class="slider-arrow slider-prev"><img src="'.BARAB_ASSETS.'img/icon/left-arrow.svg" alt=""></button>';
									echo '<button data-slider-next="#hero2Content" class="slider-arrow slider-next"><img src="'.BARAB_ASSETS.'img/icon/right-arrow.svg" alt=""></button>';
								echo '</div>';
							echo '</div>';
						echo '</div>';
					echo '</div>';
				echo '</div>';
			echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
			echo '<div class="th-hero-wrapper hero-3 black-bg" id="hero">';
				if($settings['shape1']['url'] ){
					echo '<div class="hero-3-shape-bg">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['shape1']['url'] ),
						)); 
					echo '</div>';
				}
				if($settings['shape2']['url'] ){
					echo '<div class="hero-right-shape shape-mockup jump" data-bottom="0" data-right="0">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['shape2']['url'] ),
						)); 
					echo '</div>';
				}
				if(!empty($settings['show_social'])){
					echo '<div class="hero-left-social">';
						echo '<ul>';
							foreach( $settings['social_list'] as $key => $data ){
								echo '<li><a '.barab_link_attrs($data['social_url']).'>'.wp_kses_post( $data['social_text'] ).'</a></li>';
							}
						echo '</ul>';
					echo '</div>';
				}
				echo '<div class="swiper th-slider" id="heroSlider3" data-slider-options=\'{"effect":"fade", "autoHeight": "true"}\'>';
					echo '<div class="swiper-wrapper">';
						foreach( $settings['banner_slides2'] as $key => $data ){
							echo '<div class="swiper-slide">';
								echo '<div class="hero-inner">';
									echo '<div class="hero-style3">';
										echo '<div class="container-fluid">';
											echo '<div class="row gy-40 gx-80 align-items-center">';
												echo '<div class="col-xl-6 col-lg-6">';
													echo '<div class="hero-img">';
														if($data['image']['url'] ){
															echo '<div class="img-main" data-ani="slideinrighthero" data-ani-delay="0.8s">';
																echo barab_img_tag( array(
																	'url'   => esc_url( $data['image']['url'] ),
																)); 
															echo '</div>';
														}
													echo '</div>';
												echo '</div>';
												echo '<div class="col-xl-6 col-lg-6">';
													if(!empty($data['subtitle'])){
														echo '<span class="sub-title" data-ani="slideinup" data-ani-delay="0.2s">'.wp_kses_post($data['subtitle']).'</span>';
													} 
													if(!empty($data['title'])){
														echo '<h1 class="hero-title pe-xxl-2 me-xxl-3" data-ani="slideinup" data-ani-delay="0.4s">'.wp_kses_post($data['title']).'</h1>';
													}
													if(!empty($data['desc'])){
														echo '<p class="hero-text me-xl-5 pe-xxl-5" data-ani="slideinup" data-ani-delay="0.5s">'.wp_kses_post($data['desc']).'</p>';
													}
													if(!empty($data['button_text'])){
														echo '<div class="btn-group" data-ani="slideinup" data-ani-delay="0.7s">';
															echo '<a '.barab_link_attrs($data['button_url']).' class="th-btn style6 th_btn">'.wp_kses_post( $data['button_text'] ).'</a>';
														echo '</div>';
													}
												echo '</div>';
											echo '</div>';
										echo '</div>';
									echo '</div>';
								echo '</div>';
							echo '</div>';
						}
					echo '</div>';
					echo '<div class="slider-pagination"></div>';
					echo '<div class="icon-box">';
						echo '<button data-slider-prev="#heroSlider3" class="slider-arrow slider-prev"><img src="'.BARAB_ASSETS.'img/icon/left-arrow.svg" alt="'.esc_attr__('Arrow Icon', 'barab').'"></button>';
						echo '<span class="line"></span>';
						echo '<button data-slider-next="#heroSlider3" class="slider-arrow slider-next"><img src="'.BARAB_ASSETS.'img/icon/right-arrow.svg" alt="'.esc_attr__('Arrow Icon', 'barab').'"></button>';
					echo '</div>';
				echo '</div>';
			echo '</div>';

		}elseif( $settings['layout_style'] == '3' ){
			echo '<div class="th-hero-wrapper hero-4" id="hero">';
				if(!empty($settings['show_shape'])){
					echo '<div class="hero-4-right-border"></div>';
					echo '<div class="hero-4-bg-shape">';
						echo '<img src="'.BARAB_ASSETS.'img/shape/hero-4-bg-shape.png" alt="'.esc_attr__('Shape', 'barab').'">';
					echo '</div>';
					echo '<div class="hero-right-shape shape-mockup movingX" data-top="0" data-right="3%">';
						echo '<img src="'.BARAB_ASSETS.'img/shape/hero-4-1-right.png" alt="'.esc_attr__('Shape', 'barab').'">';
					echo '</div>';
				}
				if($settings['shape1']['url'] ){
					echo '<div class="hero-4-bottom spin">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['shape1']['url'] ),
						)); 
					echo '</div>';
				}
				if(!empty($settings['show_social'])){
					echo '<div class="hero-left-social">';
						echo '<ul>';
							foreach( $settings['social_list'] as $key => $data ){
								echo '<li><a '.barab_link_attrs($data['social_url']).'>'.wp_kses_post( $data['social_text'] ).'</a></li>';
							}
						echo '</ul>';
					echo '</div>';
				}
				echo '<div class="swiper th-slider" id="heroSlider4" data-slider-options=\'{"autoplay":false,"effect":"fade", "autoHeight": "true"}\'>';
					echo '<div class="swiper-wrapper">';
						foreach( $settings['banner_slides3'] as $key => $data ){
						echo '<div class="swiper-slide">';
							echo '<div class="hero-inner">';
								echo '<div class="hero-style3 style2">';
									echo '<div class="container">';
										echo '<div class="row gy-40 gx-80">';
											echo '<div class="col-xl-6 col-lg-6">';
												echo '<div class="hero-4-content">';
													if(!empty($data['subtitle'])){
														echo '<span class="sub-title" data-ani="slideinup" data-ani-delay="0.2s">'.wp_kses_post($data['subtitle']).'</span>';
													} 
													if(!empty($data['title'])){
														echo '<h1 class="hero-title" data-ani="slideinup" data-ani-delay="0.4s">'.wp_kses_post($data['title']).'</h1>';
													}
													if(!empty($data['button_text'])){
														echo '<div class="btn-group" data-ani="slideinup" data-ani-delay="0.7s">';
															echo '<a '.barab_link_attrs($data['button_url']).' class="th-btn style6 th_btn">'.wp_kses_post( $data['button_text'] ).'</a>';
														echo '</div>';
													}
													echo '<div class="hero-4-icon">';
														echo '<button data-slider-prev="#heroSlider4" class="slider-arrow slider-prev"><img src="'.BARAB_ASSETS.'img/icon/left-arrow.svg" alt="'.esc_attr__('Arrow Icon', 'barab').'"></button>';
														echo '<span class="line"></span>';
														echo '<button data-slider-next="#heroSlider4" class="slider-arrow slider-next"><img src="'.BARAB_ASSETS.'img/icon/right-arrow.svg" alt="'.esc_attr__('Arrow Icon', 'barab').'"></button>';
													echo '</div>';
												echo '</div>';
											echo '</div>';
											echo '<div class="col-xl-6 col-lg-6">';
												if($data['image']['url'] ){
													echo '<div class="hero-img">';
														echo '<div class="img-main" data-ani="slideinrighthero" data-ani-delay="0.8s">';
															echo barab_img_tag( array(
																'url'   => esc_url( $data['image']['url'] ),
															)); 
														echo '</div>';
													echo '</div>';
												}
											echo '</div>';
										echo '</div>';
									echo '</div>';
								echo '</div>';
							echo '</div>';
						echo '</div>';
						}
					echo '</div>';
				echo '</div>';
			echo '</div>';

		}elseif( $settings['layout_style'] == '4' ){
			echo '<div class="th-hero-wrapper hero-2 style-2" id="hero">';
				if(!empty($settings['show_shape'])){
					echo '<div class="shape-mockup jump hero-5-1" data-top="0%" data-right="0%">';
						echo '<img src="'.BARAB_ASSETS.'img/shape/hero-5-1.png" alt="'.esc_attr__('Shape', 'barab').'">';
					echo '</div>';
				}
				if(!empty($settings['circle_middle_text'] || $settings['circle_text'])){
					echo '<div class="hero-img-shape-1">';
						echo '<div class="logo-icon-wrap">';
							if(!empty($settings['circle_middle_text'])){
								echo '<div class="logo-icon">';
									echo '<h4 class="order"><a '.barab_link_attrs($settings['circle_url']).'>'.esc_html( $settings['circle_middle_text'] ).'</a></h4>';
								echo '</div>';
							}
							if(!empty($settings['circle_text'])){
								echo '<div class="logo-icon-wrap__text">';
									echo '<span class="logo-animation">'.esc_html( $settings['circle_text'] ).'</span>';
								echo '</div>';
							}
						echo '</div>';
					echo '</div>';
					}
				echo '<div class="hero-inner" data-bg-src="'.esc_url( $settings['bg_shape']['url'] ).'">';
					if(!empty($settings['show_shape'])){
						echo '<div class="shape-mockup movingX hero-5-2" data-bottom="0%" data-left="22%">';
							echo '<img src="'.BARAB_ASSETS.'img/shape/hero-5-2.png" alt="'.esc_attr__('Shape', 'barab').'">';
						echo '</div>';
					}
					echo '<div class="hero-style2 style-2">';
						echo '<div class="container">';
							echo '<div class="row justify-content-center">';
								echo '<div class="col-xxl-10 col-xl-11 col-lg-12">';
									echo '<div class="hero-2-content-slider">';
										echo '<div class="swiper th-slider hero2ThumbSlide" id="hero2Content" data-slider-options=\'{"effect":"fade","autoplay": true,"spaceBetween":60,"loop":true, "autoHeight":false,"allowTouchMove": false, "simulateTouch": true}\'>';
											echo '<div class="swiper-wrapper">';
												foreach( $settings['banner_slides4'] as $key => $data ){
													echo '<div class="swiper-slide">';
														echo '<div class="hero-2-content-slider">';
															if(!empty($data['title'])){
																echo '<h1 class="hero-title" data-ani="slideinup" data-ani-delay="0.4s">'.wp_kses_post($data['title']).'</h1>';
															}
														echo '</div>';
													echo '</div>';
												}
											echo '</div>';
										echo '</div>';
									echo '</div>';
								echo '</div>';
							echo '</div>';
						echo '</div>';

						echo '<div class="container-fluid">';
							echo '<div class="hero-2-img-slider">';
								echo '<div class="swiper th-slider " data-slider-options=\'{"centeredSlides":true,"spaceBetween":70,"loop":true,"autoplay": true,"autoHeight": "false","allowTouchMove": true, "simulateTouch": true,"breakpoints":{"0":{"slidesPerView":1},"576":{"slidesPerView":"1"},"768":{"slidesPerView":"2"},"992":{"slidesPerView":"2"},"1200":{"slidesPerView":"3"}},"thumbs":{"swiper":".hero2ThumbSlide"}}\'>';
									echo '<div class="swiper-wrapper">';
										foreach( $settings['banner_slides4'] as $key => $data ){
											echo '<div class="swiper-slide">';
												if($data['image']['url'] ){
													echo '<div class="hero-2-thumb-slider">';
														echo barab_img_tag( array(
															'url'   => esc_url( $data['image']['url'] ),
														));
													echo '</div>';
												}
											echo '</div>';
										}
									echo '</div>';
									echo '<button data-slider-prev="#hero2Content" class="slider-arrow slider-prev"><img src="'.BARAB_ASSETS.'img/icon/left-arrow.svg" alt="'.esc_attr__('Arrow Icon', 'barab').'"></button>';
									echo '<button data-slider-next="#hero2Content" class="slider-arrow slider-next"><img src="'.BARAB_ASSETS.'img/icon/right-arrow.svg" alt="'.esc_attr__('Arrow Icon', 'barab').'"></button>';
								echo '</div>';
							echo '</div>';
						echo '</div>';
					echo '</div>';
				echo '</div>';

				if($settings['text_shape']['url'] ){
					echo '<div class="hero-5-bottom">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['text_shape']['url'] ),
						)); 
					echo '</div>';
				}

			echo '</div>';

		}

		
	}

} 