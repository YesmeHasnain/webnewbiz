<?php
/**
 * Chat Handler - AJAX endpoint for AI chat
 */
class AICopilot_Chat
{
    public static function init()
    {
        add_action('wp_ajax_ai_copilot_chat', [self::class, 'handleChat']);
        add_action('wp_ajax_ai_copilot_pages', [self::class, 'getPages']);
        add_action('wp_ajax_ai_copilot_undo', [self::class, 'handleUndo']);
        add_action('wp_ajax_ai_copilot_use_image', [self::class, 'handleUseImage']);
    }

    public static function handleChat()
    {
        check_ajax_referer('ai_copilot_nonce', 'nonce');

        if (!current_user_can('edit_pages')) {
            wp_send_json_error('Permission denied');
        }

        $message = sanitize_textarea_field($_POST['message'] ?? '');
        $history = json_decode(stripslashes($_POST['history'] ?? '[]'), true) ?: [];
        $pageId = intval($_POST['page_id'] ?? 0);
        $selectedElement = json_decode(stripslashes($_POST['selected_element'] ?? ''), true) ?: null;

        if (!$message) {
            wp_send_json_error('Message is required');
        }

        // Intercept undo commands - handle locally without calling Claude
        $msgLower = strtolower(trim($message));
        if (in_array($msgLower, ['undo', 'undo that', 'revert', 'go back', 'ctrl z'])) {
            $undoResult = AICopilot_History::undo($pageId);
            wp_send_json_success([
                'reply' => $undoResult['success']
                    ? 'Undo done! ' . ($undoResult['remaining'] ?? 0) . ' undo step(s) remaining.'
                    : 'Cannot undo: ' . ($undoResult['error'] ?? 'Unknown error'),
                'actions' => $undoResult['success'] ? [['tool' => 'undo', 'input' => [], 'result' => $undoResult]] : [],
                'has_changes' => $undoResult['success'],
            ]);
            return;
        }

        // Build system prompt with site context
        $systemPrompt = self::buildSystemPrompt($pageId);

        // Build messages
        $messages = [];
        foreach ($history as $msg) {
            $messages[] = [
                'role' => $msg['role'] ?? 'user',
                'content' => $msg['content'] ?? '',
            ];
        }
        $messages[] = ['role' => 'user', 'content' => $message];

        // Get tools
        $tools = AICopilot_Tools::getAll();

        // Call Claude with tool-use
        $result = AICopilot_ClaudeAPI::chat($messages, $systemPrompt, $tools, $pageId, $selectedElement);

        if (!$result['success']) {
            wp_send_json_error($result['error'] ?? 'AI request failed');
        }

        wp_send_json_success([
            'reply' => $result['reply'],
            'actions' => $result['actions'] ?? [],
            'has_changes' => !empty($result['actions']),
        ]);
    }

    public static function handleUndo()
    {
        check_ajax_referer('ai_copilot_nonce', 'nonce');

        if (!current_user_can('edit_pages')) {
            wp_send_json_error('Permission denied');
        }

        $pageId = intval($_POST['page_id'] ?? 0);
        if (!$pageId) {
            wp_send_json_error('No page selected');
        }

        $result = AICopilot_History::undo($pageId);
        if (!$result['success']) {
            wp_send_json_error($result['error'] ?? 'Cannot undo');
        }

        wp_send_json_success($result);
    }

    public static function handleUseImage()
    {
        check_ajax_referer('ai_copilot_nonce', 'nonce');

        if (!current_user_can('edit_pages')) {
            wp_send_json_error('Permission denied');
        }

        $imageUrl = esc_url_raw($_POST['image_url'] ?? '');
        $elementId = sanitize_text_field($_POST['element_id'] ?? '');
        $pageId = intval($_POST['page_id'] ?? 0);
        $alt = sanitize_text_field($_POST['alt'] ?? '');

        if (!$imageUrl) {
            wp_send_json_error('No image URL');
        }

        $result = AICopilot_Executor::execute('use_image', [
            'image_url' => $imageUrl,
            'element_id' => $elementId,
            'page_id' => $pageId,
            'alt' => $alt,
        ]);

        if (!$result['success']) {
            wp_send_json_error($result['error'] ?? 'Failed');
        }

        wp_send_json_success($result);
    }

    public static function getPages()
    {
        check_ajax_referer('ai_copilot_nonce', 'nonce');

        $pages = get_posts([
            'post_type' => 'page',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'orderby' => 'menu_order',
            'order' => 'ASC',
        ]);

        $result = [];
        foreach ($pages as $page) {
            $result[] = [
                'id' => $page->ID,
                'title' => $page->post_title,
                'url' => get_permalink($page->ID),
            ];
        }

        wp_send_json_success($result);
    }

    private static function buildSystemPrompt(int $pageId): string
    {
        $siteName = get_bloginfo('name');
        $siteUrl = home_url();
        $theme = wp_get_theme()->get('Name');

        $prompt = "You are an AI website editor for \"{$siteName}\" ({$siteUrl}). You help users edit their WordPress + Elementor website through natural language commands.\n\n";
        $prompt .= "Site Info:\n- Theme: {$theme}\n- URL: {$siteUrl}\n";

        // Add page info if selected
        if ($pageId) {
            $page = get_post($pageId);
            if ($page) {
                $prompt .= "- Current Page: \"{$page->post_title}\" (ID: {$pageId})\n";
            }
        }

        // List all pages
        $pages = get_posts(['post_type' => 'page', 'post_status' => 'publish', 'posts_per_page' => 20]);
        if ($pages) {
            $prompt .= "\nSite Pages:\n";
            foreach ($pages as $p) {
                $prompt .= "- {$p->post_title} (ID: {$p->ID})\n";
            }
        }

        $prompt .= "\nRules:\n";
        $prompt .= "- ALWAYS call get_page_editables first to see what elements exist before editing\n";
        $prompt .= "- Use element IDs from get_page_editables when editing\n";
        $prompt .= "- Be helpful and execute changes immediately when asked\n";
        $prompt .= "- Explain what you did after each action\n";
        $prompt .= "- If the user asks something you can't do with tools, explain what they can do instead\n";

        return $prompt;
    }
}
