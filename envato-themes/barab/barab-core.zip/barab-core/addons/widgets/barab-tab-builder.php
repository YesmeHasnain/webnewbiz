<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Group_Control_Border;
/**
 *
 * Tab Builder Widget .
 *
 */
class barab_Tab_Builder extends Widget_Base {

	public function get_name() {
		return 'barabtabbuilder';
	}
	public function get_title() {
		return __( 'Tab Builder', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
    public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'tab_builder_section',
			[
				'label' 	=> __( 'Tab Builder', 'barab' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One' ] );

		barab_general_fields($this, 'title', 'Section Title', 'TEXTAREA', 'Our Signature Menu', ['1'] );
		barab_general_fields($this, 'desc', 'Section Description', 'TEXTAREA', '', ['1'] );

		$repeater = new Repeater();

		barab_general_fields( $repeater, 'title', 'Tab Builder Title', 'TEXTAREA2', 'Tab 1' );

		$repeater->add_control( 
			'barab_tab_builder_option',
			[
				'label'     => __( 'Tab Name', 'barab' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => $this->barab_tab_builder_choose_option(),
				'default'	=> ''
			]
		);

		$this->add_control(
			'tab_builder_repeater',
			[
				'label' 		=> __( 'Tab', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title'    => __( 'Tab 1', 'barab' ),
					],
					
				],
				'title_field' 	=> '{{{ title }}}',
				'condition'		=> [ 
					'layout_style' => [ '1', '2' ],
				],
			]
		);

        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------
		barab_common_style_fields( $this, '02', 'Section Title', '{{WRAPPER}} .sec-title', ['1'] );
		barab_common_style_fields( $this, '03', 'Section Description', '{{WRAPPER}} .desc', ['1'] );

    }

	public function barab_tab_builder_choose_option(){

		$barab_post_query = new WP_Query( array(
			'post_type'				=> 'barab_tab_builder',
			'posts_per_page'	    => -1,
		) );

		$barab_tab_builder_title = array();
		$barab_tab_builder_title[''] = __( 'Select a Tab','barab');

		while( $barab_post_query->have_posts() ) {
			$barab_post_query->the_post();
			$barab_tab_builder_title[ get_the_ID() ] =  get_the_title();
		}
		wp_reset_postdata();

		return $barab_tab_builder_title;

	}

	protected function render() {

        $settings = $this->get_settings_for_display();

		if( $settings['layout_style'] == '1' ){ 
			echo '<div class="row gy-30 justify-content-between align-items-center mb-50">';
                echo '<div class="col-xl-6 col-lg-8">';
                    echo '<div class="title-area style3 mb-0">';
						if(!empty($settings['title'])){
							echo '<h2 class="sec-title mb-3 text-anime-style-2">'.wp_kses_post($settings['title']).'</h2>';
						}
						if(!empty($settings['desc'])){
							echo '<p class="box-text pe-xxl-5 me-xl-5 text-anime-style-3 desc">'.esc_html($settings['desc']).'</p>';
						}
                    echo '</div>';
                echo '</div>';
                echo '<div class="col-auto">';
					echo '<div class="nav nav-tabs menu-signature-tabs wow fadeinup" id="nav-tab" role="tablist">';
						$x = 0;
						foreach( $settings['tab_builder_repeater'] as $data ){
							$x++;
							$active = $x == '1' ? 'active':'';
							$aria = $x == '1' ? 'true':'false';
							echo '<button class="nav-link th-btn '.esc_attr($active).'" id="nav-'.esc_attr($x).'-tab" data-bs-toggle="tab" data-bs-target="#nav-'.esc_attr($x).'" type="button" role="tab" aria-controls="nav-'.esc_attr($x).'" aria-selected="'.esc_attr($aria).'">'.esc_html( $data['title'] ).'</button>';
						}
					echo '</div>';
                echo '</div>';
            echo '</div>';

			echo '<div class="tab-content" id="nav-tabContent">';
				$x = 0;
				foreach( $settings['tab_builder_repeater'] as $data ){
					$x++;
					$active = $x == '1' ? 'active show':'';
					echo '<div class="tab-pane fade '.esc_attr($active).'" id="nav-'.esc_attr($x).'" role="tabpanel" aria-labelledby="nav-'.esc_attr($x).'-tab">';
						$elementor = \Elementor\Plugin::instance();
						if( ! empty( $data['barab_tab_builder_option'] ) ){
							echo $elementor->frontend->get_builder_content_for_display( $data['barab_tab_builder_option'] );
						}
					echo '</div>';
				}
			echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){


		}
		
      
	}
}