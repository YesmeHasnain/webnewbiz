<?php

//oneclick importer
function ocdi_import_files()
{
	return array(
		array(
			'import_file_name'           => 'All Demo Content',
			'import_file_url'            => plugins_url('/demo-data/mancink.xml', __FILE__),
			'import_widget_file_url'     => plugins_url('/demo-data/mancink.wie', __FILE__),
			'import_preview_image_url'   => plugins_url('/demo-data/mancink.jpg', __FILE__),
			'import_customizer_file_url' => plugins_url('/demo-data/mancink.dat', __FILE__),
			'import_notice'                => __('<p>To prevent any error, please use the clean wordpress site to import the demo data. </p><p>Or you can use this plugin
			<a href="https://wordpress.org/plugins/wordpress-database-reset/" target="_blank">WordPress Database Reset</a> to reset/clear the database first.</p><p>After you import this demo, you will have to setup the elementor page builder & flickr settings separately.</p>', 'mancink_plugin'),
			'preview_url'                => 'https://theme.winnertheme.com/mancink',
		),
		array(
			'import_file_name'           => 'Library/Page Template Only',
			'import_file_url'            => '',
			'import_preview_image_url'   => plugins_url('/demo-data/library.jpg', __FILE__),
			'preview_url'                => 'https://theme.winnertheme.com/mancink',
		),
	);
}
add_filter('ocdi/import_files', 'ocdi_import_files');


add_filter('ocdi/disable_pt_branding', '__return_true');


function ocdi_after_import($selected_import)
{

	// Assign menus to their locations.
	$multi_page = get_term_by('name', 'Default Menu', 'nav_menu');
	set_theme_mod(
		'nav_menu_locations',
		array(
			'ridianur-homepage-menu' => $multi_page->term_id,
		)
	);

	if ('All Demo Content' === $selected_import['import_file_name']) {


		// Assign front page and posts page (blog page).
		$pages = get_posts([
			'post_type'   => 'page',
			'title'       => 'Home Slider',
			'numberposts' => 1,
		]);

		$front_page_id = !empty($pages) ? $pages[0]->ID : null;

		update_option('show_on_front', 'page');
		update_option('page_on_front', $front_page_id);

		//import kit/elementor settings
		// Import Elementor kit data.
		$rdn_kit = plugin_dir_path(__FILE__) . 'demo-data/elementor-kit.zip';
		$import_export_module        = \Elementor\Plugin::$instance->app->get_component('import-export');
		$import_settings['referrer'] = 'remote';
		$import_export_module->import_kit($rdn_kit, $import_settings);
	}

	//import elementor library
	if ('Library/Page Template Only' === $selected_import['import_file_name']) {
		$files = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17'];

		foreach ($files as $file) {
			$path = plugins_url('demo-data/json/' . $file . '.json', __FILE__);
			$fileContent = file_get_contents($path);
			\Elementor\Plugin::instance()->templates_manager->import_template(
				[
					'fileData' => base64_encode($fileContent),
					'fileName' => 'mancinks.json',
				]
			);
		}
	}
}
add_action('ocdi/after_import', 'ocdi_after_import');
