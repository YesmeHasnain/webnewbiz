<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Copyright Widget .
 *
 */
class Barab_Copyright extends Widget_Base {

	public function get_name() {
		return 'barabcopyright';
	}
	public function get_title() {
		return __( 'Footer Copyright', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		 $this->start_controls_section(
			'section_title_section',
			[
				'label'		 	=> __( 'Footer Copyright', 'barab' ),
				'tab' 			=> Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', ['Style One', 'Style Two', 'Style Three'] );

		barab_general_fields( $this, 'copyright_text', 'Copyright Content', 'TEXTAREA', 'Copyright Barab 2025', ['1', '2', '3'] );

        barab_media_fields( $this, 'logo', 'Choose Logo', ['1'] );
        barab_media_fields( $this, 'image1', 'Choose Image', ['1', '3'] );
        // barab_media_fields( $this, 'shape', 'Choose Shape', ['3'] );
        barab_media_fields( $this, 'bg', 'Choose Background', ['3'] );

        $menus = $this->barab_menu_select();

		if( !empty( $menus ) ){
	        $this->add_control(
				'barab_menu_select',
				[
					'label'     	=> __( 'Select Barab Menu', 'barab' ),
					'type'      	=> Controls_Manager::SELECT,
					'options'   	=> $menus,
					'description' 	=> sprintf( __( 'Go to the <a href="%s" target="_blank">Menus screen</a> to manage your menus.', 'barab' ), admin_url( 'nav-menus.php' ) ),
                    'condition'	=> [
                        'layout_style' => ['2']
                    ]
				]
			);
		}else {
			$this->add_control(
				'no_menu',
				[
					'type' 				=> Controls_Manager::RAW_HTML,
					'raw' 				=> '<strong>' . __( 'There are no menus in your site.', 'barab' ) . '</strong><br>' . sprintf( __( 'Go to the <a href="%s" target="_blank">Menus screen</a> to create one.', 'barab' ), admin_url( 'nav-menus.php?action=edit&menu=0' ) ),
					'separator' 		=> 'after',
					'content_classes' 	=> 'elementor-panel-alert elementor-panel-alert-info',
				]
			);
		}

		
        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------

		barab_common_style_fields( $this, '01', 'Copyright Content', '{{WRAPPER}} .copyright-text', ['1', '2', '3'] );

	}

    public function barab_menu_select(){ 
	    $barab_menu = wp_get_nav_menus();
	    $menu_array  = array();
		$menu_array[''] = __( 'Select A Menu', 'barab' );
	    foreach( $barab_menu as $menu ){
	        $menu_array[ $menu->slug ] = $menu->name;
	    }
	    return $menu_array;
	}

	protected function render() {

	$settings = $this->get_settings_for_display();

        //Menu by menu select
        $barab_avaiable_menu   = $this->barab_menu_select();

        if( ! $barab_avaiable_menu ){
            return;
        }

		$args = [
			'menu' 		=> $settings['barab_menu_select'],
			'menu_class' 	=> 'menu',
			'container' 	=> '',
		];


		if( $settings['layout_style'] == '1' ){
			echo '<div class="copyright-wrap">';
				echo '<div class="container">';
					echo '<div class="copy-right-content">';
						if($settings['copyright_text']){
							echo '<div class="copyright-text-wrap">';
								echo '<p class="copyright-text">';
									echo wp_kses_post($settings['copyright_text']);
								echo '</p>';
							echo '</div>';
						}
						if(!empty($settings['logo']['url'])){
							echo '<div class="footer-bottom-logo">';
								echo '<a href="'.esc_url( home_url('/') ).'">';
									echo barab_img_tag( array(
										'url'   => esc_url( $settings['logo']['url'] ),
									));
								echo '</a>';
							echo '</div>';
						}
						if($settings['image1']['url'] ){
							echo '<div class="footer-card">';
								echo barab_img_tag( array(
									'url'   => esc_url( $settings['image1']['url'] ),
								)); 
							echo '</div>';
						}
					echo '</div>';
				echo '</div>';
			echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
            echo '<div class="copyright-wrap">';
                echo '<div class="container">';
                    echo '<div class="row gy-3 align-items-center">';
                        echo '<div class="col-lg-6">';
                            if($settings['copyright_text']){
                                echo '<p class="copyright-text">';
                                    echo wp_kses_post($settings['copyright_text']);
                                echo '</p>';
                            }
                        echo '</div>';
                        echo '<div class="col-lg-6 text-center text-lg-end">';
                            echo '<div class="footer-links">';
                                if( ! empty( $settings['barab_menu_select'] ) ){
                                    wp_nav_menu( $args );
                                } 
                            echo '</div>';
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
            echo '</div>';

		}elseif( $settings['layout_style'] == '3' ){
			// if($settings['shape']['url'] ){
			// 	echo '<div class="footer_bg_3">';
			// 		echo barab_img_tag( array(
			// 			'url'   => esc_url( $settings['shape']['url'] ),
			// 		)); 
			// 	echo '</div>';
			// }
			echo '<div class="copyright-wrap">';
				echo '<div class="container">';
					echo '<div class="row gy-4">';
						echo '<div class="col-lg-6">';
							if($settings['copyright_text']){
                                echo '<p class="copyright-text">';
                                    echo wp_kses_post($settings['copyright_text']);
                                echo '</p>';
                            }
						echo '</div>';
						echo '<div class="col-lg-6 text-center text-lg-end">';
							if($settings['image1']['url'] ){
								echo '<div class="payment">';
									echo barab_img_tag( array(
										'url'   => esc_url( $settings['image1']['url'] ),
									)); 
								echo '</div>';
							}
						echo '</div>';
					echo '</div>';
				echo '</div>';
			echo '</div>';
			if($settings['bg']['url'] ){
				echo '<div class="footer-bttom-bg-wrap">';
					echo barab_img_tag( array(
						'url'   => esc_url( $settings['bg']['url'] ),
					)); 
				echo '</div>';
			}
	
		}


        
	}

}