<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

function xcency_core_register_header_footer_custom_post() {

	// Register Footer Builder Post Type
	register_post_type('xcency_header',
		array(
			'labels'       => array(
				'name'                  => esc_html__('Xcency Headers', 'xcency-core'),
				'singular_name'         => esc_html__('Header', 'xcency-core'),
				'add_new_item'          => esc_html__('Add New Header', 'xcency-core'),
				'all_items'             => esc_html__('All Headers', 'xcency-core'),
				'add_new'               => esc_html__('Add New', 'xcency-core'),
				'edit_item'             => esc_html__('Edit Header', 'xcency-core'),
			),
			'rewrite'      => array(
				'slug'       => 'header',
				'with_front' => true,
			),
			'hierarchical' => true,
			'public' => true,
			'show_ui' => true,
			'exclude_from_search' => true,
			'publicly_queryable' => true,
			'query_var'          => true,
			'has_archive'        => true,
			'menu_icon'    => 'dashicons-editor-kitchensink',
			'show_in_rest'    => false,
			'supports'     => array('title', 'editor'),
		)
	);

	// Register Footer Builder Post Type
	register_post_type('xcency_footer',
		array(
			'labels'       => array(
				'name'                  => esc_html__('Xcency Footers', 'xcency-core'),
				'singular_name'         => esc_html__('Footer', 'xcency-core'),
				'add_new_item'          => esc_html__('Add New Footer', 'xcency-core'),
				'all_items'             => esc_html__('All Footers', 'xcency-core'),
				'add_new'               => esc_html__('Add New', 'xcency-core'),
				'edit_item'             => esc_html__('Edit Footer', 'xcency-core'),
			),
			'rewrite'      => array(
				'slug'       => 'footer',
				'with_front' => true,
			),
			'hierarchical' => true,
			'public' => true,
			'show_ui' => true,
			'exclude_from_search' => true,
			'publicly_queryable' => true,
			'query_var'          => true,
			'has_archive'        => true,
			'menu_icon'    => 'dashicons-editor-kitchensink',
			'show_in_rest'    => false,
			'supports'     => array('title', 'editor'),
		)
	);
}

add_action( 'init', 'xcency_core_register_header_footer_custom_post' );


/**
 *  Footer Canvas
 */
function xcency_core_header_footer_builder_canvas() {
	global $post;

	// Check if its a correct post type/types to apply template
	if ( !in_array( $post->post_type, ['xcency_header','xcency_footer'] ) || !did_action( 'elementor/loaded' ) ) {
		return;
	}
	// Check that a template is not set already
	if ( '' !== $post->page_template ) {
		return;
	}
	// Make sure its not a page for posts
	if ( get_option( 'page_for_posts' ) === $post->ID ) {
		return;
	}

	//Finally set the page template
	$post->page_template = 'elementor_canvas';
	update_post_meta( $post->ID, '_wp_page_template', 'elementor_canvas' );
}

add_action( 'add_meta_boxes', 'xcency_core_header_footer_builder_canvas', 10 );