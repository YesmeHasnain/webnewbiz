<?php

/**
 * Elementor Widget
 * @package Saasten
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_home_faq_one extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'theme-faq-onee';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Home Faq 1', 'saasten-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saasten_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {


        $this->start_controls_section( 'section_content_faq_inner_one', [
            'label' => esc_html__( 'Team Top Content', 'saasten-extra' ),
        ] ); 


        $this->add_control( 'title', [
            'label'       => __( 'Title', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Invest in Startup', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type section title here.", 'saasten-extra' ),

        ] );


        $this->add_control( 'description', [
            'label'       => __( 'Description', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Our Sustainable Construction Advisors provide sustainable construction expertise', 'saasten-extra' ),
            'label_block' => true,
        ] );


        $this->add_control( 'feature_image', [
            'label'   => __( 'Choose Image', 'saasten-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        $this->add_control( 'feature_image_bg', [
            'label'   => __( 'Choose Banner Image Background', 'saasten-core' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );


        $this->end_controls_section();


        $this->start_controls_section( 'section_content_faq_featurelist', [
            'label' => esc_html__( 'Team Member List', 'saasten-extra' ),
        ] ); 

        $this->add_control( 'featureItems', [
            'label'       => esc_html__( 'Team Member', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'default'     => [
                [
                    'faq-title'        => esc_html__( 'Frequently asked question', 'saasten-extra' ),
                ]
            ],

            'fields'      => [
                [
                    'name'        => 'faq-title',
                    'label'       => esc_html__( 'Title', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'description' => esc_html__( 'Enter Title', 'saasten-extra' )
                ],

                [
                    'name'        => 'faq-des',
                    'label'       => esc_html__( 'Description', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'description' => esc_html__( 'Enter Description', 'saasten-extra' )
                ],

                

            ],
            'title_field' => "{{name}}"
        ] );



        $this->end_controls_section();


        // ===================== Title ======================//

        $this->start_controls_section( 'title_style', [
            'label' => __( 'Title', 'saasten-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_typography',
            'label'    => __( 'Typography', 'saasten-extra' ),
            'selector' => '
                {{WRAPPER}} .theme-banner-startup-wrapper h1.banner-heading,
                {{WRAPPER}} .__title
            ',
        ] );


        $this->add_control( 'title_color', [
            'label'     => __( 'Color', 'saasten-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-startup-wrapper h1.banner-heading' => 'color: {{VALUE}}',
                '{{WRAPPER}} .__title' => 'color: {{VALUE}}',
            ],
        ] );

        $this->end_controls_section(); //End Title Style


        // ===================== Subtitle Style ========================//
        $this->start_controls_section( 'sub_title_style', [
            'label' => __( 'Sub Title', 'saasten-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_sub_typography',
            'label'    => __( 'Typography', 'saasten-extra' ),
            'selector' => '{{WRAPPER}} .theme-banner-startup-wrapper h4.banner-sub-heading',
        ] );

        $this->add_control( 'sub_title_color', [
            'label'     => __( 'Sub Title Color', 'saasten-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-startup-wrapper h4.banner-sub-heading' => 'color: {{VALUE}}',
            ],

        ] );

        $this->end_controls_section(); //End Subtitle Style

		
	}
	


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

        $featureItems = $settings['featureItems'];

        extract($settings); 


		
		?>



    <!-- Faq Area -->
    <section
      class="faq-area saastain-bg__cover section-padding"
      style="background-image: url(<?php echo esc_url( $settings['feature_image_bg']['url'] ); ?>);"
    >
      <div class="container">
        <div class="row">
          <div class="col-12 mg-btm-30">
            <div class="section-title-area text-center" data-aos="fade-in">
              <h2 class="section-title-v3__title m-0 saastain-gsap-anim1">
                <?php echo $settings['title']; ?>
              </h2>
              <p
                class="section-title-v3__text m-0 mg-top-15 saastain-gsap-anim2 faq-subtitle"
              >
                <?php echo $settings['description']; ?>

              </p>
            </div>
          </div>
        </div>
        <div class="row mg-top-30 align-items-center">
          <div class="col-lg-5 col-md-6 col-12" data-aos="fade-right">
            <div class="faq-img rr-mg-50">
              <img src="<?php echo esc_url( $settings['feature_image']['url'] ); ?>" alt="#" />
            </div>
          </div>
          <div class="col-lg-7 col-md-6 col-12">


            <div class="accordion faq" id="accordionExample">


            <?php
              foreach ( $featureItems as $item ):
            ?>

            <?php $id = 'toggle-item-'.wp_rand( 1, 100 ); ?>

            <div
                class="accordion-item"
                data-aos="fade-up"
                data-aos-delay="200"
              >
                <h2 class="accordion-header" id="headingTwo">
                  <button
                    class="accordion-button collapsed faq-button"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapse<?php echo esc_attr( $id ); ?>"
                    aria-expanded="true"
                    aria-controls="collapseTwo"
                  >
                     <?php echo wp_kses_post( $item['faq-title'] ); ?>
                  </button>
                </h2>
                <div
                  id="collapse<?php echo esc_attr( $id ); ?>"
                  class="accordion-collapse collapse"
                  aria-labelledby="headingTwo"
                  data-bs-parent="#accordionExample"
                >
                  <div class="accordion-body faq-text">
                    <?php echo wp_kses_post( $item['faq-des'] ); ?>
                  </div>
                </div>
              </div>


            <?php endforeach; ?>




            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Faq Area -->







	<?php 


	}
				

}

