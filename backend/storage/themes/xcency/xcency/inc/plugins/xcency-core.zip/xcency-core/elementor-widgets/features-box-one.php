<?php

namespace Elementor;
class Xcency_Features_Box_One_Widget extends Widget_Base {

    public function get_name() {

        return "xcency_features_box_one";
    }

    public function get_title() {
        return __( "Features Box One", "xcency-core" );
    }

    public function get_icon() {

        return "eicon-gallery-grid";
    }

    public function get_categories() {
        return [ 'xcency_core_elements' ];
    }


    protected function register_controls() {
        //Content tab start
        $this->start_controls_section(
            'features_box_settings',
            [
                'label' => __( 'Features Box', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'title',
            [
                'label'       => __( 'Title', 'xcency-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'rows'        => 5,
                'default'     => 'Intelligent Lead Scoring and Prioritization',
                'label_block' => true,
            ]
        );

	    $repeater->add_control(
		    'desc', [
			    'label' => esc_html__( 'Description', 'xcency-core' ),
			    'type' => Controls_Manager::WYSIWYG,
			    'default' => 'Automatically rank and the prioritize leads based on the their likelihood to convert your sales team.',
			    'label_block' => true,
		    ]
	    );

	    $repeater->add_control(
            'image',
            [
                'label'       => esc_html__( 'Image', 'xcency-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );


        $repeater->add_control(
            'details_url',
            [
                'label'         => __( 'Details Url', 'xcency-core' ),
                'type'          => Controls_Manager::URL,
                'placeholder'   => __( 'https://your-link.com', 'xcency-core' ),
                'show_external' => true,
                'default'       => [
                    'url'         => '',
                    'is_external' => false,
                    'nofollow'    => false,
                ],
            ]
        );

        $this->add_control(
            'features',
            [
                'label'       => __( 'Features List', 'xcency-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [
                    [
                        'title' => 'Intelligent Lead Scoring and Prioritization',
                        'desc' => 'Automatically rank and the prioritize leads based on the their likelihood to convert your sales team.',
                    ],
                ],
                'title_field' => '{{{ title }}}',
            ]
        );

        $this->end_controls_section();



        $this->start_controls_section(
            'features_layout_settings',
            [
                'label' => __( 'Features Column', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'desktop_col',
            [
                'label'   => __( 'Columns On Desktop', 'xcency-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'col-xl-4',
                'options' => [
                    'col-xl-12' => __( '1 Column', 'xcency-core' ),
                    'col-xl-6'  => __( '2 Column', 'xcency-core' ),
                    'col-xl-4'  => __( '3 Column', 'xcency-core' ),
                    'col-xl-3'  => __( '4 Column', 'xcency-core' ),
                ],
            ]
        );

        $this->add_control(
            'iPad_pro_col',
            [
                'label'   => __( 'Columns On iPad Pro', 'xcency-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'col-lg-4',
                'options' => [
                    'col-lg-12' => __( '1 Column', 'xcency-core' ),
                    'col-lg-6'  => __( '2 Column', 'xcency-core' ),
                    'col-lg-4'  => __( '3 Column', 'xcency-core' ),
                    'col-lg-3'  => __( '4 Column', 'xcency-core' ),
                ],
            ]
        );

        $this->add_control(
            'tab_col',
            [
                'label'   => __( 'Columns On Tablet', 'xcency-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'col-md-6',
                'options' => [
                    'col-md-12' => __( '1 Column', 'xcency-core' ),
                    'col-md-6'  => __( '2 Column', 'xcency-core' ),
                    'col-md-4'  => __( '3 Column', 'xcency-core' ),
                    'col-md-3'  => __( '4 Column', 'xcency-core' ),
                ],
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            'features_box_style_options',
            [
                'label' => esc_html__( 'Features Box', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typo',
                'label' => esc_html__( 'Title Typography', 'xcency-core' ),
                'selector' => '{{WRAPPER}} .xcency-features-one-title',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'desc_typo',
                'label' => esc_html__( 'Description Typography', 'xcency-core' ),
                'selector' => '{{WRAPPER}} .xcency-features-one-desc',
            ]
        );

        $this->add_responsive_control(
            'box_padding',
            [
                'label'      => esc_html__( 'Box Padding', 'xcency-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .features-one-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }


    //Render In HTML
    protected function render() {
        $settings = $this->get_settings_for_display();
	    $column = $settings['desktop_col'] . ' ' . $settings['iPad_pro_col'] . ' ' . $settings['tab_col'];
        ?>

        <div class="xcency-features-box-wrapper">
            <div class="row">
                <?php if ( $settings['features'] ) {
                    foreach ( $settings['features'] as $feature ) {
                        $url      = $feature['details_url']['url'];
                        $target   = $feature['details_url']['is_external'] ? ' target="_blank"' : '';
                        $nofollow = $feature['details_url']['nofollow'] ? ' rel="nofollow"' : '';

                        $image_src = $feature['image']['url'];
                        $image_alt = get_post_meta( $feature['image']['id'], '_wp_attachment_image_alt', true );
                        ?>
                        <div class="<?php echo $column;?>">
                            <?php if($feature['details_url']['url']) :?>
                            <a href="<?php echo $feature['details_url']['url']?>">
                            <?php endif; ?>
                            <div class="features-one-item">
                                <div class="features-one-content">
                                    <h4 class="xcency-features-one-title"><?php echo $feature['title'];?></h4>

                                    <div class="xcency-features-one-desc xcency-last-p-0">
                                        <?php echo $feature['desc'];?>
                                    </div>

                                    <div class="xcency-features-one-img">
                                        <img src="<?php echo $image_src;?>" alt="<?php echo $image_alt;?>">
                                    </div>
                                </div>
                            </div>
	                        <?php if($feature['details_url']['url']) :?>
                            </a>
	                        <?php endif; ?>
                        </div>
                    <?php }
                } ?>
            </div>
        </div>
        <?php

    }
}

Plugin::instance()->widgets_manager->register( new Xcency_Features_Box_One_Widget );