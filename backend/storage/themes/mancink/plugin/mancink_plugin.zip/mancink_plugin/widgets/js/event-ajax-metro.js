(function($) {
	"use strict";

	var ajaxurl = $(
		".elementor-widget-mancink-event-custom .rdn-port-val"
	).data("url");
	var page = 2;
	var event_item = $(
		".elementor-widget-mancink-event-custom .rdn-port-val"
	).data("item");
	var port_column = $(
		".elementor-widget-mancink-event-custom .rdn-port-val"
	).data("col");
	var order_value = $(
		".elementor-widget-mancink-event-custom .rdn-port-val"
	).data("order");
	var security = $(
		".elementor-widget-mancink-event-custom .rdn-port-val"
	).data("nonce");
	var nomore = $(
		".elementor-widget-mancink-event-custom .rdn-port-val"
	).data("nomore");

	$(".elementor-widget-mancink-event-custom .loadmore").on(
		"click",
		function() {
			$(".elementor-widget-mancink-event-custom .loadmore").hide();
			$(".elementor-widget-mancink-event-custom .port-load").show();
			$(".elementor-widget-mancink-event-custom .new-rcol").removeClass(
				"new-rcol"
			);
			var data = {
				action: "load_metro_by_ajax",
				page: page,
				event_item: event_item,
				port_column: port_column,
				order_value: order_value,
				security: security,
				nomore: nomore
			};

			var $grid = $(
				".elementor-widget-mancink-event-custom .c-iso"
			).isotope();

			$.post(ajaxurl, data, function(response) {
				$(".elementor-widget-mancink-event-custom .c-iso").append(response);
				$grid
					.append($(".new-rcol"))
					// add and lay out newly appended elements
					.isotope("appended", $(".new-rcol"), {
						itemSelector: ".port-item",
						layoutMode: "masonry",
						masonry: {
							columnWidth: ".port-item.col-md-3"
						}
					});
				$(".elementor-widget-mancink-event-custom .new-rcol").removeClass(
					"new-rcol"
				);
				page++;
				$(".elementor-widget-mancink-event-custom .port-load").fadeOut(
					"fast"
				);
				setTimeout(function() {
					$(".elementor-widget-mancink-event-custom .loadmore").fadeIn();
				}, 400);
				if (
					$(".elementor-widget-mancink-event-custom .c-iso").find(
						".no-more"
					).length > 0
				) {
					$(".elementor-widget-mancink-event-custom .load-more").remove();
					$(".elementor-widget-mancink-event-custom .box-load").slideUp(
						"fast"
					);
					setTimeout(function() {
						$(".elementor-widget-mancink-event-custom .npsp").fadeOut();
						$(".elementor-widget-mancink-event-custom .npsp").remove();
						$(".event-custom-type").isotope("layout");
					}, 2000);
				}
			});
		}
	);
})(jQuery);
