<?php

namespace MancinkPlugin;

use MancinkPlugin\Widgets\Mancink_Contact;
use MancinkPlugin\Widgets\Mancink_Gallery;
use MancinkPlugin\Widgets\Mancink_Logo;
use MancinkPlugin\Widgets\Mancink_Button;
use MancinkPlugin\Widgets\Mancink_MasonGallery;
use MancinkPlugin\Widgets\Mancink_Menu;
use MancinkPlugin\Widgets\Mancink_Post;
use MancinkPlugin\Widgets\Mancink_PostFour;
use MancinkPlugin\Widgets\Mancink_PostSlider;
use MancinkPlugin\Widgets\Mancink_PostThree;
use MancinkPlugin\Widgets\Mancink_PostTwo;
use MancinkPlugin\Widgets\Mancink_Share;
use MancinkPlugin\Widgets\Mancink_Sidebar;
use MancinkPlugin\Widgets\Mancink_Team;
use MancinkPlugin\Widgets\Mancink_TeamHover;
use MancinkPlugin\Widgets\Mancink_Testimonial;
use MancinkPlugin\Widgets\Mancink_TextIcon;
use MancinkPlugin\Widgets\Mancink_TextIconHover;
use MancinkPlugin\Widgets\Mancink_TextLine;
use MancinkPlugin\Widgets\Mancink_Title;
use MancinkPlugin\Widgets\Rdn_Slider;
use MancinkPlugin\Widgets\Mancink_Button_Text;
use MancinkPlugin\Widgets\Mancink_Testimonial_Two;
use MancinkPlugin\Widgets\Mancink_EventMetro;
use MancinkPlugin\Widgets\Mancink_Video;
use MancinkPlugin\Widgets\Mancink_EventAjax;
use MancinkPlugin\Widgets\Mancink_EventCategory;
use MancinkPlugin\Widgets\Mancink_EventTitle;
use MancinkPlugin\Widgets\Mancink_OtherEvent;
use MancinkPlugin\Widgets\Mancink_Tab;

if (!defined('ABSPATH')) {
    exit;
}
// Exit if accessed directly

/**
 * Main Plugin Class
 *
 * Register new elementor widget.
 *
 * @since 1.0.0
 */
class MancinkPlugin
{

    /**
     * Constructor
     *
     * @since 1.0.0
     *
     * @access public
     */
    public function __construct()
    {
        $this->add_actions();
    }

    /**
     * Add Actions
     *
     * @since 1.0.0
     *
     * @access private
     */
    private function add_actions()
    {
        //register all script
        add_action('elementor/widgets/widgets_registered', [$this, 'on_widgets_registered']);
        //isotope script
        add_action('elementor/frontend/after_register_scripts', function () {
            wp_register_script('jquery-isotope', MANCINK_URL . 'widgets/js/isotope.pkgd.js', array('jquery'), null, true);
        });

        //blog masonry script
        add_action('elementor/frontend/after_register_scripts', function () {
            wp_register_script('mancink-blog-masonry', MANCINK_URL . 'widgets/js/blog-mason.js', array('jquery'), null, true);
        });
        //slider script
        add_action('elementor/frontend/after_register_scripts', function () {
            wp_register_script('jquery-slick-slider', MANCINK_URL . 'widgets/js/slick.min.js', array('jquery'), null, true);
        });
        add_action('elementor/frontend/after_register_scripts', function () {
            wp_register_script('mancink-animation', MANCINK_URL . 'widgets/js/slick-animation.js', array('jquery'), null, true);
        });
        add_action('elementor/frontend/after_register_scripts', function () {
            wp_register_script('mancink-slider-script', MANCINK_URL . 'widgets/js/slider.js', array('jquery'), null, true);
        });
        add_action('elementor/frontend/after_register_scripts', function () {
            wp_register_script('mancink-blog-slider-script', MANCINK_URL . 'widgets/js/blog-slider.js', array('jquery'), null, true);
        });

         //video script
        add_action('elementor/frontend/after_register_scripts', function () {
            wp_register_script('mancink-video-popup-script', MANCINK_URL . 'widgets/js/video-popup.js', array('jquery'), null, true);
        });

        //event script
        add_action('elementor/frontend/after_register_scripts', function () {
            wp_register_script('mancink-event-ajax-custom', MANCINK_URL . 'widgets/js/event-ajax-metro.js', array('jquery'), null, true);
        });

        add_action('elementor/frontend/after_register_scripts', function () {
            wp_register_script('mancink-event-ajax', MANCINK_URL . 'widgets/js/event-ajax.js', array('jquery'), null, true);
        });

        add_action('elementor/frontend/after_register_scripts', function () {
            wp_register_script('mancink-event', MANCINK_URL . 'widgets/js/event.js', array('jquery'), null, true);
        });

        add_action('elementor/frontend/after_register_scripts', function () {
            wp_register_script('mancink-event-custom', MANCINK_URL . 'widgets/js/event-custom.js', array('jquery'), null, true);
        });
        //gallery popup
        add_action('elementor/frontend/after_register_scripts', function () {
            wp_register_script('jquery-magnificpopup', MANCINK_URL . 'widgets/js/jquery.magnific-popup.min.js', array('jquery'), null, true);
        });
        add_action('elementor/frontend/after_register_scripts', function () {
            wp_register_script('mancink-gallery-popup', MANCINK_URL . 'widgets/js/popup-gallery.js', array('jquery'), null, true);
        });
        add_action('elementor/frontend/after_register_scripts', function () {
            wp_register_script('mancink-blog-script', MANCINK_URL . 'widgets/js/blog.js', array('jquery'), null, true);
        });

        //gallery  masonry
        add_action('elementor/frontend/after_register_scripts', function () {
            wp_register_script('mancink-masonry-gallery', MANCINK_URL . 'widgets/js/mason-gallery.js', array('jquery'), null, true);
        });

        //share script
        add_action('elementor/frontend/after_register_scripts', function () {
            wp_register_script('mancink-share', MANCINK_URL . 'widgets/js/share.js', array('jquery'), null, true);
        });

        //tab script
        add_action('elementor/frontend/after_register_scripts', function () {
            wp_enqueue_script('mancink-tab',  MANCINK_URL . 'widgets/js/tab.js', array('jquery'), null, true);
        });
    }

    /**
     * On Widgets Registered
     *
     * @since 1.0.0
     *
     * @access public
     */
    public function on_widgets_registered()
    {
        $this->includes();
        $this->register_widget();
    }

    /**
     * Includes
     *
     * @since 1.0.0
     *
     * @access private
     */
    private function includes()
    {
        require __DIR__ . '/widgets/rdn-slider.php';
        require __DIR__ . '/widgets/title.php';
        require __DIR__ . '/widgets/testimonial.php';
        require __DIR__ . '/widgets/testimonial-two.php';
        require __DIR__ . '/widgets/team.php';
        require __DIR__ . '/widgets/team-hover.php';
        require __DIR__ . '/widgets/text-line.php';
        require __DIR__ . '/widgets/text-icon.php';
        require __DIR__ . '/widgets/text-icon-hover.php';
        require __DIR__ . '/widgets/post.php';
        require __DIR__ . '/widgets/post-two.php';
        require __DIR__ . '/widgets/post-three.php';
        require __DIR__ . '/widgets/post-four.php';
        require __DIR__ . '/widgets/post-slider.php';
        require __DIR__ . '/widgets/menu.php';
        require __DIR__ . '/widgets/contact.php';
        require __DIR__ . '/widgets/gallery.php';
        require __DIR__ . '/widgets/mason-gallery.php';
        require __DIR__ . '/widgets/logo.php';
        require __DIR__ . '/widgets/sidebar.php';
        require __DIR__ . '/widgets/share.php';
        require __DIR__ . '/widgets/button.php';
        require __DIR__ . '/widgets/button-text.php';
        require __DIR__ . '/widgets/event-metro.php';
        require __DIR__ . '/widgets/video.php';
        require __DIR__ . '/widgets/event-ajax.php';
        require __DIR__ . '/widgets/event-category.php';
        require __DIR__ . '/widgets/event-title.php';
        require __DIR__ . '/widgets/other-event.php';
        require __DIR__ . '/widgets/tab.php';
    }

    /**
     * Register Widget
     *
     * @since 1.0.0
     *
     * @access private
     */
    private function register_widget()
    {
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Rdn_Slider());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_Title());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_Team());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_TeamHover());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_Testimonial());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_Testimonial_Two());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_EventMetro());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_EventAjax());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_TextIcon());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_TextLine());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_TextIconHover());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_Post());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_PostTwo());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_PostThree());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_PostFour());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_PostSlider());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_Menu());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_Contact());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_Gallery());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_MasonGallery());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_Logo());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_Sidebar());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_Share());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_Button());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_Button_Text());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_Video());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_EventTitle());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_EventCategory());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_OtherEvent());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Mancink_Tab());
    }
}

new MancinkPlugin();
