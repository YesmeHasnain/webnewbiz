<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Project Widget .
 *
 */ 
class Barab_project extends Widget_Base {

	public function get_name() {
		return 'barabproject'; 
	}
	public function get_title() {
		return __( 'Projects', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		 $this->start_controls_section(
			'project_section',
			[
				'label'     => __( 'Projects', 'barab' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One' ] );

		$repeater = new Repeater();

		barab_media_fields($repeater, 'choose_image', 'Choose Image');
		barab_general_fields($repeater, 'title', 'Title', 'TEXTAREA2', 'Huangyan Ming Villa Sales Center & Model Room');
		barab_general_fields($repeater, 'desc', 'Description', 'TEXTAREA', 'Scandinavian Hall, Indianapolis');
		barab_url_fields($repeater, 'button_url', 'Button URL');
		barab_general_fields($repeater, 'icon', 'Icon', 'TEXTAREA2', '');

		$this->add_control(
			'project_list',
			[
				'label' 		=> __( 'project Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'Huangyan Ming Villa Sales Center & Model Room', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['1', '2', '3', '4']
				]
			]
		);
		
        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------

		barab_common2_style_fields( $this, '02', 'Title', '{{WRAPPER}} .box-title a', ['1', '2', '3', '4'] );
		barab_common_style_fields( $this, '03', 'Descripion', '{{WRAPPER}} .box-text', ['1', '4'] );

	}
 
	protected function render() {

        $settings = $this->get_settings_for_display();

		if( $settings['layout_style'] == '1' ){
			echo '<div class="swiper th-slider projectSlide slider-drag-wrap has-shadow" id="projectSlide" data-slider-options=\'{"loop":true,"mousewheel": {"enabled": true,"sensitivity": 4},"breakpoints":{"0":{"slidesPerView":1},"576":{"slidesPerView":"1"},"768":{"slidesPerView":"2"},"992":{"slidesPerView":"2"},"1200":{"slidesPerView":"3"},"1300":{"slidesPerView":"4"}}}\'>';
				echo '<div class="swiper-wrapper">';
					foreach( $settings['project_list'] as $key => $data ){
						echo '<div class="swiper-slide">';
							echo '<div class="project-card">';
								echo '<div class="box-img global-img">';
									echo barab_img_tag( array(
										'url'   => esc_url( $data['choose_image']['url'] ),
									));
									if(!empty($data['icon'])){
										echo '<div class="icon">'.wp_kses_post($data['icon']).'</div>';
									}
								echo '</div>';
								echo '<div class="box-content">';
									if(!empty($data['title'])){
										echo '<h3 class="box-title"><a href="'.esc_url( $data['button_url']['url'] ).'">'.esc_html($data['title']).'</a></h3>';
									}
									if(!empty($data['desc'])){
										echo '<p class="box-text">'.esc_html($data['desc']).'</p>';
									}
								echo '</div>';
							echo '</div>';
						echo '</div>';
					}
				echo '</div>';
			echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){


		}


	}

}