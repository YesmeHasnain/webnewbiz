<?php

/**
 * Elementor Widget
 * @package Knor
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_pricing_table_tab extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'theme-pricing-widthtabs';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Pricing Table with Tabs', 'knor-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'knor_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {



        $this->start_controls_section(
            'pricing_tab_menus', [
                'label' => esc_html__( 'Pricing Tabs Menu', 'knor-extra' ),
            ]
        );


        $this->add_control(
            'tab1_title', [
                'label' => esc_html__( 'Tab 01', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Monthly',
            ]
        );

        $this->add_control(
            'tab2_title', [
                'label' => esc_html__( 'Tab 02', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Yearly',
            ]
        );

        $this->add_control(
            'currency_name', [
                'label' => esc_html__( 'Give Currecny', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '$',
            ]
        );

        $this->add_control(
            'pricing_menu_circle',
            [
                'label' => esc_html__( 'Activate Pricing menu circle Style', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'knor-extra' ),
                'label_off' => esc_html__( 'Hide', 'knor-extra' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );


        $this->end_controls_section();


        $this->start_controls_section(
            'pricing_table_tabs_wrap', [
                'label' => esc_html__( 'Pricing Table Tabs', 'knor-extra' ),
            ]
        );


        $pricingcontent = new \Elementor\Repeater();


        // Pricing Tabs
        $pricingcontent->start_controls_tabs(
            'style_pricing_tabs'
        );

        $pricingcontent->start_controls_tab(
            'style_pricing_tab1', [
                'label' => esc_html__( 'Tab 01', 'knor-extra' ),
            ]
        );

        $pricingcontent->add_control(
            'monthly_price', [
                'label' => esc_html__( 'Price', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '$8',
            ]
        );

        $pricingcontent->add_control(
            'monthly_duration', [
                'label' => esc_html__( 'Duration', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'month',
            ]
        );

        $pricingcontent->end_controls_tab(); //End Tab 01

        $pricingcontent->start_controls_tab(
            'style_pricing_tab2', [
                'label' => esc_html__( 'Tab 02', 'knor-extra' ),
            ]
        );

        $pricingcontent->add_control(
            'yearly_price', [
                'label' => esc_html__( 'Price', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '$8',
            ]
        );

        $pricingcontent->add_control(
            'yearly_duration', [
                'label' => esc_html__( 'Duration', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Mo',
            ]
        );

        $pricingcontent->end_controls_tab(); //End Tab 02

        $pricingcontent->end_controls_tabs(); //End Pricing Tabs


        $pricingcontent->add_control(
            'icon', [
                'label' => esc_html__( 'Icon', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::ICONS,
            ]
        );

        $pricingcontent->add_control(
            'package_name', [
                'label' => esc_html__( 'Package Name', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Basic Plan',
            ]
        );

        $pricingcontent->add_control(
            'contents', [
                'label' => esc_html__( 'Contents', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
            ]
        );

        $pricingcontent->add_control(
            'list_items', [
                'label' => esc_html__( 'Pricing List Items', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
            ]
        );

        $pricingcontent->add_control(
            'btn_label', [
                'label' => esc_html__( 'Button Label', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Purchase Now',
            ]
        );

        $pricingcontent->add_control(
            'btn_url', [
                'label' => esc_html__( 'Button URL', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::URL,
                'default' => [
                    'url' => '#'
                ],
            ]
        );

        $pricingcontent->add_control(
            'pricing_highlight',
            [
                'label' => esc_html__( 'Make Highlight', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'knor-extra' ),
                'label_off' => esc_html__( 'Hide', 'knor-extra' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );




        $this->add_control(
            'pricingtablesinnercontent', [
                'label' => esc_html__( 'Add Table', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $pricingcontent->get_controls(),
                'title_field' => '{{{ package_name }}}',
            ]
        );

        $this->end_controls_section();


        //Title Styling

        $this->start_controls_section( 'pricing_title_style', [
            'label' => esc_html__( 'Title', 'knor-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_control( 'title_color_one', [
            'label'     => esc_html__( 'Color', 'knor-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .pricing-section-one-wrap .pricing-package-name' => 'color: {{VALUE}};'
            ],
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
            'name'     => 'title_typography',
            'selector' => '{{WRAPPER}} .pricing-section-one-wrap .pricing-package-name',
        ] );

        $this->add_responsive_control(
            'pbox-title_margin',
            [
                'label' => esc_html__( 'Margin', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .pricing-section-one-wrap .pricing-package-name' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->end_controls_section();


        // Description Style Section
        $this->start_controls_section( 'section_subtitle_style', [
            'label' => esc_html__( 'Description', 'knor-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_control( 'subtitle_color', [
            'label'     => esc_html__( 'Sub Title color', 'knor-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .pricing-section-one-wrap .pricing-sub-content' => 'color: {{VALUE}};',
            ],
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
            'name'     => 'subtitle_typography',
            'selector' => '{{WRAPPER}} .pricing-section-one-wrap .pricing-sub-content',
        ] );

        $this->add_responsive_control(
            'pbox-subtitle_margin',
            [
                'label' => esc_html__( 'Margin', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .pricing-section-one-wrap .pricing-sub-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->end_controls_section();

        // Price Style Section
        $this->start_controls_section( 'section_price_style', [
            'label' => esc_html__( 'Price', 'knor-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );


        $this->add_control( 'price_color', [
            'label'     => esc_html__( 'Color', 'knor-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .pricing-section-one-wrap .pricing-price-title' => 'color: {{VALUE}};',
            ],
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
            'name'     => 'price_typography',
            'selector' => '{{WRAPPER}} .pricing-section-one-wrap .pricing-price-title',
        ] );


        $this->add_responsive_control(
            'pricing_price_margin',
            [
                'label' => esc_html__( 'Margin', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .pricing-section-one-wrap .pricing-price-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->add_control( 'period_color', [
            'label'     => esc_html__( 'Period color', 'knor-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .pricing-section-one-wrap .pricing-price-title span' => 'color: {{VALUE}};',
            ],
            'separator' => 'before'
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
            'label'     => esc_html__( 'Period Typography', 'knor-extra' ),
            'name'     => 'period_typography',
            'selector' => '{{WRAPPER}} .pricing-section-one-wrap .pricing-price-title span',
        ] );


        $this->end_controls_section();



        // Button Style Section
        //======================

        $this->start_controls_section(
            'section_button_style',
            [
                'label' => __('Button', 'knor-extra'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'typography',
                'label' => __('Typography', 'knor-extra'),
                'selector' => '{{WRAPPER}} .pricing-section-one-wrap .theme-pricing-btn',
            ]
        );

        $this->add_control(
            'border_radius',
            [
                'label' => __('Border Radius', 'knor-extra'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} a.tt-btn, {{WRAPPER}} .pricing-section-one-wrap .theme-pricing-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'btn_padding',
            [
                'label' => __('Padding', 'knor-extra'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} a.tt-btn, {{WRAPPER}} .pricing-section-one-wrap .theme-pricing-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        
        $this->add_responsive_control(
            'pricing_btnn_margin',
            [
                'label' => esc_html__( 'Margin', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .pricing-section-one-wrap .pricing-btn-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->start_controls_tabs('tabs_button_style');

        $this->start_controls_tab(
            'tab_button_normal',
            [
                'label' => __('Normal', 'knor-extra'),
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label' => __('Color', 'knor-extra'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .pricing-section-one-wrap .theme-pricing-btn, {{WRAPPER}} .pricing-section-two-wrap .theme-pricing-btn' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'background_color',
            [
                'label' => __('Background Color', 'knor-extra'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-section-one-wrap .theme-pricing-btn' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'border',
                'label' => __('Border', 'knor-extra'),
                'selector' => '{{WRAPPER}} .pricing-section-one-wrap .theme-pricing-btn',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'box_shadow',
                'label' => __( 'Box Shadow', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .pricing-section-one-wrap .theme-pricing-btn',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_button_hover',
            [
                'label' => __('Hover', 'knor-extra'),
            ]
        );

        $this->add_control(
            'hover_color',
            [
                'label' => __('Color', 'knor-extra'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-section-one-wrap .theme-pricing-btn:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'background_color_hover',
            [
                'label' => __('Background Color', 'knor-extra'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-section-one-wrap .theme-pricing-btn:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'border_hover',
                'label' => __('Border', 'knor-extra'),
                'selector' => '{{WRAPPER}} .pricing-section-one-wrap .theme-pricing-btn:hover'
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'box_shadow_hover',
                'label' => __( 'Box Shadow', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .pricing-section-one-wrap .theme-pricing-btn:hover',
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        $this->start_controls_section( 'section_feature_style_tab', [
            'label' => esc_html__( 'Pricing Features List', 'knor-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_control( 'text_color', [
            'label'     => esc_html__( 'Text Color', 'knor-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .pricing-section-one-wrap .pricing-features-list-wrap li' => 'color: {{VALUE}};',
            ],
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
            'label'     => esc_html__( 'Text Typography', 'knor-extra' ),
            'name'     => 'text_typography',
            'selector' => '{{WRAPPER}} .pricing-section-one-wrap .pricing-features-list-wrap li',
        ] );

        $this->add_control(
            'spacing',
            [
                'label' => __( 'Space Between', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => -15,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .pricing-section-one-wrap .pricing-features-list-wrap li:not(:last-child)' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'feature_list_border_top',
            [
                'label' => esc_html__( 'Use Border Top', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'knor-extra' ),
                'label_off' => esc_html__( 'Hide', 'knor-extra' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );


        $this->add_control( 'flist_icon_color', [
            'label'     => esc_html__( 'Features List Icon Color', 'knor-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} ul.pricing-features-list-wrap li:before' => 'color: {{VALUE}};',
                '{{WRAPPER}} .pricing-section-one-wrap ul.pricing-features-list-wrap li:before' => 'border-color: {{VALUE}}',
            ],
        ] );



        $this->end_controls_section();

        $this->start_controls_section( 'section_pricing_box', [
            'label' => esc_html__( 'Pricing Box Wrapper', 'knor-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );


        $this->add_control( 'box_background_first', [
            'label'     => esc_html__( 'Pricing Box 1 Background', 'knor-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-pricing-section-wrapper.pricing-section-one-wrap .row .col-md-6:nth-of-type(1) .pricing-single-item-box' => 'background-color: {{VALUE}};'
            ],
        ] );

        $this->add_control( 'box_background_second', [
            'label'     => esc_html__( 'Pricing Box 2 Background', 'knor-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-pricing-section-wrapper.pricing-section-one-wrap .row .col-md-6:nth-of-type(2) .pricing-single-item-box' => 'background-color: {{VALUE}};'
            ],
        ] );


        $this->add_control( 'box_background_third', [
            'label'     => esc_html__( 'Pricing Box 3 Background', 'knor-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-pricing-section-wrapper.pricing-section-one-wrap .row .col-md-6:nth-of-type(3) .pricing-single-item-box' => 'background-color: {{VALUE}};'
            ],
        ] );

         $this->add_control( 'box_background_normall', [
            'label'     => esc_html__( 'Pricing Box Normal Background', 'knor-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-pricing-section-wrapper.pricing-section-one-wrap .pricing-single-item-box' => 'background: {{VALUE}};'
            ],
        ] );

        $this->add_control( 'box_background_hoverr', [
            'label'     => esc_html__( 'Pricing Box Hover Background', 'knor-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-pricing-section-wrapper.pricing-section-one-wrap .pricing-single-item-box:hover' => 'background: {{VALUE}};'
            ],
        ] );


        // $this->add_group_control(
        //     \Elementor\Group_Control_Background::get_type(),
        //     [
        //         'name' => 'box_background_hoverr',
        //         'label' => __( 'Hover Background', 'knor-extra' ),
        //         'types' => [ 'classic', 'gradient' ],
        //         'selector' => '{{WRAPPER}} .pricing-section-one-wrap .pricing-single-item-box:hover',
        //     ]
        // );


         $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'box_border_boxx',
                'label' => __( 'box Border', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .pricing-section-one-wrap .pricing-single-item-box',
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'box_border_hoverr',
                'label' => __( 'Hover Border', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .pricing-section-one-wrap .pricing-single-item-box:hover',
            ]
        );


        $this->add_responsive_control(
            'pricing_box_padding',
            [
                'label' => esc_html__( 'Padding', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .pricing-section-one-wrap .pricing-single-item-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'box_box_shadow',
                'label' => __( 'Box Shadow', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .pricing-section-one-wrap .pricing-single-item-box',
            ]
        );


        $this->add_control(
            'box_border_radius',
            [
                'label' => __( 'Border Radius', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .pricing-section-one-wrap .pricing-single-item-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

		
	}
	


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

        $feature_list_border_top = $settings['feature_list_border_top'];
        $pricing_menu_circle = $settings['pricing_menu_circle'];

        $repeatpricing = $settings['pricingtablesinnercontent'];

        extract($settings);

		
		?>


		<div class="theme-pricing-section-wrapper pricing-section-one-wrap pricing_table_filter__Wrapper">

            <div class="row">
                <div class="col-lg-12 pricing_table_filter__Column">

                    <?php if($pricing_menu_circle =='yes'): ?>

                    <div class="pricing-menu-wrap pricing-menu-style-two pricing_table_filter__Styleone">
                        <ul class="pricing-menu-list list-style2 align-items-center">
                            <li><a href="javascript:void(0)" class="pricing_mon_swicther active"><span class="position-pnav"><?php echo esc_html( $settings['tab1_title'] ) ?></span></a></li>
                            <li><a href="javascript:void(0)" class="pricing_yo_swicther"><span class="position-pnavright"><?php echo esc_html( $settings['tab2_title'] ) ?></span></a></li>
                        </ul>
                    </div>

                    <?php else: ?> 

                    <div class="pricing-menu-wrap pricing_table_filter__Stylealt">
                        <ul class="pricing-menu-list align-items-center">
                            <li><a href="javascript:void(0)" class="pricing_mon_swicther active"><?php echo esc_html( $settings['tab1_title'] ) ?></a></li>
                            <li><a href="javascript:void(0)" class="pricing_yo_swicther"><?php echo esc_html( $settings['tab2_title'] ) ?></a></li>
                        </ul>
                    </div>

                    <?php endif; ?> 


                </div>
            </div>

            <div class="row">

                <?php
                if ( is_array($pricingtablesinnercontent)) {
                    foreach ( $pricingtablesinnercontent as $item ) {
                ?>


                <div class="col-xl-4 col-lg-6">

                    <div class="pricing_table_single__Item pricing-single-item-box <?php if($item['pricing_highlight'] == 'yes' ) { echo "pricing-item-highlight"; } else { echo "pricing-item-normal"; } ?> elementor-repeater-item-<?php echo esc_attr( $item['_id']); ?>">

                        <?php

                        if ( !empty( $item['package_name'] ) ) { ?>

                            
                            <h3 class="pricing-package-name">
                                <span class="icon-package">
                                    <?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                </span>
                            <?php echo esc_html($item['package_name']) ?></h3>
                            <?php
                        }

                        if ( !empty( $item['contents'] ) ) { ?>
                            <p class="pricing-sub-content pricing_table_single__Content"><?php echo esc_html($item['contents']) ?></p>
                            <?php
                        }

                        //Monthly Pricing Tab
                        if ( !empty( $item['monthly_price'] ) ) { ?>
                            <h2 class="pricing-price-title pricing-month">
                                <?php echo esc_html($settings['currency_name']) ?><?php echo esc_html($item['monthly_price']) ?><span>/<?php echo esc_html($item['monthly_duration']) ?></span>
                            </h2>
                            <?php
                        }

                        //Yearly Pricing Tab
                        if ( !empty( $item['yearly_price'] ) ) { ?>
                            <h2 class="pricing-price-title pricing-year">
                                <?php echo esc_html($settings['currency_name']) ?><?php echo esc_html($item['yearly_price']) ?><span>/<?php echo esc_html($item['yearly_duration']) ?></span>
                            </h2>
                            <?php
                        }


                        ?>


                        
                        <?php if($feature_list_border_top =='yes'): ?>

                        <div class="pricing-divider"></div>

                        <?php endif; ?> 



                        <?php 

                        $item_contents = preg_split( '/\r\n|[\r\n]/', $item['list_items'] );

                        if( !empty( $item_contents ) ){
                            echo '<ul class="pricing-features-list-wrap">';
                            foreach( $item_contents as $content ){
                                echo '<li>'. esc_html( $content ) .'</li>';
                            }
                            echo '</ul>';
                        }

                        if ( !empty( $item['btn_label'] ) ) { ?>

                            <div class="pricing-btn-wrap pricing_table_single__Button">
                                <a class="theme-pricing-btn" href="<?php echo esc_url( $item['btn_url']['url'] ); ?>"><?php echo esc_html( $item['btn_label']); ?></a>
                            </div>

                            <?php
                        }
                        ?>


                    </div>




                </div>

                    <?php
                
                    }
                
                    }
                ?>


            </div>

        </div>
	

	<?php 


	}
				

}

