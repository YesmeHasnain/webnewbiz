<?php
namespace Elementor;

class Xcency_Home_Banner_Three_Widget extends Widget_Base {

	public function get_name() {
		return 'xcency_home_banner_three';
	}

	public function get_title() {
		return esc_html__( 'Home Banner Three', 'xcency-core' );
	}

	public function get_icon() {
		return 'flaticon-flag-1';
	}

	public function get_categories() {
		return [ 'xcency_core_elements' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'banner_three_options',
			[
				'label' => esc_html__( 'Banner Options', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
            'subtitle',
            [
                'label'       => esc_html__( 'Subtitle', 'xcency-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => esc_html__( 'AI CRM Platform', 'xcency-core' ),
            ]
        );

        $this->add_control(
            'banner_title',
            [
                'label'       => __( 'Title', 'xcency-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'rows'        => 5,
                'default'     => 'Revolutionize Your Customer Experience with AI-Driven CRM Solutions',
            ]
        );

        $this->add_control(
            'desc',
            [
                'label'       => __( 'Description', 'xcency-core' ),
                'type'        => Controls_Manager::WYSIWYG,
                'default'     => 'Artificial Intelligence (AI) Customer Relationship Management (CRM) systems are transforming the way businesses interact with their customers',
                'label_block' => true,
            ]
        );

		$this->add_control(
			'wpcf7_form_list',
			[
				'label' => __( 'Select Contact Form', 'xcency-core' ),
				'label_block' => true,
				'type' => Controls_Manager::SELECT,
				'options' => $this->xcency_banner_contact_form7(),
			]
		);

        $this->add_control(
            'banner_bg_img',
            [
                'label'       => esc_html__( 'Background Image', 'xcency-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'subtitle_style_options',
			[
				'label' => esc_html__( 'Subtitle', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'subtitle_typo_options',
				'label' => esc_html__( 'Typography', 'xcency-core' ),
				'selector' => '{{WRAPPER}} .banner-three-subtitle',
			]
		);

		$this->add_control(
			'subtitle_color',
			[
				'label'       => esc_html__('Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .banner-three-subtitle' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'subtitle_bg_color',
			[
				'label'       => esc_html__('Background Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .banner-three-subtitle' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'subtitle_margin',
			[
				'label'      => esc_html__( 'Subtitle Margin', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .banner-three-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


        $this->start_controls_section(
            'title_style_options',
            [
                'label' => esc_html__( 'Title', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typo_options',
                'label' => esc_html__( 'Typography', 'xcency-core' ),
                'selector' => '{{WRAPPER}} .banner-three-title',
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'       => esc_html__('Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .banner-three-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_margin',
            [
                'label'      => esc_html__( 'Margin', 'xcency-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .banner-three-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'desc_style_options',
			[
				'label' => esc_html__( 'Description', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'desc_typo_options',
				'label' => esc_html__( 'Typography', 'xcency-core' ),
				'selector' => '{{WRAPPER}} .home-banner-three-desc',
			]
		);

		$this->add_control(
			'desc_color',
			[
				'label'       => esc_html__('Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .home-banner-three-desc' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'desc_margin',
			[
				'label'      => esc_html__( 'Margin', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .home-banner-three-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'desc_padding',
			[
				'label'      => esc_html__( 'Padding', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .home-banner-three-desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'wrapper_style',
            [
                'label' => esc_html__( 'Wrapper', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'wrapper_background_color',
            [
                'label'       => esc_html__('Background Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .home-banner-three-wrapper' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'wrapper_padding',
            [
                'label'      => esc_html__( 'Wrapper Padding', 'xcency-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .home-banner-three-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'xcency_form_field_style',
			[
				'label' => __( 'Form Style', 'xcency-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'field_bg_color',
			[
				'label'       => esc_html__('Background Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-form-control-wrapper input' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .xcency-form-control-wrapper textarea' => 'background-color: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'field_box_shadow',
                'label' => esc_html__( 'Box Shadow', 'xcency-core' ),
                'selector' => '{{WRAPPER}} .xcency-banner-three-form .xcency-form-control-wrapper input',
            ]
        );

		$this->add_control(
			'field_text_color',
			[
				'label'       => esc_html__('Text Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-banner-three-form .xcency-form-control-wrapper ::placeholder' => 'color: {{VALUE}};',
					'{{WRAPPER}} .xcency-banner-three-form .xcency-form-control-wrapper :-ms-input-placeholder' => 'color: {{VALUE}};',
					'{{WRAPPER}} .xcency-banner-three-form .xcency-form-control-wrapper ::-ms-input-placeholder' => 'color: {{VALUE}};',
					'{{WRAPPER}} .xcency-banner-three-form .xcency-form-control-wrapper input' => 'color: {{VALUE}};',
					'{{WRAPPER}} .xcency-banner-three-form .xcency-form-control-wrapper textarea' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_default_background',
			[
				'label'     => esc_html__('Button Background Color', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .xcency-banner-three-form input[type="submit"],{{WRAPPER}} .xcency-banner-three-form button[type="submit"]' => 'background-color: {{VALUE}};border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_default_color',
			[
				'label'     => esc_html__('Button Color', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .xcency-banner-three-form input[type="submit"],{{WRAPPER}} .xcency-banner-three-form button[type="submit"]' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_hover_background',
			[
				'label'     => esc_html__('Button Hover Background Color', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .xcency-banner-three-form input[type="submit"]:hover,{{WRAPPER}} .xcency-banner-three-form button[type="submit"]:hover' => 'background-color: {{VALUE}};border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_hover_color',
			[
				'label'     => esc_html__('Button Hover Color', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .xcency-banner-three-form input[type="submit"]:hover,{{WRAPPER}} .xcency-banner-three-form button[type="submit"]:hover' => 'color: {{VALUE}};',
				],
			]
		);

        $this->end_controls_section();

	}

	protected function xcency_banner_contact_form7( ) {

		if ( ! class_exists( 'WPCF7_ContactForm' ) ) {
			return array();
		}

		$forms = \WPCF7_ContactForm::find( array(
			'orderby' => 'title',
			'order'   => 'ASC',
		) );

		if ( empty( $forms ) ) {
			return array();
		}

		$result = array();

		foreach ( $forms as $item ) {
			$key            = sprintf( '%1$s::%2$s', $item->id(), $item->title() );
			$result[ $key ] = $item->title();
		}

		return $result;
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<div class="home-banner-three-wrapper xcency-cover-bg" style="background-image: url(<?php echo $settings['banner_bg_img']['url'];?>)">
			<div class="container">
                <div class="row">
                    <div class="col-xl-8 offset-xl-2">
                        <div class="home-banner-three-content">
                            <div class="banner-three-subtitle"><?php echo $settings['subtitle'];?></div>

                            <h2 class="banner-three-title"><?php echo $settings['banner_title'];?></h2>

                            <div class="home-banner-three-desc xcency-last-p-0">
                                <?php echo $settings['desc'];?>
                            </div>

	                        <?php if ( ! empty( $settings['wpcf7_form_list'] ) ) {?>
                                <div class="xcency-banner-three-contact-form-container">
                                    <div class="xcency-banner-three-form">
                                        <?php echo do_shortcode( '[contact-form-7 id="' . $settings['wpcf7_form_list'] . '" ]' );?>
                                    </div>
                                </div>
	                        <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new Xcency_Home_Banner_Three_Widget );