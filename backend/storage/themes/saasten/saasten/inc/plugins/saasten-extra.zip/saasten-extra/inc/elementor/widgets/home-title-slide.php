<?php

/**
 * Elementor Widget
 * @package Saasten
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_home_next_one extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'theme-next-onee';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Home Animated Text', 'saasten-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saasten_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {





        $this->start_controls_section( 'section_content_tstmonials_tickerpage', [
            'label' => esc_html__( 'Animated Text Items', 'saasten-extra' ),
        ] );

        $this->add_control( 'tickerItems', [
            'label'       => esc_html__( 'Testimonial Page Items', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'default'     => [
                [
                    'title-name'        => esc_html__( 'Testimonials', 'saasten-extra' ),
                ]
            ],

            'fields'      => [
                
                [
                    'name'        => 'title-name1',
                    'label'       => esc_html__( 'Title', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXT,
                    'default'     => __( 'Amazing Services', 'saasten-extra' ),
                    'description' => esc_html__( 'Enter Title', 'saasten-extra' )
                ],

                [
                    'name'        => 'title-name2',
                    'label'       => esc_html__( 'Title', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXT,
                    'default'     => __( 'Amazing Services', 'saasten-extra' ),
                    'description' => esc_html__( 'Enter Title', 'saasten-extra' )
                ],


            ],
            'title_field' => "{{name}}"
        ] );

        $this->end_controls_section(); 




        // ===================== Title ======================//

        $this->start_controls_section( 'title_style', [
            'label' => __( 'Title', 'saasten-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_typography',
            'label'    => __( 'Typography', 'saasten-extra' ),
            'selector' => '
                {{WRAPPER}} .theme-banner-startup-wrapper h1.banner-heading,
                {{WRAPPER}} .__title
            ',
        ] );


        $this->add_control( 'title_color', [
            'label'     => __( 'Color', 'saasten-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-startup-wrapper h1.banner-heading' => 'color: {{VALUE}}',
                '{{WRAPPER}} .__title' => 'color: {{VALUE}}',
            ],
        ] );

        $this->end_controls_section(); //End Title Style


        // ===================== Subtitle Style ========================//
        $this->start_controls_section( 'sub_title_style', [
            'label' => __( 'Sub Title', 'saasten-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_sub_typography',
            'label'    => __( 'Typography', 'saasten-extra' ),
            'selector' => '{{WRAPPER}} .theme-banner-startup-wrapper h4.banner-sub-heading',
        ] );

        $this->add_control( 'sub_title_color', [
            'label'     => __( 'Sub Title Color', 'saasten-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-startup-wrapper h4.banner-sub-heading' => 'color: {{VALUE}}',
            ],

        ] );

        $this->end_controls_section(); //End Subtitle Style

		
	}
	


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

        $tickerItems = $settings['tickerItems'];

        extract($settings); 


		
		?>



    <div class="animated-list ov-hidden">
      <div class="animated-lists">



        <?php
            foreach ( $tickerItems as $item ):
        ?>


        <!-- Animate List -->
        <div data-aos="fade-up" class="animated-lists__single">
          <span><?php echo esc_html( $item['title-name1'] ); ?></span>
          <img src="<?php echo SAASTEN_IMG ."/animate-list-icon.svg"; ?>" />
          <span class="stroke-text"><?php echo esc_html( $item['title-name2'] ); ?></span>
          <img src="<?php echo SAASTEN_IMG ."/animate-list-icon.svg"; ?>" />
        </div>
        <!-- End Animate List -->

        <?php endforeach; ?> 



      </div>
    </div>


	

	<?php 


	}
				

}

