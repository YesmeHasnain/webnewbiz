<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow; 


// General Fields
// barab_general_fields($th, $id, $label, $field_type, $default_value, $condition = null);
if (!function_exists('barab_general_fields')) {
    function barab_general_fields($th, $id, $label, $field_type, $default_value, $condition = null) {

        $control_args = [
            'label'      => __( $label, 'barab' ),
            'default'       => __( $default_value , 'barab' ),
        ];

        if ($field_type === 'TEXT' || $field_type === 'TEXT2') {
            $control_args['type'] = Controls_Manager::TEXT;
        } elseif ($field_type === 'TEXTAREA' || $field_type === 'TEXTAREA2' || $field_type === 'TEXTAREA3') {
            $control_args['type'] = Controls_Manager::TEXTAREA;
        } elseif ($field_type === 'HEADING') {
            $control_args['type'] = Controls_Manager::HEADING;
        } elseif ($field_type === 'WYSIWYG') {
            $control_args['type'] = Controls_Manager::WYSIWYG;
        } elseif ($field_type === 'DIVIDER') {
            $control_args['type'] = Controls_Manager::DIVIDER;
        } else{
            $control_args['type'] = Controls_Manager::TEXT;
        }

        if ($field_type === 'TEXT') {
            $control_args['label_block'] = true;
        }

        if ($field_type === 'TEXTAREA') {
            $control_args['rows'] = 4;
        }elseif ($field_type === 'TEXTAREA2') {
            $control_args['rows'] = 2;
        }elseif ($field_type === 'TEXTAREA3') {
            $control_args['rows'] = 6;
        }

        if (!empty($condition)) {
            $control_args['condition'] = [
                'layout_style' => $condition,
            ];
        }

        $th->add_control($id, $control_args);

    }
}

// Media Fields
// barab_media_fields($th, $id, $label, $condition = null);
if (!function_exists('barab_media_fields')) {
    function barab_media_fields($th, $id, $label, $condition = null) {

        $control_args = [
            'label'      => __( $label, 'barab' ),
            'type' 			=> Controls_Manager::MEDIA,
            'dynamic' 		=> [
                'active' 		=> true,
            ],
            'default' 		=> [
                'url' 			=> Utils::get_placeholder_image_src(),
            ],
        ];

        if (!empty($condition)) {
            $control_args['condition'] = [
                'layout_style' => $condition,
            ];
        }

        $th->add_control($id, $control_args);

    }
}

// URL Fields
// barab_url_fields($th, $id, $label, $condition = null);
if (!function_exists('barab_url_fields')) {
    function barab_url_fields($th, $id, $label, $condition = null) {

        $control_args = [
            'label'      => __( $label, 'barab' ),
            'type' 			=> Controls_Manager::URL,
            'placeholder' 	=> __( 'https://your-link.com', 'barab' ),
            'show_external' => true,
            'default' 		=> [
                'url' 			=> '#',
                'is_external' 	=> false,
                'nofollow' 		=> false,
            ],
        ];

        if (!empty($condition)) {
            $control_args['condition'] = [
                'layout_style' => $condition,
            ];
        }

        $th->add_control($id, $control_args); 

    }
}

// Icon Field
// barab_icon_field($th, $id, $label, $condition = null);
if ( ! function_exists( 'barab_icon_field' ) ) {
    function barab_icon_field( $th, $id, $label, $condition = null ) {

        $control_args = [
            'label' => __( $label, 'barab' ),
            'type'  => \Elementor\Controls_Manager::ICONS,
            'default' => [], // Empty by default
        ];

        if ( ! empty( $condition ) ) {
            $control_args['condition'] = [
                'layout_style' => $condition,
            ];
        }

        $th->add_control( $id, $control_args );
    }
}

// SELECT Fields
// barab_select_field($th, $id, $label, $options = [], $condition = null);
if (!function_exists('barab_select_field')) {
    function barab_select_field($th, $id, $label, $options = [], $condition = null) {
        $formatted_options = generate_formatted_options($options);

        $control_args = [
            'label'      => __( $label, 'barab' ),
            'type'       => Controls_Manager::SELECT,
            'options'    => $formatted_options,
            'default'    => '1',
        ];

        if (!empty($condition)) {
            $control_args['condition'] = [
                'layout_style' => $condition,
            ];
        }

        $th->add_control($id, $control_args);
    }

    function generate_formatted_options($options) {
        $formatted_options = [];
    
        // Check if options array is empty
        if (empty($options)) {
            // If options array is empty, add the default option
            $formatted_options['1'] = __( 'Option One', 'barab' );
        }
    
        // Add the rest of the options
        foreach ($options as $index => $option_label) {
            $option_id = $index + 1;  // Generate option ID based on index (starting from 1)
            $formatted_options[$option_id] = __( $option_label, 'barab' );
        }
    
        return $formatted_options;
    }
    
}


// Switcher Fields
// barab_switcher_fields($th, $id, $label, $condition = null);
if (!function_exists('barab_switcher_fields')) {
    function barab_switcher_fields($th, $id, $label, $condition = null) {

        $control_args = [
            'label'      => __( $label, 'barab' ),
            'type' 			=> Controls_Manager::SWITCHER,
			'label_on' 		=> __( 'Yes', 'barab' ),
			'label_off' 	=> __( 'No', 'barab' ),
			'return_value' 	=> 'yes',
			'default' 		=> 'yes',
        ];

        if (!empty($condition)) {
            $control_args['condition'] = [
                'layout_style' => $condition,
            ];
        }

        $th->add_control($id, $control_args);

    }
}

// Code Fields
// barab_code_fields($th, $id, $label, $condition = null);
if (!function_exists('barab_code_fields')) {
    function barab_code_fields($th, $id, $label, $default_value, $condition = null) {

        $control_args = [
            'label'      => __( $label, 'barab' ),
            'type' => \Elementor\Controls_Manager::CODE, 
			'language' => 'html',
            'rows' => 7,
            'default'       => __( $default_value , 'barab' ),
        ];

        if (!empty($condition)) {
            $control_args['condition'] = [
                'layout_style' => $condition,
            ];
        }

        $th->add_control($id, $control_args);

    }
}

// Social Repeater
// barab_social_fields($this, 'social', 'Social List');
if (!function_exists('barab_social_fields')) {
    function barab_social_fields($th, $id, $label, $condition = null) {

        $repeater = new Repeater();

		$repeater->add_control(
			'social_icon',
			[
				'label' 	=> __( 'Social Icon', 'barab' ),
				'type' 		=> Controls_Manager::ICONS,
				'default' 	=> [
					'value' 	=> 'fab fa-facebook-f',
					'library' 	=> 'solid',
				],
			]
		);
		$repeater->add_control(
			'icon_link',
			[
				'label' 		=> __( 'Link', 'barab' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __( 'https://your-link.com', 'barab' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> true,
					'nofollow' 		=> true,
				],
			]
		);

        $control_args = [
            'label' 		=> __( $label , 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' => [
                    [
                        'social_icon' => ['value' => 'fab fa-facebook-f', 'library' => 'solid'],
                        'icon_link' => ['url' => '#', 'is_external' => true, 'nofollow' => true],
                    ],
                    [
                        'social_icon' => ['value' => 'fab fa-twitter', 'library' => 'solid'],
                        'icon_link' => ['url' => '#', 'is_external' => true, 'nofollow' => true],
                    ],
                    [
                        'social_icon' => ['value' => 'fab fa-instagram', 'library' => 'solid'],
                        'icon_link' => ['url' => '#', 'is_external' => true, 'nofollow' => true],
                    ],
                    [
                        'social_icon' => ['value' => 'fab fa-linkedin-in', 'library' => 'solid'],
                        'icon_link' => ['url' => '#', 'is_external' => true, 'nofollow' => true],
                    ],
                ],
        ];

        if (!empty($condition)) {
            $control_args['condition'] = [
                'layout_style' => $condition,
            ];
        }

        $th->add_control($id, $control_args);

    }
}

// Column Responsive controls
if ( ! function_exists( 'barab_add_responsive_columns_controls' ) ) {
    function barab_add_responsive_columns_controls( $th, $condition = [] ) {

        $th->start_controls_section(
            'col_res_section',
            [
                'label'     => __( 'Column Responsive controls', 'barab' ),
                'tab'       => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => $condition,
            ]
        );

        $options = [
            ''   => esc_html__('Default', 'barab'),
            '12' => '1 Column',
            '6'  => '2 Column',
            '4'  => '3 Column',
            '3'  => '4 Column',
            '2'  => '6 Column',
        ];

        $controls = [
            'col_xl' => ['Extra large Column', '3', '1200px and above (desktops, large monitors)'],
            'col_lg' => ['Large Column', '4', '992px to 1199px (standard desktops)'],
            'col_md' => ['Medium Column', '6', '768px to 991px (tablets)'],
            'col_sm' => ['Small Column', '6', '576px to 767px (mobile landscape)'],
            'col_xs' => ['Extra small Column', '12', 'less than 576px (mobile phones)'],
        ];

        foreach ( $controls as $id => [$label, $default, $desc] ) {
            $th->add_control(
                $id,
                [
                    'label'       => esc_html__( $label, 'barab' ),
                    'type'        => \Elementor\Controls_Manager::SELECT,
                    'options'     => $options,
                    'default'     => $default,
                    'description' => esc_html__( "Screen width: $desc", 'barab' ),
                ]
            );
        }

        $th->end_controls_section();
    }
}
// Get Column Responsive controls Class
if ( ! function_exists( 'barab_get_responsive_columns_class' ) ) {
    function barab_get_responsive_columns_class( $settings ) {
        $classes = [];

        if ( ! empty( $settings['col_xl'] ) ) {
            $classes[] = 'col-xl-' . $settings['col_xl'];
        }
        if ( ! empty( $settings['col_lg'] ) ) {
            $classes[] = 'col-lg-' . $settings['col_lg'];
        }
        if ( ! empty( $settings['col_md'] ) ) {
            $classes[] = 'col-md-' . $settings['col_md'];
        }
        if ( ! empty( $settings['col_sm'] ) ) {
            $classes[] = 'col-sm-' . $settings['col_sm'];
        }
        if ( ! empty( $settings['col_xs'] ) ) {
            $classes[] = 'col-' . $settings['col_xs'];
        }

        // If no columns set, default to full width
        if ( empty( $classes ) ) {
            $classes[] = 'col-12';
        }

        return implode( ' ', $classes );
    }
}

// Slider Responsive control
// barab_elementor_slider_options($this, ['1']);
if (!function_exists('barab_elementor_slider_options')) {
    function barab_elementor_slider_options($th, $condition = null) {

        $th->start_controls_section(
			'slider_control',
			[
				'label'     => __( 'Slider Control', 'barab' ),
				'tab'       => \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' => [
                    'layout_style' => $condition
                ]
			]
        );

		$th->add_control(
			'desktop_items',
			[
				'label' 		=> __( 'Items To Show (1400 +)', 'barab' ),
				'type' 			=> \Elementor\Controls_Manager::SLIDER,
				'size_units' 	=> [ '%' ],
				'range' 		=> [
					'%' 	=> [
						'min' 		=> 0,
						'step' 		=> 1,
						'max' 		=> 10,
					],
				],
				'default' 		=> [
					'unit' 			=> '%',
					'size' 			=> 4,
				],
			]
		);

		$th->add_control(
			'large_laptop_items',
			[
				'label' 		=> __( 'Large Laptop Items (max 1399)', 'barab' ),
				'type' 			=> \Elementor\Controls_Manager::SLIDER,
				'size_units' 	=> [ '%' ],
				'range' 		=> [
					'%' 	=> [
						'min' 	=> 0,
						'step' 	=> 1,
						'max' 	=> 10,
					],
				],
				'default' 	=> [
					'unit' 		=> '%',
					'size' 		=> 4,
				],
			]
		);

		$th->add_control(
			'laptop_items',
			[
				'label' 		=> __( 'Laptop Items (max 1199)', 'barab' ),
				'type' 			=> \Elementor\Controls_Manager::SLIDER,
				'size_units' 	=> [ '%' ],
				'range' 		=> [
					'%' 	=> [
						'min' 	=> 0,
						'step' 	=> 1,
						'max' 	=> 10,
					],
				],
				'default' 	=> [
					'unit' 		=> '%',
					'size' 		=> 2,
				],
			]
		);

        $th->add_control(
			'tablet_items',
			[
				'label' 		=> __( 'Tablet Items (max 991)', 'barab' ),
				'type' 			=> \Elementor\Controls_Manager::SLIDER,
				'size_units' 	=> [ '%' ],
				'range' 		=> [
					'%' 	=> [
						'min' 	=> 0,
						'step' 	=> 1,
						'max' 	=> 10,
					],
				],
				'default' 	=> [
					'unit' 		=> '%',
					'size' 		=> 2,
				],
			]
		);
        $th->add_control(
			'mobile_items',
			[
				'label' 		=> __( 'Mobile Items (max 767)', 'barab' ),
				'type' 			=> \Elementor\Controls_Manager::SLIDER,
				'size_units' 	=> [ '%' ],
				'range' 		=> [
					'%' 	=> [
						'min' 	=> 0,
						'step' 	=> 1,
						'max' 	=> 10,
					],
				],
				'default' 	=> [
					'unit' 		=> '%',
					'size' 		=> 1,
				],
			]
		);

        $th->add_control(
			'small_mobile_items',
			[
				'label' 		=> __( 'Small Mobile (max 430)', 'barab' ),
				'type' 			=> \Elementor\Controls_Manager::SLIDER,
				'size_units' 	=> [ '%' ],
				'range' 		=> [
					'%' 	=> [
						'min' 	=> 0,
						'step' 	=> 1,
						'max' 	=> 10,
					],
				],
				'default' 	=> [
					'unit' 		=> '%',
					'size' 		=> 1,
				],
			]
		);

		$th->end_controls_section();
        
    }
}