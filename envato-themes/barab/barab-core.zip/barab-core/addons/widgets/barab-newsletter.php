<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Repeater;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Background;
/**
 * 
 * Newsletter Widget .
 *
 */
class Barab_Newsletter extends Widget_Base {

	public function get_name() {
		return 'barabnewsletter';
	}
	public function get_title() {
		return __( 'Newsletter', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
			'layout_section',
			[
				'label'     => __( 'Newsletter Style', 'barab' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One' ] );
		
		barab_general_fields( $this, 'title', 'Title', 'TEXTAREA2', 'Newsletter', ['1'] );
		barab_general_fields( $this, 'content', 'Content', 'TEXTAREA2', 'Sign up to receive the latest articles', ['1'] );
		barab_general_fields( $this, 'newsletter_placeholder', 'Placeholder', 'TEXT', 'Enter your Email' );
		barab_general_fields( $this, 'newsletter_button', 'Subscribe Button', 'TEXT', 'Subscribe' );

		barab_media_fields($this, 'image', 'Choose Image', ['1']);

		barab_media_fields( $this, 'shape1', 'Choose Shape', ['1'] );
		barab_media_fields( $this, 'shape2', 'Choose Shape', ['1'] );
		barab_media_fields( $this, 'section_curve_shape', 'Section Curve Shape', ['1'] );

        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------

		barab_common_style_fields($this, '01', 'Title', '{{WRAPPER}} .sec-title', ['1'] );
		barab_common_style_fields($this, '02', 'Content', '{{WRAPPER}} .sec-text', ['1'] );
		

	}

	protected function render() {

        $settings = $this->get_settings_for_display();

		if( $settings['layout_style'] == '1' ){
			echo '<section class="cta-area-1 bg-theme4 overflow-hidden shape-mockup-wrap">';
				if($settings['shape1']['url'] ){
					echo '<div class="shape-mockup footer-bg-shape1-1 jump d-none d-xl-block" data-left="0" data-top="5%">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['shape1']['url'] ),
						)); 
					echo '</div>';
				}
				echo barab_img_tag( array(
					'url'   => esc_url( $settings['section_curve_shape']['url'] ),
					'class' => 'round-shape-top',
				));
				if($settings['shape2']['url'] ){
					echo '<div class="cta-bg-1-1-wrap">';
						echo '<div class="cta-bg-1-1">';
							echo barab_img_tag( array(
								'url'   => esc_url( $settings['shape2']['url'] ),
							)); 
						echo '</div>';
					echo '</div>';
				}
				echo '<div class="cta-1-shape-trangle"></div>';
				echo '<div class="cta-round-shape"></div>';
				echo '<div class="container z-index-common">';
					echo '<div class="row gy-30">';
						echo '<div class="col-xl-6 col-lg-6">';
							echo '<div class="cta-wrap1">';
								echo '<div class="title-area me-xl-5 pe-xl-5 mb-0">';
									if($settings['title']){
										echo '<h2 class="sec-title text-anime-style-1">'.wp_kses_post($settings['title']).'</h2>';
									}
									if($settings['content']){
										echo '<p class="sec-text text-anime-style-2 mt-30 mb-20 fw-medium">'.esc_html($settings['content']).'</p>';
									}
									echo '<form class="newsletter-form img-anime-style-1">';
										echo '<div class="form-group">';
											echo '<input class="form-control" type="email" placeholder="'.esc_attr( $settings['newsletter_placeholder'] ).'" required="">';
										echo '</div>';
										echo '<button type="submit" class="th-btn style4 mt-0">'.wp_kses_post( $settings['newsletter_button'] ).'</button>';
									echo '</form>';
								echo '</div>';
							echo '</div>';
						echo '</div>';
						echo '<div class="col-xl-6 col-lg-6 align-self-end">';
							if(!empty($settings['image']['url'])){
								echo '<div class="cta-thumb1-1 text-center text-lg-end tilt-active wow fadeiright">';
									echo barab_img_tag( array(
										'url'   => esc_url( $settings['image']['url'] ),
									));
								echo '</div>';
							}
						echo '</div>';
					echo '</div>';
				echo '</div>';
			echo '</section>';

		}elseif( $settings['layout_style'] == '2' ){
			echo '<div class="widget newsletter-widget footer-widget">';
				if($settings['title']){
					echo '<h3 class="newsletter-title">'.esc_html($settings['title']).'</h3>';
				}
				if($settings['content']){
					echo '<p class="newsletter-text">'.esc_html($settings['content']).'</p>';
				}
				echo '<form class="newsletter-form">';
					echo '<input class="form-control" type="email" placeholder="'.esc_attr( $settings['newsletter_placeholder'] ).'" required="">';
					echo '<button type="submit" class="th-btn style3">'.wp_kses_post( $settings['newsletter_button'] ).'</button>';
				echo '</form>';
				if($settings['notice']){
				echo '<div class="col-12 form-group">';
					echo '<input type="checkbox" id="html">';
					echo '<label for="html">'.esc_html($settings['notice']).'</label>';
				echo '</div>';
				}
			echo '</div>';
		}
	

	}
}
						