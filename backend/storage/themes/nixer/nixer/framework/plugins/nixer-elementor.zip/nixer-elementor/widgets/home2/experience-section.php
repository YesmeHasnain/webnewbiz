<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome2ExpSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home2-exp-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 2 - Experience Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-clock';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home2' ];
	}

	public function get_keywords() {
		return [ 'home2expsection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_exp_section',
			[
				'label' => esc_html__( 'Experience Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'img_bg_sec',
			[
				'label'       	=> esc_html__( 'Image Background Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image background section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Experience' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_row = new \Elementor\Repeater();
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'img_icon_item',
			[
				'label'       	=> esc_html__( 'Image Icon Item', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image icon item', 'bdevs-elementor' ),
			]
		);
		$repeater->add_control(
			'label_item',
			[
				'label' 		=> esc_html__( 'Label Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Label Item' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'time_item',
			[
				'label' 		=> esc_html__( 'Time Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'April 2025' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'title_item',
			[
				'label' 		=> esc_html__( 'Title Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Title Item' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'title_item',
			[
				'label' 		=> esc_html__( 'Title Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Title Item' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'link_item',
			[
				'label' 		=> esc_html__( 'Link Item - If have', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '#' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_row->add_control(
			'tabs',
			[
				'label' 		=> esc_html__( 'List Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
					],
					[
					],
				],
				'title_field' 	=> '{{{ title_item }}}',
			]
		);
		$this->add_control(
			'tab_row',
			[
				'label' 		=> esc_html__( 'List Row', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $rp_row->get_controls(),
				'default' 		=> [
					[
					],
				],
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-experiance-ptb fix pt-110 pb-120" data-background="<?php echo wp_kses_post($settings['img_bg_sec']['url']); ?>">
	<div class="container">
		<div class="row">
			<?php if (!empty($settings['title_sec'])): ?>
				<div class="col-lg-12">
					<div class="tp-experiance-heading text-center mb-50">
						<h3 class="tp-section-title tp-char-animation"><?php echo wp_kses_post($settings['title_sec']); ?></h3>
					</div>
				</div>
			<?php endif ?>
			<div class="col-lg-12">
				<?php
				$i = 0;
				foreach ($settings['tab_row'] as $itemr) :
					$i++;
				?>
					<?php if ($i == 1) { ?>
						<div class="tp-experiance-wrap d-flex">
					<?php } else { ?>
						<div class="tp-experiance-wrap two d-flex">
					<?php } ?>
							<?php
							foreach ($itemr['tabs'] as $item) :
							?>
								<div class="tp-experiance-item d-flex align-items-center">
									<?php if (!empty($item['img_icon_item']['url'])): ?>
										<div class="tp-experiance-item-icon">
											<span>
												<img src="<?php echo wp_kses_post($item['img_icon_item']['url']); ?>" alt="<?php echo wp_kses_post($item['img_icon_item']['alt']); ?>">
											</span>
										</div>
									<?php endif ?>
									<div class="tp-experiance-item-content">
										<?php if (!empty($item['label_item']) || !empty($item['time_item'])): ?>
											<div class="tp-experiance-item-tags d-flex">
												<?php if (!empty($item['label_item'])): ?>
													<span><?php echo wp_kses_post($item['label_item']); ?></span>
												<?php endif ?>
												<?php if (!empty($item['label_item']) && !empty($item['time_item'])): ?>
													<span class="dev"></span>
												<?php endif ?>
												<?php if (!empty($item['time_item'])): ?>
													<span><?php echo wp_kses_post($item['time_item']); ?></span>
												<?php endif ?>
											</div>
										<?php endif ?>
										<?php if (!empty($item['title_item'])): ?>											
											<h3 class="tp-experiance-item-title">
												<?php if (!empty($item['link_item'])) { ?>
													<a href="<?php echo wp_kses_post($item['link_item']); ?>">
														<?php echo wp_kses_post($item['title_item']); ?>
													</a>
												<?php } else { ?>
													<span><?php echo wp_kses_post($item['title_item']); ?></span>
												<?php } ?>
											</h3>
										<?php endif ?>
									</div>
								</div>
							<?php endforeach; ?>
						</div>
				<?php endforeach ?>
			</div>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-background]").each(function () {
			jQuery(this).css("background-image", "url( " + jQuery(this).attr("data-background") + "  )");
		});

		if (jQuery('.tp-experiance-heading .tp-char-animation').length > 0) {
			var char_come = gsap.utils.toArray(".tp-experiance-heading .tp-char-animation");
			char_come.forEach(splitTextLine => {
				var tl = gsap.timeline({
					scrollTrigger: {
						trigger: splitTextLine,
						start: 'top 90%',
						end: 'bottom 60%',
						scrub: false,
						markers: false,
						toggleActions: 'play none none none'
					}
				});

				var itemSplitted = new SplitText(splitTextLine, { type: "chars, words" });
				gsap.set(splitTextLine, { perspective: 300 });
				itemSplitted.split({ type: "chars, words" })
				tl.from(itemSplitted.chars,
					{
						duration: 1,
						delay: 0.5,
						x: 100,
						autoAlpha: 0,
						stagger: 0.05
					});
			});
		}

	</script>
<?php } ?>

<?php
}

}