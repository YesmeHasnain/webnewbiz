<?php
namespace EARLSPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Float_Image extends Widget_Base {
	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'earls_float_image';
	}
	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Earls Float Image', 'earls' );
	}
	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-image-hotspot';
	}
	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'earls' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'float_image',
			[
				'label' => esc_html__( 'Earls Float Image', 'earls' ),
			]
		);
		
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'earls' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'earls'),
					'2' => esc_html__( 'Style Two ', 'earls'),
					'3' => esc_html__( 'Style Three ', 'earls'),
					'4' => esc_html__( 'Style Four ', 'earls'),
				),
			]
		);
		
		//Our Slider		
		$this->add_control(
			'block_img',
			[
				'label' => esc_html__('Choose Image ', 'earls'),							
				'type' => Controls_Manager::MEDIA,							
				'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition'   => [ 'layout_control' => ['1', '2', '3', '4'] ]
			]
		);
		$this->add_control(
			'schdule_title',
			[
				'label' => esc_html__( 'Schdule Desription', 'earls' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Schdule Desription', 'earls' ),
				'default' => esc_html__( 'Add Your Schdule Desription Here', 'earls' ),
				'condition'   => [ 'layout_control' => ['3', '4'] ]
			]
		);
		$this->add_control(
			'block_img_two',
			[
				'label' => esc_html__('Choose Image ', 'earls'),							
				'type' => Controls_Manager::MEDIA,							
				'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition'   => [ 'layout_control' => ['2', '3'] ]
			]
		);
		
		$this->end_controls_section();
    }
	
	
	/**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post'); 
		$layout = $settings[ 'layout_control' ];
	?>
	
	<?php if( $layout === '4' ): ?>
	
    <div class="batter__food__two three p-0 m-0">
        <div class="batter__food__right__two p_relative wow slideInRight animated animated" data-wow-delay="00ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: slideInRight; background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['block_img']['id'])); ?>);">
           <div class="batter__food__right_feature_image">
               <img class="d-block" src="<?php echo esc_url(wp_get_attachment_url($settings['block_img']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','earls');?>">
           </div>
           <div class="absulate__content">
               <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/resource/gori.png" alt="<?php esc_attr_e('Awesome Image','earls');?>">
                <?php if($settings['schdule_title']){ ?>
                <div class="text">
                    <p> <?php echo wp_kses($settings['schdule_title'], true); ?> </p> 
                </div>
                <?php } ?>
           </div>
       </div>
    </div>
    
	<?php elseif( $layout === '3' ): ?>
    
    <div class="batter__food__right__two p_relative wow slideInRight animated animated" data-wow-delay="00ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: slideInRight; background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['block_img']['id'])); ?>);">
       <div class="batter__food__right_feature_image">
           <img class="d-block " src="<?php echo esc_url(wp_get_attachment_url($settings['block_img']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','earls');?>">
       </div>
       <div class="absulate__content">
           <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/resource/gori.png" alt="<?php esc_attr_e('Awesome Image'); ?>">
           <?php if($settings['schdule_title']){ ?>
           <div class="text">
             <p> <?php echo wp_kses($settings['schdule_title'], true); ?> </p> 
           </div>
           <?php } ?>
       </div>
   </div>
   <div class="better__food__tometo wow zoomIn animated" data-wow-delay="100ms" data-wow-duration="1500ms" style="background-image:url(<?php echo esc_url(wp_get_attachment_url($settings['block_img_two']['id'])); ?>)"></div>
    
	<?php elseif( $layout === '2' ): ?>
    
    <div class="about__img__right__one p_absolute">
        <figure data-parallax='{"y": -50}'>
            <img src="<?php echo esc_url(wp_get_attachment_url($settings['block_img']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','earls');?>">
        </figure>
    </div>
    <div class="about__img__right__two p_absolute">
        <figure data-parallax='{"y": -50}'>
            <img src="<?php echo esc_url(wp_get_attachment_url($settings['block_img_two']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','earls');?>">
        </figure>
    </div>
    
    <?php else: ?>
    
    <div class="wow slideInRight animated animated" data-wow-delay="200ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 200ms; animation-name: slideInRight;">
        <div class="food__right__img " style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['block_img']['id'])); ?>);">
            <div class="food__right__img_feature_image">
                <img class="d-block d-lg-none" src="<?php echo esc_url(wp_get_attachment_url($settings['block_img']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','earls');?>">
            </div>
        </div>
    </div>
    
    <?php endif;
	}
}