<?php namespace EARLSPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Banner extends Widget_Base {

    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'earls_banner';
    }

    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Earls Banner', 'earls' );
    }

    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-banner';
    }

    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'earls' ];
    }
	
	public function get_script_depends() {
		wp_register_script( 'banner-slider', YT_URL . 'assets/js/banner-carousel.js', [ 'elementor-frontend' ], '1.0.0', true );
		return [ 'banner-slider' ];
	}
	
    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'banner',
            [
                'label' => esc_html__( 'Earls Banner', 'earls' ),
            ]
        );
		$this->add_control(
			'layout_control',
			[
				'label'       => __( 'Template Layout', 'earls' ),
				'type'        => 'elementor-layout-control',
				'default' => '1',
				'options' => [
					'one' => [
						'label' => esc_html__('Layout 1', 'earls' ),
						'image' => get_template_directory_uri() . '/assets/images/redux/layout/banner/banner-01.png'
					],
					'two' => [
						'label' => esc_html__('Layout 2', 'earls' ),
						'image' => get_template_directory_uri() . '/assets/images/redux/layout/banner/banner-02.png'
					],
					'three' => [
						'label' => esc_html__('Layout 3', 'earls' ),
						'image' => get_template_directory_uri() . '/assets/images/redux/layout/banner/banner-03.png'
					],
					'four' => [
						'label' => esc_html__('Layout 4', 'earls' ),
						'image' => get_template_directory_uri() . '/assets/images/redux/layout/banner/banner-04.png'
					],
					'five' => [
						'label' => esc_html__('Layout 5', 'earls' ),
						'image' => get_template_directory_uri() . '/assets/images/redux/layout/banner/banner-05.png'
					],
				],
			]
		);
		
		//Banner SLide Repeater
		$repeater = new Repeater();
		$repeater->add_control(
			'bg_leaf_image',
			[
				'label' => __( 'Banner Leaf Image', 'earls' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$repeater->add_control(
			'transparent_title',
			[
				'label'       => __( 'Transparent Title ', 'earls' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Transparent Title', 'earls' ),
			]
		);
		$repeater->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title', 'earls' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Sub Title', 'earls' ),
			]
		);
		$repeater->add_control(
			'title',
			[
				'label'       => __( 'Title', 'earls' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Title', 'earls' ),
			]
		);
		$repeater->add_control(
			'text',
			[
				'label'       => __( 'Description', 'earls' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Description', 'earls' ),
			]
		);
		$repeater->add_control(
			'btn_title',
			[
				'label'       => __( 'Button Title', 'earls' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Button Title', 'earls' ),
			]
		);
		$repeater->add_control(
			'btn_link',
			[
				  'label' => __( 'External Url', 'earls' ),
				  'type' => Controls_Manager::URL,
				  'placeholder' => __( 'https://your-link.com', 'plugin-domain' ),
				  'show_external' => true,
				  'default' => [
				    'url' => '',
				    'is_external' => true,
				    'nofollow' => true,
				  ],
			 ]
		);
		$repeater->add_control(
			'banner_image',
			[
				'label' => __( 'Banner Image', 'earls' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$this->add_control(
			'slide',
			[
				'label'                 => __('Add Slide Item', 'earls'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
				'condition'             => [
					'layout_control'    => 'one'
				]
			]
		);
		
		//Banner Two SLide Repeater
		$repeater = new Repeater();
		$repeater->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title', 'earls' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Sub Title', 'earls' ),
			]
		);
		$repeater->add_control(
			'title',
			[
				'label'       => __( 'Title', 'earls' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Title', 'earls' ),
			]
		);
		$repeater->add_control(
			'text',
			[
				'label'       => __( 'Description', 'earls' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Description', 'earls' ),
			]
		);
		$repeater->add_control(
			'btn_title',
			[
				'label'       => __( 'Button Title', 'earls' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Button Title', 'earls' ),
			]
		);
		$repeater->add_control(
			'btn_link',
			[
				  'label' => __( 'External Url', 'earls' ),
				  'type' => Controls_Manager::URL,
				  'placeholder' => __( 'https://your-link.com', 'plugin-domain' ),
				  'show_external' => true,
				  'default' => [
				    'url' => '',
				    'is_external' => true,
				    'nofollow' => true,
				  ],
			 ]
		);
		$repeater->add_control(
			'banner_image',
			[
				'label' => __( 'Banner Image', 'earls' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$this->add_control(
			'slide_v2',
			[
				'label'                 => __('Add Slide Item', 'earls'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
				'condition'             => [
					'layout_control'    => ['two', 'three', 'four']
				]
			]
		);
		
		//Banner five SLide Repeater
		$repeater = new Repeater();
		$repeater->add_control(
			'banner_image',
			[
				'label' => __( 'Banner Image', 'earls' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$repeater->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title', 'earls' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Sub Title', 'earls' ),
			]
		);
		$repeater->add_control(
			'title',
			[
				'label'       => __( 'Title', 'earls' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Title', 'earls' ),
			]
		);
		$repeater->add_control(
			'text',
			[
				'label'       => __( 'Description', 'earls' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Description', 'earls' ),
			]
		);
		$this->add_control(
			'slide_v3',
			[
				'label'                 => __('Add Slide Item', 'earls'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
				'condition'             => [
					'layout_control'    => 'five'
				]
			]
		);
		$this->end_controls_section();
		
		/**Carousel Setting Start**/
		$this->start_controls_section(
			'carousel',
			[
				'label' => esc_html__( 'Carousel Setting', 'earls' ),
				'condition'             => [
					'layout_control'    => ['one', 'two', 'three', 'four', 'five']
				]
			]
		);
		$this->add_control(
			'infinite',
			[
				'label' => __( 'infinite Loop?', 'earls' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'earls' ),
				'label_off' => __( 'Hide', 'earls' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_responsive_control(
			'items_show',
			[
				'label' => esc_html__( 'No. of Items', 'earls' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 100,
				'default' => 3,
			]
		);
		$this->add_responsive_control(
			'image_item_gap',
			[
				'label' => __( 'Item Gap', 'earls' ),
				'type' => Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 100,
				'default' => 30,
			]
		);
		$this->add_control(
			'autoplay',
			[
				'label' => __( 'Autoplay?', 'earls' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'earls' ),
				'label_off' => __( 'Hide', 'earls' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'autoplay_speed',
			array(
				'label'       => __( 'Animation Speed', 'earls' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '2500', 'earls' ),
			)
		);
		$this->add_control(
            'earls_nav_heading',
            [
                'label' => __('Navigation', 'earls'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
			]
        );
		$this->add_control(
			'arrows',
			[
				'label' => __( 'Enable Arrows?', 'earls' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'earls' ),
				'label_off' => __( 'Hide', 'earls' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'dots',
			[
				'label' => __( 'Enable Dots?', 'earls' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'earls' ),
				'label_off' => __( 'Hide', 'earls' ),
				'return_value' => 'yes',
				'default' => '',
			]
		);
		$this->end_controls_section();
		
		/** Style Tab **/
		$this->register_style_background_controls();
    }
	
	/************************************************************************
								Tab Style Start
	*************************************************************************/
	
	protected function register_style_background_controls()
	{
		/**Layout Control Style**/		
		$this->start_controls_section(
			'earls_layout_style',
			[
				'label' => esc_html__('Earls Layout Setting', 'earls'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'earls_layout_margin',
			[
				'label'              => __( 'Spacing', 'earls' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', 'em', '%' ],
				'selectors'          => [
					'{{WRAPPER}} .banner-carousel .content-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
				'frontend_available' => true,
				
			]
		);
		$this->add_responsive_control(
			'earls_layout_padding',
			[
				'label'              => __( 'Gapping', 'earls' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', 'em', '%' ],
				'selectors'          => [
					'{{WRAPPER}} .banner-carousel .content-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
				'frontend_available' => true,
				
			]
		);
		$this->add_control(
			'earls_layout_background',
			[
				'label'                 => __( 'Background', 'earls' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'earls_layout_bgtype',
				'label' => __( 'Button Background', 'earls' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => 
					'{{WRAPPER}} .banner-carousel .content-box',				
			]
		);
		$this->end_controls_section();
	}

    /**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');
		$layout = $settings[ 'layout_control' ];
		
		$items_show = $settings[ 'items_show' ];
		$image_item_gap = $settings[ 'image_item_gap' ];
		$autoplay_speed = $settings[ 'autoplay_speed' ];
		
		if($settings['infinite'] == 'yes'){
			$infiinite = true;
		}else{
			$infiinite = false;
		}

		if($settings['autoplay'] == 'yes'){
			$autoplay = true;
		}else{
			$autoplay = false;
		}

		if($settings['dots'] == 'yes'){
			$dots = true;
		}else{
			$dots = false;
		}

		if($settings['arrows'] == 'yes'){
			$arrows = true;
		} else{
			$arrows = false;
		}
		
		$changed_atts = array(
			'infinite'       => $infiinite,
			'autoplay'       => $autoplay,
			'autoplaySpeed'  => $autoplay_speed,
			'dots' 			 => $dots,
			'nav' 		 => $arrows,
			'item_gap' 	     => $image_item_gap,
			'item_show' 	 => $items_show
		);
		
		$slider_atts = 'data-slider';		
		$this->add_render_attribute( 'slider_settings', $slider_atts , wp_json_encode( $changed_atts ) );
	?>
	
    <?php if( $layout === 'five' ): ?>
    
	<!-- banner-section -->
    <section class="banner-style-five p_relative p-0 m-0">
        <div class="banner-carousel owl-theme owl-carousel <?php if(! $settings['dots'] == 'yes' ) echo 'owl-dots-none';?> <?php if( $settings['arrows'] == 'yes' ) echo 'nav-style-one'; else echo 'owl-nav-none';?>" id="yt-banner-slider" <?php $this->print_render_attribute_string( 'slider_settings' ); ?>>
            <?php foreach($settings['slide_v3'] as $key => $item): ?>
            <div class="slide-item">
                <?php if($item[ 'banner_image' ]){ ?>
                <div class="image-layer" style="background-image:url(<?php echo esc_url( wp_get_attachment_url( $item[ 'banner_image' ]['id'] ) );?>)"></div>
                <?php } ?>
                <div class="content-box">
                    <?php if($item[ 'subtitle']){ ?>
                    <div class="sub____title">
                        <span><?php echo wp_kses( $item[ 'subtitle'], true  );?></span>
                    </div>
                    <?php } ?>
                    <h1><?php echo wp_kses( $item[ 'title'], true  );?></h1>
                    <p><?php echo wp_kses( $item[ 'text'], true  );?> </p>
                </div> 
            </div>
            <?php endforeach; ?>
        </div>
    </section>
    <!-- banner-section end -->
    
	<?php elseif( $layout === 'four' ): ?>
    
	<!-- banner-section -->
    <section class="banner-section style-three style-four">
        <div class="content-container">
            <div class="banner-carousel owl-theme owl-carousel <?php if(! $settings['dots'] == 'yes' ) echo 'owl-dots-none';?> <?php if( $settings['arrows'] == 'yes' ) echo 'nav-style-one'; else echo 'owl-nav-none';?>" id="yt-banner-slider" <?php $this->print_render_attribute_string( 'slider_settings' ); ?>>
                <?php $count = 1; foreach($settings['slide_v2'] as $key => $item): ?>
                <div class="slide-item" data-dot="<button role='button' class='owl-dot'><?php echo wp_kses($count, true); ?></button>">
                    <?php if($item[ 'banner_image' ]){ ?>
                    <div class="image-layer" style="background-image:url(<?php echo esc_url( wp_get_attachment_url( $item[ 'banner_image' ]['id'] ) );?>)"></div>
                    <?php } ?>
                    <div class="content-box">
                        <div class="title-text">
                            <?php if($item[ 'subtitle']){ ?>
                            <div class="sub____title">
                                <span><?php echo wp_kses( $item[ 'subtitle'], true  );?></span>
                            </div>
                            <?php } ?>
                            <h1><?php echo wp_kses( $item[ 'title'], true  );?></h1>
                        	<p><?php echo wp_kses( $item[ 'text'], true  );?> </p>
                        </div>
                        <?php if($item[ 'btn_link'] and $item[ 'btn_title']){ ?>
                        <div class="btn-box">
                            <a href="<?php echo esc_url( $item[ 'btn_link']['url'] );?>" class="theme-btn-one"><?php echo wp_kses( $item[ 'btn_title'], true  );?></a>
                        </div>
                        <?php } ?>
                    </div>
                </div>
                <?php $count++; endforeach; ?>
            </div>
        </div>
    </section>
    <!-- banner-section end -->
    
	<?php elseif( $layout === 'three' ): ?>
    
    <!-- banner-section -->
    <section class="banner-section style-three">
        <div class="banner-carousel owl-theme owl-carousel <?php if(! $settings['dots'] == 'yes' ) echo 'owl-dots-none';?> <?php if( $settings['arrows'] == 'yes' ) echo 'nav-style-one'; else echo 'owl-nav-none';?>" id="yt-banner-slider" <?php $this->print_render_attribute_string( 'slider_settings' ); ?>>
            <?php foreach($settings['slide_v2'] as $key => $item): ?>
            <div class="slide-item">
                <?php if($item[ 'banner_image' ]){ ?>
                <div class="image-layer" style="background-image:url(<?php echo esc_url( wp_get_attachment_url( $item[ 'banner_image' ]['id'] ) );?>)"></div>
                <?php } ?>
                <div class="medium-container">
                    <div class="content-box">
                        <div class="title-text">
                            <?php if($item[ 'subtitle']){ ?>
                            <div class="sub____title">
                                <span><?php echo wp_kses( $item[ 'subtitle'], true  );?></span>
                            </div>
                            <?php } ?>
                            <h1><?php echo wp_kses( $item[ 'title'], true  );?></h1>
                        	<p><?php echo wp_kses( $item[ 'text'], true  );?> </p>
                        </div>
                        <?php if($item[ 'btn_link'] and $item[ 'btn_title']){ ?>
                        <div class="btn-box">
                            <a href="<?php echo esc_url( $item[ 'btn_link']['url'] );?>" class="theme-btn-one"><?php echo wp_kses( $item[ 'btn_title'], true  );?></a>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>
    <!-- banner-section end -->
    
    <?php elseif( $layout === 'two' ): ?>
    
    <!-- banner-section -->
    <section class="banner-style-two p_relative">
        <div class="banner-carousel owl-theme owl-carousel <?php if(! $settings['dots'] == 'yes' ) echo 'owl-dots-none';?> <?php if( $settings['arrows'] == 'yes' ) echo 'nav-style-one'; else echo 'owl-nav-none';?>" id="yt-banner-slider" <?php $this->print_render_attribute_string( 'slider_settings' ); ?>>
            <?php foreach($settings['slide_v2'] as $key => $item): ?>
            <div class="slide-item">
                <?php if($item[ 'banner_image' ]){ ?>
                <div class="image-layer" style="background-image:url(<?php echo esc_url( wp_get_attachment_url( $item[ 'banner_image' ]['id'] ) );?>)"></div>
                <?php } ?>
                <div class="medium-container">
                    <div class="content-box">
                        <?php if($item[ 'subtitle']){ ?>
                        <div class="sub____title">
                            <span><?php echo wp_kses( $item[ 'subtitle'], true  );?></span>
                        </div>
                        <?php } ?>
                        <h1><?php echo wp_kses( $item[ 'title'], true  );?></h1>
                        <p> <?php echo wp_kses( $item[ 'text'], true  );?> </p>
                        <?php if($item[ 'btn_link'] and $item[ 'btn_title']){ ?>
                        <div class="btn-box">
                            <a href="<?php echo esc_url( $item[ 'btn_link']['url'] );?>" class="theme-btn-one"><?php echo wp_kses( $item[ 'btn_title'], true  );?></a>
                        </div>
                        <?php } ?> 
                    </div> 
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>
    <!-- banner-section end -->
    
    <?php else: ?>
    
    <!-- banner one -->
	<section class="banner-section style-one">
        <div class="banner-carousel owl-theme owl-carousel <?php if(! $settings['dots'] == 'yes' ) echo 'owl-dots-none';?> <?php if( $settings['arrows'] == 'yes' ) echo 'nav-style-one'; else echo 'owl-nav-none';?>" id="yt-banner-slider" <?php $this->print_render_attribute_string( 'slider_settings' ); ?>>
            <?php $count = 1; foreach($settings['slide'] as $key => $item): ?>
            <div class="slide-item" data-dot="<button role='button' class='owl-dot'><?php echo wp_kses($count, true); ?></button>">
                <div class="auto-container">
                    <?php if($item[ 'bg_leaf_image' ]){ ?>
                    <div class="anim-icon">
                        <div class="icon icons-1 " data-parallax='{"x": 500}' style="background-image: url(<?php echo esc_url( wp_get_attachment_url( $item[ 'bg_leaf_image' ]['id'] ) );?>);"></div>
                    </div>
                    <?php } ?>
                    <?php if($item[ 'transparent_title']){ ?>
                    <div class="banner__top__text">
                        <h1><?php echo wp_kses( $item[ 'transparent_title'], true  );?></h1>
                    </div>
                    <?php } ?>
                    <div class="content-inner">
                        <div class="content-box">
                            <?php if($item[ 'subtitle']){ ?>
                            <div class="sub____title">
                                <span><?php echo wp_kses( $item[ 'subtitle'], true  );?></span>
                            </div>
                            <?php } ?>
                            <h1><?php echo wp_kses( $item[ 'title'], true  );?></h1>
                            <p><?php echo wp_kses( $item[ 'text'], true  );?> </p>
                            <?php if($item[ 'btn_link'] and $item[ 'btn_title']){ ?>
                            <div class="btn-box">
                                <a href="<?php echo esc_url( $item[ 'btn_link']['url'] );?>" class="theme-btn-two"><?php echo wp_kses( $item[ 'btn_title'], true  );?></a>
                            </div>
                            <?php } ?>
                        </div>
                        <?php if($item[ 'banner_image' ]){ ?>
                        <figure class="image-box style-one">
                            <img src="<?php echo esc_url( wp_get_attachment_url( $item[ 'banner_image' ]['id'] ) );?>" alt="<?php esc_attr_e('Awesome Image', 'earls'); ?>">
                        </figure>
                        <?php } ?>
                    </div>  
                </div>
            </div>
            <?php $count++; endforeach; ?>
        </div>
    </section>
    <!-- banner one end-->
    
    <?php endif;
    }
}
