<?php
if (!defined('ABSPATH')) exit;

require_once ('controls/icons.php');

class Xcency_Core_Elementor_Scripts {

	public function __construct() {
		add_action( 'elementor/frontend/after_register_scripts', array( $this, 'xcency_core_register_scripts' ) );
	}

	public function xcency_core_register_scripts() {
		wp_register_script( 'counterup', plugins_url( '/', __FILE__ ) . 'assets/js/counterup.min.js', array( 'jquery' ), '1.0', true );
	}
}

new Xcency_Core_Elementor_Scripts();


class Xcency_Core_Elementor_Custom_Widget {

	private static $instance = null;

	public static function get_instance() {
		if ( ! self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	public function xcency_core_add_elementor_custom_widgets() {
		require_once('accordion.php');
		require_once('brand-image-slider-widget.php');
		require_once('contact-box-one.php');
		require_once('brand-image-gallery.php');
		require_once('contact-form-7.php');
		require_once('contact-form-7-two.php');
		require_once('count-up-one.php');
		require_once('count-up-two.php');
		require_once('count-section-one.php');
		require_once('count-section-two.php');
		require_once('cta-one.php');
		require_once('cta-two.php');
		require_once('features-box-one.php');
		require_once('filterable-gallery-widget.php');
		require_once('home-banner-one.php');
		require_once('home-banner-two.php');
		require_once('home-banner-three.php');
		require_once('marquee-text.php');
		require_once('pricing-table-one.php');
		require_once('project-info-list.php');
		require_once('project-slider.php');
		require_once('recent-post-one.php');
		require_once('recent-post-two.php');
		require_once('section-title.php');
		require_once('service-box-one.php');
		require_once('team-and-rating-widget.php');
		require_once('team-member-one.php');
		require_once('testimonial-one.php');
		require_once('testimonial-two.php');
		require_once('video-popup.php');
		require_once('why-choose-us-section.php');
		require_once('working-process.php');
		require_once('xcency-button.php');
		require_once('xcency-tab-widget.php');

		require_once('header-elements/header-template-one.php');

		require_once('footer-elements/footer-contact-info-one.php');
		require_once('footer-elements/about-company.php');
		require_once('footer-elements/quick-links.php');
		require_once('footer-elements/footer-subscribe.php');

	}

	public function init() {
		add_action('elementor/widgets/register', array($this, 'xcency_core_add_elementor_custom_widgets'));
	}
}

Xcency_Core_Elementor_Custom_Widget::get_instance()->init();


// Add New Category In Elementor Widget
function xcency_core_elementor_widget_categories( $elements_manager ) {

	$elements_manager->add_category(
		'xcency_core_elements',
		[
			'title' => __( 'Xcency Elements', 'xcency-core' ),
		]
	);
}

add_action('elementor/elements/categories_registered', 'xcency_core_elementor_widget_categories');