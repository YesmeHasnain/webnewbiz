<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome2PortfolioSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home-2-portfolio-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 2 - Portfolio Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-post-list';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home2' ];
	}

	public function get_keywords() {
		return [ 'home2portfoliosection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}
	

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_portfolio_section',
			[
				'label' => esc_html__( 'Portfolio Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'title_sec_1',
			[
				'label' 		=> esc_html__( 'Title Section 1', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Recent' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'title_sec_2',
			[
				'label' 		=> esc_html__( 'Title Section 2', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Projects' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_btn',
			[
				'label' 		=> esc_html__( 'Text Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( 'View All' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'link_btn',
			[
				'label' 		=> esc_html__( 'Link Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( '#' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'img_pattern',
			[
				'label'       	=> esc_html__( 'Image Pattern Portfolio', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image pattern', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'post_number',
			[
				'label'       => __( 'Post Number', 'bdevs-elementor' ),
				'type'        => Controls_Manager::NUMBER,
				'placeholder' => __( 'Enter your post number', 'bdevs-elementor' ),
				'min'		  => 0,
				'default'     => __( '3', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order_by',
			[
				'label'       => __( 'Post Order By', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text post order by', 'bdevs-elementor' ),
				'default'     => __( 'ID', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
				],
				'default'   => 'desc',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-project-2-ptb pt-120 pb-150">
	<div class="container">
		<?php if (!empty($settings['title_sec_1']) || !empty($settings['title_sec_2'])): ?>
			<div class="row">
				<div class="col-lg-12">
					<div class="tp-project-2-heading mb-60">
						<?php if (!empty($settings['title_sec_1'])): ?>
							<h3 class="tp-section-title text-slide-1 pl-110"><?php echo wp_kses_post($settings['title_sec_1']); ?></h3>
						<?php endif ?>
						<?php if (!empty($settings['title_sec_2'])): ?>
							<h3 class="tp-section-title text-slide-2 pl"><?php echo wp_kses_post($settings['title_sec_2']); ?></h3>
						<?php endif ?>
					</div>
				</div>
			</div>
		<?php endif ?>
		<?php
		$wp_query = new \WP_Query([
			'post_type'      => 'portfolio',
			'posts_per_page' => intval($settings['post_number']),
			'orderby'        => sanitize_text_field($settings['post_order_by']),
			'order'          => sanitize_text_field($settings['post_order']),
		]);
		$i = 0;
		while($wp_query->have_posts()): $wp_query->the_post();
			$i++;
			$post_id = get_the_ID();

			$port_title 	= get_post_meta($post_id,'_cmb_port_title_home_2', true);
			$port_excerpt 	= get_post_meta($post_id,'_cmb_port_excerpt_home_2', true);
			$img_id1 		= get_post_meta($post_id,'_cmb_port_thumb_home_21', true);
			$img_id2 		= get_post_meta($post_id,'_cmb_port_thumb_home_22', true);

			$title = !empty($port_title) ? $port_title : get_the_title();
			$img_url1 = '';
			$img_url2 = '';

			if (!empty($img_id1)) {
				$img_url1 = wp_get_attachment_url($img_id1);
			} else {
				$img_url1 = get_the_post_thumbnail_url();
			}

			if (!empty($img_id2)) {
				$img_url2 = wp_get_attachment_url($img_id2);
			} else {
				$img_url2 = get_the_post_thumbnail_url();
			}
		?>
			<?php if ($i % 2 == 1) { ?>
				<div class="tp-project-2-wrapper pb-100">
					<div class="row align-items-center">
						<div class="col-lg-6">
							<?php if (!empty($img_url1) || !empty($img_url2)): ?>
								<div class="tp-project-2-thumb">
									<div class="tp-hover-distort-wrapper">
										<div class="canvas"></div>
										<?php if (!empty($settings['img_pattern']['url'])) { ?>
											<div class="tp-hover-distort" data-displacementImage="<?php echo esc_url($settings['img_pattern']['url']); ?>">
										<?php } else { ?>
											<div class="tp-hover-distort" data-displacementImage="<?php echo esc_url(get_template_directory_uri());?>/assets/img/others/webgl-pattern.jpg">
										<?php } ?>
												<?php if (!empty($img_url1)): ?>
													<img class="tp-hover-distort-img front" src="<?php echo esc_url($img_url1); ?>" alt="<?php the_title_attribute(); ?>">
												<?php endif ?>
												<?php if (!empty($img_url2)): ?>
													<img class="tp-hover-distort-img back" src="<?php echo esc_url($img_url2); ?>" alt="<?php the_title_attribute(); ?>">
												<?php endif ?>
											</div>
									</div>
								</div>
							<?php endif ?>
						</div>
						<div class="col-lg-6">
							<div class="tp-project-2-content tp_fade_bottom">
								<h3 class="tp-project-2-title">
									<a href="<?php the_permalink(); ?>">
										<?php echo wp_kses_post($title); ?>
									</a>
								</h3>
								<p>
									<?php if ( '' !== wp_specialchars_decode($port_excerpt)): ?>
										<?php print wp_specialchars_decode($port_excerpt); ?>
									<?php else:?>
										<?php if(isset($nixer_redux_demo['blog_excerpt'])){?>
										<?php echo esc_attr(nixer_excerpt($nixer_redux_demo['blog_excerpt'])); ?>
										<?php }else{?>
										<?php echo esc_attr(nixer_excerpt(20)); 
										}?>
									<?php endif ?>
								</p>
								<div class="tp-project-2-btn-box d-flex">
									<?php 
									$terms = get_the_terms( get_the_ID(), 'portfolio-cat' );
									if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
										foreach ( $terms as $term ) {
											$term_link = get_term_link( $term );
											if ( ! is_wp_error( $term_link ) ) {
												echo '<a href="' . esc_url( $term_link ) . '">' . esc_html( $term->name ) . '</a>';
											}
										}
									} ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			<?php } else { ?>
				<div class="tp-project-2-wrapper pb-100">
					<div class="row align-items-center">
						<div class="col-lg-6">
							<div class="tp-project-2-content two tp_fade_bottom">
								<h3 class="tp-project-2-title">
									<a href="<?php the_permalink(); ?>">
										<?php echo wp_kses_post($title); ?>
									</a>
								</h3>
								<p>
									<?php if ( '' !== wp_specialchars_decode($port_excerpt)): ?>
										<?php print wp_specialchars_decode($port_excerpt); ?>
									<?php else:?>
										<?php if(isset($nixer_redux_demo['blog_excerpt'])){?>
										<?php echo esc_attr(nixer_excerpt($nixer_redux_demo['blog_excerpt'])); ?>
										<?php }else{?>
										<?php echo esc_attr(nixer_excerpt(20)); 
										}?>
									<?php endif ?>
								</p>
								<div class="tp-project-2-btn-box d-flex">
									<?php 
									$terms = get_the_terms( get_the_ID(), 'portfolio-cat' );
									if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
										foreach ( $terms as $term ) {
											$term_link = get_term_link( $term );
											if ( ! is_wp_error( $term_link ) ) {
												echo '<a href="' . esc_url( $term_link ) . '">' . esc_html( $term->name ) . '</a>';
											}
										}
									} ?>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<?php if (!empty($img_url1) || !empty($img_url2)): ?>
								<div class="tp-project-2-thumb">
									<div class="tp-hover-distort-wrapper">
										<div class="canvas"></div>
										<?php if (!empty($settings['img_pattern']['url'])) { ?>
											<div class="tp-hover-distort" data-displacementImage="<?php echo esc_url($settings['img_pattern']['url']); ?>">
										<?php } else { ?>
											<div class="tp-hover-distort" data-displacementImage="<?php echo esc_url(get_template_directory_uri());?>/assets/img/others/webgl-pattern.jpg">
										<?php } ?>
												<?php if (!empty($img_url1)): ?>
													<img class="tp-hover-distort-img front" src="<?php echo esc_url($img_url1); ?>" alt="<?php the_title_attribute(); ?>">
												<?php endif ?>
												<?php if (!empty($img_url2)): ?>
													<img class="tp-hover-distort-img back" src="<?php echo esc_url($img_url2); ?>" alt="<?php the_title_attribute(); ?>">
												<?php endif ?>
											</div>
									</div>
								</div>
							<?php endif ?>
						</div>
					</div>
				</div>
			<?php } ?>
		<?php endwhile; ?>
		<?php if (!empty($settings['link_btn']) && !empty($settings['text_btn'])): ?>
			<div class="tp-project-2-btn text-center">
				<a class="tp-btn button-style-2" href="<?php echo wp_kses_post($settings['link_btn']); ?>">
					<?php echo wp_kses_post($settings['text_btn']); ?>
					<span>
						<svg xmlns="http://www.w3.org/2000/svg" width="19" height="16" viewBox="0 0 19 16" fill="none">
							<path d="M0 7.80933H17.6902M10.7188 0C10.7188 4.31672 14.4207 7.80972 18.9956 7.80972C14.4207 7.80972 10.7188 11.3023 10.7188 15.6191" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10"></path>
						</svg>
					</span>
				</a>
			</div>
		<?php endif ?>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery('img').imagesLoaded()
		.done(function(instance) {
		  allImagesLoaded();
		})
		.fail(function(instance) {
		  handleFailedImages(instance);
		});
		function allImagesLoaded() {
			$('.tp-hover-distort-wrapper').each(function(){
				var $this = $(this)
				var canvas = $this.find('.canvas')
				
				if($this.find('img.front')){
					$this.css({
						"width" : $this.find('img.front').width(),
						"height" : $this.find('img.front').height(),
					})
				}
				var frontImage = $this.find('img.front').attr('src')
				var backImage = $this.find('img.back').attr('src')
				var displacementImage = $this.find('.tp-hover-distort').attr('data-displacementImage')
				var distortEffect = new hoverEffect({
					parent: canvas[0],
					intensity: 3,
					speedIn: 2,
					speedOut: 2,
					angle: Math.PI / 3,
					angle2: -Math.PI / 3,
					image1: frontImage,
					image2: backImage,
					displacementImage: displacementImage,
					imagesRatio: $this.find('.tp-hover-distort').height()/$this.find('.tp-hover-distort').width()
				});
			});
		}

		function handleFailedImages(instance) {
			console.error('One or more images failed to load.');
			var failedImages = instance.images.filter(function(img) {
			return !img.isLoaded;
			});
			failedImages.forEach(function(failedImage) {
			console.error('Failed image source:', failedImage.img.src);
			});
		}
	</script>
<?php } ?>

<?php
}

}