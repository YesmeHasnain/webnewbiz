<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsTestimonialSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-testimonial-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Testimonial Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-testimonial-carousel';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-global' ];
	}

	public function get_keywords() {
		return [ 'testimonialsection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_testimonial_section',
			[
				'label' => esc_html__( 'Testimonial Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'bg_color',
			[
				'label' 		=> esc_html__( 'Background Color (Default: #121212)', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::COLOR,
				'default'		=> '#121212',
			]
		);
		$rp_counter = new \Elementor\Repeater();
		$rp_counter->add_control(
			'img_user_item',
			[
				'label'       	=> esc_html__( 'Image User Item', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image user item', 'bdevs-elementor' ),
			]
		);
		$rp_counter->add_control(
			'user_title',
			[
				'label' 		=> esc_html__( 'User Title', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_counter->add_control(
			'user_subtitle',
			[
				'label' 		=> esc_html__( 'User SubTitle', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_counter->add_control(
			'text_item',
			[
				'label' 		=> esc_html__( 'Text Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_counter->add_control(
			'num_count',
			[
				'label' 		=> esc_html__( 'Number Star Vote', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::NUMBER,
				'min' 			=> 1,
				'max' 			=> 5,
				'default' 		=> 5,
			]
		);
		$this->add_control(
			'tabs',
			[
				'label' 		=> esc_html__( 'List Testimonial Content', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $rp_counter->get_controls(),
				'default' 		=> [
					[
						
					],
				],
				'title_field' 	=> '{{{ user_title }}}',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-testimonial-team-ptb pb-140" data-bg-color="<?php echo wp_kses_post($settings['bg_color']); ?>">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12">
				<div class="tp-testimonial-team-wrapper">
					<div class="tp-testimonial-team-active swiper">
						<div class="swiper-wrapper">
							<?php
							foreach ($settings['tabs'] as $item) :
							?>
								<div class="swiper-slide">
									<div class="tp-testimonial-5-item">
										<?php if (!empty($item['img_user_item']['url']) || !empty($item['user_title']) || !empty($item['user_subtitle'])): ?>
											<div class="tp-testimonial-5-user d-flex align-items-center">
												<?php if (!empty($item['img_user_item']['url'])): ?>
													<div class="tp-testimonial-5-user-thumb">
														<img src="<?php echo wp_kses_post($item['img_user_item']['url']); ?>" alt="<?php echo wp_kses_post($item['img_user_item']['alt']); ?>">
													</div>
												<?php endif ?>
												<?php if (!empty($item['user_title']) || !empty($item['user_subtitle'])): ?>
													<div class="tp-testimonial-5-user-content">
														<?php if (!empty($item['user_title'])): ?>
															<h4 class="tp-testimonial-5-user-title"><?php echo wp_kses_post($item['user_title']); ?></h4>
														<?php endif ?>
														<?php if (!empty($item['user_subtitle'])): ?>
															<p><?php echo wp_kses_post($item['user_subtitle']); ?></p>
														<?php endif ?>
													</div>
												<?php endif ?>
											</div>
										<?php endif ?>
										<?php if (!empty($item['text_item'])): ?>
											<div class="tp-testimonial-5-item-content">
												<p><?php echo wp_kses_post($item['text_item']); ?></p>
											</div>
										<?php endif ?>
										<div class="tp-testimonial-5-item-star">
											<?php
											for ($i = 0; $i < $item['num_count']; ++$i) {
											?>
												<span>
													<svg xmlns="http://www.w3.org/2000/svg" width="23" height="23" viewBox="0 0 23 23" fill="none">
														<path d="M11.5 0L15.0535 7.56993L23 8.79127L17.25 14.6803L18.607 23L11.5 19.0699L4.393 23L5.75 14.6803L0 8.79127L7.9465 7.56993L11.5 0Z" fill="#E8BF96"/>
													</svg>
												</span>
											<?php } ?>
										</div>
									</div>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-bg-color]").each(function () {
			jQuery(this).css("background-color", jQuery(this).attr("data-bg-color"));
		});

		if (jQuery('.tp-testimonial-team-active').length > 0) {
			var slider = new Swiper('.tp-testimonial-team-active', {
				slidesPerView: 4,
				loop: true,
				spaceBetween: 30,
				breakpoints: {
					'1200': {
						slidesPerView: 4,
					},
					'992': {
						slidesPerView: 3.5,
					},
					'768': {
						slidesPerView: 2.8,
					},
					'576': {
						slidesPerView: 2,
					},
					'0': {
						slidesPerView: 1.5,
					},
				},
			});
		}
	</script>
<?php } ?>

<?php
}

}