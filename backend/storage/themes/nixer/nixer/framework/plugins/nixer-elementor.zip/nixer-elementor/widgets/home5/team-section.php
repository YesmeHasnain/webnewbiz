<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome5TeamSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home5-team-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 5 - Team Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-posts-grid';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home5' ];
	}

	public function get_keywords() {
		return [ 'home5teamsection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}
	

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_team_section',
			[
				'label' => esc_html__( 'Team Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'bg_color',
			[
				'label' 		=> esc_html__( 'Background Color (Default: #F8F8F8)', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::COLOR,
				'default'		=> '#F8F8F8',
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Explore our dynamic <br> team of experts' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_btn',
			[
				'label' 		=> esc_html__( 'Text Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'All Members' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'link_btn',
			[
				'label' 		=> esc_html__( 'Link Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '#' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'item_column',
			[
				'label'     	=> esc_html__( 'Item Column', 'bdevs-elementor' ),
				'type'      	=> Controls_Manager::SELECT,
				'options'   	=> [
					'type1'  		=> esc_html__( 'Two Columns', 'bdevs-elementor' ),
					'type2'  		=> esc_html__( 'Three Columns', 'bdevs-elementor' ),
					'type3'  		=> esc_html__( 'Four Columns', 'bdevs-elementor' ),
				],
				'default'   	=> 'type3',
			]
		);
		$this->add_control(
			'post_number',
			[
				'label'       => __( 'Post Number', 'bdevs-elementor' ),
				'type'        => Controls_Manager::NUMBER,
				'placeholder' => __( 'Enter your post number', 'bdevs-elementor' ),
				'min'		  	  => 0,
				'default'     => __( '4', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order_by',
			[
				'label'       => __( 'Post Order By', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text post order by', 'bdevs-elementor' ),
				'default'     => __( 'ID', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
				],
				'default'   => 'desc',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-team-5-ptb pb-110" data-bg-color="<?php echo wp_kses_post($settings['bg_color']); ?>">
	<div class="container container-1610">
		<?php if (!empty($settings['title_sec']) || (!empty($settings['text_btn']) && !empty($settings['link_btn']))): ?>
			<div class="row align-items-end">
				<?php if (!empty($settings['title_sec'])): ?>
					<div class="col-lg-7">
						<div class="tp-team-5-heading mb-90">
							<h3 class="tp-section-5-title tp-title-anim"><?php echo wp_kses_post($settings['title_sec']); ?></h3>
						</div>
					</div>
				<?php endif ?>
				<?php if (!empty($settings['link_btn']) && !empty($settings['text_btn'])): ?>
					<div class="col-lg-5">
						<div class="tp-team-5-btn text-start text-lg-end mb-90">
							<div class="tp-practice-item-btn">
								<a href="<?php echo wp_kses_post($settings['link_btn']); ?>">
									<?php echo wp_kses_post($settings['text_btn']); ?>
									<span>
										<svg width="19" height="16" viewBox="0 0 19 16" fill="none" xmlns="http://www.w3.org/2000/svg">
											<path d="M0 7.68652H17.6902M10.7188 0C10.7188 4.25031 14.4207 7.68957 18.9956 7.68957M18.9956 7.68652C14.4207 7.68652 10.7188 11.1258 10.7188 15.3761" stroke="#121212" stroke-width="1.5" stroke-miterlimit="10"/>
										</svg>
									</span>
								</a>
							</div>
						</div>
					</div>
				<?php endif ?>
			</div>
		<?php endif ?>
		<div class="row tp-gx-40">
			<?php
			$wp_query = new \WP_Query([
				'post_type'      => 'team',
				'posts_per_page' => intval($settings['post_number']),
				'orderby'        => sanitize_text_field($settings['post_order_by']),
				'order'          => sanitize_text_field($settings['post_order']),
			]);

			$column_class = match ($settings['item_column']) {
				'type1' => 'col-xxl-6 col-lg-6 col-md-6',
				'type2' => 'col-xxl-4 col-lg-4 col-md-6',
				default => 'col-xxl-3 col-lg-4 col-md-6',
			};

			$i = 0;
			while ($wp_query->have_posts()) : $wp_query->the_post();
				$i++;
				$post_id = get_the_ID();

				$custom_title = get_post_meta($post_id, '_cmb_team_title_home_5', true);
				$img_id       = get_post_meta($post_id, '_cmb_team_thumb_home_5', true);

				$title = !empty($custom_title) ? $custom_title : get_the_title();
				$thumbnail_url = '';

				if (!empty($img_id)) {
					$thumbnail_url = wp_get_attachment_image_url($img_id, 'full');
				} elseif (has_post_thumbnail()) {
					$thumbnail_url = get_the_post_thumbnail_url($post_id, 'full');
				} else {
					$thumbnail_url = get_template_directory_uri() . '/assets/img/team/home-5/team-5-1.jpg';
				} ?>
				<div class="<?php echo esc_attr($column_class); ?>">
					<div class="tp-team-5-item text-center mb-30">
						<div class="tp-team-5-item-thumb">
							<a href="<?php the_permalink(); ?>">
								<img src="<?php echo esc_url($thumbnail_url); ?>" alt="<?php the_title_attribute(); ?>">
							</a>
						</div>
						<div class="tp-team-5-item-content">
							<h4 class="tp-team-5-item-title">
								<a href="<?php the_permalink(); ?>"><?php echo wp_kses_post($title); ?></a>
							</h4>
							<p>
								<?php
								$terms = get_the_terms(get_the_ID(), 'team-job');
								if ($terms && !is_wp_error($terms)) {
								    echo esc_html($terms[0]->name);
								} ?>
							</p>
						</div>
					</div>
				</div>
			<?php endwhile; ?>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-bg-color]").each(function () {
			jQuery(this).css("background-color", jQuery(this).attr("data-bg-color"));
		});

		if ($('.tp-team-5-heading .tp-title-anim').length > 0) {
			var splitTitleLines = gsap.utils.toArray(".tp-team-5-heading .tp-title-anim");
			splitTitleLines.forEach(splitTextLine => {
				var tl = gsap.timeline({
				scrollTrigger: {
					trigger: splitTextLine,
					start: 'top 90%',
					end: 'bottom 60%',
					scrub: false,
					markers: false,
					toggleActions: 'play none none none'
				}
				});
	
				var itemSplitted = new SplitText(splitTextLine, { type: "words, lines" });
				gsap.set(splitTextLine, { perspective: 300});
				itemSplitted.split({ type: "lines" })
				tl.from(itemSplitted.lines, { duration: 1, delay: 0.3, opacity: 0, rotationX: -50, force3D: true, transformOrigin: "top center -50", stagger: 0.2 });
			});	
		}
	</script>
<?php } ?>

<?php
}

}