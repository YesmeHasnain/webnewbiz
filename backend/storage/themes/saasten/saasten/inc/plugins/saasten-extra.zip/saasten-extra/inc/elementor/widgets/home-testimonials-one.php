<?php

/**
 * Elementor Widget
 * @package Saasten
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_home_testimonial_one extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'theme-testimonial-one';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Home Testimonials 1', 'saasten-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saasten_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {




      $this->start_controls_section( 'section_content_test_inner_one', [
            'label' => esc_html__( 'Title Content', 'saasten-extra' ),
        ] ); 


        $this->add_control( 'subtitle', [
            'label'       => __( 'Sub Title', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => __( 'About Us', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type section subtitle here.", 'saasten-extra' ),
        ] );

        $this->add_control( 'title', [
            'label'       => __( 'Title', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Invest in Startup', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type section title here.", 'saasten-extra' ),

        ] );


        $this->end_controls_section();


        $this->start_controls_section( 'section_content_tstmonials_one', [
            'label' => esc_html__( 'Testimonial Item Content', 'saasten-extra' ),
        ] );

        $this->add_control( 'sliderItems', [
            'label'       => esc_html__( 'Testimonial Items', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'default'     => [
                [
                    'author-name'        => esc_html__( 'Daniel', 'saasten-extra' ),
                ]
            ],

            'fields'      => [
                [
                    'name'        => 'testimonial-content',
                    'label'       => esc_html__( 'Testimonial Content', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'description' => esc_html__( 'Enter Testimonial Content', 'saasten-extra' )
                ],
            
                
                [
                    'name'        => 'author-name',
                    'label'       => esc_html__( 'Reviewer Name', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXT,
                    'default'     => __( 'Aristo Melmon', 'saasten-extra' ),
                    'description' => esc_html__( 'Enter Reviewer Name', 'saasten-extra' )
                ],

                [
                    'name'        => 'author-position',
                    'label'       => esc_html__( 'Reviewer Position', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXT,
                    'default'     => __( 'Designer', 'saasten-extra' ),
                    'description' => esc_html__( 'Enter Reviewer Position', 'saasten-extra' )
                ],

                [
                    'name'        => 'author-location',
                    'label'       => esc_html__( 'Reviewer Location', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXT,
                    'default'     => __( 'London', 'saasten-extra' ),
                    'description' => esc_html__( 'Enter Reviewer Position', 'saasten-extra' )
                ],

                [
                    'name'        => 'author-image',
                    'label'       => esc_html__( 'Author Image', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                    ],
                    'description' => esc_html__( 'Upload author image', 'saasten-extra' )
                ],
                


            ],
            'title_field' => "{{name}}"
        ] );

        $this->end_controls_section(); 

		
	}
	


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

        $slider_items = $settings['sliderItems'];

        extract($settings); 


		
		?>




    <!-- Testimonial Slides -->
    <section class="section-padding black-bg saastain-bg__cover">
      <div class="container">
        <div class="row">
          <div class="col-12 mg-btm-40">
            <!-- Section Title -->
            <div class="section-title-v3 text-center" data-aos="fade-in">
              <p class="section-title-v3__label text-white mg-btm-20">
                <?php echo wp_kses_post( $settings['subtitle'] ); ?>
              </p>
              <h2
                class="section-title-v3__title text-white m-0 saastain-gsap-anim2"
              >
               <?php echo wp_kses_post( $settings['title'] ); ?>
              </h2>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12" data-aos="fade-in">
            <!-- Sponsor Slide -->
            <div class="testimonial-g-slide align-items-center">


              <?php
                  foreach ( $slider_items as $item ):
              ?>                     

              <div class="single-slide">
                <!-- Feedback Area -->
                <div
                  class="single-feedback single-feedback__v2 single-feedback__modify"
                >
                  <div class="single-feedback__content">
                    <div
                      class="saastain-flex__space saastain-flex-gap-10 mg-btm-25"
                    >
                      <!-- feedback author -->
                      <div class="single-feedback__author p-0 m-0">
                        <div class="flex-shrink-0">
                          <img src="<?php echo esc_url( $item['author-image']['url'] ); ?>" alt="#" />
                        </div>
                        <div class="flex-shrink-0">
                          <h4 class="single-feedback__author-name">
                            <?php echo esc_html( $item['author-name'] ); ?>
                          </h4>
                          <p class="single-feedback__author-postion">
                            <?php echo esc_html( $item['author-position'] ); ?>
                          </p>
                        </div>
                      </div>
                      <span><img src="<?php echo SAASTEN_IMG ."/quote-iconv3.svg"; ?>" /></span>
                    </div>
                    <p class="offwhite-color m-0">

                      <?php echo wp_kses_post( $item['testimonial-content'] ); ?>

                    </p>
                    <div
                      class="saastain-flex__space saastain-flex-gap-10 mg-top-20 flex-wrap"
                    >
                      <div
                        class="d-flex gap-4 justify-content-between align-items-center flex-wrap"
                      >
                        <p class="inline-line-bar"><?php echo esc_html( $item['author-location'] ); ?></p>
                      </div>
                      <div
                        class="ratting-icons saastain-flex-start saastain-flex-gap-10"
                      >
                        <span class="yellow-text"
                          ><i class="fas fa-star"></i
                        ></span>
                        <span class="yellow-text"
                          ><i class="fas fa-star"></i
                        ></span>
                        <span class="yellow-text"
                          ><i class="fas fa-star"></i
                        ></span>
                        <span class="yellow-text"
                          ><i class="fas fa-star"></i
                        ></span>
                        <span class="yellow-text"
                          ><i class="fas fa-star"></i
                        ></span>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- End Feedback Area -->
              </div>


              <?php endforeach; ?> 



            </div>
            <!-- End Sponsor Slide -->


          </div>
        </div>
      </div>
    </section>
    <!-- End Testimonial Slides -->




	

	<?php 


	}
				

}

