<?php

/**

 * Seacab Footer Contact Info

 *

 *

 * @author 		TwinkleTheme

 * @category 	Widgets

 * @package 	seacab/Widgets

 * @version 	1.0.0

 * @extends 	WP_Widget

 */



add_action('widgets_init', function(){

	register_widget('Twinkle_footer_contact_info');

});



class Twinkle_footer_contact_info  extends WP_Widget{

	

	public function __construct(){

		parent::__construct('Twinkle_footer_contact_info',esc_html__('Seacab Footer Contact Info', 'twinkle-core'),array(

			'description' => esc_html__('Seacab Footer Contact Info by Seacab', 'twinkle-core'),

		));

	}

	

	public function widget($args, $instance){

		extract($args);

		extract($instance);

		



			print $before_widget; 

								

			if ( ! empty( $title ) ) {

				print $before_title . apply_filters( 'widget_title', $title ) . $after_title;

			}

			

			?>



				<div class="footer-contact-info">

					<ul>

						<?php 

						if($address): ?>

							<li>

								<div class="icon">

									<i class="fas fa-map-marker-alt"></i>

								</div>

								<span> <?php print esc_html($address); ?></span>

							</li>

						<?php 

						endif; ?>



						<?php 

						if($email): ?>

							<li>

								<div class="icon">

									<i class="far fa-envelope"></i>

								</div>

								<span> <?php print esc_html($email); ?></span>

							</li>

						<?php 

						endif; ?>



						<?php 

						if($phone_number): ?>

							<li>

								<div class="icon">

									<i class="fas fa-phone-alt"></i>

								</div>

								<span> <?php print esc_html($phone_number); ?></span>

							</li>

						<?php 

						endif; ?>  



						<?php 

						if($website): ?>

							<li>

								<div class="icon">

									<i class="fas fa-globe"></i>

								</div>

								<span> <?php print esc_html($website); ?></span>

							</li>

						<?php 

						endif; ?> 	

					</ul>

				</div>



			<?php print $after_widget; ?>

		<?php 

	}

	



	/**

	 * widget function.

	 *

	 * @see WP_Widget

	 * @access public

	 * @param array $instance

	 * @return void

	 */

	public function form($instance){



		$title  = isset($instance['title'])? $instance['title']:'';

		$address  = isset($instance['address'])? $instance['address']:'';

		$email  = isset($instance['email'])? $instance['email']:'';

		$phone_number  = isset($instance['phone_number'])? $instance['phone_number']:'';

		$website  = isset($instance['website'])? $instance['website']:'';

		

		?>



		<p>

			<label for="title"><?php esc_html_e('Title:','twinkle-core'); ?></label>

			<input type="text" id="<?php print esc_attr($this->get_field_id('title')); ?>"  name="<?php print esc_attr($this->get_field_name('title')); ?>" class="widefat" value="<?php print esc_attr($title); ?>">

		</p>



		<p>

			<label for="title"><?php esc_html_e('Address:','twinkle-core'); ?></label>

			<input type="text" id="<?php print esc_attr($this->get_field_id('address')); ?>"  name="<?php print esc_attr($this->get_field_name('address')); ?>" class="widefat" value="<?php print esc_attr($address); ?>">

		</p>



		<p>

			<label for="title"><?php esc_html_e('Email Address:','twinkle-core'); ?></label>

			<input type="text" id="<?php print esc_attr($this->get_field_id('email')); ?>"  name="<?php print esc_attr($this->get_field_name('email')); ?>" class="widefat" value="<?php print esc_attr($email); ?>">

		</p>



		<p>

			<label for="title"><?php esc_html_e('Phone Number:','twinkle-core'); ?></label>

			<input type="text" id="<?php print esc_attr($this->get_field_id('phone_number')); ?>"  name="<?php print esc_attr($this->get_field_name('phone_number')); ?>" class="widefat" value="<?php print esc_attr($phone_number); ?>">

		</p>



		<p>

			<label for="title"><?php esc_html_e('Website Url:','twinkle-core'); ?></label>

			<input type="text" id="<?php print esc_attr($this->get_field_id('website')); ?>"  name="<?php print esc_attr($this->get_field_name('website')); ?>" class="widefat" value="<?php print esc_attr($website); ?>">

		</p>

		

		<?php

	}

			

	public function update( $new_instance, $old_instance ) {

		$instance = array();

		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

		$instance['address'] = ( ! empty( $new_instance['address'] ) ) ? strip_tags( $new_instance['address'] ) : '';

		$instance['email'] = ( ! empty( $new_instance['email'] ) ) ? strip_tags( $new_instance['email'] ) : '';

		$instance['phone_number'] = ( ! empty( $new_instance['phone_number'] ) ) ? strip_tags( $new_instance['phone_number'] ) : '';

		$instance['website'] = ( ! empty( $new_instance['website'] ) ) ? strip_tags( $new_instance['website'] ) : '';



		return $instance;

	}

}