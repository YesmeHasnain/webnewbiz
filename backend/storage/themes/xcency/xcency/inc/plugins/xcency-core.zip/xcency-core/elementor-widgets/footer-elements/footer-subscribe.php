<?php
namespace Elementor;

class Xcency_Footer_Subscribe_Widget extends Widget_Base {

	public function get_name() {
		return 'xcency_footer_subscribe';
	}

	public function get_title() {
		return esc_html__( 'Footer Subscribe', 'xcency-core' );
	}

	public function get_icon() {
		return 'eicon-form-horizontal';
	}

	public function get_categories() {
		return [ 'xcency_elements' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'subscribe_widget',
			[
				'label' => esc_html__( 'Subscribe Options', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'xcency-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 5,
				'default'     => __( 'Subscribe Newsletter', 'xcency-core' ),
			]
		);

		$this->add_control(
			'desc',
			[
				'label' => esc_html__( 'Description', 'xcency-core' ),
				'type' => Controls_Manager::TEXTAREA,
				'rows' => 5,
				'default' => 'Subscribe our newsletter to get more updates ',
			]
		);

		$this->add_control(
			'subscribe_form',
			[
				'label'       => __( 'Subscribe Form Shortcode', 'xcency-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
			]
		);

        $this->add_control(
            'social_media_title',
            [
                'label'       => esc_html__( 'Social Media Title', 'xcency-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => esc_html__( 'Social Media', 'xcency-core' ),
            ]
        );

		$repeater = new Repeater();

		$repeater->add_control(
			'selected_social_icon',
			[
				'label'            => esc_html__( 'Select Icon', 'xcency-core' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fab fa-facebook-f',
					'library' => 'brands',
				],
			]
		);

		$repeater->add_control(
			'profile_url',
			[
				'label'         => __( 'Profile URL', 'xcency-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'xcency-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '#',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'socials',
			[
				'label'       => __( 'Social Profile List', 'xcency-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'selected_social_icon' => 'fab fa-facebook-f',
					],
				],
				'title_field' => '<i class="{{{selected_social_icon.value}}}"></i>',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'title!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typo',
				'label' => esc_html__( 'Typography', 'xcency-core' ),
				'selector' => '{{WRAPPER}} .widget-title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'       => esc_html__('Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .widget-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_margin',
			[
				'label'      => esc_html__( 'Title Margin', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .widget-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'about_company_desc_style',
			[
				'label' => esc_html__( 'Description', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'desc_typo',
				'label' => esc_html__( 'Typography', 'xcency-core' ),
				'selector' => '{{WRAPPER}} .subscribe-desc',
			]
		);

		$this->add_control(
			'desc_color',
			[
				'label'       => esc_html__('Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .subscribe-desc' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'desc_margin',
			[
				'label'      => esc_html__( 'Description Margin', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .subscribe-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Start Social section
		$this->start_controls_section(
			'xcency_social_style_options',
			[
				'label' => esc_html__('Social Icons', 'xcency-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
            'social_title_color',
            [
                'label'       => esc_html__('Title Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .social-media-title' => 'color: {{VALUE}};',
                ],
            ]
        );

		$this->start_controls_tabs('xcency_social_style_tabs');

		//Default style tab start
		$this->start_controls_tab(
			'xcency_social_style_default',
			[
				'label' => esc_html__('Default', 'xcency-core'),
			]
		);

		$this->add_control(
			'icon_default_color',
			[
				'label'     => esc_html__('Color', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .footer-social-icon li a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();//Default style tab end

		//Hover style tab start
		$this->start_controls_tab(
			'xcency_social_style_hover',
			[
				'label' => esc_html__('Hover', 'xcency-core'),
			]
		);

		$this->add_control(
			'icon_hover_color',
			[
				'label'     => esc_html__('Color', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .footer-social-icon li a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tabs();//Hover style tab end

		$this->end_controls_section();// End Social section

		$this->start_controls_section(
			'subscribe_color_style',
			[
				'label' => esc_html__( 'Subscribe Form', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'subscribe_bg_color',
			[
				'label'       => esc_html__('Form Background', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-subscribe-form input[type="email"]' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'subscribe_border_color',
			[
				'label'       => esc_html__('Form Border Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-subscribe-form input[type="email"]' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'subscribe_hover_border_color',
			[
				'label'       => esc_html__('Form Focus Border Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-subscribe-form input[type="email"]:focus' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'subscribe_placeholder',
			[
				'label'       => esc_html__('Subscribe Placeholder Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-subscribe-form ::placeholder' => 'color: {{VALUE}};',
					'{{WRAPPER}} .xcency-subscribe-form :-ms-input-placeholder' => 'color: {{VALUE}};',
					'{{WRAPPER}} .xcency-subscribe-form ::-ms-input-placeholder' => 'color: {{VALUE}};',

				],
			]
		);

		$this->add_control(
			'subscribe_text_color',
			[
				'label'       => esc_html__('Subscribe Text Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-subscribe-form input[type="email"]' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_bg_color',
			[
				'label'       => esc_html__('Button Background', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-subscribe-button input[type="submit"]' => 'background-color: {{VALUE}};border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_text_color',
			[
				'label'       => esc_html__('Button Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-subscribe-button input[type="submit"]' => 'color: {{VALUE}};',
				],
			]
		);



		$this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<div class="xcency-elementor-widget widget footer_subscribe_widget">
			<?php if ($settings['title']) : ?>
				<h4 class="widget-title"><?php echo $settings['title'];?></h4>
			<?php endif; ?>

			<div class="subscribe-desc">
				<?php echo $settings['desc'];?>
			</div>

			<div class="xcency-subscribe-form">
				<?php echo do_shortcode( esc_html($settings['subscribe_form']));?>
			</div>

            <div class="social-media-wrapper">
                <div class="social-media-title"><?php echo $settings['social_media_title'];?></div>

                <ul class="widget-social-icons footer-social-icon xcency-list-inline">
		            <?php if ( $settings['socials'] ) {
			            foreach ( $settings['socials'] as $social ) {
				            $profile_url = $social['profile_url']['url'];
				            $target      = $social['profile_url']['is_external'] ? ' target="_blank"' : '';
				            $nofollow    = $social['profile_url']['nofollow'] ? ' rel="nofollow"' : '';
				            ?>
                            <li>
                                <a href="<?php echo $profile_url; ?>" <?php echo $target . $nofollow ?>>

                                    <i class="<?php echo $social['selected_social_icon']['value']; ?>"></i>
                                </a>
                            </li>
			            <?php }
		            } ?>
                </ul>
            </div>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new Xcency_Footer_Subscribe_Widget );