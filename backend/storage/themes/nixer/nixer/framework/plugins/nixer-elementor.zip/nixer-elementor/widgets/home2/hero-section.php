<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome2HeroSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home2-hero-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 2 - Hero Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-featured-image';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home2' ];
	}

	public function get_keywords() {
		return [ 'home2herosection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_hero_section',
			[
				'label' => esc_html__( 'Hero Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'bg_color',
			[
				'label' 		=> esc_html__( 'Background Color (Default: #ffffff)', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::COLOR,
				'default'		=> '#ffffff',
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Creative Agency Studio Creative Agency Studio' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'img_left_sec',
			[
				'label'       	=> esc_html__( 'Image Left Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image left section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'img_shape_sec',
			[
				'label'       	=> esc_html__( 'Image Shape Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image shape section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'hero_text_right',
			[
				'label' 		=> esc_html__( 'Hero Text Right', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'From Concept to Creation <br> Beautiful design has the <br> power to captivate <br> audiences.' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_social = new \Elementor\Repeater();
		$rp_social->add_control(
			'rp_social_text',
			[
				'label'       	=> __( 'Text Item', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::TEXTAREA,
				'placeholder' 	=> __( 'Enter your text item', 'bdevs-elementor' ),
				'default'     	=> __( '', 'bdevs-elementor' ),
				'label_block' 	=> true,
			]
		);
		$rp_social->add_control(
			'rp_social_link',
			[
				'label'       	=> __( 'Link Item', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::TEXTAREA,
				'placeholder' 	=> __( 'Enter your link item', 'bdevs-elementor' ),
				'default'     	=> __( '', 'bdevs-elementor' ),
				'label_block' 	=> true,
			]
		);
		$this->add_control(
			'tab_social',
			[
				'label' 		=> esc_html__( 'List Social Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $rp_social->get_controls(),
				'default' 		=> [
					[
					],
				],
				'title_field' 	=> '{{{ rp_social_text }}}',
			]
		);
		$this->end_controls_section();


		$this->start_controls_section(
			'section_content_hero_down',
			[
				'label' => esc_html__( 'Hero Down Smooth', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'show_hero_down_smooth',
			[
				'label'   => esc_html__( 'Show Hero Down Smooth', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'text_btn',
			[
				'label' 		=> esc_html__( 'Text Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Keep <br> Scrolling' , 'bdevs-elementor' ),
				'show_label' 	=> true,
				'condition' 	=> [
					'show_hero_down_smooth' 	=> 'yes',
				],
			]
		);
		$this->add_control(
			'link_btn',
			[
				'label' 		=> esc_html__( 'Link Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '#down' , 'bdevs-elementor' ),
				'show_label' 	=> true,
				'condition' 	=> [
					'show_hero_down_smooth' 	=> 'yes',
				],
			]
		);
		$this->end_controls_section();


		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-hero-2-ptb fix pt-170 pb-100 p-relative" data-bg-color="<?php echo wp_kses_post($settings['bg_color']); ?>">
	<?php if (!empty($settings['title_sec'])): ?>
		<div class="tp-hero-2-text-sliding pb-50">
			<div class="tp-hero-2-text-scroll-hr">
				<div class="tp-hero-2-text-scroll-wrap">
					<h3 class="tp-hero-2-text-title"><?php echo wp_kses_post($settings['title_sec']); ?></h3>
				</div>
			</div>
		</div>
	<?php endif ?>
	<div class="container container-1800">
		<div class="row align-items-center">
			<div class="col-lg-6">
				<div class="tp-hero-2-thumb p-relative">
					<?php if (!empty($settings['img_left_sec']['url'])): ?>
						<div class="tp_img_reveal">
							<img src="<?php echo wp_kses_post($settings['img_left_sec']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_left_sec']['alt']); ?>">
						</div>
					<?php endif ?>
					<?php if (!empty($settings['img_shape_sec']['url'])): ?>
						<div class="tp-hero-2-shape">
							<img src="<?php echo wp_kses_post($settings['img_shape_sec']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_shape_sec']['alt']); ?>">
						</div>
					<?php endif ?>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="tp-hero-2-content tp_fade_bottom">
					<?php if (!empty($settings['hero_text_right'])): ?>
						<h4 class="tp-hero-2-title"><?php echo wp_kses_post($settings['hero_text_right']); ?></h4>
					<?php endif ?>
					<?php if (!empty($settings['tab_social'])): ?>
						<div class="tp-hero-2-btn-box">
							<div class="tp-project-2-btn-box d-flex">
								<?php
								foreach ($settings['tab_social'] as $item) :
								?>
									<?php if (!empty($item['rp_social_link']) && !empty($item['rp_social_text'])): ?>
										<a href="<?php echo wp_kses_post($item['rp_social_link']); ?>">
											<?php echo wp_kses_post($item['rp_social_text']); ?>
										</a>
									<?php endif ?>
								<?php endforeach; ?>
							</div>
						</div>
					<?php endif ?>
				</div>
			</div>
		</div>
	</div>
	<?php if (!empty($settings['show_hero_down_smooth'])): ?>
		<div class="tp-hero-2-down smooth">
			<?php if (!empty($settings['link_btn']) && !empty($settings['text_btn'])): ?>
				<a href="<?php echo wp_kses_post($settings['link_btn']); ?>" class="d-flex align-items-center">
					<div class="tp-hero-down-text">
						<span><?php echo wp_kses_post($settings['text_btn']); ?></span>
					</div>
					<div class="tp-hero-down-icon">
						<span>
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="72" viewBox="0 0 16 72" fill="none">
								<path d="M16 63C11.578 63 7.99989 66.5781 7.99989 71C7.99989 66.5781 4.42196 63 0 63M7.30078 1H8.80078V71H7.30078V1Z" stroke="#19191A" stroke-width="1.5" stroke-miterlimit="10"/>
							</svg>
						</span>
					</div>
				</a>
			<?php endif ?>
		</div>
	<?php endif ?>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-bg-color]").each(function () {
			jQuery(this).css("background-color", jQuery(this).attr("data-bg-color"));
		});

		var tp_img_reveal = document.querySelectorAll(".tp_img_reveal");

		tp_img_reveal.forEach((img_reveal) => {
			var image = img_reveal.querySelector("img");
			var tl = gsap.timeline({
				scrollTrigger: {
					trigger: img_reveal,
					start: "top 70%",
				}
			});

			tl.set(img_reveal, { autoAlpha: 1 });
			tl.from(img_reveal, 1.5, {
				xPercent: -100,
				ease: Power2.out
			});
			tl.from(image, 1.5, {
				xPercent: 100,
				scale: 1.5,
				duration: 3,
				delay: -1.5,
				ease: Power2.out
			});
		});

		gsap.set(".tp_fade_bottom", { y: 100, opacity: 0 });
		var fadeArray = gsap.utils.toArray(".tp_fade_bottom")
		fadeArray.forEach((item, i) => {
			var fadeTl = gsap.timeline({
				scrollTrigger: {
					trigger: item,
					start: "top center+=400",
				}
			})
			fadeTl.to(item, {
				y: 0,
				opacity: 1,
				ease: "power2.out",
				duration: 1.5,
			})
		})

	</script>
<?php } ?>

<?php
}

}