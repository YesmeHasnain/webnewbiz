<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Group_Control_Border;
/**
 *
 * Gallery Widget .
 *
 */
class Barab_Gallery extends Widget_Base {

	public function get_name() {
		return 'barabgallery';
	}
	public function get_title() {
		return __( 'Gallery', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'gallery_section',
			[
				'label' 	=> __( 'Gallery', 'barab' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        ); 

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two', 'Style Three', 'Style Four', 'Style Five', 'Style Six' ] ); 

		barab_general_fields($this, 'title', 'Section Title', 'TEXTAREA', 'Instagram', ['5', '6'] );

		$repeater = new Repeater();

		barab_media_fields($repeater, 'image', 'Choose Image');

		$this->add_control(
			'gallery_lists',
			[
				'label' 		=> __( 'Gallery Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'condition'	=> [
					'layout_style' => ['1', '3', '4']
				]
			]
		);

		$repeater = new Repeater();

		barab_media_fields($repeater, 'image', 'Choose Image');
		barab_general_fields($repeater, 'icon', 'Icon', 'TEXT', '');

		$this->add_control(
			'gallery_lists2',
			[
				'label' 		=> __( 'Gallery Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'condition'	=> [
					'layout_style' => ['2', '5', '6']
				]
			]
		);

		$this->end_controls_section();

		//---------------------------------------
			//Style Section Start
		//---------------------------------------


	}

	protected function render() {

	$settings = $this->get_settings_for_display();

		if( $settings['layout_style'] == '1' ){
			echo '<div class="slider-area">';
                echo '<div class="slider-area-wrap" data-mask-src="'.BARAB_ASSETS.'img/bg/gallery-1-mask.png">';
                    echo '<div class="swiper th-slider has-shadow gallery-1-slider" id="gallerySlider1" data-slider-options=\'{"breakpoints":{"0":{"slidesPerView":1},"576":{"slidesPerView":"1"},"768":{"slidesPerView":"1"},"992":{"slidesPerView":"2"},"1200":{"slidesPerView":"3"}}, "loop":true, "autoHeight": "true"}\'>';
                        echo '<div class="swiper-wrapper">';
							foreach ( $settings['gallery_lists'] as $data ){
								echo '<div class="swiper-slide">';
									echo '<div class="gallery-thumb-1">';
										echo barab_img_tag( array(
											'url'   => esc_url( $data['image']['url'] ),
										));
										echo '<a href="'.esc_url( $data['image']['url'] ).'" class="gallery-btn popup-image"> <img src="'.BARAB_ASSETS.'img/icon/plus-icon.svg" alt="img"> </a>';
									echo '</div>';
								echo '</div>';
							}
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
                echo '<button data-slider-prev="#gallerySlider1" class="slider-arrow slider-prev">';
					echo '<img src="'.BARAB_ASSETS.'img/icon/left-arrow.svg" alt="'.esc_attr__('Arrow', 'barab').'">';
				echo '</button>';
                echo '<button data-slider-next="#gallerySlider1" class="slider-arrow slider-next">';
					echo '<img src="'.BARAB_ASSETS.'img/icon/right-arrow.svg" alt="'.esc_attr__('Arrow', 'barab').'">';
				echo '</button>';
            echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
  			echo '<div class="slider-area"> ';
                echo '<div class="swiper th-slider instsSlider2" id="instsSlider2" data-slider-options=\'{"autoplay":true,"centeredSlides":"true","loop":true,"breakpoints":{"0":{"slidesPerView":1},"400":{"slidesPerView":"1"},"768":{"slidesPerView":"2"},"992":{"slidesPerView":"3"},"1200":{"slidesPerView":"4"},"1400":{"slidesPerView":"5"}}}\'>';
                    echo '<div class="swiper-wrapper">';
						foreach ( $settings['gallery_lists2'] as $data ){
							echo '<div class="swiper-slide">';
								echo '<div class="insta-item">';
									echo '<div class="thumb">';
										echo barab_img_tag( array(
											'url'   => esc_url( $data['image']['url'] ),
										));
										echo '<a href="'.esc_url( $data['image']['url'] ).'"" class=" icon popup-image">'.wp_kses_post($data['icon']).'</a>';
									echo '</div>';
								echo '</div>';
							echo '</div>';
						}
                    echo '</div>';
                echo '</div>';
            echo '</div>';

		}elseif( $settings['layout_style'] == '3' ){
			echo '<div class="row gy-4">';
				foreach ( $settings['gallery_lists'] as $data ){
					echo '<div class="col-lg-4 col-md-6">';
						echo '<div class="gallery-thumb-1 style-2">';
							echo barab_img_tag( array(
								'url'   => esc_url( $data['image']['url'] ),
							));
							echo '<a href="'.esc_url( $data['image']['url'] ).'" class="gallery-btn popup-image"> <img src="'.BARAB_ASSETS.'img/icon/plus-icon.svg" alt="img"> </a>';
						echo '</div>';
					echo '</div>';
				}
			echo '</div>';

		}elseif( $settings['layout_style'] == '4' ){
			echo '<div class="row gy-4">';
				foreach ( $settings['gallery_lists'] as $data ){
					echo '<div class="col-lg-4 col-md-4 col-sm-4">';
						echo '<div class="signature-dishes-thumb">';
						 	echo '<div class="thumb bg-mask" style="mask-image: url('.BARAB_ASSETS.'img/bg/menu-1-msk-bg.jpg);">';
								echo barab_img_tag( array(
									'url'   => esc_url( $data['image']['url'] ),
								));
							echo '</div>';
						echo '</div>';
					echo '</div>';
				}
			echo '</div>';

		}elseif( $settings['layout_style'] == '5' ){
			if(!empty($settings['title'])){
				echo '<div class="big-title3-wrap insta3-title style-2">';
					echo '<h4 class="big-title3-title">'.esc_html($settings['title']).'</h4>';
				echo '</div>';
			}
            echo '<div class="row gy-4 ">';
                echo '<div class="insta-2-items-wrap">';
					foreach ( $settings['gallery_lists2'] as $key => $data ) {
						// Item 0 and 1: single items
						if ($key == 0 || $key == 1) {
							echo '<div class="insta-item wow fadeinup">';
								echo '<div class="thumb">';
									echo barab_img_tag( array(
										'url' => esc_url( $data['image']['url'] ),
									));
									echo '<a href="'.esc_url( $data['image']['url'] ).'" class="icon popup-image">'.wp_kses_post($data['icon']).'</a>';
								echo '</div>';
							echo '</div>';
						}
						// Item 2 & 3: grouped inside one wrapper
						if ($key == 2) {
							echo '<div class="insta-item-wrapper">';
						}
						if ($key == 2 || $key == 3) {
							echo '<div class="insta-item wow fadeinup">';
								echo '<div class="thumb">';
									echo barab_img_tag( array(
										'url' => esc_url( $data['image']['url'] ),
									));
									echo '<a href="'.esc_url( $data['image']['url'] ).'" class="icon popup-image">'.wp_kses_post($data['icon']).'</a>';
								echo '</div>';
							echo '</div>';
						}
						if ($key == 3) {
							echo '</div>'; // close insta-item-wrapper
						}
						// Items after 3: single items again
						if ($key > 3) {
							echo '<div class="insta-item wow fadeinup">';
								echo '<div class="thumb">';
									echo barab_img_tag( array(
										'url' => esc_url( $data['image']['url'] ),
									));
									echo '<a href="'.esc_url( $data['image']['url'] ).'" class="icon popup-image">'.wp_kses_post($data['icon']).'</a>';
								echo '</div>';
							echo '</div>';
						}
					}
                echo '</div>';
           	echo' </div>';

		}elseif( $settings['layout_style'] == '6' ){
			if(!empty($settings['title'])){
				echo '<div class="big-title3-wrap insta3-title style-2">';
					echo '<h4 class="big-title3-title">'.esc_html($settings['title']).'</h4>';
				echo '</div>';
			}
            echo '<div class="row gy-4 ">';
				foreach ( $settings['gallery_lists2'] as $data ){
					echo '<div class="col-lg-3 col-md-6 insta-item3-wrap">';
						echo ' <div class="insta-item style2 wow fadeinup">';
							echo '<div class="thumb">';
								echo barab_img_tag( array(
									'url'   => esc_url( $data['image']['url'] ),
								));
								echo '<a href="'.esc_url( $data['image']['url'] ).'" class="icon popup-image">'.wp_kses_post($data['icon']).'</a>';
							echo '</div>';
						echo '</div>';
					echo '</div>';
				}
            echo '</div>';

		}

		
	}

}