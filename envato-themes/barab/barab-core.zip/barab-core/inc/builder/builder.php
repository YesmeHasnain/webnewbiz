<?php
    /**
     * Class For Builder
     */
    class BarabBuilder{

        function __construct(){
            // register admin menus
        	add_action( 'admin_menu', [$this, 'register_settings_menus'] );

            // Custom Footer Builder With Post Type
			add_action( 'init',[ $this,'post_type' ],0 );

 		    add_action( 'elementor/frontend/after_enqueue_scripts', [ $this,'widget_scripts'] );

			add_filter( 'single_template', [ $this, 'load_canvas_template' ] );

            add_action( 'elementor/element/wp-page/document_settings/after_section_end', [ $this,'barab_add_elementor_page_settings_controls' ],10,2 );

		}

		public function widget_scripts( ) {
			wp_enqueue_script( 'barab-core',BARAB_PLUGDIRURI.'assets/js/barab-core.js',array( 'jquery' ),'1.0',true );
		}


        public function barab_add_elementor_page_settings_controls( \Elementor\Core\DocumentTypes\Page $page ){

			$page->start_controls_section(
                'barab_header_option',
                [
                    'label'     => __( 'Header Option', 'barab' ),
                    'tab'       => \Elementor\Controls_Manager::TAB_SETTINGS,
                ]
            );


            $page->add_control(
                'barab_header_style',
                [
                    'label'     => __( 'Header Option', 'barab' ),
                    'type'      => \Elementor\Controls_Manager::SELECT,
                    'options'   => [
    					'prebuilt'             => __( 'Pre Built', 'barab' ),
    					'header_builder'       => __( 'Header Builder', 'barab' ),
    				],
                    'default'   => 'prebuilt',
                ]
			);

            $page->add_control(
                'barab_header_builder_option',
                [
                    'label'     => __( 'Header Name', 'barab' ),
                    'type'      => \Elementor\Controls_Manager::SELECT,
                    'options'   => $this->barab_header_choose_option(),
                    'condition' => [ 'barab_header_style' => 'header_builder'],
                    'default'	=> ''
                ]
            );

            $page->end_controls_section();

            $page->start_controls_section(
                'barab_footer_option',
                [
                    'label'     => __( 'Footer Option', 'barab' ),
                    'tab'       => \Elementor\Controls_Manager::TAB_SETTINGS,
                ]
            );
            $page->add_control(
    			'barab_footer_choice',
    			[
    				'label'         => __( 'Enable Footer?', 'barab' ),
    				'type'          => \Elementor\Controls_Manager::SWITCHER,
    				'label_on'      => __( 'Yes', 'barab' ),
    				'label_off'     => __( 'No', 'barab' ),
    				'return_value'  => 'yes',
    				'default'       => 'yes',
    			]
    		);
            $page->add_control(
                'barab_footer_style',
                [
                    'label'     => __( 'Footer Style', 'barab' ),
                    'type'      => \Elementor\Controls_Manager::SELECT,
                    'options'   => [
    					'prebuilt'             => __( 'Pre Built', 'barab' ),
    					'footer_builder'       => __( 'Footer Builder', 'barab' ),
    				],
                    'default'   => 'prebuilt',
                    'condition' => [ 'barab_footer_choice' => 'yes' ],
                ]
            );
            $page->add_control(
                'barab_footer_builder_option',
                [
                    'label'     => __( 'Footer Name', 'barab' ),
                    'type'      => \Elementor\Controls_Manager::SELECT,
                    'options'   => $this->barab_footer_build_choose_option(),
                    'condition' => [ 'barab_footer_style' => 'footer_builder','barab_footer_choice' => 'yes' ],
                    'default'	=> ''
                ]
            );

			$page->end_controls_section();

        }

		public function register_settings_menus(){
			add_menu_page(
				esc_html__( 'Barab Builder', 'barab' ),
            	esc_html__( 'Barab Builder', 'barab' ),
				'manage_options',
				'barab',
				[$this,'register_settings_contents__settings'],
				'dashicons-admin-site',
				2
			);

			add_submenu_page('barab', esc_html__('Footer Builder', 'barab'), esc_html__('Footer Builder', 'barab'), 'manage_options', 'edit.php?post_type=barab_footerbuild');
			add_submenu_page('barab', esc_html__('Header Builder', 'barab'), esc_html__('Header Builder', 'barab'), 'manage_options', 'edit.php?post_type=barab_header');
			add_submenu_page('barab', esc_html__('Tab Builder', 'barab'), esc_html__('Tab Builder', 'barab'), 'manage_options', 'edit.php?post_type=barab_tab_builder');
			add_submenu_page('barab', esc_html__('Megamenu', 'barab'), esc_html__('Megamenu', 'barab'), 'manage_options', 'edit.php?post_type=barab_megamenu');
		}

		// Callback Function
		public function register_settings_contents__settings(){
            echo '<h2>';
			    echo esc_html__( 'Welcome To Header, Footer and Megamenu Builder Of This Theme','barab' );
            echo '</h2>';
		}

		public function post_type() {

			$labels = array(
				'name'               => __( 'Footer', 'barab' ),
				'singular_name'      => __( 'Footer', 'barab' ),
				'menu_name'          => __( 'Barab Footer Builder', 'barab' ),
				'name_admin_bar'     => __( 'Footer', 'barab' ),
				'add_new'            => __( 'Add New', 'barab' ),
				'add_new_item'       => __( 'Add New Footer', 'barab' ),
				'new_item'           => __( 'New Footer', 'barab' ),
				'edit_item'          => __( 'Edit Footer', 'barab' ),
				'view_item'          => __( 'View Footer', 'barab' ),
				'all_items'          => __( 'All Footer', 'barab' ),
				'search_items'       => __( 'Search Footer', 'barab' ),
				'parent_item_colon'  => __( 'Parent Footer:', 'barab' ),
				'not_found'          => __( 'No Footer found.', 'barab' ),
				'not_found_in_trash' => __( 'No Footer found in Trash.', 'barab' ),
			);

			$args = array(
				'labels'              => $labels,
				'public'              => true,
				'rewrite'             => false,
				'show_ui'             => true,
				'show_in_menu'        => false,
				'show_in_nav_menus'   => false,
				'exclude_from_search' => true,
				'capability_type'     => 'post',
				'hierarchical'        => false,
				'supports'            => array( 'title', 'elementor' ),
			);

			register_post_type( 'barab_footerbuild', $args );

			$labels = array(
				'name'               => __( 'Header', 'barab' ),
				'singular_name'      => __( 'Header', 'barab' ),
				'menu_name'          => __( 'Barab Header Builder', 'barab' ),
				'name_admin_bar'     => __( 'Header', 'barab' ),
				'add_new'            => __( 'Add New', 'barab' ),
				'add_new_item'       => __( 'Add New Header', 'barab' ),
				'new_item'           => __( 'New Header', 'barab' ),
				'edit_item'          => __( 'Edit Header', 'barab' ),
				'view_item'          => __( 'View Header', 'barab' ),
				'all_items'          => __( 'All Header', 'barab' ),
				'search_items'       => __( 'Search Header', 'barab' ),
				'parent_item_colon'  => __( 'Parent Header:', 'barab' ),
				'not_found'          => __( 'No Header found.', 'barab' ),
				'not_found_in_trash' => __( 'No Header found in Trash.', 'barab' ),
			);

			$args = array(
				'labels'              => $labels,
				'public'              => true,
				'rewrite'             => false,
				'show_ui'             => true,
				'show_in_menu'        => false,
				'show_in_nav_menus'   => false,
				'exclude_from_search' => true,
				'capability_type'     => 'post',
				'hierarchical'        => false,
				'supports'            => array( 'title', 'elementor' ),
			);

			register_post_type( 'barab_header', $args );

			$labels = array(
				'name'               => __( 'Tab Builder', 'barab' ),
				'singular_name'      => __( 'Tab Builder', 'barab' ),
				'menu_name'          => __( 'Gesund Tab Builder', 'barab' ),
				'name_admin_bar'     => __( 'Tab Builder', 'barab' ),
				'add_new'            => __( 'Add New', 'barab' ),
				'add_new_item'       => __( 'Add New Tab Builder', 'barab' ),
				'new_item'           => __( 'New Tab Builder', 'barab' ),
				'edit_item'          => __( 'Edit Tab Builder', 'barab' ),
				'view_item'          => __( 'View Tab Builder', 'barab' ),
				'all_items'          => __( 'All Tab Builder', 'barab' ),
				'search_items'       => __( 'Search Tab Builder', 'barab' ),
				'parent_item_colon'  => __( 'Parent Tab Builder:', 'barab' ),
				'not_found'          => __( 'No Tab Builder found.', 'barab' ),
				'not_found_in_trash' => __( 'No Tab Builder found in Trash.', 'barab' ),
			);

			$args = array(
				'labels'              => $labels,
				'public'              => true,
				'rewrite'             => false,
				'show_ui'             => true,
				'show_in_menu'        => false,
				'show_in_nav_menus'   => false,
				'exclude_from_search' => true,
				'capability_type'     => 'post',
				'hierarchical'        => false,
				'supports'            => array( 'title', 'elementor' ),
			);

			register_post_type( 'barab_tab_builder', $args );

			$labels = array(
				'name'               => __( 'Megamenu', 'barab' ),
				'singular_name'      => __( 'Megamenu', 'barab' ),
				'menu_name'          => __( 'barab Megamenu', 'barab' ),
				'name_admin_bar'     => __( 'Megamenu', 'barab' ),
				'add_new'            => __( 'Add New', 'barab' ),
				'add_new_item'       => __( 'Add New Megamenu', 'barab' ),
				'new_item'           => __( 'New Megamenu', 'barab' ),
				'edit_item'          => __( 'Edit Megamenu', 'barab' ),
				'view_item'          => __( 'View Megamenu', 'barab' ),
				'all_items'          => __( 'All Megamenu', 'barab' ),
				'search_items'       => __( 'Search Megamenu', 'barab' ),
				'parent_item_colon'  => __( 'Parent Megamenu:', 'barab' ),
				'not_found'          => __( 'No Megamenu found.', 'barab' ),
				'not_found_in_trash' => __( 'No Megamenu found in Trash.', 'barab' ),
			);

			$args = array(
				'labels'              => $labels,
				'public'              => true,
				'rewrite'             => false,
				'show_ui'             => true,
				'show_in_menu'        => false,
				'show_in_nav_menus'   => false,
				'exclude_from_search' => true,
				'capability_type'     => 'post',
				'hierarchical'        => false,
				'supports'            => array( 'title', 'elementor' ),
			);

			register_post_type( 'barab_megamenu', $args );
			
		}

		function load_canvas_template( $single_template ) {

			global $post;

			if ( 'barab_footerbuild' == $post->post_type || 'barab_header' == $post->post_type || 'barab_tab_build' == $post->post_type ) {

				$elementor_2_0_canvas = ELEMENTOR_PATH . '/modules/page-templates/templates/canvas.php';

				if ( file_exists( $elementor_2_0_canvas ) ) {
					return $elementor_2_0_canvas;
				} else {
					return ELEMENTOR_PATH . '/includes/page-templates/canvas.php';
				}
			}

			return $single_template;
		}

        public function barab_footer_build_choose_option(){

			$barab_post_query = new WP_Query( array(
				'post_type'			=> 'barab_footerbuild',
				'posts_per_page'	    => -1,
			) );

			$barab_builder_post_title = array();
			$barab_builder_post_title[''] = __('Select a Footer','barab');

			while( $barab_post_query->have_posts() ) {
				$barab_post_query->the_post();
				$barab_builder_post_title[ get_the_ID() ] =  get_the_title();
			}
			wp_reset_postdata();

			return $barab_builder_post_title;

		}

		public function barab_header_choose_option(){

			$barab_post_query = new WP_Query( array(
				'post_type'			=> 'barab_header',
				'posts_per_page'	    => -1,
			) );

			$barab_builder_post_title = array();
			$barab_builder_post_title[''] = __('Select a Header','barab');

			while( $barab_post_query->have_posts() ) {
				$barab_post_query->the_post();
				$barab_builder_post_title[ get_the_ID() ] =  get_the_title();
			}
			wp_reset_postdata();

			return $barab_builder_post_title;

        }

    }

    $builder_execute = new BarabBuilder();