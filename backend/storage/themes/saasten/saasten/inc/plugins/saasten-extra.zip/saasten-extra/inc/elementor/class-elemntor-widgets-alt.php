<?php 

/**
 * All Elementor widget init
 * @package Saasten
 * @since 1.0.0
 */

function register_elementor_extra_widgets( $widgets_manager ) {



    //require_once( SAASTEN_EXTRA_ELEMENTOR . '/widgets/feature-box.php' );
	require_once( SAASTEN_EXTRA_ELEMENTOR . '/widgets/home-blog-column.php' );
    require_once( SAASTEN_EXTRA_ELEMENTOR . '/widgets/home-banner-one.php' );
    require_once( SAASTEN_EXTRA_ELEMENTOR . '/widgets/home-about-section-one.php' );
    require_once( SAASTEN_EXTRA_ELEMENTOR . '/widgets/home-title-slide.php' );
    require_once( SAASTEN_EXTRA_ELEMENTOR . '/widgets/home-services-section.php' );
    require_once( SAASTEN_EXTRA_ELEMENTOR . '/widgets/home-pricing-section.php' );
    require_once( SAASTEN_EXTRA_ELEMENTOR . '/widgets/home-about-section-two.php' );
    require_once( SAASTEN_EXTRA_ELEMENTOR . '/widgets/home-testimonials-one.php' );
    require_once( SAASTEN_EXTRA_ELEMENTOR . '/widgets/home-banner-two.php' );

    require_once( SAASTEN_EXTRA_ELEMENTOR . '/widgets/home-brands-section.php' );
    require_once( SAASTEN_EXTRA_ELEMENTOR . '/widgets/home-services-section-two.php' );
    require_once( SAASTEN_EXTRA_ELEMENTOR . '/widgets/home-about-section-three.php' );
    require_once( SAASTEN_EXTRA_ELEMENTOR . '/widgets/home-overview.php' );

    require_once( SAASTEN_EXTRA_ELEMENTOR . '/widgets/home-counter.php' );
    require_once( SAASTEN_EXTRA_ELEMENTOR . '/widgets/home-about-section-video.php' );

    require_once( SAASTEN_EXTRA_ELEMENTOR . '/widgets/home-overview-two.php' );
    require_once( SAASTEN_EXTRA_ELEMENTOR . '/widgets/home-team.php' );

    require_once( SAASTEN_EXTRA_ELEMENTOR . '/widgets/home-faq.php' );
    require_once( SAASTEN_EXTRA_ELEMENTOR . '/widgets/home-contact-boxes.php' );

    require_once( SAASTEN_EXTRA_ELEMENTOR . '/widgets/home-contact-form.php' );
    require_once( SAASTEN_EXTRA_ELEMENTOR . '/widgets/home-integrations-section.php' );

    require_once( SAASTEN_EXTRA_ELEMENTOR . '/widgets/home-package-section.php' );


    
    
    
    
    

    //$widgets_manager->register( new \theme_feature_box_one() );
	$widgets_manager->register( new \theme_home_blog_grid() );
    $widgets_manager->register( new \theme_banner_one() );
    $widgets_manager->register( new \theme_home_about_one() );
    $widgets_manager->register( new \theme_home_next_one() );
    $widgets_manager->register( new \theme_home_services_one() );
    $widgets_manager->register( new \theme_home_pricing_one() );
    $widgets_manager->register( new \theme_home_about_two() );
    $widgets_manager->register( new \theme_home_testimonial_one() );
    $widgets_manager->register( new \theme_banner_two() );

    $widgets_manager->register( new \theme_home_brands_one() );
    $widgets_manager->register( new \theme_home_services_two() );
    $widgets_manager->register( new \theme_home_about_three() );
    $widgets_manager->register( new \theme_home_overview_one() );

    $widgets_manager->register( new \theme_home_counter_one() );
    $widgets_manager->register( new \theme_home_about_video() );

    $widgets_manager->register( new \theme_home_overview_two() );

    $widgets_manager->register( new \theme_home_team_one() );

    $widgets_manager->register( new \theme_home_faq_one() );
    
    $widgets_manager->register( new \theme_home_contact_one() );

    $widgets_manager->register( new \theme_home_contact_form() );
    $widgets_manager->register( new \theme_home_integrations() );
    
    $widgets_manager->register( new \theme_home_package() );
    
    
    


}


add_action( 'elementor/widgets/register', 'register_elementor_extra_widgets' );



/**
 * Saasten Elementor _widget_categories()
 * @since 1.0.0
 * */


function saasten_elementor_widget_categories($elements_manager) {

    $elements_manager->add_category(
        'saasten_widgets',
        [
            'title' => __('Saasten Widgets', 'saasten-extra'),
        ]
    );

}

add_action('elementor/elements/categories_registered', 'saasten_elementor_widget_categories');