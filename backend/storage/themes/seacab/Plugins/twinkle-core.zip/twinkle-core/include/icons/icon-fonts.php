<?php
    	
// Append new icons
$twinkle_icons = array(
	'icon-university',
	'icon-settings',
	'icon-focus',
	'icon-book',
	'icon-grocery',
	'icon-analytics',
	'icon-conversation',
	'icon-telephone',
	'icon-envelope',
	'icon-location',
	'icon-happiness',
	'icon-completed-task',
	'icon-partner',
	'icon-award-1',
	'icon-plus-sign',
	'icon-link',
); 

return $twinkle_icons;