<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
/**
 *
 * Image Widget .
 *
 */
class barab_Animated_Shape extends Widget_Base {

	public function get_name() {
		return 'barabshapeimage';
	}
	public function get_title() {
		return __( 'Animated Image', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'image_section',
			[
				'label' 	=> __( 'Image', 'barab' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', ['Style One'] );    

        $this->add_control(
			'image',
			[
				'label' 		=> __( 'Choose Image', 'barab' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
			]
		);
		$this->add_control(
			'effect_style',
			[
				'label' 		=> esc_html__( 'Add Styling Attributes', 'barab' ),
				'type' 			=> \Elementor\Controls_Manager::SELECT,
				'options' 		=> [
					'jump'  			=> esc_html__( 'Jump Effect', 'barab' ),
					'jump-reverse'  	=> esc_html__( 'Jump Reverse Effect', 'barab' ),
					'moving'  			=> esc_html__( 'Moving Effect', 'barab' ),
					'movingX'  			=> esc_html__( 'Moving Reverse Effect(X)', 'barab' ),
					'spin'			=> esc_html__( 'Spin Effect', 'barab' ),
					'pulse'			=> esc_html__( 'Pulse Effect', 'barab' ),
					'rotate-x'			=> esc_html__( 'Rotate Effect', 'barab' ),
					''			=> esc_html__( 'No Effect', 'barab' ),
				],
				'default' => [ 'jump'],
			]
		);
		$this->add_control(
			'from_top',
			[
				'label' 		=> __( 'Top', 'barab' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ '%', 'px' ],
				'range' => [
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
				],
			]
		);
		$this->add_control(
			'from_left',
			[
				'label' 		=> __( 'Left', 'barab' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' => [ '%', 'px' ],
				'range' 		=> [
					'%' 			=> [
						'min' 			=> 0,
						'max' 			=> 100,
					],
				],
				'default' => [
					'unit' => '%',
				],
			]
		);
		$this->add_control(
			'from_right',
			[
				'label' 		=> __( 'Right', 'barab' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' => [ '%', 'px' ],
				'range' 		=> [
					'%' 			=> [
						'min' 			=> 0,
						'max' 			=> 100,
					],
				],
				'default' => [
					'unit' => '%',
				],
			]
		);
		$this->add_control(
			'from_bottom',
			[
				'label' 		=> __( 'Bottom', 'barab' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' => [ '%', 'px' ],
				'range' 		=> [
					'%' 			=> [
						'min' 			=> 0,
						'max' 			=> 100,
					],
				],
				'default' => [
					'unit' => '%',
				],
			]
		);
		$this->add_control(
			'responsive_style',
			[
				'label' 		=> esc_html__( 'Responsive Styling', 'barab' ),
				'type' 			=> \Elementor\Controls_Manager::SELECT2,
				'label_block' 	=> true,
				'multiple' 		=> true,
				'options' 		=> [
					'd-xxl-block'  		=> esc_html__( 'Hide From Extra large Device (xxl)', 'barab' ),
					'd-xl-block'  		=> esc_html__( 'Hide From large Device (xl)', 'barab' ),
					'd-lg-block'  		=> esc_html__( 'Hide From Tablet (lg)', 'barab' ),
					'd-md-block'  		=> esc_html__( 'Hide From Mobile (md)', 'barab' ),
					'd-sm-block'  		=> esc_html__( 'D Small Device (sm)', 'barab' ),
					'd-none'  			=> esc_html__( 'Display None', 'barab' ),
					' '  				=> esc_html__( 'Default', 'barab' ),
				],
			]
		);
		$this->add_control(
			'image_class', [
				'label' 		=> __( 'Image Wrap Class Name', 'barab' ),
				'description' 		=> __( 'Need to add image wrapper class name', 'barab' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'label_block' 	=> true,
			]
        );
		$this->add_control(
			'image_class2', [
				'label' 		=> __( 'Image Class Name', 'barab' ),
				'description' 		=> __( 'Need to add image class name', 'barab' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'label_block' 	=> true,
				'condition'		=> [ 
					'layout_style' => [ '1' ]
				],
			]
        );

        $this->end_controls_section();

	}

	protected function render() {

        $settings = $this->get_settings_for_display();

        $this->add_render_attribute('wrapper','class','shape-mockup');
		if(!empty($settings['image_class'])){
			$this->add_render_attribute('wrapper','class', $settings['image_class']);
		}
        $this->add_render_attribute('wrapper','class', $settings['effect_style']);
        $this->add_render_attribute('wrapper','class', $settings['responsive_style']);

	    if($settings['from_top']['size']){
	        $this->add_render_attribute( 'wrapper', 'data-top', $settings['from_top']['size'] . $settings['from_top']['unit'] );
	    }
		if($settings['from_bottom']['size']){
	        $this->add_render_attribute( 'wrapper', 'data-bottom', $settings['from_bottom']['size'] . $settings['from_bottom']['unit'] );
	    }
	    if($settings['from_right']['size']){
	        $this->add_render_attribute( 'wrapper', 'data-right', $settings['from_right']['size'] . $settings['from_right']['unit'] );
	    }
	    if($settings['from_left']['size']){
	        $this->add_render_attribute( 'wrapper', 'data-left', $settings['from_left']['size'] . $settings['from_left']['unit'] );
	    }

		if( $settings['layout_style'] == '2' ){
			$this->add_render_attribute('wrapper','data-mask-src',  $settings['image']['url']);
		}

		if( $settings['layout_style'] == '1' ){
			if( !empty( $settings['image']['id'] ) ) {
				echo '<!-- Image -->';
					echo '<div '.$this->get_render_attribute_string('wrapper').'>';
						echo '<img class="'.esc_attr($settings['image_class2']).'" src="'.esc_url( $settings['image']['url']).'" alt="'.esc_attr__('Shape Image', 'barab').'" >';
					echo '</div>';
				echo '<!-- End Image -->';
			}
		}
		
	}
}