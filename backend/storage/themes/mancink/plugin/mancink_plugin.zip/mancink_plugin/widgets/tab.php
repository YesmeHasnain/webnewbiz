<?php

namespace MancinkPlugin\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Utils;
use Elementor\Repeater;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Border;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Background;

if (!defined('ABSPATH')) exit; // Exit if accessed directly



/**
 * @since 1.1.0
 */
class Mancink_Tab extends Widget_Base
{

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.1.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name()
	{
		return 'mancink-tab';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.1.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title()
	{
		return __('Mancink Tabs', 'mancink_plugin');
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.1.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon()
	{
		return 'fa fa-indent';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.1.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories()
	{
		return ['mancink-elements'];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.1.0
	 *
	 * @access protected
	 */
	protected function _register_controls()
	{

		$this->start_controls_section(
			'section_content',
			[
				'label' => __('Tab Settings', 'mancink_plugin'),
			]
		);

		$tabs = new \Elementor\Repeater();

		$this->add_control(
			'notes',
			[
				'label' => __( 'Please note, if you are using the Elementor Template for the tab content, not every elementor element is supported inside the tab content.', 'mancink_plugin' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$tabs->add_control(
			'name',
			[
				'label' => __('Tab Name Title', 'mancink_plugin'),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => __('Tab Name..', 'mancink_plugin'),
			]
		);

		$tabs->add_control(
			'tc_text',
			[
				'label' => __('Tab Name Text', 'mancink_plugin'),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => __('Tab Text..', 'mancink_plugin'),
			]
		);
		$tabs->add_control(
			'selected_icon',
			[
				'label' => __('Icon for tab name. Leave it blank if you don\'t want it.', 'elementor'),
				'type' => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
			]
		);

		$tabs->add_control(
			'more_options',
			[
				'label' => __( 'You can use the elementor template for the tab content.', 'mancink_plugin' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$tabs->add_control(
            'use_template',
            [
                'label' => __('Use Elementor Template', 'mancink_plugin'),
                'type' => Controls_Manager::SELECT,
                'default' => 'no',
                'options' => [
					'yes'  => __( 'Yes', 'mancink_plugin' ),
					'no' => __( 'No', 'mancink_plugin' ),
				],
            ]
        );


		$tabs->add_control(
			'elementor_template',
			[
				'label'   => __('Choose the template', 'mancink_plugin'),
                'type'    => Controls_Manager::SELECT, 
                'options' => choose_template_elementor(),
				'condition' => [
					'use_template' => 'yes',
				],
			]
		);

		

		$tabs->add_control(
			'title',
			[
				'label' => __('Tab Content Title', 'mancink_plugin'),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => __('Tab Title..', 'mancink_plugin'),
				'condition' => [
					'use_template' => 'no',
				],
			]
		);
		$tabs->add_control(
			'text',
			[
				'label' => __('Tab Content Text', 'mancink_plugin'),
				'type' => Controls_Manager::WYSIWYG,
				'label_block' => true,
				'placeholder' => __('Tab Text..', 'mancink_plugin'),
				'condition' => [
					'use_template' => 'no',
				],
			]
		);

		$tabs->add_control(
			'image',
			[
				'label' => __('Tab Content Image', 'mancink_plugin'),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'use_template' => 'no',
				],
			]
		);

		$tabs->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name' => 'image2', // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `image_size` and `image_custom_dimension`.
				'default' => 'large',
				'separator' => 'none',
				'condition' => [
					'use_template' => 'no',
				],
			]
		);

		
		$this->add_control(
			'tabs_list',
			[
				'label' => __('Tab List', 'mancink_plugin'),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'name' => 'Tab Name',
						'title' => 'Tab Title',
						'text' => 'Tab Text',
					],
					[
						'name' => 'Tab Name',
						'title' => 'Tab Title',
						'text' => 'Tab Text',
					],
					[
						'name' => 'Tab Name',
						'title' => 'Tab Title',
						'text' => 'Tab Text',
					]
				],
				'fields' => $tabs->get_controls(),
				'title_field' => '{{ name }}',
			]
		);

		$this->add_control(
			'tab_select',
			[
				'label' => __( 'Seperate Tab Name Title and Icon', 'mancink_plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'no',
				'label_on' => __( 'Yes', 'mancink_plugin' ),
				'label_off' => __( 'No', 'mancink_plugin' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'tab_style',
			[
				'label' => __( 'Strecth Table name', 'mancink_plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'no',
				'label_on' => __( 'Yes', 'mancink_plugin' ),
				'label_off' => __( 'No', 'mancink_plugin' ),
				'return_value' => 'yes',
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label' => __('Tab Name Alignment', 'mancink_plugin'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __('Left', 'mancink_plugin'),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __('Center', 'mancink_plugin'),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __('Right', 'mancink_plugin'),
						'icon' => 'fa fa-align-right',
					]
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .rdn-tab-list li' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'tc_align',
			[
				'label' => __('Tab Content Alignment', 'mancink_plugin'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __('Left', 'mancink_plugin'),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __('Center', 'mancink_plugin'),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __('Right', 'mancink_plugin'),
						'icon' => 'fa fa-align-right',
					]
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .rdn-tab-content' => 'text-align: {{VALUE}};',
				],
			]
		);
		
		$this->add_control(
			'notes_templating',
			[
				'label' => __( 'If you\'re using the elementor template for tab content, you can edit the tab content in the elementor template editor.  WordPress dashboard->Templates and choose the template.', 'mancink_plugin' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'name_settings',
			[
				'label' => __('Tab Name Setting', 'mancink_plugin'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'name_color',
			[
				'label' => __('Title Color', 'mancink_plugin'),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .rdn-tab-list li h3' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'name_color_active',
			[
				'label' => __('Title Color on active state', 'mancink_plugin'),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .rdn-tab-list li .active h3' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'tc_text_color',
			[
				'label' => __('Text Color', 'mancink_plugin'),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .rdn-tab-list li span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'tc_text_color_active',
			[
				'label' => __('Text Color on active state', 'mancink_plugin'),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .rdn-tab-list li .active span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'name_typography',
				'label'     => __('Tab Name Title Typography', 'mancink_plugin'),
				'selector'  => '{{WRAPPER}} .rdn-tab-list h3',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'tc_text_typography',
				'label'     => __('Tab Name Text Typography', 'mancink_plugin'),
				'selector'  => '{{WRAPPER}} .rdn-tab-list span',
			]
		);
		$this->add_responsive_control(
			'title_text_margin',
			[
				'label' => __( 'Tab Name Title Margin', 'mancink_plugin' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .rdn-tab-list h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		

		$this->add_responsive_control(
			'tc_text_margin',
			[
				'label' => __( 'Tab Name Text Margin', 'mancink_plugin' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .rdn-tab-list span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_margin',
			[
				'label' => __( 'Tab Name Margin', 'mancink_plugin' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .rdn-tab-list a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'link_padding',
			[
				'label' => __( 'Tab Name Padding', 'mancink_plugin' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .rdn-tab-list a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'tb_bg_settings',
			[
				'label' => __('Tab Name Background', 'mancink_plugin'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'tab_name_bg',
				'label' => __('Tab Name Background', 'mancink_plugin'),
				'types' => ['classic', 'gradient'],
				'selector' => '{{WRAPPER}} .rdn-tab-link',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'tb_bg_settings_active',
			[
				'label' => __('Tab Name Background on Active State', 'mancink_plugin'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'tab_name_bg_active',
				'label' => __('Tab Name Background in Active state', 'mancink_plugin'),
				'types' => ['classic', 'gradient'],
				'selector' => '{{WRAPPER}} .active.rdn-tab-link',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'border_settings',
			[
				'label' => __('Tab Name Border', 'mancink_plugin'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'icon_bordering',
				'placeholder' => '1px',
				'default' => '',
				'selector' => '{{WRAPPER}} .rdn-tab-link',
				'separator' => 'before',
			]
		);


		$this->add_responsive_control(
			'icon_radius',
			[
				'label' => __( 'Border Radius', 'mancink_plugin' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .rdn-tab-link' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		
		$this->end_controls_section();

		$this->start_controls_section(
			'border_settings_active',
			[
				'label' => __('Tab Name Border on active', 'mancink_plugin'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'icon_bordering_active',
				'placeholder' => '1px',
				'default' => '',
				'selector' => '{{WRAPPER}} .active.rdn-tab-link',
				'separator' => 'before',
			]
		);


		$this->add_responsive_control(
			'icon_radius_active',
			[
				'label' => __( 'Border Radius', 'mancink_plugin' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .active.rdn-tab-link' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		
		$this->end_controls_section();

		$this->start_controls_section(
			'icon_settings',
			[
				'label' => __('Icon Setting', 'mancink_plugin'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'icon_size',
			[
				'label' => __('Icon Size', 'mancink_plugin'),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' =>0,
						'max' => 300,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .rdn-tab-list i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_width_size',
			[
				'label' => __('Icon Background Width & Height Size', 'mancink_plugin'),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' =>0,
						'max' => 300,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .rdn-tab-list i' => 'width: {{SIZE}}{{UNIT}};height:{{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_lh_size',
			[
				'label' => __('Icon Line Height', 'mancink_plugin'),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' =>0,
						'max' => 300,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .rdn-tab-list i' => 'line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_align',
			[
				'label' => __('Icon Alignment', 'mancink_plugin'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __('Left', 'mancink_plugin'),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __('Center', 'mancink_plugin'),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __('Right', 'mancink_plugin'),
						'icon' => 'fa fa-align-right',
					]
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .rdn-tab-list i' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label' => __('Icon  Color', 'mancink_plugin'),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .rdn-tab-list i' => 'color: {{VALUE}};',
				],
			]
		); 
		$this->add_control(
			'icon_color_active',
			[
				'label' => __('Icon  Color on active state', 'mancink_plugin'),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .rdn-tab-list .active i' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_tn_border',
			[
				'label' => __('Border Radius', 'mancink_plugin'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => [
					'{{WRAPPER}} .mancink-tabicon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_tn_margin',
			[
				'label' => __('Margin', 'mancink_plugin'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => [
					'{{WRAPPER}} .mancink-tabicon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->add_control(
			'icon_tcbg_color',
			[
				'label' => __('Background Color', 'mancink_plugin'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .mancink-tabicon' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_tc_active_color',
			[
				'label' => __('Background Color on active state', 'mancink_plugin'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .active .mancink-tabicon' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'icon_tc_bordering',
				'placeholder' => '1px',
				'default' => '',
				'selector' => '{{WRAPPER}} .mancink-tabicon',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'icon_tc_boder_active_color',
			[
				'label' => __('Border Color on active state', 'mancink_plugin'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .active .mancink-tabicon' => 'border-color: {{VALUE}};',
				],
			]
		);
		

		$this->end_controls_section();



	

		$this->start_controls_section(
			'tab_content',
			[
				'label' => __('Tab Content Settings', 'mancink_plugin'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_control(
			'notes_tab',
			[
				'label' => __( 'Some of the settings only affect for the tab content that not using the elementor template.', 'mancink_plugin' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'tab_content_margin',
			[
				'label' => __( 'Tab Content Margin', 'mancink_plugin' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .tab-inner' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'tab_content_padding',
			[
				'label' => __( 'Tab Content Padding', 'mancink_plugin' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .tab-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'title_tc_color',
			[
				'label' => __('Color', 'mancink_plugin'),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .rdn-tab-ct .content-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'title_tc_typography',
				'label'     => __('Title Typography', 'mancink_plugin'),
				'selector'  => '{{WRAPPER}} .rdn-tab-ct .content-title',
			]
		);

		$this->add_responsive_control(
			'title_tc_margin',
			[
				'label' => __( 'Title Margin', 'mancink_plugin' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .rdn-tab-ct .content-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_tc_padding',
			[
				'label' => __( 'Title Padding', 'mancink_plugin' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .rdn-tab-ct .content-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'text_tc_typography',
				'label'     => __('Text Typography', 'mancink_plugin'),
				'selector'  => '{{WRAPPER}} .rdn-tab-ct .tab-inner p',
			]
		);


		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'content_bg_color',
				'label' => __('Content Background', 'mancink_plugin'),
				'types' => ['classic', 'gradient'],
				'selector' => '{{WRAPPER}} .tab-inner',
			]
		);
		
		$this->end_controls_section();



	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.1.0
	 *
	 * @access protected
	 */
	protected function render()
	{
		$settings = $this->get_settings();
		$tab_id = substr( $this->get_id_int(), 0, 3 );
		?>


		<div id="tab-<?php echo $tab_id ?>" class="rdn-tab clearfix" >
		<ul class="rdn-tab-list <?php if($settings['tab_select'] == 'yes'){echo 'tab-seperated';}?> <?php if($settings['tab_style'] == 'yes'){echo 'tab-flex';}?>">
			<?php 
			$i = 0;
			foreach ($settings['tabs_list'] as $index => $item) : ?>
            
                <li>
                    <a class="rdn-tab-link <?php if ($i == 0){echo 'active';}?>" href="#" data-tab="#tab<?php echo $i; ?>" data-id="#tab-<?php echo $tab_id ?>">
						<?php 
						$migrated = isset($item['__fa4_migrated']['selected_icon']);
						$is_new = empty($item['icon']) && Icons_Manager::is_migration_allowed();
						if (!empty($item['icon']) || !empty($item['selected_icon']['value'])) :  if ($is_new || $migrated) :
							Icons_Manager::render_icon($item['selected_icon'], ['class' => 'mancink-tabicon']);
						else : ?>
							<i class="mancink-tabicon <?php echo esc_attr($item['icon']); ?>" aria-hidden="true"></i>
						<?php endif;
						endif;?>
						<div class="tb-name clearfix">
							<h3><?php echo  $item['name']; ?></h3>
							<?php if ($item['tc_text'] != ''){ ?>
							<span><?php echo  $item['tc_text']; ?></span>
							<?php }?>
						</div>
					</a>
                </li>
			
			<?php 
			$i++;
			endforeach; ?>
			</ul>

			<div class="rdn-tab-content">
				<?php 
				$i = 0;
				foreach ($settings['tabs_list'] as $index => $item) : ?>
                <div id='tab<?php echo $i; ?>' class='rdn-tab-ct <?php if ($i == 0){echo 'active';}?>'>
					<div class="tab-inner clearfix">
						<div class="row">
							<?php if ($item['use_template'] == 'yes') {
								echo \Elementor\Plugin::$instance->frontend->get_builder_content_for_display($item['elementor_template'], false); 
							}else { ?>
								<div class="col-md-6">
									<?php echo Group_Control_Image_Size::get_attachment_image_html($item, 'image2', 'image'); ?>
								</div>
								<div class="col-md-6">
									<h2 class="content-title"><?php echo  $item['title']; ?></h2>
									<?php echo  $item['text']; ?>
								</div>
							<?php } ?>
						</div>
                    </div>
                </div>
                <?php 
				$i++;
				endforeach; ?>
            </div>
		</div>
		<!--/.tab-->


<?php
}

/**
 * Render the widget output in the editor.
 *
 * Written as a Backbone JavaScript template and used to generate the live preview.
 *
 * @since 1.1.0
 *
 * @access protected
 */
protected function _content_template()
{ }
}