<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome5HeroSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home5-hero-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 5 - Hero Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-featured-image';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home5' ];
	}

	public function get_keywords() {
		return [ 'home5herosection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_hero_section',
			[
				'label' => esc_html__( 'Hero Title Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'img_mask_right_sec',
			[
				'label'       	=> esc_html__( 'Image Mask For Image Right Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image mask', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'img_right_sec',
			[
				'label'       	=> esc_html__( 'Image Right Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image right section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'title_sec_1',
			[
				'label' 		=> esc_html__( 'Title Before Image Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Legal liberty' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'img_title_sec',
			[
				'label'       	=> esc_html__( 'Image Titlte Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image title section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'title_sec_2',
			[
				'label' 		=> esc_html__( 'Title After Image Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Advocates & <br> Associates in action' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->end_controls_section();


		$this->start_controls_section(
			'section_content_hero_bottom',
			[
				'label' => esc_html__( 'Hero Bottom Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'text_left_sec',
			[
				'label' 		=> esc_html__( 'Text Left Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Best writer <i>awarded</i> <br> by Daily Publication <br> -2024' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'link_btn_left',
			[
				'label' 		=> esc_html__( 'Link Button Left', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '#' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'img_center_bottom',
			[
				'label'       	=> esc_html__( 'Image Center Bottom Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image center bottom section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'text_right_sec',
			[
				'label' 		=> esc_html__( 'Text Right Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '<i>Based</i> in California, lawyers seek to <br> continually improve <span>their skills</span> and <br> approach to deliver legal advice suitable <br> for today.' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_btn_right',
			[
				'label' 		=> esc_html__( 'Text Button Right', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Get in touch ' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'link_btn_right',
			[
				'label' 		=> esc_html__( 'Link Button Right', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '#' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->end_controls_section();


		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-hero-5-ptb fix pb-80 p-relative">
	<div class="container">
		<div class="row">
			<div class="tp-hero-5-content tp-btn-trigger fix p-relative mb-40">
				<?php if (!empty($settings['img_right_sec']['url'])): ?>
					<div class="tp-hero-5-text-box">
						<?php if (!empty($settings['img_mask_right_sec']['url'])) { ?>
							<div class="tp-hero-5-text-shape tp_fade_right" data-mask-img="<?php echo wp_kses_post($settings['img_mask_right_sec']['url']); ?>">
						<?php } else { ?>
							<div class="tp-hero-5-text-shape tp_fade_right">
						<?php } ?>
								<img src="<?php echo wp_kses_post($settings['img_right_sec']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_right_sec']['alt']); ?>">
							</div>
					</div>
				<?php endif ?>
				<?php if (!empty($settings['title_sec_1']) || !empty($settings['img_title_sec']['url']) || !empty($settings['title_sec_2'])): ?>
					<h3 class="tp-hero-5-title">
						<?php echo wp_kses_post($settings['title_sec_1']); ?>
						<br> 
						<?php if (!empty($settings['img_title_sec']['url'])): ?>
							<span class="tp-btn-bounce"><img src="<?php echo wp_kses_post($settings['img_title_sec']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_title_sec']['alt']); ?>"></span> 
						<?php endif ?>
						<?php echo wp_kses_post($settings['title_sec_2']); ?>
					</h3>
				<?php endif ?>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-4 col-md-6">
				<div class="tp-hero-5-text-item tp_fade_bottom mb-30">
					<?php if (!empty($settings['text_left_sec'])): ?>
						<p><?php echo wp_kses_post($settings['text_left_sec']); ?></p>
					<?php endif ?>
					<?php if (!empty($settings['link_btn_left'])): ?>
						<span>
							<a href="<?php echo wp_kses_post($settings['link_btn_left']); ?>">
								<svg width="18" height="19" viewBox="0 0 18 19" fill="none" xmlns="http://www.w3.org/2000/svg">
									<path d="M4.28125 2.4429C7.60237 5.7665 13.4584 5.28729 17.3742 1.37146M17.3735 1.3736C13.4577 5.28943 12.9764 11.1474 16.2976 14.471M1.11719 17.6304L16.2589 2.48871" stroke="#F5F7F5" stroke-width="1.5" stroke-miterlimit="10"/>
								</svg>
							</a>
						</span>
					<?php endif ?>
				</div>
			</div>
			<div class="col-lg-4 order-3 order-lg-2">
				<?php if (!empty($settings['img_center_bottom']['url'])): ?>
					<div class="tp-hero-5-thumb tp_fade_bottom mb-30">
						<img src="<?php echo wp_kses_post($settings['img_center_bottom']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_center_bottom']['alt']); ?>">
					</div>
				<?php endif ?>
			</div>
			<div class="col-lg-4 col-md-6 order-2 order-lg-3">
				<div class="tp-hero-5-btn-box tp_fade_bottom mb-30">
					<?php if (!empty($settings['text_right_sec'])): ?>
						<p><?php echo wp_kses_post($settings['text_right_sec']); ?></p>
					<?php endif ?>
					<?php if (!empty($settings['link_btn_right']) && !empty($settings['text_btn_right'])): ?>
						<div class="tp-hero-5-btn">
							<a href="<?php echo wp_kses_post($settings['link_btn_right']); ?>">
								<?php echo wp_kses_post($settings['text_btn_right']); ?>
								<span>
									<svg width="19" height="16" viewBox="0 0 19 16" fill="none" xmlns="http://www.w3.org/2000/svg">
										<path d="M0 7.68652H17.6902M10.7188 0C10.7188 4.25031 14.4207 7.68957 18.9956 7.68957M18.9956 7.68652C14.4207 7.68652 10.7188 11.1258 10.7188 15.3761" stroke="#F5F7F5" stroke-width="1.5" stroke-miterlimit="10"/>
									</svg>
								</span>
							</a>
						</div>
					<?php endif ?>
				</div>
			</div>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-mask-img]").each(function () {
			jQuery(this).css("-webkit-mask-image", "url( " + jQuery(this).attr("data-mask-img") + "  )");
		});

		if (jQuery('.tp-btn-trigger').length > 0) {
			gsap.set(".tp-btn-bounce", { y: -100, opacity: 0 });
			var mybtn = gsap.utils.toArray(".tp-btn-bounce");
			mybtn.forEach((btn) => {
				var $this = $(btn);
				gsap.to(btn, {
					scrollTrigger: {
						trigger: $this.closest('.tp-btn-trigger'),
						start: "top center",
						markers: false
					},
					duration: 1,
					ease: "bounce.out",
					y: 0,
					opacity: 1,
				})
			});
		}

		gsap.set(".tp_fade_right", { x: 100, opacity: 0 });
		var faderightArray = gsap.utils.toArray(".tp_fade_right")
		faderightArray.forEach((item, i) => {
			var fadeTl = gsap.timeline({
				scrollTrigger: {
					trigger: item,
					start: "top center+=100",
				}
			})
			fadeTl.to(item, {
				x: 0,
				opacity: 1,
				ease: "power2.out",
				duration: 2.5,
			})
		})

		gsap.set(".tp_fade_bottom", { y: 100, opacity: 0 });
		var fadeArray = gsap.utils.toArray(".tp_fade_bottom")
		fadeArray.forEach((item, i) => {
			var fadeTl = gsap.timeline({
				scrollTrigger: {
					trigger: item,
					start: "top center+=400",
				}
			})
			fadeTl.to(item, {
				y: 0,
				opacity: 1,
				ease: "power2.out",
				duration: 1.5,
			})
		})
	</script>
<?php } ?>

<?php
}

}