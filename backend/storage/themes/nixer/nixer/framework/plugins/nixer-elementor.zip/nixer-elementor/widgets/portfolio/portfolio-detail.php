<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsPortfolioDetail extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-portfolio-detail';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Portfolio Detail', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-info-box';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-portfolio' ];
	}

	public function get_keywords() {
		return [ 'portfoliodetail', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_portfolio_top',
			[
				'label' => esc_html__( 'Portfolio Detail Top', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'show_port_top',
			[
				'label'   => esc_html__( 'Show Portfolio Detail Top', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'img_thumb_1',
			[
				'label'       	=> esc_html__( 'Image Thumbnail Portfolio Detail Top - If this field empty then use portfolio thumbnail', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image Thumbnail Portfolio Detail Top', 'bdevs-elementor' ),
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_portfolio_wrap',
			[
				'label' => esc_html__( 'Portfolio Detail Wrap', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'show_port_wrap',
			[
				'label'   => esc_html__( 'Show Portfolio Detail Wrap', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'title_port',
			[
				'label' 		=> esc_html__( 'Title Portfolio - If this field empty then use title portfolio', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'meta_label_1',
			[
				'label' 		=> esc_html__( 'Label Portfolio Category', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( 'Category' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'meta_label_2',
			[
				'label' 		=> esc_html__( 'Label Portfolio Date', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Date' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'meta_label_3',
			[
				'label' 		=> esc_html__( 'Label Portfolio Client', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Client' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'meta_text_3',
			[
				'label' 		=> esc_html__( 'Text Portfolio Client', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Cameron Williamso, New York' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'meta_text_4',
			[
				'label' 		=> esc_html__( 'Portfolio Meta Text', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Visit Website' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'meta_link_4',
			[
				'label' 		=> esc_html__( 'Portfolio Meta Link', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '#' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'show_port_wrap_right',
			[
				'label'   => esc_html__( 'Show Portfolio Detail Wrap Right', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'port_wrap_heading',
			[
				'label' 		=> esc_html__( 'Portfolio Wrap Heading', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Introduction' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'port_wrap_text',
			[
				'label' 		=> esc_html__( 'Portfolio Wrap Text', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'There are many variations...' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'port_wrap_list_title',
			[
				'label' 		=> esc_html__( 'Portfolio Wrap List Title', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'This event will allow participants to:' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_list_wrap = new \Elementor\Repeater();
		$rp_list_wrap->add_control(
			'wrap_text_item',
			[
				'label' 		=> esc_html__( 'Portfolio Wrap Text Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Portfolio Wrap Text Item' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'tab_list_wrap',
			[
				'label' 		=> esc_html__( 'List Wrap Content', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $rp_list_wrap->get_controls(),
				'default' 		=> [
					[
						
					],
				],
			]
		);
		$this->add_control(
			'img_thumb_2',
			[
				'label'       	=> esc_html__( 'Image Thumbnail Portfolio 2', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image Thumbnail Portfolio 2', 'bdevs-elementor' ),
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_portfolio_content',
			[
				'label' => esc_html__( 'Portfolio Detail Content', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'show_port_content',
			[
				'label'   => esc_html__( 'Show Portfolio Detail Content', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'title_counter',
			[
				'label' 		=> esc_html__( 'Portfolio Content Title Counter', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Results & Metrics' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_counter',
			[
				'label' 		=> esc_html__( 'Portfolio Content Text Counter', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'We deploy world-class creative design...' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_counter = new \Elementor\Repeater();
		$rp_counter->add_control(
			'label_counter',
			[
				'label' 		=> esc_html__( 'Label Counter Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Label Counter' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_counter->add_control(
			'num_count',
			[
				'label' 		=> esc_html__( 'Number Counter', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::NUMBER,
				'min' 			=> 0,
				'default' 		=> 102,
			]
		);
		$rp_counter->add_control(
			'text_num_bf',
			[
				'label' 		=> esc_html__( 'Text Befoter Number Counter', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXT,
				'default' 		=> __( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_counter->add_control(
			'text_num_af',
			[
				'label' 		=> esc_html__( 'Text After Number Counter', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXT,
				'default' 		=> __( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'tab_counter',
			[
				'label' 		=> esc_html__( 'List Counter Content', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $rp_counter->get_controls(),
				'default' 		=> [
					[
						
					],
				],
				'title_field' 	=> '{{{ label_counter }}}',
			]
		);
		$this->add_control(
			'img_ctn_1',
			[
				'label'       	=> esc_html__( 'Image Content Column 1', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image content column 1', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'img_ctn_2',
			[
				'label'       	=> esc_html__( 'Image Content Column 2', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image content column 2', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'title_list_1',
			[
				'label' 		=> esc_html__( 'Portfolio Content Title List 1', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( "What we've done" , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_list_1',
			[
				'label' 		=> esc_html__( 'Portfolio Content Text List 1', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'We deploy world-class creative design...' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_list_ctn = new \Elementor\Repeater();
		$rp_list_ctn->add_control(
			'ctn_text_item',
			[
				'label' 		=> esc_html__( 'Portfolio Content List Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Portfolio Wrap Text Item' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'tab_list_ctn',
			[
				'label' 		=> esc_html__( 'List Portfolio Content', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $rp_list_ctn->get_controls(),
				'default' 		=> [
					[
						
					],
				],
			]
		);
		$this->add_control(
			'title_list_2',
			[
				'label' 		=> esc_html__( 'Portfolio Content Title List 2', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'A place where great brands grow' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_list_2',
			[
				'label' 		=> esc_html__( 'Portfolio Content Text List 2', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'We deploy world-class creative design...' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_portfolio_image',
			[
				'label' => esc_html__( 'Portfolio Detail Image Justified', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'show_port_media',
			[
				'label'   => esc_html__( 'Show Portfolio Image Justified', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'img_width',
			[
				'label'     	=> esc_html__( 'Choose Width Column Image', 'bdevs-elementor' ),
				'type'      	=> Controls_Manager::SELECT,
				'options'   	=> [
					'type1'  		=> esc_html__( 'Width Column 25%', 'bdevs-elementor' ),
					'type2'  		=> esc_html__( 'Width Column 50%', 'bdevs-elementor' ),
				],
				'default'   	=> 'type1',
			]
		);
		$repeater->add_control(
			'type1_img_1',
			[
				'label'       	=> esc_html__( 'Image Item 1', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload your image', 'bdevs-elementor' ),
				'condition' 	=> [
					'img_width' 	=> 'type1',
				],
			]
		);
		$repeater->add_control(
			'type1_img_2',
			[
				'label'       	=> esc_html__( 'Image Item 2', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload your image', 'bdevs-elementor' ),
				'condition' 	=> [
					'img_width' 	=> 'type1',
				],
			]
		);
		$repeater->add_control(
			'type2_img',
			[
				'label'       	=> esc_html__( 'Image Item', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload your image', 'bdevs-elementor' ),
				'condition' 	=> [
					'img_width' 	=> 'type2',
				],
			]
		);
		$this->add_control(
			'tabs',
			[
				'label' 		=> esc_html__( 'List Column Image', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						
					],
				],
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-portfolio-details-ptb pt-80 pb-70 p-header p-relative">
	<?php if (!empty($settings['show_port_top'])): ?>
		<div class="container-fluid gx-0">
			<div class="row gx-0">
				<div class="col-lg-12">
					<div class="tp-portfolio-details-top">
						<?php if (!empty($settings['img_thumb_1']['url'])) { ?>
							<img src="<?php echo wp_kses_post($settings['img_thumb_1']['url']); ?>" alt="<?php the_title_attribute(); ?>">
						<?php } else { ?>
							<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title_attribute(); ?>">
						<?php } ?>
					</div>
				</div>
			</div>
		</div>
	<?php endif ?>
	<div class="container container-1520">
		<?php if (!empty($settings['show_port_wrap'])): ?>
			<?php if (!empty($settings['show_port_top'])) { ?>
				<div class="tp-portfolio-details-wrap">
			<?php } else { ?>
				<div class="tp-portfolio-details-wrap mt-0">
			<?php } ?>
					<div class="row">
						<div class="col-lg-6">
							<h3 class="tp-portfolio-details-title">
								<?php if (!empty($settings['title_port'])) { ?>
									<?php echo wp_kses_post($settings['title_port']); ?>
								<?php } else { ?>
									<?php the_title(); ?>
								<?php } ?>
							</h3>
							<div class="tp-portfolio-details-info">
								<?php if (!empty($settings['meta_label_1'])): ?>
									<div class="tp-portfolio-details-info-item">
										<span><?php echo wp_kses_post($settings['meta_label_1']); ?></span>
										<p><?php echo get_the_term_list( get_the_ID(), 'portfolio-cat', '', ', ', '' ); ?></p>
									</div>
								<?php endif ?>
								<?php if (!empty($settings['meta_label_2'])): ?>
									<div class="tp-portfolio-details-info-item">
										<span><?php echo wp_kses_post($settings['meta_label_2']); ?></span>
										<p><?php the_time(get_option( 'date_format' ));?></p>
									</div>
								<?php endif ?>
								<?php if (!empty($settings['meta_label_3']) && !empty($settings['meta_text_3'])): ?>
									<div class="tp-portfolio-details-info-item">
										<span><?php echo wp_kses_post($settings['meta_label_3']); ?></span>
										<p><?php echo wp_kses_post($settings['meta_text_3']); ?></p>
									</div>
								<?php endif ?>
								<?php if (!empty($settings['meta_link_4']) && !empty($settings['meta_text_4'])): ?>
									<div class="tp-portfolio-details-info-btn">
										<a href="<?php echo wp_kses_post($settings['meta_link_4']); ?>">
											<?php echo wp_kses_post($settings['meta_text_4']); ?>
										</a>
									</div>
								<?php endif ?>
							</div>
						</div>
						<?php if (!empty($settings['show_port_wrap_right'])): ?>
							<div class="col-lg-6">
								<div class="tp-portfolio-details-right">
									<?php if (!empty($settings['port_wrap_heading']) || !empty($settings['port_wrap_text'])): ?>
										<div class="tp-portfolio-details-heading">
											<?php if (!empty($settings['port_wrap_heading'])): ?>
												<span><?php echo wp_kses_post($settings['port_wrap_heading']); ?></span>
											<?php endif ?>
											<?php if (!empty($settings['port_wrap_text'])): ?>
												<p><?php echo wp_kses_post($settings['port_wrap_text']); ?></p>
											<?php endif ?>
										</div>
									<?php endif ?>
									<div class="tp-portfolio-details-list">
										<?php if (!empty($settings['port_wrap_list_title'])): ?>
											<h4 class="tp-portfolio-details-list-title"><?php echo wp_kses_post($settings['port_wrap_list_title']); ?></h4>
										<?php endif ?>
										<?php if (!empty($settings['tab_list_wrap'])): ?>
											<ul>
												<?php
												foreach ($settings['tab_list_wrap'] as $item1) :
												?>
													<li>
														<span>
															<svg xmlns="http://www.w3.org/2000/svg" width="13" height="8" viewBox="0 0 13 8" fill="none">
																<path d="M4.99099 7.84596C4.87207 7.94512 4.71768 8 4.55762 8C4.39756 8 4.24317 7.94512 4.12425 7.84596L0.663542 4.87475C0.578894 4.8045 0.511188 4.71852 0.464838 4.62243C0.418487 4.52634 0.394531 4.42228 0.394531 4.31705C0.394531 4.21181 0.418487 4.10776 0.464838 4.01167C0.511188 3.91557 0.578894 3.8296 0.663542 3.75934L1.09691 3.38722C1.27518 3.23827 1.50681 3.15581 1.74697 3.15581C1.98713 3.15581 2.21876 3.23827 2.39703 3.38722L4.55762 5.24204L10.3951 0.231404C10.5734 0.0824528 10.805 0 11.0451 0C11.2853 0 11.5169 0.0824528 11.6952 0.231404L12.1286 0.603529C12.2132 0.673784 12.2809 0.759759 12.3273 0.855852C12.3736 0.951945 12.3976 1.056 12.3976 1.16123C12.3976 1.26647 12.3736 1.37052 12.3273 1.46661C12.2809 1.56271 12.2132 1.64868 12.1286 1.71894L4.99099 7.84596Z" fill="#19191A"/>
															</svg>
														</span> 
														<?php echo wp_kses_post($item1['wrap_text_item']); ?>
													</li>
												<?php endforeach; ?>
											</ul>
										<?php endif ?>
									</div>
								</div>
							</div>
						<?php endif ?>
					</div>
				</div>
			<?php if (!empty($settings['img_thumb_2']['url'])): ?>
				<div class="row">
					<div class="col-lg-12">
						<div class="tp-portfolio-details-thumb fix mb-60">
							<img data-speed=".8" src="<?php echo wp_kses_post($settings['img_thumb_2']['url']); ?>" alt="<?php the_title_attribute(); ?>">
						</div>
					</div>
				</div>
			<?php endif ?>
		<?php endif ?>
		<?php if (!empty($settings['show_port_content'])): ?>
			<div class="row">

				<div class="col-lg-12">
					<div class="tp-portfolio-details-counter-wrap pb-100">
						<?php if (!empty($settings['title_counter']) || !empty($settings['text_counter'])): ?>
							<div class="tp-portfolio-details-text-heading pb-60">
								<?php if (!empty($settings['title_counter'])): ?>
									<h4 class="tp-portfolio-details-text-title"><?php echo wp_kses_post($settings['title_counter']); ?></h4>
								<?php endif ?>
								<?php if (!empty($settings['text_counter'])): ?>
									<p><?php echo wp_kses_post($settings['text_counter']); ?></p>
								<?php endif ?>
							</div>
						<?php endif ?>
						<div class="tp-counter-3-wrapper portfolio-details d-flex">
							<?php
							foreach ($settings['tab_counter'] as $item2) :
							?>
								<div class="tp-counter-3-item text-center mb-40">
									<?php if (!empty($item2['num_count'])): ?>
										<h4 class="tp-counter-3-item-title">
											<?php echo wp_kses_post($item2['text_num_bf']); ?><span class="purecounter" data-purecounter-duration="2" data-purecounter-end="<?php echo wp_kses_post($item2['num_count']); ?>"><?php echo wp_kses_post($item2['num_count']); ?></span><?php echo wp_kses_post($item2['text_num_af']); ?>
										</h4>
									<?php endif ?>
									<?php if (!empty($item2['label_counter'])): ?>
										<p><?php echo wp_kses_post($item2['label_counter']); ?></p>
									<?php endif ?>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				</div>

				<div class="col-lg-6">
					<?php if (!empty($settings['img_ctn_1']['url'])): ?>
						<div class="anim-zoomin-wrap">
							<div class="tp-portfolio-details-thumb anim-zoomin pb-50">
								<a href="<?php echo wp_kses_post($settings['img_ctn_1']['url']); ?>" class="popup-image">
									<img src="<?php echo wp_kses_post($settings['img_ctn_1']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_ctn_1']['alt']); ?>">
								</a>
							</div>
						</div>
					<?php endif ?>
				</div>
				<div class="col-lg-6">
					<?php if (!empty($settings['img_ctn_2']['url'])): ?>
						<div class="anim-zoomin-wrap">
							<div class="tp-portfolio-details-thumb anim-zoomin pb-50">
								<a href="<?php echo wp_kses_post($settings['img_ctn_2']['url']); ?>" class="popup-image">
									<img src="<?php echo wp_kses_post($settings['img_ctn_2']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_ctn_2']['alt']); ?>">
								</a>
							</div>
						</div>
					<?php endif ?>
				</div>

				<div class="col-lg-12">
					<?php if (!empty($settings['title_list_1']) || !empty($settings['text_list_1'])): ?>
						<div class="tp-portfolio-details-text-heading mb-40">
							<?php if (!empty($settings['title_list_1'])): ?>
								<h4 class="tp-portfolio-details-text-title"><?php echo wp_kses_post($settings['title_list_1']); ?></h4>
							<?php endif ?>
							<?php if (!empty($settings['text_list_1'])): ?>
								<p><?php echo wp_kses_post($settings['text_list_1']); ?></p>
							<?php endif ?>
						</div>
					<?php endif ?>
					<?php if (!empty($settings['tab_list_ctn'])): ?>
						<div class="tp-portfolio-details-list pb-45">
							<ul>
								<?php
								foreach ($settings['tab_list_ctn'] as $item3) :
								?>
									<li><?php echo wp_kses_post($item3['ctn_text_item']); ?></li>
								<?php endforeach; ?>
							</ul>
						</div>
					<?php endif ?>
					<?php if (!empty($settings['title_list_2']) || !empty($settings['text_list_2'])): ?>
						<div class="tp-portfolio-details-text-heading mb-135">
							<?php if (!empty($settings['title_list_2'])): ?>
								<h4 class="tp-portfolio-details-text-title"><?php echo wp_kses_post($settings['title_list_2']); ?></h4>
							<?php endif ?>
							<?php if (!empty($settings['text_list_2'])): ?>
								<p><?php echo wp_kses_post($settings['text_list_2']); ?></p>
							<?php endif ?>
						</div>
					<?php endif ?>
				</div>
				
			</div>
		<?php endif ?>
		<?php if (!empty($settings['show_port_media'])): ?>
			<div class="row tp-gx-15">
				<?php
				foreach ($settings['tabs'] as $item) :
				?>
					<?php if ($item['img_width'] == 'type1') { ?>
						<div class="col-lg-3">
							<div class="tp-portfolio-details-thumb pb-50">
								<?php if (!empty($item['type1_img_1']['url'])): ?>
									<a href="<?php echo wp_kses_post($item['type1_img_1']['url']); ?>" class="about-popup-image">
										<img class="mb-15" src="<?php echo wp_kses_post($item['type1_img_1']['url']); ?>" alt="<?php echo wp_kses_post($item['type1_img_1']['alt']); ?>php">
									</a>
								<?php endif ?>
								<?php if (!empty($item['type1_img_2']['url'])): ?>
									<a href="<?php echo wp_kses_post($item['type1_img_1']['url']); ?>" class="about-popup-image">
										<img src="<?php echo wp_kses_post($item['type1_img_2']['url']); ?>" alt="<?php echo wp_kses_post($item['type1_img_2']['alt']); ?>">
									</a>
								<?php endif ?>
							</div>
						</div>
					<?php } else { ?>
						<div class="col-lg-6">
							<div class="anim-zoomin-wrap">
								<div class="tp-portfolio-details-thumb anim-zoomin pb-50">
									<?php if (!empty($item['type2_img']['url'])): ?>
										<a href="<?php echo wp_kses_post($item['type2_img']['url']); ?>" class="about-popup-image">
											<img src="<?php echo wp_kses_post($item['type2_img']['url']); ?>" alt="<?php echo wp_kses_post($item['type2_img']['alt']); ?>">
										</a>
									<?php endif ?>
								</div>
							</div>
						</div>
					<?php } ?>
				<?php endforeach; ?>
			</div>
		<?php endif ?>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery(".anim-zoomin").each(function() {

			jQuery(this).wrap('<div class="anim-zoomin-wrap"></div>');
			jQuery(".anim-zoomin-wrap").css({ "overflow": "hidden" })
			var $this = jQuery(this);
			var $asiWrap = $this.parents(".anim-zoomin-wrap");
			let tp_ZoomIn = gsap.timeline({
				scrollTrigger: {
					trigger: $asiWrap,
					start: "top 100%",
					markers: false,
				}
			});
			tp_ZoomIn.from($this, { duration: 1.5, autoAlpha: 0, scale: 1.2, ease: Power2.easeOut, clearProps:"all" });
		});

		gsap.registerPlugin(ScrollTrigger, ScrollSmoother);
		var smoother = ScrollSmoother.create({
			smooth: 2,
			effects: true,
			smoothTouch: true
		});
	</script>
<?php } ?>

<?php
}

}