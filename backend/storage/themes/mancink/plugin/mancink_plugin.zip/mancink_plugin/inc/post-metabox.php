<?php
/**
 * Initialize the Post Post Meta Boxes. 
 */
add_action('cmb2_admin_init', 'mancink_post_mb');
function mancink_post_mb()
{

	$mancink_post_metabox_cmb2 = new_cmb2_box(array(
		'id'            => 'mancink_post_metabox',
		'title'         => esc_html__('Post Settings', 'mancink_plugin'),
		'object_types'  => array('post'), // Post type
		'priority'      => 'high',
	));

	$mancink_post_metabox_cmb2->add_field(array(
		'name'             => esc_html__('Please Read:', 'mancink_plugin'),
		'id'            => 'mancink_post_title_text',
		'desc' => wp_kses_post('Always use the same ratio/size for images in slider/gallery below.
		<br> To be able to edit this post with <strong>elementor</strong>, make sure you have checklist the <strong>Posts</strong> in <strong>Elementor Settings -> Post Type</strong>.', 'mancink_plugin'),
		'type'             => 'title',
	));

	$mancink_post_metabox_cmb2->add_field(array(
		'name'             => esc_html__('Post Format', 'mancink_plugin'),
		'desc'             => esc_html__('Choose Post Format Here', 'mancink_plugin'),
		'id'               => 'post_format',
		'type'             => 'select',
		'default' => 'post_standard',
		'options'          => array(
			'post_standard' => esc_html__('Post Standard', 'mancink_plugin'),
			'post_gallery'   => esc_html__('Post Gallery', 'mancink_plugin'),
			'post_slider'   => esc_html__('Post Slider', 'mancink_plugin'),
			'post_video'   => esc_html__('Post Video', 'mancink_plugin'),
			'post_audio'   => esc_html__('Post Audio', 'mancink_plugin'),
		),
	));

	$mancink_post_metabox_cmb2->add_field(array(
		'name'             => esc_html__('Gallery Setting', 'mancink_plugin'),
		'desc'             => esc_html__('Create your Post Gallery here. Try to use same ratio for each image.', 'mancink_plugin'),
		'id'   => 'post_gallery_setting',
		'type' => 'file_list',
		'text' => array(
			'add_upload_files_text' => 'Upload images',
		),
		'preview_size' => array(100, 100), // Default: array( 50, 50 )
		'query_args' => array('type' => 'image'), // Only images attachment
	));

	$mancink_post_metabox_cmb2->add_field(array(
		'name'             => esc_html__('Slider Setting', 'mancink_plugin'),
		'desc'             => esc_html__('Create your Post Slider here. Try to use same ratio for each image.', 'mancink_plugin'),
		'id'   => 'post_slider_setting',
		'type' => 'file_list',
		'text' => array(
			'add_upload_files_text' => 'Upload images',
		),
		'preview_size' => array(100, 100), // Default: array( 50, 50 )
		'query_args' => array('type' => 'image'), // Only images attachment
	));

	$mancink_post_metabox_cmb2->add_field(array(
		'name'             => esc_html__('Video Setting', 'mancink_plugin'),
		'desc'             => wp_kses_post('Insert the link for video embed here.<br/> For video from youtube/vimeo just put the link without any attribute like ?wmode=opaque.<br/>eg: https://www.youtube.com/embed/IzgAYZTuBA8 <br>For <b>vimeo</b> video, you can use the post type audio format.', 'mancink_plugin'),
		'id'               => 'post_video_setting',
		'type'             => 'text',
	));

	$mancink_post_metabox_cmb2->add_field(array(
		'name'             => esc_html__('Audio Setting', 'mancink_plugin'),
		'desc'             => wp_kses_post('Insert your iframe/embedded code for audio here.<br/>
		You can input iframe/embed code from youtube/vimeo here too, if you don\'t like the default style of Post video.', 'mancink_plugin'),
		'id'               => 'post_audio_setting',
		'type'             => 'textarea',
		'sanitization_cb' => false,
	));

	$mancink_post_metabox_cmb2->add_field(array(
		'name'             => esc_html__('Sidebar Setting', 'mancink_plugin'),
		'desc'             => esc_html__('You can show/hide the sidebar here.', 'mancink_plugin'),
		'id'               => 'post_sidebar',
		'type'             => 'select',
		'default' => 'show',
		'options'          => array(
			'show' => esc_html__('Show Sidebar', 'mancink_plugin'),
			'hide'   => esc_html__('Hide Sidebar', 'mancink_plugin'),
		),
	));
}