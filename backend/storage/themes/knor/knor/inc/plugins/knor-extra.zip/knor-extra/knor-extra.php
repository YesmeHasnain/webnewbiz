<?php
/*
Plugin Name: Knor Extra
Plugin URI: https://gossipthemes.com/knor-extra
Description: This is a helper plugin for Knor Theme.
Author: Gossip Themes
Version: 1.0
Author URI: https://gossipthemes.com
*/

/**  Related Theme Type */

global $related_theme_type;
$related_theme_type = array('Knor','Knor Child');
//define current theme name
$current_theme = !empty( wp_get_theme() ) ? wp_get_theme()->get('Name') : '';
define('CURRENT_THEME_NAME',$current_theme);


/*
 * Define Plugin Dir Path
 * @since 1.0.0
 * */
define('KNOR_EXTRA_SELF_PATH','knor-extra/knor-extra.php');
define('KNOR_EXTRA_ROOT_PATH',plugin_dir_path(__FILE__));
define('KNOR_EXTRA_ROOT_URL',plugin_dir_url(__FILE__));
define('KNOR_EXTRA_LIB',KNOR_EXTRA_ROOT_PATH.'/lib');
define('KNOR_EXTRA_INC',KNOR_EXTRA_ROOT_PATH .'/inc');
define('KNOR_EXTRA_ADMIN',KNOR_EXTRA_INC .'/admin');
define('KNOR_EXTRA_ADMIN_ASSETS',KNOR_EXTRA_ROOT_URL .'inc/admin/assets');
define('KNOR_EXTRA_CSS',KNOR_EXTRA_ROOT_URL .'assets/css');
define('KNOR_EXTRA_JS',KNOR_EXTRA_ROOT_URL .'assets/js');
define('KNOR_EXTRA_ELEMENTOR',KNOR_EXTRA_INC .'/elementor');
define('KNOR_EXTRA_SHORTCODES',KNOR_EXTRA_INC .'/shortcodes');
define('KNOR_EXTRA_WIDGETS',KNOR_EXTRA_INC .'/widgets');

/** Plugin version **/
define('KNOR_CORE_VERSION','1.0.0');

//initial file
include_once ABSPATH .'wp-admin/includes/plugin.php';

if ( is_plugin_active(KNOR_EXTRA_SELF_PATH) ) {

	if ( !in_array(CURRENT_THEME_NAME,$GLOBALS['related_theme_type']) && file_exists(KNOR_EXTRA_INC .'/cs-framework-functions.php') ) {
		
		require_once KNOR_EXTRA_INC .'/cs-framework-functions.php';
		
	}

	//plugin core file include
	
	if ( file_exists(KNOR_EXTRA_INC .'/class-knor-extra-init.php') ) {
		require_once KNOR_EXTRA_INC .'/class-knor-extra-init.php';
	}
	
	//Demo data import 
	
		if ( file_exists(KNOR_EXTRA_INC .'/demo-import.php') ) {
		require_once KNOR_EXTRA_INC .'/demo-import.php';
	}
	
	
}

/** Add Contact Methods in the User Profile **/
function knor_user_contact_methods( $user_contact ) {
	
    $user_contact['facebook']   = esc_html__( 'Facebook Profile Link', 'knor' );
    $user_contact['twitter']    = esc_html__( 'Twitter Profile', 'knor' );
    $user_contact['instagram']  = esc_html__( 'Instagram', 'knor' ); 
	$user_contact['pinterest']  = esc_html__( 'Pinterest', 'knor' );
	$user_contact['youtube']    = esc_html__( 'Youtube Profile', 'knor' );
	
    return $user_contact; 
};
add_filter( 'user_contactmethods', 'knor_user_contact_methods' );

function knor_theme_author_box() {

    global $post;

    $theme_author_markup = '';
    // Get author's display name - NB! changed display_name to first_name. Error in code.
    $display_name = get_the_author_meta( 'display_name', $post->post_author );

    // If display name is not available then use nickname as display name
    if ( empty( $display_name ) )
    $display_name = get_the_author_meta( 'nickname', $post->post_author );

    // Get author's biographical information or description
    $user_description   = get_the_author_meta( 'user_description', $post->post_author );
    
    $user_facebook      = get_the_author_meta('facebook', $post->post_author);
    $user_twitter       = get_the_author_meta('twitter', $post->post_author);
    $user_instagram     = get_the_author_meta('instagram', $post->post_author);
	$user_pinterest     = get_the_author_meta('pinterest', $post->post_author);
	$user_youtube       = get_the_author_meta('youtube', $post->post_author);

    // Get link to the author archive page
    $user_posts = get_author_posts_url( get_the_author_meta( 'ID' , $post->post_author));
    if ( ! empty( $display_name ) )
    // Author avatar - - the number 90 is the px size of the image.
    $theme_author_markup .= '<div class="author-thumb">' . get_avatar( get_the_author_meta('ID') , 200 ) . '</div>';
    $theme_author_markup .= '<div class="theme_author_Info">';
    $theme_author_markup .= '<h6 class="theme_author_Title">' . esc_html__('About Author', 'knor'). '</h6>';
    $theme_author_markup .= '<h4 class="theme_author__Name">' . $display_name . '</h4>';
    $theme_author_markup .= '<p class="theme_author__Description">' . get_the_author_meta( 'description' ). '</p>';
    $theme_author_markup .= '<div class="theme_author_Socials">';


	// Check if author has Twitter in their profile
	
    if ( ! empty( $user_facebook ) ) {
        $theme_author_markup .= ' <a href="' . $user_facebook .'" target="_blank" rel="nofollow" title="Facebook"><i class="fa fa-facebook-f"></i> </a>';
    }
	
	    
    if ( ! empty( $user_twitter ) ) {
        $theme_author_markup .= ' <a href="' . $user_twitter .'" target="_blank" rel="nofollow" title="Twitter"><i class="fa fa-twitter"></i> </a>';
    }
	
	if ( ! empty( $user_instagram ) ) {
        $theme_author_markup .= ' <a href="' . $user_instagram .'" target="_blank" rel="nofollow" title="Instagram"><i class="fa fa-instagram"></i> </a>';
    }
	
	if ( ! empty( $user_pinterest ) ) {
        $theme_author_markup .= ' <a href="' . $user_pinterest .'" target="_blank" rel="nofollow" title="Pinterest"><i class="fa fa-pinterest"></i> </a>';
    }

    if ( ! empty( $user_youtube ) ) {
        $theme_author_markup .= ' <a href="' . $user_youtube .'" target="_blank" rel="nofollow" title="Youtube"><i class="fa fa-youtube"></i> </a>';
    }

    $theme_author_markup .= '</div></div>';

    // Pass all this info to post content 
    echo '<div class="author_bio__Wrapper" >' . $theme_author_markup . '</div>';
}


// Page List
function knor_page_list() {
    $args = wp_parse_args( array(
        'post_type'   => 'page',
        'numberposts' => -1,
    ) );
    $posts = get_posts( $args );
    $post_options = array( esc_html__( '-- Select Page --', 'knor-extra' ) => '' );
    if ( $posts ) {
        foreach ( $posts as $post ) {
            $post_options[$post->ID] = $post->post_title;
        }
    }
    return $post_options;
}



/*** Custom Elementor Animations ***/


function sassaprk_entrance_animations() {
    return array(
        'Knor Fading Animations' => [
            'themeFadeInLeft' => 'Knor Fadeinleft',
            'themeFadeInRight' => 'Knor Fadeinright',
            'themeFadeInDown' => 'Knor Fadeindown',
            'themeFadeInUp' => 'Knor Fadeinup',               
        ],
    );
}
add_filter( 'elementor/controls/animations/additional_animations', 'sassaprk_entrance_animations' );



/*** Register Custom Post Types - Portfolio & Team ***/

add_action( 'init', 'knor_custom_post_type' );

function knor_custom_post_type() {
	
    register_post_type( 'theme_portfolio',
        array(
            'labels' => array(
                'name' => esc_html__('Portfolio','knor-extra'),
                'singular_name' => esc_html__('Portfolio','knor-extra'),
            ),
            'show_in_rest'  => true,
            'supports'      => array('title','thumbnail', 'page-attributes','editor','excerpt'),
            'menu_icon'     => esc_attr__('dashicons-image-filter','knor-extra'),
            'public'        => true,
            'rewrite'               => array(
                'slug'              => 'theme-portfolio', 
                'with_front'        => true 
            )
        )
    );
	
    register_post_type( 'theme_team',
        array(
            'labels' => array(
                'name' => esc_html__('Team','knor-extra'),
                'singular_name' => esc_html__('Team','knor-extra'),
            ),
            'show_in_rest'  => true,
            'supports'      => array('title','thumbnail', 'page-attributes','editor','excerpt'),
            'menu_icon'     => esc_attr__('dashicons-admin-users','knor-extra'),
            'public'        => true,
            'rewrite'               => array(
                'slug'              => 'theme-team', 
                'with_front'        => true 
            )
        )
    );
}


/*** Custom taxonomy ***/

add_action( 'init', 'knor_custom_post_taxonomy');

function knor_custom_post_taxonomy() {
    register_taxonomy(
        'theme_portfolio_cat',
        'theme_portfolio',                  
            array(
                'label'                 => esc_html__('Portfolio Category', 'knor-extra'),
                'query_var'             => true,
                'hierarchical'          => true,
                'public'                => true,
                'show_ui'               => true,
                'show_admin_column'     => false,
                'show_in_nav_menus'     => true,
                'show_in_rest'          => true,
                'show_tagcloud'         => true,
                'rewrite'               => array(
                    'slug'              => 'portfolio-category', 
                    'with_front'        => true 
                )
            )
    );
}



// Custom paginations Start
if ( !function_exists( 'knor_paginate_nav' ) ):
    function knor_paginate_nav( $themeQuery = null ) {
        if ( empty( $themeQuery ) ):
            $themeQuery = $GLOBALS['wp_query'];
        endif;
        // Don't print empty markup if there's only one page.
        if ( $themeQuery->max_num_pages < 2 ) {
            return;
        }
        $paged = get_query_var( 'paged' ) ? intval( get_query_var( 'paged' ) ) : 1;
        $pagenum_link = html_entity_decode( get_pagenum_link() );
        $query_args = array();
        $url_parts = explode( '?', $pagenum_link );
        if ( isset( $url_parts[1] ) ) {
            wp_parse_str( $url_parts[1], $query_args );
        }
        $pagenum_link = remove_query_arg( array_keys( $query_args ), $pagenum_link );
        $pagenum_link = trailingslashit( $pagenum_link ) . '%_%';
        $format = $GLOBALS['wp_rewrite']->using_index_permalinks() && !strpos( $pagenum_link, 'index.php' ) ? 'index.php/' : '';
        $format .= $GLOBALS['wp_rewrite']->using_permalinks() ? user_trailingslashit( 'page/%#%', 'paged' ) : '?paged=%#%';
        // Set up paginated links.
        $links = paginate_links( array(
            'base'      => $pagenum_link,
            'format'    => $format,
            'total'     => $themeQuery->max_num_pages,
            'current'   => $paged,
            'add_args'  => array_map( 'urlencode', $query_args ),
            'prev_text' => '<i class="icofont-long-arrow-left" aria-hidden="true"></i>',
            'next_text' => '<i class="icofont-long-arrow-right" aria-hidden="true"></i>',
            'type'      => 'array',
        ) );
        if ( $links ):
        ?>
		<div class="pagination-area">
			<ul class="">
                <?php foreach ( $links as $key => $page_link ): ?>
                    <li class="<?php if ( strpos( $page_link, 'current' ) !== false ) {echo ' active';}?>"><?php echo str_replace( 'span', 'a', $page_link ) ?></li>
                <?php endforeach?>
			</ul>
		</div><!-- .navigation -->
		<?php
endif;
}
endif;
// Custom paginations End