<?php

namespace Elementor;
class Xcency_Service_Box_One_Widget extends Widget_Base {

    public function get_name() {

        return "xcency_service_box_one";
    }

    public function get_title() {
        return __( "Service Box One", "xcency-core" );
    }

    public function get_icon() {

        return "eicon-gallery-grid";
    }

    public function get_categories() {
        return [ 'xcency_core_elements' ];
    }


    protected function register_controls() {
        //Content tab start
        $this->start_controls_section(
            'service_box_settings',
            [
                'label' => __( 'Service Box', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'title',
            [
                'label'       => __( 'Title', 'xcency-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => 'Research & Analysis',
                'label_block' => true,
            ]
        );

	    $repeater->add_control(
		    'desc', [
			    'label' => esc_html__( 'Description', 'xcency-core' ),
			    'type' => Controls_Manager::WYSIWYG,
			    'default' => 'Business plans and strategies guide startups from inception growth.',
			    'label_block' => true,
		    ]
	    );

        $repeater->add_control(
            'selected_icon',
            [
                'label'            => esc_html__( 'Select Icon', 'xcency-core' ),
                'type'             => Controls_Manager::ICONS,
                'fa4compatibility' => 'icon',
                'label_block'      => true,
                'default'          => [
                    'value'   => 'flaticon-software',
                    'library' => 'xcency-icon',
                ],
            ]
        );

        $repeater->add_control(
            'details_url',
            [
                'label'         => __( 'Details Url', 'xcency-core' ),
                'type'          => Controls_Manager::URL,
                'placeholder'   => __( 'https://your-link.com', 'xcency-core' ),
                'show_external' => true,
                'default'       => [
                    'url'         => '',
                    'is_external' => false,
                    'nofollow'    => false,
                ],
            ]
        );

        $this->add_control(
            'services',
            [
                'label'       => __( 'Service List', 'xcency-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [
                    [
                        'title' => 'Research & Analysis',
                        'desc' => 'Business plans and strategies guide startups from inception growth.',
                    ],
                ],
                'title_field' => '{{{ title }}}',
            ]
        );

        $this->add_control(
            'details_btn_text',
            [
                'label'       => esc_html__( 'Details Button Text', 'xcency-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => esc_html__( 'Read More', 'xcency-core' ),
            ]
        );

        $this->add_control(
            'enable_border_two',
            [
                'label'     => esc_html__( 'Enable Bottom Border Two', 'xcency-core' ),
                'type'      => Controls_Manager::SWITCHER,
                'label_on'  => esc_html__( 'Yes', 'xcency-core' ),
                'label_off' => esc_html__( 'No', 'xcency-core' ),
                'default'   => 'no',
            ]
        );

        $this->end_controls_section();



        $this->start_controls_section(
            'service_layout_settings',
            [
                'label' => __( 'Service Column', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'desktop_col',
            [
                'label'   => __( 'Columns On Desktop', 'xcency-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'col-xl-4',
                'options' => [
                    'col-xl-12' => __( '1 Column', 'xcency-core' ),
                    'col-xl-6'  => __( '2 Column', 'xcency-core' ),
                    'col-xl-4'  => __( '3 Column', 'xcency-core' ),
                    'col-xl-3'  => __( '4 Column', 'xcency-core' ),
                ],
            ]
        );

        $this->add_control(
            'iPad_pro_col',
            [
                'label'   => __( 'Columns On iPad Pro', 'xcency-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'col-lg-4',
                'options' => [
                    'col-lg-12' => __( '1 Column', 'xcency-core' ),
                    'col-lg-6'  => __( '2 Column', 'xcency-core' ),
                    'col-lg-4'  => __( '3 Column', 'xcency-core' ),
                    'col-lg-3'  => __( '4 Column', 'xcency-core' ),
                ],
            ]
        );

        $this->add_control(
            'tab_col',
            [
                'label'   => __( 'Columns On Tablet', 'xcency-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'col-md-6',
                'options' => [
                    'col-md-12' => __( '1 Column', 'xcency-core' ),
                    'col-md-6'  => __( '2 Column', 'xcency-core' ),
                    'col-md-4'  => __( '3 Column', 'xcency-core' ),
                    'col-md-3'  => __( '4 Column', 'xcency-core' ),
                ],
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            'service_box_style_options',
            [
                'label' => esc_html__( 'Service Box', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typo',
                'label' => esc_html__( 'Title Typography', 'xcency-core' ),
                'selector' => '{{WRAPPER}} .xcency-service-one-title',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'desc_typo',
                'label' => esc_html__( 'Description Typography', 'xcency-core' ),
                'selector' => '{{WRAPPER}} .xcency-service-one-desc',
            ]
        );

        $this->add_responsive_control(
            'box_padding',
            [
                'label'      => esc_html__( 'Box Padding', 'xcency-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .service-one-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->start_controls_tabs('xcency_icon_box_style_tabs');

        //Default style tab start
        $this->start_controls_tab(
            'xcency_box_style_default',
            [
                'label' => esc_html__('Default', 'xcency-core'),
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label'     => esc_html__('Icon Color', 'xcency-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-one-icon' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .service-one-icon svg path' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'box_bg_color',
            [
                'label'     => esc_html__('Box Background Color', 'xcency-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-one-item' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'box_border_color',
            [
                'label'     => esc_html__('Box Border Color', 'xcency-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-one-item' => 'border: 1px solid {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'     => esc_html__('Title Color', 'xcency-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .xcency-service-one-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'desc_color',
            [
                'label'     => esc_html__('Description Color', 'xcency-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .xcency-service-one-desc' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'btn_default_color',
            [
                'label'       => esc_html__('Button Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .xcency-service-one-btn a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'bottom_border_color',
            [
                'label'       => esc_html__('Bottom Border Two Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .border-two-enable .service-one-item:before' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'enable_border_two' => 'yes',
                ],
            ]
        );

        $this->end_controls_tab();//Default style tab end

        //Hover style tab start
        $this->start_controls_tab(
            'xcency_box_style_hover',
            [
                'label' => esc_html__('Hover', 'xcency-core'),
            ]
        );

        $this->add_control(
            'hover_icon_color',
            [
                'label'     => esc_html__('Icon Color', 'xcency-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-one-item:hover .service-one-icon' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .service-one-item:hover .service-one-icon svg path' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'hover_box_bg_color',
            [
                'label'     => esc_html__('Box Background Color', 'xcency-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-one-item:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

	    $this->add_control(
		    'box_hover_border_color',
		    [
			    'label'     => esc_html__('Box Border Color', 'xcency-core'),
			    'type'      => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .service-one-item:hover' => 'border: 1px solid {{VALUE}};',
			    ],
		    ]
	    );

        $this->add_control(
            'hover_title_color',
            [
                'label'     => esc_html__('Title Color', 'xcency-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-one-item:hover .xcency-service-one-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'hover_desc_color',
            [
                'label'     => esc_html__('Description Color', 'xcency-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-one-item:hover .xcency-service-one-desc' => 'color: {{VALUE}};',
                ],
            ]
        );

	    $this->add_control(
		    'btn_hover_color',
		    [
			    'label'       => esc_html__('Button Color', 'xcency-core'),
			    'type'        => Controls_Manager::COLOR,
			    'selectors'   => [
				    '{{WRAPPER}} .service-one-item:hover .xcency-service-one-btn a' => 'color: {{VALUE}};',
			    ],
		    ]
	    );

	    $this->add_control(
		    'bottom_border_hover_color',
		    [
			    'label'       => esc_html__('Bottom Border Two Color', 'xcency-core'),
			    'type'        => Controls_Manager::COLOR,
			    'selectors'   => [
				    '{{WRAPPER}} .border-two-enable .service-one-item:hover:before' => 'border-color: {{VALUE}};',
			    ],
			    'condition' => [
				    'enable_border_two' => 'yes',
			    ],
		    ]
	    );

        $this->end_controls_tabs();//Hover style tab end
        $this->end_controls_section();
    }


    //Render In HTML
    protected function render() {
        $settings = $this->get_settings_for_display();
	    $column = $settings['desktop_col'] . ' ' . $settings['iPad_pro_col'] . ' ' . $settings['tab_col'];
        ?>

        <div class="xcency-service-box-wrapper <?php if($settings['enable_border_two'] == 'yes'){echo 'border-two-enable';}?>">
            <div class="row">
                <?php if ( $settings['services'] ) {
                    foreach ( $settings['services'] as $service ) {
                        $url      = $service['details_url']['url'];
                        $target   = $service['details_url']['is_external'] ? ' target="_blank"' : '';
                        $nofollow = $service['details_url']['nofollow'] ? ' rel="nofollow"' : '';

                        ?>
                        <div class="<?php echo $column;?>">
                            <div class="service-one-item">

                                <div class="service-one-icon">
                                    <?php xcency_custom_icon_render($service, 'icon', 'selected_icon'); ?>
                                </div>

                                <div class="service-one-content">
                                    <a href="<?php echo esc_url($url);?>" <?php echo $target . $nofollow;?>>
                                        <h4 class="xcency-service-one-title"><?php echo $service['title'];?></h4>
                                    </a>

                                    <div class="xcency-service-one-desc xcency-last-p-0">
                                        <?php echo $service['desc'];?>
                                    </div>

                                    <div class="xcency-service-one-btn">
                                        <a href="<?php echo esc_url($url);?>"><?php echo $settings['details_btn_text'];?></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php }
                } ?>
            </div>
        </div>
        <?php

    }
}

Plugin::instance()->widgets_manager->register( new Xcency_Service_Box_One_Widget );