<?php
namespace Elementor;
use WP_Query;
class Xcency_Team_Member_One_Widget extends Widget_Base {

    public function get_name() {

        return 'xcency_team_member_one';
    }

    public function get_title() {
        return esc_html__( 'Team Member One', 'xcency-core' );
    }

    public function get_icon() {

        return 'flaticon-customer-service';
    }

    public function get_categories() {
        return [ 'xcency_core_elements' ];
    }


    protected function register_controls() {

        //Content tab start
        $this->start_controls_section(
            'team_one_options',
            [
                'label' => esc_html__( 'Team Members', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'member_name',
            [
                'label'       => __( 'Member Name', 'xcency-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => 'Robert Simmons',
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'designation',
            [
                'label'       => __( 'Designation', 'xcency-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => 'CEO & Founder',
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'image',
            [
                'label'       => __( 'Member Image', 'xcency-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'selected_member_profile',
            [
                'label'       => __( 'Social Profile & <br> Details Link', 'xcency-core' ),
                'type'        => Controls_Manager::SELECT,
                'show_label'  => true,
                'label_block' => false,
                'options'     => xcency_core_team_member_list(),
                'description' => esc_html__( 'Select member name to associate his/her details page link.', 'xcency-core' ),
            ]
        );

        $this->add_control(
            'members',
            [
                'label'       => __( 'Member List', 'xcency-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [
                    [
                        'member_name' => 'Robert Simmons',
                        'designation' => 'CEO & Founder',
                    ],
                ],
                'title_field' => '{{{ member_name }}}',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'team_member_column',
            [
                'label' => esc_html__( 'Column', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'xl_col',
            [
                'label'   => __( 'Columns On Desktop', 'xcency-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'col-xl-3',
                'options' => [
                    'col-xl-12' => __( '1 Column', 'xcency-core' ),
                    'col-xl-6'  => __( '2 Column', 'xcency-core' ),
                    'col-xl-4'  => __( '3 Column', 'xcency-core' ),
                    'col-xl-3'  => __( '4 Column', 'xcency-core' ),
                ],
            ]
        );

        $this->add_control(
            'lg_col',
            [
                'label'   => __( 'Columns On iPad Pro', 'xcency-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'col-lg-4',
                'options' => [
                    'col-lg-12' => __( '1 Column', 'xcency-core' ),
                    'col-lg-6'  => __( '2 Column', 'xcency-core' ),
                    'col-lg-4'  => __( '3 Column', 'xcency-core' ),
                    'col-lg-3'  => __( '4 Column', 'xcency-core' ),
                ],
            ]
        );

        $this->add_control(
            'md_col',
            [
                'label'   => __( 'Columns On iPad', 'xcency-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'col-md-6',
                'options' => [
                    'col-md-12' => __( '1 Column', 'xcency-core' ),
                    'col-md-6'  => __( '2 Column', 'xcency-core' ),
                    'col-md-4'  => __( '3 Column', 'xcency-core' ),
                    'col-md-3'  => __( '4 Column', 'xcency-core' ),
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'team_one_style',
            [
                'label' => esc_html__( 'Team Members', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'social_icon_bg',
            [
                'label'     => esc_html__( 'Social Icon Background', 'xcency-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .xcency-team-member-social' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'social_icon_color',
            [
                'label'     => esc_html__( 'Social Icon', 'xcency-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .xcency-team-member-social ul li a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'social_icon_hover_color',
            [
                'label'     => esc_html__( 'Social Icon Hover Color', 'xcency-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .xcency-team-member-social ul li a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    //Render
    protected function render() {
        $settings = $this->get_settings_for_display();
        $col = $settings['xl_col'] . ' ' . $settings['lg_col'] . ' ' . $settings['md_col'];
        ?>

        <div class="xcency-team-one-wrapper">
            <div class="row">
                <?php
                if ( $settings['members'] ) {
                    foreach ( $settings['members'] as $member ) {
                        $image_src = $member['image']['url'];
                        $image_alt = get_post_meta( $member['image']['id'], '_wp_attachment_image_alt', true );
                        $image_title = get_the_title($member['image']['id']);
                        $name = $member['member_name'];
                        $designation = $member['designation'];

                        $member_query = new WP_Query(
                            array(
                                'posts_per_page' => 1,
                                'post_type'      => 'xcency_team',
                                'p'              => $member['selected_member_profile'],
                            )
                        );

                        while ( $member_query->have_posts() ) :
                            $member_query->the_post();
                            if ( get_post_meta( get_the_ID(), 'xcency_team_meta', true ) ) {
                                $team_meta = get_post_meta( get_the_ID(), 'xcency_team_meta', true );
                            } else {
                                $team_meta = array();
                            }

                            if ( array_key_exists( 'member_social_profile', $team_meta ) ) {
                                $member_social = $team_meta['member_social_profile'];
                            } else {
                                $member_social = array();
                            }
                            ?>

                            <div class="<?php echo $col;?>">
                                <div class="xcency-single-team-member">
                                    <?php if($member['selected_member_profile']){ ?>

                                        <div class="xcency-member-image-wrapper">
                                            <a class="xcency-member-image" href="<?php the_permalink(); ?>">
                                                <img src="<?php echo $image_src;?>" alt="<?php echo $image_alt;?>" title="<?php echo $image_title;?>">
                                            </a>

                                            <div class="xcency-team-member-social-wrapper">
                                                <div class="xcency-team-member-social">
                                                    <ul>
                                                        <?php
                                                        foreach ( $member_social as $social ) {
                                                            $icon = $social['site_icon'];
                                                            $url  = $social['site_url']; ?>
                                                            <li>
                                                                <a target="_blank" href="<?php echo esc_url($url); ?>">
                                                                    <i class="<?php echo $icon; ?>"></i>
                                                                </a>
                                                            </li>
                                                            <?php
                                                        }
                                                        ?>
                                                    </ul>
                                                </div>
                                            </div>

                                        </div>

                                        <div class="xcency-member-designation-name text-center">
                                            <a href="<?php the_permalink(); ?>">
                                                <h3 class="xcency-team-member-name"><?php echo $name;?></h3>
                                            </a>
                                            <span class="xcency-member-designation"><?php echo $designation;?></span>
                                        </div>
                                    <?php }else{ ?>

                                        <div class="xcency-member-image-wrapper">
                                            <div class="xcency-member-image">
                                                <img src="<?php echo $image_src;?>" alt="<?php echo $image_alt;?>" title="<?php echo $image_title;?>">
                                            </div>
                                        </div>

                                        <div class="xcency-member-designation-name text-center">
                                            <h3 class="xcency-team-member-name"><?php echo $name;?></h3>
                                            <span class="xcency-member-designation"><?php echo $designation;?></span>
                                        </div>
                                    <?php }?>
                                </div>
                            </div>
                        <?php
                        endwhile;
                        wp_reset_query();
                    }
                }
                ?>
            </div>
        </div>
        <?php
    }
}

Plugin::instance()->widgets_manager->register( new Xcency_Team_Member_One_Widget );