<?php
///----footer widgets---
//Contact Us
class Earls_Contact_Us extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Earls_Contact_Us', /* Name */esc_html__('Earls Contact Us','earls'), array( 'description' => esc_html__('Show the Contact Us', 'earls' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget);
		?>
                               
        <div class="footer__widget">
            <div class="widget__content">
                <div class="footer__content">
                    <?php echo wp_kses_post($before_title.$title.$after_title); ?>
                    <p><?php echo wp_kses( $instance[ 'footer_widget_address' ], true );?> </p>
                    <p> <?php echo wp_kses( $instance[ 'footer_widget_phone_no' ], true );?> </p>
                </div>                
            </div>
        </div>
                             
        <?php		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['footer_widget_address'] = $new_instance['footer_widget_address'];
		$instance['footer_widget_phone_no'] = $new_instance['footer_widget_phone_no'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ($instance) ? esc_attr($instance['title']) : '';
		$footer_widget_address = ($instance) ? esc_attr($instance['footer_widget_address']) : '';
		$footer_widget_phone_no = ($instance) ? esc_attr($instance['footer_widget_phone_no']) : '';
	?>
    
    <p>
        <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title: ', 'earls'); ?></label>
        <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
    </p> 
    <p>
        <label for="<?php echo esc_attr($this->get_field_id('footer_widget_address')); ?>"><?php esc_html_e('Address:', 'earls'); ?></label>
        <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('footer_widget_address')); ?>" name="<?php echo esc_attr($this->get_field_name('footer_widget_address')); ?>" ><?php echo wp_kses_post($footer_widget_address); ?></textarea>
    </p>
    <p>
        <label for="<?php echo esc_attr($this->get_field_id('footer_widget_phone_no')); ?>"><?php esc_html_e('Phone Number:', 'earls'); ?></label>
        <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('footer_widget_phone_no')); ?>" name="<?php echo esc_attr($this->get_field_name('footer_widget_phone_no')); ?>" ><?php echo wp_kses_post($footer_widget_phone_no); ?></textarea>
    </p>
    
    <?php 
	}
	
}

//About Company
class Earls_About_Company extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Earls_About_Company', /* Name */esc_html__('Earls About Company','earls'), array( 'description' => esc_html__('Show the About Company', 'earls' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		echo wp_kses_post($before_widget);?>
                               
        <div class="footer__widget__middel">
            <div class="widget__content">
                <?php if($instance['widget_logo_img']) { ?>
                <div class="footer__logo">
                    <figure>
                        <img src="<?php echo esc_url( $instance['widget_logo_img'] );?>" alt="<?php esc_attr_e( 'Awesome Image', 'earls' );?>">
                    </figure>
                </div>
                <?php } ?>
                
                <?php if($instance[ 'content' ]){ ?>
                <div class="footer__middel__text">
                    <p><?php echo wp_kses( $instance[ 'content' ], true );?> </p>
                </div>
                <?php } ?>
                
                <?php if( $instance['show'] ): ?>
				<?php echo wp_kses(earls_get_social_icon(), true); ?>
                <?php endif; ?>
            	
                <?php if($instance[ 'widget_copyright' ]){ ?>
                <div class="copy__right">
                    <p> <?php echo wp_kses( $instance[ 'widget_copyright' ], true );?></p>
                </div>
                <?php } ?>
            </div>
        </div>
                             
        <?php		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		$instance['widget_logo_img'] = strip_tags($new_instance['widget_logo_img']);
		$instance['content'] = $new_instance['content'];
		$instance['show'] = $new_instance['show'];
		$instance['widget_copyright'] = $new_instance['widget_copyright'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$widget_logo_img = ($instance) ? esc_attr($instance['widget_logo_img']) : '';
		$content = ($instance) ? esc_attr($instance['content']) : '';
		$show = ($instance) ? esc_attr($instance['show']) : '';
		$widget_copyright = ($instance) ? esc_attr($instance['widget_copyright']) : '';
	?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('widget_logo_img')); ?>"><?php esc_html_e('Widget Logo Image: ', 'earls'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('widget_logo_img')); ?>" name="<?php echo esc_attr($this->get_field_name('widget_logo_img')); ?>" type="text" value="<?php echo esc_attr( $widget_logo_img ); ?>" />
        </p> 
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('content')); ?>"><?php esc_html_e('Content:', 'earls'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('content')); ?>" name="<?php echo esc_attr($this->get_field_name('content')); ?>" ><?php echo wp_kses_post($content); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('show')); ?>"><?php esc_html_e('Show Social Icons:', 'earls'); ?></label>
			<?php $selected = ( $show ) ? ' checked="checked"' : ''; ?>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('show')); ?>"<?php echo esc_attr($selected); ?> name="<?php echo esc_attr($this->get_field_name('show')); ?>" type="checkbox" value="true" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('widget_copyright')); ?>"><?php esc_html_e('Enter Copyright Text:', 'earls'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('widget_copyright')); ?>" name="<?php echo esc_attr($this->get_field_name('widget_copyright')); ?>" ><?php echo wp_kses_post($widget_copyright); ?></textarea>
        </p>
    <?php 
	}
	
}

//Working Hours
class Earls_Working_Hours extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Earls_Working_Hours', /* Name */esc_html__('Earls Working Hours','earls'), array( 'description' => esc_html__('Show the Working Hours', 'earls' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget);
		?>
        
        <div class="footer__widget style-two">
            <div class="widget__content">
                <div class="footer__content">
                    <?php echo wp_kses_post($before_title.$title.$after_title); ?>
                    <div class="working___time">
                        <?php if($instance[ 'mon_fri_working_days' ]){ ?><p><?php echo wp_kses( $instance[ 'mon_fri_working_days' ], true );?></p><?php } ?>
                        <?php if($instance[ 'sat_sun_working_days' ]){ ?><p> <?php echo wp_kses( $instance[ 'sat_sun_working_days' ], true );?></p><?php } ?>    
                    </div>
                </div>
            </div>
        </div>
                             
        <?php		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['mon_fri_working_days'] = $new_instance['mon_fri_working_days'];
		$instance['sat_sun_working_days'] = $new_instance['sat_sun_working_days'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ($instance) ? esc_attr($instance['title']) : '';
		$mon_fri_working_days = ($instance) ? esc_attr($instance['mon_fri_working_days']) : '';
		$sat_sun_working_days = ($instance) ? esc_attr($instance['sat_sun_working_days']) : '';
	?>
    
    <p>
        <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title: ', 'earls'); ?></label>
        <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
    </p> 
    <p>
        <label for="<?php echo esc_attr($this->get_field_id('mon_fri_working_days')); ?>"><?php esc_html_e('Monday To Friday Time:', 'earls'); ?></label>
        <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('mon_fri_working_days')); ?>" name="<?php echo esc_attr($this->get_field_name('mon_fri_working_days')); ?>" ><?php echo wp_kses_post($mon_fri_working_days); ?></textarea>
    </p>
    <p>
        <label for="<?php echo esc_attr($this->get_field_id('sat_sun_working_days')); ?>"><?php esc_html_e('Saturday To Sunday Time:', 'earls'); ?></label>
        <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('sat_sun_working_days')); ?>" name="<?php echo esc_attr($this->get_field_name('sat_sun_working_days')); ?>" ><?php echo wp_kses_post($sat_sun_working_days); ?></textarea>
    </p>
    
    <?php 
	}
	
}

///----footer Two widgets---
//About Company
class Earls_About_Company_V2 extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Earls_About_Company_V2', /* Name */esc_html__('Earls About Company V2','earls'), array( 'description' => esc_html__('Show the About Company V2', 'earls' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		echo wp_kses_post($before_widget);?>
        
        <div class="footer__widget">
            <div class="widget__content">
                <?php if($instance['widget_logo_img']) { ?>
                <div class="footer__logo">
                    <figure>
                        <img src="<?php echo esc_url( $instance['widget_logo_img'] );?>" alt="<?php esc_attr_e( 'Awesome Image', 'earls' );?>">
                    </figure>
                </div>
                <?php } ?>
                
				<?php if( $instance['show'] ): ?>
				<?php echo wp_kses(earls_get_social_icon(), true); ?>
                <?php endif; ?>
                
                <?php if($instance[ 'content' ]){ ?>
                <div class="footer__middel__text">
                    <p><?php echo wp_kses( $instance[ 'content' ], true );?> </p>
                </div>
                <?php } ?>
            </div>
        </div>
                           
        <?php		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		$instance['widget_logo_img'] = strip_tags($new_instance['widget_logo_img']);
		$instance['show'] = $new_instance['show'];
		$instance['content'] = $new_instance['content'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$widget_logo_img = ($instance) ? esc_attr($instance['widget_logo_img']) : '';
		$show = ($instance) ? esc_attr($instance['show']) : '';
		$content = ($instance) ? esc_attr($instance['content']) : '';
	?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('widget_logo_img')); ?>"><?php esc_html_e('Widget Logo Image: ', 'earls'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('widget_logo_img')); ?>" name="<?php echo esc_attr($this->get_field_name('widget_logo_img')); ?>" type="text" value="<?php echo esc_attr( $widget_logo_img ); ?>" />
        </p> 
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('show')); ?>"><?php esc_html_e('Show Social Icons:', 'earls'); ?></label>
			<?php $selected = ( $show ) ? ' checked="checked"' : ''; ?>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('show')); ?>"<?php echo esc_attr($selected); ?> name="<?php echo esc_attr($this->get_field_name('show')); ?>" type="checkbox" value="true" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('content')); ?>"><?php esc_html_e('Content:', 'earls'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('content')); ?>" name="<?php echo esc_attr($this->get_field_name('content')); ?>" ><?php echo wp_kses_post($content); ?></textarea>
        </p>
    <?php 
	}
	
}



///----Blog widgets---
//Opening Time
class Earls_Opening_Time extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Earls_Opening_Time', /* Name */esc_html__('Earls Opening Time','earls'), array( 'description' => esc_html__('Show the Opening Time', 'earls' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget);
		?>
        
        <div class="opning-time">
            <?php echo wp_kses_post($before_title.$title.$after_title); ?>
            <div class="widget-content">
                <?php if($instance[ 'opening_days' ]){ ?><p class="m-0"><?php echo wp_kses( $instance[ 'opening_days' ], true );?> </p><?php } ?>
                <?php if($instance[ 'happy_hour' ]){ ?><p class="mt-3"><?php echo wp_kses( $instance[ 'happy_hour' ], true );?></p><?php } ?>
            </div>
        </div>
                                     
        <?php		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['opening_days'] = $new_instance['opening_days'];
		$instance['happy_hour'] = $new_instance['happy_hour'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ($instance) ? esc_attr($instance['title']) : '';
		$opening_days = ($instance) ? esc_attr($instance['opening_days']) : '';
		$happy_hour = ($instance) ? esc_attr($instance['happy_hour']) : '';
	?>
    
    <p>
        <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title: ', 'earls'); ?></label>
        <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
    </p> 
    <p>
        <label for="<?php echo esc_attr($this->get_field_id('opening_days')); ?>"><?php esc_html_e('Opening Time:', 'earls'); ?></label>
        <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('opening_days')); ?>" name="<?php echo esc_attr($this->get_field_name('opening_days')); ?>" ><?php echo wp_kses_post($opening_days); ?></textarea>
    </p>
    <p>
        <label for="<?php echo esc_attr($this->get_field_id('happy_hour')); ?>"><?php esc_html_e('happy Hour:', 'earls'); ?></label>
        <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('happy_hour')); ?>" name="<?php echo esc_attr($this->get_field_name('happy_hour')); ?>" ><?php echo wp_kses_post($happy_hour); ?></textarea>
    </p>
    
    <?php 
	}
	
}

//About Company V3
class Earls_About_Company_V3 extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Earls_About_Company_V3', /* Name */esc_html__('Earls About Company V3','earls'), array( 'description' => esc_html__('Show the About Company V3', 'earls' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		echo wp_kses_post($before_widget);?>
        
        <div class="about-company">
            <?php echo wp_kses_post($before_title.$title.$after_title); ?>
            <div class="widget-content">
                <?php if($instance['widget_about_img']) { ?>
                <div class="left__site">
                    <figure>
                        <img src="<?php echo esc_url( $instance['widget_about_img'] );?>" alt="<?php esc_attr_e( 'Awesome Image', 'earls' );?>">
                    </figure>
                </div>
                <?php } ?>
                <div class="right__site">
                    <p> <?php echo wp_kses( $instance[ 'content' ], true );?> </p>
                    <?php if($instance['widget_signature_img']){ ?>
                    <div class="signeture">
                        <img src="<?php echo esc_url( $instance['widget_signature_img'] );?>" alt="<?php esc_attr_e( 'Awesome Image', 'earls' );?>">
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
                          
        <?php		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['widget_about_img'] = $new_instance['widget_about_img'];
		$instance['content'] = $new_instance['content'];
		$instance['widget_signature_img'] = $new_instance['widget_signature_img'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ($instance) ? esc_attr($instance['title']) : '';
		$widget_about_img = ($instance) ? esc_attr($instance['widget_about_img']) : '';
		$content = ($instance) ? esc_attr($instance['content']) : '';
		$widget_signature_img = ($instance) ? esc_attr($instance['widget_signature_img']) : '';
	?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Enter Title: ', 'earls'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
        </p> 
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('widget_about_img')); ?>"><?php esc_html_e('Widget About Image: ', 'earls'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('widget_about_img')); ?>" name="<?php echo esc_attr($this->get_field_name('widget_about_img')); ?>" type="text" value="<?php echo esc_attr( $widget_about_img ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('content')); ?>"><?php esc_html_e('Content:', 'earls'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('content')); ?>" name="<?php echo esc_attr($this->get_field_name('content')); ?>" ><?php echo wp_kses_post($content); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('widget_signature_img')); ?>"><?php esc_html_e('Widget Signature Image: ', 'earls'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('widget_signature_img')); ?>" name="<?php echo esc_attr($this->get_field_name('widget_signature_img')); ?>" type="text" value="<?php echo esc_attr( $widget_signature_img ); ?>" />
        </p>
    <?php 
	}
	
}

//Recent Posts
class Earls_Recent_Posts extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Earls_Recent_Posts', /* Name */esc_html__('Earls Recent Posts','earls'), array( 'description' => esc_html__('Show the Recent Posts', 'earls' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );

		echo wp_kses_post($before_widget); ?>
		
        <!--Start Single Sidebar Box-->
        <div class="post-widget">
            <?php echo wp_kses_post($before_title.$title.$after_title); ?>
            <div class="widget-content">
                <div class="post-inner">
                    <?php $query_string = array('showposts'=>$instance['number']);
					if ($instance['cat']) {
						$query_string['tax_query'] = array(array('taxonomy' => 'category','field' => 'id','terms' => (array)$instance['cat']));
					}
					$this->posts($query_string); ?>
                </div>
            </div>
        </div>
        <!--End Single Sidebar Box-->
        
		<?php echo wp_kses_post($after_widget);
	}
 
 
	/* @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = $new_instance['number'];
		$instance['cat'] = $new_instance['cat'];
		
		return $instance;
	}

	/* @see WP_Widget::form */
	function form($instance)
	{
		$title = ( $instance ) ? esc_attr($instance['title']) : esc_html__('Recent Posts', 'earls');
		$number = ( $instance ) ? esc_attr($instance['number']) : 3;
		$cat = ( $instance ) ? esc_attr($instance['cat']) : '';?>
			
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title: ', 'earls'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('No. of Posts:', 'earls'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('categories')); ?>"><?php esc_html_e('Category', 'earls'); ?></label>
            <?php wp_dropdown_categories(array('show_option_all'=>esc_html__('All Categories', 'earls'), 'taxonomy' => 'category', 'selected'=>$cat, 'class'=>'widefat', 'name'=>$this->get_field_name('cat'))); ?>
        </p>
            
		<?php 
	}
	
	function posts($query_string)
	{
		
		$query = new WP_Query($query_string);
		if( $query->have_posts() ):?>
        
           	<!-- Title -->
			<?php 
				global $post;
				while ( $query->have_posts() ) : $query->the_post(); 
				$post_thumbnail_id = get_post_thumbnail_id($post->ID);
				$post_thumbnail_url = wp_get_attachment_url($post_thumbnail_id);
			?>
            <div class="post">
                <figure class="post-thumb" style="background-image:url('<?php echo esc_url($post_thumbnail_url);?>'); "><a href="<?php echo esc_url(get_the_permalink(get_the_id()));?>"></a></figure>
                <div class="re__post__content">
                    <p><span><?php echo get_the_date('M');?></span> <?php echo get_the_date('d, y');?></p>
                    <h6><a href="<?php echo esc_url(get_the_permalink(get_the_id()));?>"><?php the_title(); ?></a></h6>
                </div>
            </div>
                        
            <?php endwhile; ?>
            
        <?php endif;
		wp_reset_postdata();
    }
}

//Our Portfolio
class Earls_Our_Portfolio extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Earls_Our_Portfolio', /* Name */esc_html__('Earls Our Portfolio','earls'), array( 'description' => esc_html__('Show the Our Portfolio', 'earls' )) );
	}
 
	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget); ?>
		
        <div class="instagram-post">
            <?php echo wp_kses_post($before_title.$title.$after_title); ?>
            <div class="widget-content">
                <div class="instagram__content">
                    <?php 
						$args = array('post_type' => 'project', 'showposts'=>$instance['number']);
						if( $instance['cat'] ) $args['tax_query'] = array(array('taxonomy' => 'project_cat','field' => 'id','terms' => (array)$instance['cat']));
						$this->posts($args);
                    ?>
                </div>
            </div>
        </div>
                        
        <?php echo wp_kses_post($after_widget);
	}
 
 
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['title'] = $new_instance['title'];
		$instance['number'] = $new_instance['number'];
		$instance['cat'] = $new_instance['cat'];
		
		return $instance;
	}
	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ( $instance ) ? esc_attr($instance['title']) : 'Our Portfolio';
		$number = ( $instance ) ? esc_attr($instance['number']) : 8;
		$cat = ( $instance ) ? esc_attr($instance['cat']) : '';
		?>
		
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'earls'); ?></label>
            <input placeholder="<?php esc_attr_e('Recent Gallery', 'earls');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('Number of posts: ', 'earls'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('cat')); ?>"><?php esc_html_e('Category', 'earls'); ?></label>
            <?php wp_dropdown_categories( array('show_option_all'=>esc_html__('All Categories', 'earls'), 'selected'=>$cat, 'taxonomy' => 'project_cat', 'class'=>'widefat', 'name'=>$this->get_field_name('cat')) ); ?>
        </p>
        
		<?php 
	}
	
	function posts($args)
	{
		
		$query = new WP_Query($args);
		if( $query->have_posts() ):?>
        
           	<!-- Title -->
            <?php 
				while( $query->have_posts() ): $query->the_post(); 
			?>
            <div class="instagram__img">
                <a href="<?php echo esc_url(get_the_permalink(get_the_id()));?>" class="icon-">
                	<?php the_post_thumbnail('earls_100x100'); ?>
                </a>
            </div>
            <?php endwhile; ?>
                
        <?php endif;
		wp_reset_postdata();
    }
}

