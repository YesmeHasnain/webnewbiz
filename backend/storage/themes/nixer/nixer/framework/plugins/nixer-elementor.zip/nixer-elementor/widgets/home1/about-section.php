<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome1AboutSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home1-about-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 1 - About Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-alert';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home1' ];
	}

	public function get_keywords() {
		return [ 'home1aboutsection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_about_section',
			[
				'label' => esc_html__( 'About Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'We help you connect with <br> your customers' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'img_left_sec',
			[
				'label'       	=> esc_html__( 'Image Left Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image left section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'text_sec_1',
			[
				'label' 		=> esc_html__( 'Text Section 1', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Growth and operational...' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_sec_2',
			[
				'label' 		=> esc_html__( 'Text Section 2', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'In this introduction...' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_btn',
			[
				'label' 		=> esc_html__( 'Text Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'About Us' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'link_btn',
			[
				'label' 		=> esc_html__( 'Link Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '#' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'img_thumb_bt_sec',
			[
				'label'       	=> esc_html__( 'Image Thumbnail Bottom Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image thumbnail bottom section', 'bdevs-elementor' ),
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-about-ptb fix pt-100 pb-150">
	<div class="container">
		<?php if (!empty($settings['title_sec'])): ?>
			<div class="row">
				<div class="col-lg-12">
					<div class="tp-about-heading mb-80">
						<h3 class="tp-section-title titleBurrowing"><?php echo wp_kses_post($settings['title_sec']); ?></h3>
					</div>
				</div>
			</div>
		<?php endif ?>
		<div class="tp-about-box pb-180">
			<div class="row align-items-end">
				<div class="col-lg-5">
					<?php if (!empty($settings['img_left_sec']['url'])): ?>
						<div class="tp-about-thumb tp_fade_bottom">
							<img src="<?php echo wp_kses_post($settings['img_left_sec']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_left_sec']['alt']); ?>">
						</div>
					<?php endif ?>
				</div>
				<div class="col-lg-7">
					<div class="tp-about-content">
						<?php if (!empty($settings['text_sec_1'])): ?>
							<p class="tp-about-text-1 tp_fade_bottom"><?php echo wp_kses_post($settings['text_sec_1']); ?></p>
						<?php endif ?>
						<?php if (!empty($settings['text_sec_2'])): ?>
							<p class="tp-about-text-2 tp_fade_bottom"><?php echo wp_kses_post($settings['text_sec_2']); ?></p>
						<?php endif ?>
						<?php if (!empty($settings['link_btn']) && !empty($settings['text_btn'])): ?>
							<div class="tp-about-btn tp_fade_bottom">
								<a class="tp-btn button-style-2" href="<?php echo wp_kses_post($settings['link_btn']); ?>">
									<?php echo wp_kses_post($settings['text_btn']); ?>
									<span>
										<svg xmlns="http://www.w3.org/2000/svg" width="19" height="16" viewBox="0 0 19 16" fill="none">
											<path d="M0 7.80933H17.6902M10.7188 0C10.7188 4.31672 14.4207 7.80972 18.9956 7.80972C14.4207 7.80972 10.7188 11.3023 10.7188 15.6191" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10"/>
										</svg>
									</span>
								</a>
							</div>
						<?php endif ?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php if (!empty($settings['img_thumb_bt_sec']['url'])): ?>
		<div class="container-fluid gx-0 p-0">
			<div class="row gx-0 p-0">
				<div class="tp-about-wrap fix">
					<img class="w-100" data-speed=".8" src="<?php echo wp_kses_post($settings['img_thumb_bt_sec']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_thumb_bt_sec']['alt']); ?>">
				</div>
			</div>
		</div>
	<?php endif ?>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-bg-color]").each(function () {
			jQuery(this).css("background-color", jQuery(this).attr("data-bg-color"));
		});

		function setupSplits() {
		// Target all elements with class "animate-text"
		var elements = document.querySelectorAll('.titleBurrowing');

		// Loop over each element and apply SplitText animation
		elements.forEach(element => {
			var tlSplit = gsap.timeline(),
				splitInstance = new SplitText(element, {type: "words,chars"}),
				chars = splitInstance.chars; // Array of divs wrapping each character
			
			tlSplit.from(chars, {
			duration: 0.8,
			opacity: 0,
			y: 10,
			ease: "circ.out",
			stagger: 0.02,
			scrollTrigger: {
				trigger: element,
				start: "top 75%",
				end: "bottom center",
				scrub: 1
			}
			});
		});
		}

		ScrollTrigger.addEventListener("refresh", setupSplits);
		setupSplits();

		gsap.registerPlugin(ScrollTrigger, ScrollSmoother);
		var smoother = ScrollSmoother.create({
			smooth: 2,
			effects: true,
			smoothTouch: true
		});
	</script>
<?php } ?>

<?php
}

}