// IIFE with jQuery Wrapper
(function ($) {
  "use strict";

}(jQuery));