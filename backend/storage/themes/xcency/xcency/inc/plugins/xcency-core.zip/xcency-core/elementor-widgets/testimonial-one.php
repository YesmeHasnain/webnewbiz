<?php
namespace Elementor;
class Xcency_Testimonial_One_Widget extends Widget_Base {

	public function get_name() {

		return 'xcency_testimonial_one';
	}

	public function get_title() {
		return esc_html__( 'Testimonials One', 'xcency-core' );
	}

	public function get_icon() {

		return 'eicon-testimonial';
	}

	public function get_categories() {
		return [ 'xcency_core_elements' ];
	}


	protected function register_controls() {

		//Content tab start
		$this->start_controls_section(
			'testimonial_settings',
			[
				'label' => esc_html__( 'Testimonial One', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'author_name',
			[
				'label'       => __('Name', 'xcency-core'),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Karen Mckenzie',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'designation',
			[
				'label'       => __('Designation', 'xcency-core'),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'CEO Of Xcency',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'photo',
			[
				'label'       => __( 'Image', 'xcency-core' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'default'     => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);


		$repeater->add_control(
			'testimonial_text',
			[
				'label'   => __('Description', 'xcency-core'),
				'type'    => Controls_Manager::WYSIWYG,
				'default' => 'This is due to their excellent servic competiti of pricing and custome refresing to get more such personal and most flamable furtune touch.',
			]
		);

		$this->add_control(
			'testimonials',
			[
				'label'       => __('Testimonial List', 'xcency-core'),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'author_name'        => 'Karen Mckenzie',
						'designation'        => 'CEO Of Xcency',
						'testimonial_text' => 'This is due to their excellent servic competiti of pricing and custome refresing to get more such personal and most flamable furtune touch.',
					],
				],
				'title_field' => '{{{ author_name }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'slider_options',
			[
				'label' => esc_html__( 'Slider Options', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'desktop_column',
			[
				'label'       => esc_html__( 'Column On Desktop', 'xcency-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					1 => __( '1 Column', 'xcency-core' ),
					2 => __( '2 Column', 'xcency-core' ),
					3 => __( '3 Column', 'xcency-core' ),
					4 => __( '4 Column', 'xcency-core' ),
				],
				'default'     => 3,
			]
		);

		$this->add_control(
			'ipad_pro_column',
			[
				'label'       => esc_html__( 'Column On iPad Pro', 'xcency-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					1 => __( '1 Column', 'xcency-core' ),
					2 => __( '2 Column', 'xcency-core' ),
					3 => __( '3 Column', 'xcency-core' ),
					4 => __( '4 Column', 'xcency-core' ),
				],
				'default'     => 2,
			]
		);

		$this->add_control(
			'tab_column',
			[
				'label'       => __( 'Column On Tablet', 'xcency-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					1 => __( '1 Column', 'xcency-core' ),
					2 => __( '2 Column', 'xcency-core' ),
					3 => __( '3 Column', 'xcency-core' ),
					4 => __( '4 Column', 'xcency-core' ),
				],
				'default'     => 2,
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'       => __( 'Autoplay', 'xcency-core' ),
				'type'        => Controls_Manager::SWITCHER,
				'show_label'  => true,
				'label_block' => false,
				'default'     => 'yes',
			]
		);

		$this->add_control(
			'autoplay_interval',
			[
				'label'       => __( 'Autoplay Interval', 'xcency-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					'2000'  => __( '2 seconds', 'xcency-core' ),
					'3000'  => __( '3 seconds', 'xcency-core' ),
					'4000'  => __( '4 seconds', 'xcency-core' ),
					'5000'  => __( '5 seconds', 'xcency-core' ),
					'6000'  => __( '6 seconds', 'xcency-core' ),
					'7000'  => __( '7 seconds', 'xcency-core' ),
					'8000'  => __( '8 seconds', 'xcency-core' ),
					'9000'  => __( '9 seconds', 'xcency-core' ),
					'10000' => __( '10 seconds', 'xcency-core' ),
				],
				'default'     => '4000',
				'condition'   => [
					'autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'infinity_loop',
			[
				'label'       => __( 'Loop', 'xcency-core' ),
				'type'        => Controls_Manager::SWITCHER,
				'show_label'  => true,
				'label_block' => false,
				'default'     => 'yes',
			]
		);

        $this->add_control(
            'dots',
            [
                'label'     => esc_html__( 'Dots', 'xcency-core' ),
                'type'      => Controls_Manager::SWITCHER,
                'label_on'  => esc_html__( 'Yes', 'xcency-core' ),
                'label_off' => esc_html__( 'No', 'xcency-core' ),
                'default'   => 'yes',
            ]
        );

        $this->add_responsive_control(
            'dot_text_align',
            [
                'label'       => esc_html__('Dot Align', 'xcency-core'),
                'description' => esc_html__('', 'xcency-core'),
                'type'        => Controls_Manager::CHOOSE,
                'label_block' => false,

                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'xcency-core'),
                        'icon'  => 'eicon-text-align-left',
                    ],

                    'center' => [
                        'title' => esc_html__('Center', 'xcency-core'),
                        'icon'  => 'eicon-text-align-center',
                    ],

                    'right' => [
                        'title' => esc_html__('Right', 'xcency-core'),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],

                'devices' => ['desktop', 'tablet', 'mobile'],

                'selectors' => [
                    '{{WRAPPER}} .xcency-testimonial-one-wrapper .slick-dots' => 'text-align: {{VALUE}};',
                ],

                'condition' => [
                    'dots' => 'yes',
                ],

            ],
        );

		$this->end_controls_section();

        $this->start_controls_section(
            'testimonial_style',
            [
                'label' => esc_html__( 'Testimonial', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'testi_item_bg',
            [
                'label'       => esc_html__('Background Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .xcency-testimonial-one-item' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'testi_icon_color',
            [
                'label'       => esc_html__('Icon Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .testimonial-one-icon svg path' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'dot_color',
            [
                'label'       => esc_html__('Dots Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .xcency-testimonial-one-wrapper .slick-dots button:before' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .xcency-testimonial-one-wrapper .slick-dots button:hover,{{WRAPPER}} .xcency-testimonial-one-wrapper .slick-dots .slick-active button' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'dots' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$slide_id = rand(100, 100000);
		?>

		<div class="xcency-testimonial-one-wrapper">
			<div class="row" id="xcency-testimonial-slider-<?php echo esc_attr($slide_id);?>">
				<?php if($settings['testimonials']){
					foreach ($settings['testimonials'] as $testimonial){
						?>
						<div class="col-12">
							<div class="xcency-testimonial-one-item">
                                <div class="testimonial-one-text">
									<?php echo wp_kses($testimonial['testimonial_text'], xcency_allow_html());?>
                                </div>

                                <div class="testimonial-one-content">
                                    <div class="person-img" style="background-image: url(<?php echo $testimonial['photo']['url'];?>)"></div>
                                    <div class="testimonial-one-person">
                                        <h6 class="testimonial-one-person-name"><?php echo esc_html($testimonial['author_name']);?></h6>
                                        <span class="testimonial-one-person-designation"><?php echo esc_html($testimonial['designation']);?></span>
                                    </div>
                                </div>

                                <div class="testimonial-one-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="45" height="45" viewBox="0 0 45 45" fill="none">
                                        <path d="M13.1442 2.85589C13.0559 2.76616 12.9335 2.71843 12.8075 2.72529C12.6817 2.73197 12.5649 2.79235 12.4867 2.89105L2.37929 15.6352C2.30476 15.7291 2.27189 15.8496 2.28832 15.9684C2.30476 16.0872 2.36901 16.1942 2.46622 16.2645C2.54347 16.3204 10.1944 21.9312 10.1944 28.6525C10.1944 35.4066 3.80655 41.4546 3.74204 41.5149C3.5906 41.6564 3.55861 41.8845 3.66522 42.0622C3.74643 42.1975 3.8911 42.2756 4.04209 42.2756C4.08947 42.2756 4.13737 42.268 4.18421 42.2519C4.35753 42.1926 8.47846 40.7611 12.7722 37.4032C15.3003 35.4262 17.3536 33.1912 18.8752 30.7603C20.783 27.7125 21.8541 24.3504 22.0588 20.7675C22.059 20.7642 22.0591 20.7611 22.0592 20.7578C22.0623 20.6694 22.1228 18.5547 21.0487 15.2772C20.0651 12.2753 17.8952 7.68373 13.1442 2.85589ZM21.1809 20.7234C20.735 28.4909 16.0795 33.6952 12.252 36.694C9.80403 38.612 7.37148 39.9002 5.76835 40.6409C6.33613 39.9832 7.01666 39.132 7.70098 38.1284C9.23933 35.8721 11.0733 32.3965 11.0733 28.6524C11.0733 25.6712 9.66903 22.4571 7.01236 19.3576C5.50644 17.6007 4.01678 16.3565 3.34644 15.8301L12.8645 3.82911C17.2375 8.38483 19.2648 12.6759 20.1979 15.5033C21.2147 18.5842 21.1831 20.6266 21.1809 20.7234ZM41.7036 15.277C40.72 12.2753 38.5501 7.68373 33.799 2.85589C33.7107 2.76607 33.5876 2.71826 33.4624 2.72529C33.3366 2.73197 33.2198 2.79235 33.1415 2.89105L23.0341 15.6352C22.9596 15.7291 22.9268 15.8496 22.9432 15.9684C22.9597 16.0872 23.0239 16.1942 23.121 16.2645C23.1983 16.3204 30.8492 21.9312 30.8492 28.6525C30.8492 35.4066 24.4614 41.4546 24.3969 41.5149C24.2454 41.6564 24.2134 41.8845 24.3201 42.0622C24.4013 42.1975 24.5459 42.2756 24.6969 42.2756C24.7443 42.2756 24.7923 42.268 24.839 42.2519C25.0124 42.1926 29.1333 40.7611 33.427 37.4032C35.9551 35.4262 38.0085 33.1912 39.53 30.7603C41.4378 27.7125 42.5089 24.3504 42.7137 20.7675C42.7139 20.7642 42.7141 20.7611 42.7141 20.7578C42.7173 20.6692 42.7777 18.5545 41.7036 15.277ZM41.8359 20.7234C41.3899 28.4909 36.7344 33.6952 32.907 36.694C30.4589 38.612 28.0263 39.9002 26.4232 40.6409C26.991 39.9832 27.6715 39.132 28.3557 38.1284C29.8942 35.8721 31.728 32.3965 31.728 28.6524C31.728 25.6712 30.3238 22.4571 27.6671 19.3576C26.1612 17.6007 24.6715 16.3565 24.0013 15.8301L33.5194 3.82911C37.8924 8.38483 39.9197 12.6759 40.8528 15.5033C41.8696 18.5842 41.8381 20.6266 41.8359 20.7234Z" fill="#5D5AD6"/>
                                    </svg>
                                </div>
							</div>
						</div>
						<?php
					}
				} ?>
			</div>
		</div>

		<script>
            (function ($) {
                "use strict";
                $(document).ready(function () {
                    $("#xcency-testimonial-slider-<?php echo esc_attr($slide_id);?>").slick({
                        slidesToShow: <?php echo json_encode( $settings['desktop_column'] )?>,
                        autoplay: <?php echo json_encode( $settings['autoplay'] == 'yes' ? true : false ); ?>,
                        autoplaySpeed: <?php echo json_encode( $settings['autoplay_interval'] )?>, //interval
                        speed: 1500, // slide speed
                        dots: <?php echo json_encode( $settings['dots'] == 'yes' ? true : false ); ?>,
                        arrows: false,
                        fade: false,
                        infinite: <?php echo json_encode( $settings['infinity_loop'] == 'yes' ? true : false ); ?>,
                        pauseOnHover: false,
                        centerMode: false,
                        responsive: [
                            {
                                breakpoint: 1025,
                                settings: {
                                    slidesToShow: <?php echo json_encode( $settings['ipad_pro_column'] )?>, // 992-1024
                                    dots: false,
                                }
                            },
                            {
                                breakpoint: 992,
                                settings: {
                                    slidesToShow: <?php echo json_encode( $settings['tab_column'] )?>, //768-991
                                    dots: false,
                                }
                            },
                            {
                                breakpoint: 768,
                                settings: {
                                    slidesToShow: 1, // 0 -767
                                    dots: false,
                                }
                            }
                        ]
                    });
                });
            })(jQuery);
		</script>

		<?php
	}
}

Plugin::instance()->widgets_manager->register( new Xcency_Testimonial_One_Widget );