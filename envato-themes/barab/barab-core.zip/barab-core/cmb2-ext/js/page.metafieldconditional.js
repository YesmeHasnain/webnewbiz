(function($){
    "use strict";
    
    let $barab_page_breadcrumb_area      = $("#_barab_page_breadcrumb_area");
    let $barab_page_settings             = $("#_barab_page_breadcrumb_settings");
    let $barab_page_breadcrumb_image     = $("#_barab_breadcumb_image");
    let $barab_page_title                = $("#_barab_page_title");
    let $barab_page_title_settings       = $("#_barab_page_title_settings");

    if( $barab_page_breadcrumb_area.val() == '1' ) {
        $(".cmb2-id--barab-page-breadcrumb-settings").show();
        if( $barab_page_settings.val() == 'global' ) {
            $(".cmb2-id--barab-breadcumb-image").hide();
            $(".cmb2-id--barab-page-title").hide();
            $(".cmb2-id--barab-page-title-settings").hide();
            $(".cmb2-id--barab-custom-page-title").hide();
            $(".cmb2-id--barab-page-breadcrumb-trigger").hide();
        } else {
            $(".cmb2-id--barab-breadcumb-image").show();
            $(".cmb2-id--barab-page-title").show();
            $(".cmb2-id--barab-page-breadcrumb-trigger").show();
    
            if( $barab_page_title.val() == '1' ) {
                $(".cmb2-id--barab-page-title-settings").show();
                if( $barab_page_title_settings.val() == 'default' ) {
                    $(".cmb2-id--barab-custom-page-title").hide();
                } else {
                    $(".cmb2-id--barab-custom-page-title").show();
                }
            } else {
                $(".cmb2-id--barab-page-title-settings").hide();
                $(".cmb2-id--barab-custom-page-title").hide();
    
            }
        }
    } else {
        $barab_page_breadcrumb_area.parents('.cmb2-id--barab-page-breadcrumb-area').siblings().hide();
    }


    // breadcrumb area
    $barab_page_breadcrumb_area.on("change",function(){
        if( $(this).val() == '1' ) {
            $(".cmb2-id--barab-page-breadcrumb-settings").show();
            if( $barab_page_settings.val() == 'global' ) {
                $(".cmb2-id--barab-breadcumb-image").hide();
                $(".cmb2-id--barab-page-title").hide();
                $(".cmb2-id--barab-page-title-settings").hide();
                $(".cmb2-id--barab-custom-page-title").hide();
                $(".cmb2-id--barab-page-breadcrumb-trigger").hide();
            } else {
                $(".cmb2-id--barab-breadcumb-image").show();
                $(".cmb2-id--barab-page-title").show();
                $(".cmb2-id--barab-page-breadcrumb-trigger").show();
        
                if( $barab_page_title.val() == '1' ) {
                    $(".cmb2-id--barab-page-title-settings").show();
                    if( $barab_page_title_settings.val() == 'default' ) {
                        $(".cmb2-id--barab-custom-page-title").hide();
                    } else {
                        $(".cmb2-id--barab-custom-page-title").show();
                    }
                } else {
                    $(".cmb2-id--barab-page-title-settings").hide();
                    $(".cmb2-id--barab-custom-page-title").hide();
        
                }
            }
        } else {
            $(this).parents('.cmb2-id--barab-page-breadcrumb-area').siblings().hide();
        }
    });

    // page title
    $barab_page_title.on("change",function(){
        if( $(this).val() == '1' ) {
            $(".cmb2-id--barab-page-title-settings").show();
            if( $barab_page_title_settings.val() == 'default' ) {
                $(".cmb2-id--barab-custom-page-title").hide();
            } else {
                $(".cmb2-id--barab-custom-page-title").show();
            }
        } else {
            $(".cmb2-id--barab-page-title-settings").hide();
            $(".cmb2-id--barab-custom-page-title").hide();

        }
    });

    //page settings
    $barab_page_settings.on("change",function(){
        if( $(this).val() == 'global' ) {
            $(".cmb2-id--barab-breadcumb-image").hide();
            $(".cmb2-id--barab-page-title").hide();
            $(".cmb2-id--barab-page-title-settings").hide();
            $(".cmb2-id--barab-custom-page-title").hide();
            $(".cmb2-id--barab-page-breadcrumb-trigger").hide();
        } else {
            $(".cmb2-id--barab-breadcumb-image").show();
            $(".cmb2-id--barab-page-title").show();
            $(".cmb2-id--barab-page-breadcrumb-trigger").show();
    
            if( $barab_page_title.val() == '1' ) {
                $(".cmb2-id--barab-page-title-settings").show();
                if( $barab_page_title_settings.val() == 'default' ) {
                    $(".cmb2-id--barab-custom-page-title").hide();
                } else {
                    $(".cmb2-id--barab-custom-page-title").show();
                }
            } else {
                $(".cmb2-id--barab-page-title-settings").hide();
                $(".cmb2-id--barab-custom-page-title").hide();
    
            }
        }
    });

    // page title settings
    $barab_page_title_settings.on("change",function(){
        if( $(this).val() == 'default' ) {
            $(".cmb2-id--barab-custom-page-title").hide();
        } else {
            $(".cmb2-id--barab-custom-page-title").show();
        }
    });
    
})(jQuery);