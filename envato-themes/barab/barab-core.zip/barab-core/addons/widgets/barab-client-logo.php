<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * features Widget .
 *
 */
class Barab_Client_Logos extends Widget_Base {

	public function get_name() {
		return 'barabclientlogos';
	}
	public function get_title() {
		return __( 'Client Logos', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'arrow_section',
			[
				'label'     => __( 'Client Logos', 'barab' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two' ] );

        $repeater = new Repeater();

		barab_media_fields($repeater, 'image', 'Choose Image');
		barab_url_fields($repeater, 'logo_url', 'Button URL');
		
		$this->add_control(
			'client_logo',
			[
				'label' 		=> __( 'Logos', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
                'default'   => [
                    [
                        'image'    => Utils::get_placeholder_image_src(),
                    ],
                    [
                        'image'    => Utils::get_placeholder_image_src(),
                    ],
                    [
                        'image'    => Utils::get_placeholder_image_src(),
                    ],
                    [
                        'image'    => Utils::get_placeholder_image_src(),
                    ],
                    [
                        'image'    => Utils::get_placeholder_image_src(),
                    ],
                ],
				'condition'	=> [
					'layout_style' => ['1', '2']
				]
			]
		);


        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------


	}

	protected function render() {

    $settings = $this->get_settings_for_display(); 

		if( $settings['layout_style'] == '1' ){
			$total_items = count($settings['client_logo']);
			$index = 0;

			while ($index < $total_items) {
				// First loop: 3 items
				echo '<div class="brand-wrapp">';
				for ($i = 0; $i < 3 && $index < $total_items; $i++, $index++) {
					$data = $settings['client_logo'][$index];
					echo '<div class="brand-item">';
						echo '<a ' . barab_link_attrs($data['logo_url']) . '>';
							echo barab_img_tag(array(
								'url' => esc_url($data['image']['url']),
							));
						echo '</a>';
					echo '</div>';
				}
				echo '</div>';

				// Second loop: 2 items
				echo '<div class="brand-wrapp style2">';
				for ($i = 0; $i < 2 && $index < $total_items; $i++, $index++) {
					$data = $settings['client_logo'][$index];
					echo '<div class="brand-item">';
						echo '<a ' . barab_link_attrs($data['logo_url']) . '>';
							echo barab_img_tag(array(
								'url' => esc_url($data['image']['url']),
							));
						echo '</a>';
					echo '</div>';
				}
				echo '</div>';
			}

		}elseif( $settings['layout_style'] == '2' ){
			echo '<div class="slider-area">';
				echo '<div class="swiper th-slider" id="brandSlider1" data-slider-options=\'{"breakpoints":{"0":{"slidesPerView":1},"476":{"slidesPerView":"2"},"768":{"slidesPerView":"2"},"992":{"slidesPerView":"3"},"1200":{"slidesPerView":"4"},"1400":{"slidesPerView":"5"}}}\'>';
					echo '<div class="swiper-wrapper">';
						foreach( $settings['client_logo'] as $data ){
							echo '<div class="swiper-slide">';
								echo '<div class="brand-card">';
									echo '<a href="'.esc_url( $data['logo_url']['url'] ).'">';
										echo barab_img_tag( array(
											'url'   => esc_url( $data['image']['url'] ),
											'class' => 'original'
										) );
										echo barab_img_tag( array(
											'url'   => esc_url( $data['image']['url'] ),
											'class' => 'gray'
										) );
									echo '</a>';
								echo '</div>';
							echo '</div>';
						}
					echo '</div>';
				echo '</div>';
			echo '</div>'; 

		}
		
			
	}
}