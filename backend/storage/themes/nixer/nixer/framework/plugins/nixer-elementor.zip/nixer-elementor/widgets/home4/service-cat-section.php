<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome4ServiceCatSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home4-service-cat-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 4 - Service Category Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-post-list';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home4' ];
	}

	public function get_keywords() {
		return [ 'home4servicecatsection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}
	public function get_term_titles_options() {
		$args = [
			'taxonomy'   => 'service-cat',
			'hide_empty' => true,
		];
		$terms = get_terms($args);

		if (!empty($terms) && !is_wp_error($terms)) {
			$title_options = [];
			foreach ($terms as $term) {
				$title_options[$term->slug] = $term->name;
			}
			return $title_options;
		}

		return [];
	}


	

	protected function _register_controls() {
		$title_options = $this->get_term_titles_options();
		$this->start_controls_section(
			'section_content_service_section',
			[
				'label' => esc_html__( 'Service Category Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'heading_sec',
			[
				'label' 		=> esc_html__( 'Heading Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'My expertise' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Professional <br> Services' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_sec',
			[
				'label' 		=> esc_html__( 'Text Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Beautiful, functional websites created...' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_btn',
			[
				'label' 		=> esc_html__( 'Text Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'All Service' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'link_btn',
			[
				'label' 		=> esc_html__( 'Link Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '#' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'name_cat',
			[
				'label'     	=> esc_html__( 'Choose Service Category For Name', 'bdevs-elementor' ),
				'type'      	=> Controls_Manager::SELECT,
				'options'   	=> $title_options,
				'default'    	=> !empty($title_options) ? array_key_first($title_options) : '',
				'label_block' 	=> true,
			]
		);
		$repeater->add_control(
			'name_item',
			[
				'label' 		=> esc_html__( 'Name Item - If it is empty then using service category name', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'tabs',
			[
				'label' 		=> esc_html__( 'Service Category Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						
					],
				],
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section id="down" class="tp-service-4-ptb pb-130">
	<div class="container container-1610">
		<div class="row">
			<div class="col-lg-6">
				<div class="tp-service-4-wrapper">
					<?php if (!empty($settings['heading_sec'])): ?>
						<span class="tp-service-4-subtitle tp-title-anim"><?php echo wp_kses_post($settings['heading_sec']); ?></span>
					<?php endif ?>
					<?php if (!empty($settings['title_sec'])): ?>
						<h3 class="tp-section-4-title tp-title-anim"><?php echo wp_kses_post($settings['title_sec']); ?></h3>
					<?php endif ?>
					<?php if (!empty($settings['text_sec'])): ?>
						<p class="tp-title-anim"><?php echo wp_kses_post($settings['text_sec']); ?></p>
					<?php endif ?>
					<?php if (!empty($settings['link_btn']) && !empty($settings['text_btn'])): ?>
						<div class="tp-service-4-btn-box tp-title-anim">
							<div class="tp-service-4-btn">
								<div class="tp-project-4-btn">
									<a href="<?php echo wp_kses_post($settings['link_btn']); ?>">
										<?php echo wp_kses_post($settings['text_btn']); ?>
										<span>
											<svg xmlns="http://www.w3.org/2000/svg" width="17" height="16" viewBox="0 0 17 16" fill="none">
												<path d="M1.51562 14.7968L14.6838 1.62864M3.83594 1.16205C6.96385 4.28996 12.2505 4.06539 15.656 0.659936M15.6533 0.655273C12.2478 4.06072 12.0232 9.34739 15.1511 12.4753" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10"></path>
											</svg>
										</span>
									</a>
								</div>
							</div>
						</div>
					<?php endif ?>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="tp-service-4-content">
					<?php
					$i = 0;
					foreach ($settings['tabs'] as $item) :
						$i++;
						$term_slug = !empty($item['name_cat']) ? $item['name_cat'] : '';
						$term = get_term_by('slug', $term_slug, 'service-cat');

						if (!is_wp_error($term) && !empty($term)) {
							$term_name = $term->name;
							$term_link = get_term_link($term, 'service-cat');
							?>
							<?php if ($i == 1) { ?>
								 <a href="<?php echo esc_url($term_link); ?>" class="tp-service-4-item active d-flex justify-content-between">
							<?php } else { ?>
								 <a href="<?php echo esc_url($term_link); ?>" class="tp-service-4-item d-flex justify-content-between">
							<?php } ?>
									<span>
										<?php if (!empty($item['name_item'])) { ?>
											<?php echo wp_kses_post($item['name_item']); ?>
										<?php } else { ?>
											<?php echo esc_html($term_name); ?>
										<?php } ?>
									</span>
									<span class="icon">
										<svg xmlns="http://www.w3.org/2000/svg" width="36" height="26" viewBox="0 0 36 26" fill="none">
											<path d="M20.5078 0C20.5051 7.18628 27.3242 13.0013 35.754 13.0013M35.7432 12.999C27.3134 12.999 20.49 18.814 20.4873 26.0003M0.75 13.0039H33.3462" stroke="currentColor" stroke-width="2" stroke-miterlimit="10"/>
										</svg>
									</span>
								</a>
						<?php } ?>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		if (jQuery('.tp-service-4-wrapper .tp-title-anim').length > 0) {
			var splitTitleLines = gsap.utils.toArray(".tp-service-4-wrapper .tp-title-anim");
			splitTitleLines.forEach(splitTextLine => {
				var tl = gsap.timeline({
				scrollTrigger: {
					trigger: splitTextLine,
					start: 'top 90%',
					end: 'bottom 60%',
					scrub: false,
					markers: false,
					toggleActions: 'play none none none'
				}
				});
	
				var itemSplitted = new SplitText(splitTextLine, { type: "words, lines" });
				gsap.set(splitTextLine, { perspective: 300});
				itemSplitted.split({ type: "lines" })
				tl.from(itemSplitted.lines, { duration: 1, delay: 0.3, opacity: 0, rotationX: -50, force3D: true, transformOrigin: "top center -50", stagger: 0.2 });
			});	
		}

		jQuery('.tp-service-4-item, .tp-blog-5-wrapper').on('mouseenter', function () {
			jQuery('.tp-service-4-item, .tp-blog-5-wrapper').removeClass('active');
			jQuery(this).addClass('active');
		});
	</script>
<?php } ?>

<?php
}

}