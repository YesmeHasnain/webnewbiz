/**
 * AI Copilot - Frontend Chat Logic
 */
(function($) {
    let history = [];
    let isLoading = false;
    let selectedElement = null; // Currently selected element from iframe
    let lastActionType = '';    // Track last action for smart suggestions

    // Load pages on init and auto-select home
    $(document).ready(function() {
        loadPages();

        // When page selected, change preview + load session
        $('#aic-page-select').on('change', function() {
            var sel = $(this).find(':selected');
            var url = sel.data('url');
            if (url) {
                showPreviewLoader();
                var iframe = document.getElementById('aic-preview');
                if (iframe) iframe.src = url + '?t=' + Date.now();
            }
            clearSelection();
            loadChatSession();
        });

        // Auto-resize textarea
        $('#aic-input').on('input', function() {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 120) + 'px';
        });

        // Enter to send
        $('#aic-input').on('keydown', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                aiSendMessage();
            }
        });

        // Listen for postMessage from preview iframe (bridge script)
        window.addEventListener('message', handleBridgeMessage);

        // Inject bridge script when iframe loads + sync dropdown with nav clicks
        var iframe = document.getElementById('aic-preview');
        if (iframe) {
            iframe.addEventListener('load', function() {
                hidePreviewLoader();
                injectBridgeScript(iframe);
                syncDropdownWithIframe(iframe);
            });
        }
    });

    // ─── Bridge Communication ───

    function handleBridgeMessage(e) {
        if (!e.data || e.data.source !== 'aic-bridge') return;

        switch (e.data.type) {
            case 'element-selected':
                setSelection(e.data.data);
                break;
            case 'element-deselected':
                clearSelection();
                break;
            case 'quick-action':
                handleQuickAction(e.data.data);
                break;
            case 'navigating':
                showPreviewLoader();
                break;
            case 'bridge-ready':
                // Bridge loaded successfully in iframe
                break;
        }
    }

    /**
     * Inject the preview-bridge.js script into the iframe
     */
    function injectBridgeScript(iframe) {
        try {
            var doc = iframe.contentDocument || iframe.contentWindow.document;
            if (!doc || !doc.body) return;

            // Remove old bridge if re-injecting
            var old = doc.getElementById('aic-bridge-script');
            if (old) old.remove();

            var script = doc.createElement('script');
            script.id = 'aic-bridge-script';
            script.src = aiCopilot.bridgeUrl + '?v=' + Date.now();
            doc.body.appendChild(script);
        } catch (err) {
            // Cross-origin iframe - can't inject (different domain)
            console.log('AI Copilot: Cannot inject bridge script (cross-origin)');
        }
    }

    // ─── Element Selection ───

    function setSelection(info) {
        selectedElement = info;
        showSelectionChip(info);
    }

    function clearSelection() {
        selectedElement = null;
        $('#aic-selection-chip').remove();
        // Tell iframe to clear too
        var iframe = document.getElementById('aic-preview');
        if (iframe && iframe.contentWindow) {
            iframe.contentWindow.postMessage({ source: 'aic-parent', type: 'deselect' }, '*');
        }
    }

    function showSelectionChip(info) {
        // Remove old chip
        $('#aic-selection-chip').remove();

        var typeLabel = info.widgetType || info.elType || info.type || 'element';
        var textPreview = info.text || '';
        if (textPreview.length > 35) textPreview = textPreview.substring(0, 35) + '...';

        var chipHtml =
            '<div id="aic-selection-chip" class="aic-selection-chip">' +
                '<span class="aic-chip-dot"></span>' +
                '<span class="aic-chip-type">' + typeLabel + '</span>' +
                (textPreview ? '<span class="aic-chip-text">' + textPreview + '</span>' : '') +
                '<button class="aic-chip-close" onclick="clearElementSelection()" title="Deselect">&times;</button>' +
            '</div>';

        $('.aic-input-area').before(chipHtml);
    }

    // Global function for chip close button
    window.clearElementSelection = function() {
        clearSelection();
    };

    /**
     * Handle quick action from iframe toolbar button
     */
    function handleQuickAction(data) {
        if (!data) return;
        // Set the element as selected
        if (data.element) setSelection(data.element);
        // Fill chat input with the command
        var cmd = data.command || '';
        if (cmd) {
            $('#aic-input').val(cmd).focus();
            // Auto-send for these actions (no user editing needed)
            if (data.action === 'remove' || data.action === 'duplicate' || data.autoSend) {
                aiSendMessage();
            }
            // For edit/style - user can modify before sending
        }
    }

    // ─── Preview Loader ───

    function showPreviewLoader() {
        if ($('#aic-preview-loader').length) return;
        $('.aic-preview-panel').append(
            '<div id="aic-preview-loader">' +
                '<div class="aic-preview-spinner"></div>' +
                '<span>Loading page...</span>' +
            '</div>'
        );
    }

    function hidePreviewLoader() {
        $('#aic-preview-loader').remove();
    }

    // ─── Handle nav link clicks inside iframe ───

    function syncDropdownWithIframe(iframe) {
        try {
            var iframeUrl = iframe.contentWindow.location.href.split('?')[0].replace(/\/$/, '');
            var sel = $('#aic-page-select');
            sel.find('option').each(function() {
                var optUrl = $(this).data('url');
                if (optUrl) {
                    optUrl = optUrl.split('?')[0].replace(/\/$/, '');
                    if (optUrl === iframeUrl) {
                        // Update dropdown without triggering change (which would reload iframe)
                        sel.val($(this).val());
                        return false; // break
                    }
                }
            });
        } catch (e) {
            // Cross-origin - can't read iframe URL
        }
    }

    // ─── Chat Panel Collapse/Expand ───

    window.toggleChatPanel = function() {
        var panel = $('.aic-chat-panel');
        panel.toggleClass('collapsed');
    };

    // ─── Options Toggle ───

    window.toggleOptions = function() {
        var bar = $('#aic-options-bar');
        var btn = $('.aic-options-toggle');
        if (bar.is(':visible')) {
            bar.hide();
            btn.removeClass('active');
        } else {
            bar.show();
            btn.addClass('active');
        }
    };

    /**
     * Build context suffix from tone/language/seo options
     */
    function getOptionsContext() {
        var parts = [];
        var tone = $('#aic-tone').val();
        var lang = $('#aic-language').val();
        var seo = $('#aic-seo-keywords').val();
        if (tone) parts.push('[Tone: ' + tone + ']');
        if (lang) parts.push('[Language: ' + lang + ']');
        if (seo) parts.push('[SEO Keywords: ' + seo + ']');
        return parts.join(' ');
    }

    // ─── Pages ───

    function loadPages() {
        $.post(aiCopilot.ajaxUrl, {
            action: 'ai_copilot_pages',
            nonce: aiCopilot.nonce
        }, function(res) {
            if (res.success && res.data) {
                var sel = $('#aic-page-select');
                sel.empty();
                res.data.forEach(function(p) {
                    var opt = $('<option></option>').val(p.id).text(p.title).data('url', p.url);
                    sel.append(opt);
                });
                // Auto-select first page (Home)
                if (res.data.length > 0) {
                    sel.val(res.data[0].id).trigger('change');
                }
            }
        });
    }

    // ─── Chat ───

    // Global function for suggestion buttons
    window.aiSend = function(text) {
        $('#aic-input').val(text);
        aiSendMessage();
    };

    window.aiSendMessage = function() {
        var input = $('#aic-input');
        var msg = input.val().trim();
        if (!msg || isLoading) return;

        isLoading = true;
        input.val('').css('height', 'auto');
        $('#aic-send').prop('disabled', true);

        // Remove welcome
        $('.aic-welcome').remove();

        // Add user message (include selection context in display)
        var displayMsg = msg;
        if (selectedElement) {
            displayMsg = '<span class="aic-inline-chip">' + (selectedElement.widgetType || selectedElement.type) + '</span> ' + msg;
        }
        addMessage('user', displayMsg);
        history.push({ role: 'user', content: msg });

        // Add loading with progress steps
        var loadingId = 'loading-' + Date.now();
        $('#aic-messages').append(
            '<div class="aic-msg aic-msg-loading" id="' + loadingId + '">' +
            '<div class="aic-spinner"></div><span class="aic-loading-text">Reading page elements...</span></div>'
        );
        scrollToBottom();

        // Simulate progress steps
        setTimeout(function() {
            $('#' + loadingId + ' .aic-loading-text').text('AI is thinking...');
        }, 1500);
        setTimeout(function() {
            $('#' + loadingId + ' .aic-loading-text').text('Applying changes...');
        }, 5000);

        // Append tone/language/seo context to message
        var optCtx = getOptionsContext();
        var fullMsg = optCtx ? msg + ' ' + optCtx : msg;

        // Build request data
        var requestData = {
            action: 'ai_copilot_chat',
            nonce: aiCopilot.nonce,
            message: fullMsg,
            history: JSON.stringify(history.slice(-20)),
            page_id: $('#aic-page-select').val() || 0
        };

        // Include selected element if any
        if (selectedElement) {
            requestData.selected_element = JSON.stringify(selectedElement);
        }

        // Send to backend
        $.post(aiCopilot.ajaxUrl, requestData, function(res) {
            $('#' + loadingId).remove();
            isLoading = false;
            $('#aic-send').prop('disabled', false);

            if (res.success && res.data) {
                var reply = res.data.reply || 'Done.';
                var actions = res.data.actions || [];

                // Show actions
                actions.forEach(function(act) {
                    addAction(act);
                });

                // Show reply
                addMessage('ai', reply);
                history.push({ role: 'assistant', content: reply });

                // Refresh preview if changes were made
                if (res.data.has_changes) {
                    refreshPreviewAfterChange();
                    showUndoButton();
                }

                // Show smart suggestion chips
                if (actions.length > 0) {
                    lastActionType = actions[actions.length - 1].tool || '';
                    showSuggestionChips(lastActionType);
                    // Keep element selected so user can make multiple changes
                    // Selection only clears when user clicks X or clicks elsewhere
                }

                // Save chat session
                saveChatSession();
            } else {
                addMessage('ai', '&#10060; ' + (res.data || 'Something went wrong.'));
            }
            scrollToBottom();
        }).fail(function() {
            $('#' + loadingId).remove();
            isLoading = false;
            $('#aic-send').prop('disabled', false);
            addMessage('ai', '&#10060; Request failed. Please try again.');
            scrollToBottom();
        });
    };

    // ─── UI Helpers ───

    function addMessage(role, text) {
        var cls = role === 'user' ? 'aic-msg-user' : 'aic-msg-ai';
        // Convert markdown-like formatting
        text = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        text = text.replace(/\n/g, '<br>');
        $('#aic-messages').append(
            '<div class="aic-msg ' + cls + '"><div class="aic-bubble">' + text + '</div></div>'
        );
        scrollToBottom();
    }

    function addAction(act) {
        var tool = act.tool || '';
        var result = act.result || {};
        var success = result.success !== false;
        var msg = result.message || result.error || tool;

        $('#aic-messages').append(
            '<div class="aic-action">' +
            '<div class="aic-action-title">' + (success ? '&#9989;' : '&#10060;') + ' ' + tool.replace(/_/g, ' ') + '</div>' +
            '<div class="aic-action-detail">' + msg + '</div>' +
            '</div>'
        );

        // If image search returned results, show picker
        if (tool === 'search_images' && result.needs_selection && result.images) {
            showImagePicker(result.images, act.input);
        }

        // Show diff card if available
        if (result.diff && (result.diff.before || result.diff.after)) {
            var d = result.diff;
            var diffHtml = '<div class="aic-diff-card">' +
                '<span class="aic-diff-field">' + (d.field || '') + '</span> ' +
                (d.before ? '<span class="aic-diff-before">' + d.before + '</span>' : '') +
                ' <span class="aic-diff-arrow">&rarr;</span> ' +
                '<span class="aic-diff-after">' + (d.after || '') + '</span>' +
            '</div>';
            $('#aic-messages').append(diffHtml);
        }
    }

    function showImagePicker(images, searchInput) {
        var html = '<div class="aic-image-picker">';
        html += '<div class="aic-image-picker-title">Choose an image:</div>';
        html += '<div class="aic-image-grid">';
        images.forEach(function(img, i) {
            html += '<div class="aic-image-option" data-url="' + img.url + '" data-alt="' + (img.alt || '') + '">';
            html += '<img src="' + img.thumb + '" alt="' + (img.alt || '') + '" loading="lazy">';
            html += '<div class="aic-image-credit">' + (img.credit || '') + '</div>';
            html += '<button class="aic-image-use-btn" onclick="aiUseImage(' + i + ')">Use This</button>';
            html += '</div>';
        });
        html += '</div></div>';

        // Store images data for use button
        window._aicImageOptions = images;
        window._aicImageTarget = searchInput;

        $('#aic-messages').append(html);
        scrollToBottom();
    }

    window.aiUseImage = function(index) {
        var images = window._aicImageOptions || [];
        var target = window._aicImageTarget || {};
        if (!images[index]) return;

        var img = images[index];
        var pageId = $('#aic-page-select').val() || 0;
        var elementId = (selectedElement ? selectedElement.id : '') || (target.element_id || '');

        // Disable all use buttons
        $('.aic-image-use-btn').prop('disabled', true).text('Downloading...');

        $.post(aiCopilot.ajaxUrl, {
            action: 'ai_copilot_use_image',
            nonce: aiCopilot.nonce,
            image_url: img.url,
            element_id: elementId,
            page_id: pageId,
            alt: img.alt || ''
        }, function(res) {
            if (res.success) {
                // Replace picker with success message
                $('.aic-image-picker').replaceWith(
                    '<div class="aic-action"><div class="aic-action-title">&#9989; Image inserted</div>' +
                    '<div class="aic-action-detail">' + (res.data.message || 'Done') + '</div></div>'
                );
                refreshPreviewAfterChange();
                showUndoButton();
            } else {
                $('.aic-image-use-btn').prop('disabled', false).text('Use This');
                addMessage('ai', '&#10060; ' + (res.data || 'Failed to use image'));
            }
            scrollToBottom();
        }).fail(function() {
            $('.aic-image-use-btn').prop('disabled', false).text('Use This');
        });
    };

    function scrollToBottom() {
        var el = document.getElementById('aic-messages');
        if (el) el.scrollTop = el.scrollHeight;
    }

    /**
     * Refresh preview after AI makes changes - double refresh to ensure
     * Elementor regenerates CSS from the updated JSON data
     */
    function refreshPreviewAfterChange() {
        var iframe = document.getElementById('aic-preview');
        if (!iframe) return;
        var baseUrl = iframe.src.split('?')[0];
        // First refresh after short delay (lets server clear cache)
        setTimeout(function() {
            iframe.src = baseUrl + '?nocache=' + Date.now();
        }, 600);
        // Second refresh to catch any Elementor CSS regeneration
        setTimeout(function() {
            iframe.src = baseUrl + '?nocache=' + Date.now();
        }, 2500);
    }

    window.refreshPreview = function() {
        var iframe = document.getElementById('aic-preview');
        if (iframe) {
            iframe.src = iframe.src.split('?')[0] + '?nocache=' + Date.now();
        }
    };

    // ─── Undo ───

    window.aiUndo = function() {
        var pageId = $('#aic-page-select').val() || 0;
        if (!pageId) return;

        $('#aic-undo-btn').prop('disabled', true).css('opacity', 0.5);

        $.post(aiCopilot.ajaxUrl, {
            action: 'ai_copilot_undo',
            nonce: aiCopilot.nonce,
            page_id: pageId
        }, function(res) {
            $('#aic-undo-btn').prop('disabled', false).css('opacity', 1);

            if (res.success && res.data) {
                addAction({ tool: 'undo', result: res.data });
                addMessage('ai', res.data.message || 'Undo done!');
                refreshPreviewAfterChange();
                // Hide undo button if no more steps
                if ((res.data.remaining || 0) <= 0) {
                    $('#aic-undo-btn').hide();
                }
            } else {
                addMessage('ai', '&#10060; ' + (res.data || 'Nothing to undo.'));
            }
            scrollToBottom();
        }).fail(function() {
            $('#aic-undo-btn').prop('disabled', false).css('opacity', 1);
            addMessage('ai', '&#10060; Undo failed.');
            scrollToBottom();
        });
    };

    /**
     * Show undo button when changes are made
     */
    function showUndoButton() {
        $('#aic-undo-btn').show();
    }

    // ─── Suggestion Chips ───

    function showSuggestionChips(actionType) {
        // Remove old chips
        $('.aic-smart-suggestions').remove();

        var suggestions = [];

        switch (actionType) {
            case 'edit_element_style':
                suggestions = ['Change the font', 'Make it bigger', 'Try another color', 'Undo'];
                break;
            case 'edit_element_text':
                suggestions = ['Improve writing', 'Make it shorter', 'Make it longer', 'Fix grammar', 'Change to professional tone', 'Undo'];
                break;
            case 'add_section':
                suggestions = ['Edit section text', 'Change background', 'Add another section', 'Remove it'];
                break;
            case 'remove_section':
                suggestions = ['Undo', 'Add a new section'];
                break;
            case 'search_images':
                suggestions = ['Search for different images', 'Change image style'];
                break;
            case 'undo':
                suggestions = ['Undo again', 'Try something different'];
                break;
            default:
                suggestions = ['Change colors', 'Edit text', 'Add section', 'Undo'];
        }

        var html = '<div class="aic-smart-suggestions">';
        suggestions.forEach(function(s) {
            html += '<button onclick="aiSend(\'' + s.replace(/'/g, "\\'") + '\')">' + s + '</button>';
        });
        html += '</div>';

        $('#aic-messages').append(html);
        scrollToBottom();
    }

    // ─── Per-Page Chat Sessions ───

    function getSessionKey() {
        var pageId = $('#aic-page-select').val() || 0;
        return 'aic_chat_' + pageId;
    }

    function saveChatSession() {
        try {
            var key = getSessionKey();
            var data = {
                history: history.slice(-30),
                html: $('#aic-messages').html()
            };
            localStorage.setItem(key, JSON.stringify(data));
        } catch (e) { /* localStorage full or unavailable */ }
    }

    function loadChatSession() {
        var key = getSessionKey();
        // Clear current chat
        history = [];
        $('#aic-messages').html('');

        try {
            var saved = localStorage.getItem(key);
            if (saved) {
                var data = JSON.parse(saved);
                history = data.history || [];
                if (data.html) {
                    $('#aic-messages').html(data.html);
                    // Remove old suggestion chips and loading states
                    $('.aic-smart-suggestions').remove();
                    $('.aic-msg-loading').remove();
                    scrollToBottom();
                    return;
                }
            }
        } catch (e) { /* parse error */ }

        // Show welcome if no session
        $('#aic-messages').html(
            '<div class="aic-welcome">' +
                '<div class="aic-welcome-icon">&#10024;</div>' +
                '<h3>How can I help?</h3>' +
                '<p>I can edit text, change styles, add sections, update images, manage SEO, and more.</p>' +
                '<div class="aic-suggestions">' +
                    '<button onclick="aiSend(\'Change the hero heading text\')">Change hero text</button>' +
                    '<button onclick="aiSend(\'Update the color scheme to blue\')">Change colors</button>' +
                    '<button onclick="aiSend(\'Add a testimonials section\')">Add testimonials</button>' +
                    '<button onclick="aiSend(\'Update SEO meta description\')">Update SEO</button>' +
                '</div>' +
            '</div>'
        );
    }
})(jQuery);
