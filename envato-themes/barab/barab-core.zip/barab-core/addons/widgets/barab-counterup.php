<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Group_Control_Border;
/**
 *
 * Counter Up Widget .
 *
 */
class barab_Counterup extends Widget_Base {

	public function get_name() {
		return 'barabcounterup';
	}
	public function get_title() {
		return __( 'Counter Up', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'counter_section',
			[
				'label' 	=> __( 'Counter Up', 'barab' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two' ] ); 

		$repeater = new Repeater(); 

		barab_general_fields($repeater, 'number', 'Number', 'TEXTAREA2', '100');
		barab_general_fields($repeater, 'after_prefix', 'After Prefix', 'TEXT2', 'k');
		barab_general_fields($repeater, 'description', 'Content', 'TEXTAREA2', 'Completed Projects'); 

		$this->add_control(
			'counter_lists',
			[
				'label' 		=> __( 'Counter List', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'number' 	=> __( '100', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['1']
				]
			]
		);

		$repeater = new Repeater(); 

		barab_general_fields($repeater, 'title', 'Title', 'TEXTAREA2', 'Completed Projects'); 
		barab_general_fields($repeater, 'number', 'Number', 'TEXTAREA2', '100');
		barab_general_fields($repeater, 'after_prefix', 'After Prefix', 'TEXT2', 'k');
		barab_general_fields($repeater, 'description', 'Content', 'TEXTAREA2', 'Delivering diverse architectural solutions, showcasing our expertise and creativity.'); 

		$this->add_control(
			'counter_lists2',
			[
				'label' 		=> __( 'Counter List', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'number' 	=> __( '100', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['2']
				]
			]
		);

		$this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------

		barab_common_style_fields($this, '011', 'Title', '{{WRAPPER}} .sub-title' );
		barab_common_style_fields($this, '01', 'Number', '{{WRAPPER}} .num .counter-number' );
		barab_common_style_fields($this, '02', 'Number Prefix', '{{WRAPPER}} .num');
		barab_common_style_fields($this, '03', 'Content', '{{WRAPPER}} .desc', ['1', '2']);

	}

	protected function render() {

	$settings = $this->get_settings_for_display();

		if( $settings['layout_style'] == '1' ){
			echo '<div class="counter-card_wrapp">';
				foreach( $settings['counter_lists'] as $key => $data ){
					$delay = 0.2 + ($key * 0.2);
					echo '<div class="counter-card wow fadeInUp" data-wow-delay="' . $delay . 's">';
						echo '<h2 class="box-number num"><span class="counter-number">'.esc_html( $data['number'] ).'</span>'.esc_html( $data['after_prefix'] ).'</h2>';
						if(!empty($data['description'])){
							echo '<p class="box-text desc">'.esc_html( $data['description'] ).'</p>';
						}
					echo '</div>';
				}
			echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
			echo '<div class="counter-card_wrapp style2">';
				foreach( $settings['counter_lists2'] as $key => $data ){
					$delay = 0.2 + ($key * 0.2);
					echo '<div class="counter-card style2 wow fadeInUp" data-wow-delay="' . $delay . 's">';
						if(!empty($data['title'])){
							echo '<span class="sub-title style2">'.esc_html( $data['title'] ).'</span>';
						}
						echo '<h3 class="box-number"><span class="counter-number">'.esc_html( $data['number'] ).'</span>'.esc_html( $data['after_prefix'] ).'</h3>';
						if(!empty($data['description'])){
							echo '<p class="box-text desc">'.esc_html( $data['description'] ).'</p>';
						}
					echo '</div>';
				}
            echo '</div>';
			
		}elseif( $settings['layout_style'] == '3' ){
		

		}

	
	}

}