(function($) {
	"use strict";
	$(window).on("load", function() {
		// makes sure the whole site is loaded

		//isotope setting(event)
		$(".event-custom-type").imagesLoaded(function() {
			$(".event-custom-type").isotope({
				itemSelector: ".port-item",
				layoutMode: "masonry",
				masonry: {
					columnWidth: ".port-item.col-md-3"
				}
			});
		});

		// filter items when filter link is clicked
		$(".port-filter a").on("click", function() {
			var selector = $(this).attr("data-filter");
			$(".event-custom-type").isotope({
				itemSelector: ".port-item",
				filter: selector,
				layoutMode: "masonry",
				masonry: {
					columnWidth: ".port-item.col-md-3"
				}
			});
			$(".port-filter a").removeClass("active");
			$(this).addClass("active");
			return false;
		});
	});
})(jQuery);
