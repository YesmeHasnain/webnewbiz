<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsRelatedProjects extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-related-projects';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Related Projects', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Slider widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-info-circle';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Slider widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'projects-elementor' ];
	}

	public function get_keywords() {
		return [ 'relatedprojects', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_related_projects',
			[
				'label' => esc_html__( 'Related Projects', 'bdevs-elementor' ),
			]
		);

	   $this->add_control(
	        'title',
	        [
	            'label'       => __( 'Title', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   );

	   $this->add_control(
	        'subtitle',
	        [
	            'label'       => __( 'Subtitle', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   );

	   $this->add_control(
	        'link',
	        [
	            'label'       => __( 'Link', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your link', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   );

	   $this->add_control(
	        'button',
	        [
	            'label'       => __( 'Button', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   );

	   $this->add_control(
	         'post_number',
	         [
	            'label'     => esc_html__( 'Post Count', 'bdevs-elementor' ),
	            'type'      => Controls_Manager::TEXT,
	            'default'   => '3',
	         ]
	   );
	   $this->add_control(
	        'orderpost',
	        [
	            'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
	            'type'      => Controls_Manager::SELECT,
	            'options'   => [
	               'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
	               'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
	            ],
	            'default'   => 'desc',
	        ]
	   );

   	$this->add_control(
      	'orderby',
      	[
            'label'     => esc_html__( 'Order By', 'bdevs-elementor' ),
            'type'      => Controls_Manager::SELECT,
            'options'   => [
               'date'  => esc_html__( 'Date', 'bdevs-elementor' ),
               'title' => esc_html__( 'Title', 'bdevs-elementor' ),
               'rand' => esc_html__( 'Random', 'bdevs-elementor' ),
            ],
            'default'   => 'desc',
      	]
   	);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		$wp_query = new \WP_Query(array('post_type' => 'projects', 'posts_per_page' => $settings['post_number'],'orderby' => $settings['orderby'], 'order' => $settings['orderpost'],));
		extract($settings);
		?>
<section id="related" class="tCenter bgGrey ofsTSmall">
    <div class="container clearfix ">
        <h1 class="title"><?php echo wp_kses_post($settings['title']); ?></h1>
        <p class="introShort"><?php echo wp_kses_post($settings['subtitle']); ?> </p>
    </div>
    <div class=" works clearfix ">
        <ul class="portfolio clearfix">
        		<?php
		      	$i = 0;
		        while($wp_query->have_posts()): $wp_query->the_post();
		        $cates = get_the_terms(get_the_ID(),'type1');
		              $cate_name = '';
		              $cate_slug = '';
		            foreach((array)$cates as $cate){
		                if(count($cates)>0){
		                    $cate_name .= $cate->name.' ';
		                    $cate_slug .= $cate->slug.' ';
		                }
		            }
		        $i++;
		      ?>
		      <?php $id_projects = get_post_meta(get_the_ID(),'_cmb_id_projects', true); ?>
	            <li class="item" data-id="<?php echo esc_attr($id_projects);?>" data-type="<?php echo esc_attr($cate_slug);?>">
	                <div class="itemDesc">
	                    <div class="itemDescInner">
	                    <h3><?php the_title(); ?><span><?php echo esc_attr($cate_name);?></span></h3>
	                    <div class="doubleBtn itemBtn ">
	                        <a  href="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>" class="doubleLeft folio"><i class="icon-eye"></i></a>
	                        <a href="<?php the_permalink(); ?>" class="doubleRight"><i class="icon-link"></i></a>
	                    </div>
	                    </div>
	                </div>
	                 <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>" alt="">
	            </li>
            <?php endwhile; ?>
        </ul>
    </div>
    <div class="allWorks btn">
        <a href="<?php echo wp_kses_post($settings['link']); ?>">
        	<?php echo wp_kses_post($settings['button']); ?>
        </a>
    </div>
</section>


<?php
if (is_admin()) { ?>
<script>
    $(".itemDesc").css({ opacity: 0 });
    
    $('.itemDesc').hover( function(){ 
        $(this).stop().animate({ opacity: 1 }, 'slow');
    }, function(){ 
        $(this).stop().animate({ opacity: 0 }, 'slow'); 
    });

        $('.itemDesc').hover(function () {
        var projDesc = $(this).find('.itemDesc');
        var offset = ($(this).height() / 2) - (projDesc.height() / 2);
        $(this).find('.itemDescInner').css('padding-top', offset -30);
    });
</script>
<?php } ?>
<?php
}

}