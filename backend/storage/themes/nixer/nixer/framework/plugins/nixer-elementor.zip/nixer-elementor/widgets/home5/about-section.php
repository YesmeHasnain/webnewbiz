<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome5AboutSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home5-about-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 5 - About Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-alert';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home5' ];
	}

	public function get_keywords() {
		return [ 'home5aboutsection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_about_section',
			[
				'label' => esc_html__( 'About Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'bg_color',
			[
				'label' 		=> esc_html__( 'Background Color (Default: #F8F8F8)', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::COLOR,
				'default'		=> '#F8F8F8',
			]
		);
		$this->add_control(
			'img_shape_sec',
			[
				'label'       	=> esc_html__( 'Image Shape Right Bottom Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image shape section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'img_left_sec',
			[
				'label'       	=> esc_html__( 'Image Left Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image left section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'img_left_shape_sec',
			[
				'label'       	=> esc_html__( 'Image Left Shape Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image left shape section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'label_left_1',
			[
				'label' 		=> esc_html__( 'Label Left Section 1', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Years Experience' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_left_1',
			[
				'label' 		=> esc_html__( 'Text Left Section 1', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '20+' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'link_left_1',
			[
				'label' 		=> esc_html__( 'Link Left Section 1 - If have', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'label_left_2',
			[
				'label' 		=> esc_html__( 'Label Left Section 2', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Call us for more details' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_left_2',
			[
				'label' 		=> esc_html__( 'Text Left Section 2', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '124 888 4567' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'link_left_2',
			[
				'label' 		=> esc_html__( 'Link Left Section 2 - If have', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'tel:1248884567' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'We earn your trust <br> and are diligent <br> in your case.' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_sec',
			[
				'label' 		=> esc_html__( 'Text Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Although we are maritime lawyers...' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_counter = new \Elementor\Repeater();
		$rp_counter->add_control(
			'label_counter',
			[
				'label' 		=> esc_html__( 'Label Counter Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Label Counter' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_counter->add_control(
			'num_count',
			[
				'label' 		=> esc_html__( 'Number Counter', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::NUMBER,
				'min' 			=> 0,
				'default' 		=> 75,
			]
		);
		$rp_counter->add_control(
			'text_num_bf',
			[
				'label' 		=> esc_html__( 'Text Befoter Number Counter', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXT,
				'default' 		=> __( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_counter->add_control(
			'text_num_af',
			[
				'label' 		=> esc_html__( 'Text After Number Counter', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXT,
				'default' 		=> __( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'tabs',
			[
				'label' 		=> esc_html__( 'List Counter Content', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $rp_counter->get_controls(),
				'default' 		=> [
					[
						
					],
				],
				'title_field' 	=> '{{{ label_counter }}}',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-about-5-ptb p-relative pt-160 pb-160" data-bg-color="<?php echo wp_kses_post($settings['bg_color']); ?>">
	<div class="container container-1380">
		<?php if (!empty($settings['img_shape_sec']['url'])): ?>
			<div class="tp-about-5-bg-shape">
				<img src="<?php echo wp_kses_post($settings['img_shape_sec']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_shape_sec']['alt']); ?>">
			</div>
		<?php endif ?>
		<div class="row">
			<div class="col-lg-6">
				<div class="tp-about-5-thumb p-relative">
					<?php if (!empty($settings['label_left_1']) || !empty($settings['text_left_1'])): ?>
						<div class="tp-about-5-year">
							<?php if (!empty($settings['text_left_1'])): ?>
								<?php if (!empty($settings['link_left_1'])) { ?>
									<a href="<?php echo wp_kses_post($settings['link_left_1']); ?>"><?php echo wp_kses_post($settings['text_left_1']); ?></a>
								<?php } else { ?>
									<span><?php echo wp_kses_post($settings['text_left_1']); ?></span>
								<?php } ?>
							<?php endif ?>
							<?php if (!empty($settings['label_left_1'])): ?>
								<p><?php echo wp_kses_post($settings['label_left_1']); ?></p>
							<?php endif ?>
						</div>
					<?php endif ?>
					<div class="tp-about-5-thumb-main">
						<?php if (!empty($settings['img_left_sec']['url'])): ?>
							<img src="<?php echo wp_kses_post($settings['img_left_sec']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_left_sec']['alt']); ?>">
						<?php endif ?>
					</div>
					<?php if (!empty($settings['img_left_shape_sec']['url'])): ?>
						<div class="tp-about-5-thumb-shape tp_img_reveal">
							<img src="<?php echo wp_kses_post($settings['img_left_shape_sec']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_left_shape_sec']['alt']); ?>">
						</div>
					<?php endif ?>
					<?php if (!empty($settings['label_left_2']) || !empty($settings['text_left_2'])): ?>
						<div class="tp-about-5-call">
							<?php if (!empty($settings['label_left_2'])): ?>
								<p><?php echo wp_kses_post($settings['label_left_2']); ?></p>
							<?php endif ?>
							<?php if (!empty($settings['text_left_2'])): ?>
								<?php if (!empty($settings['link_left_2'])) { ?>
									<a href="<?php echo wp_kses_post($settings['link_left_2']); ?>"><?php echo wp_kses_post($settings['text_left_2']); ?></a>
								<?php } else { ?>
									<span><?php echo wp_kses_post($settings['text_left_2']); ?></span>
								<?php } ?>
							<?php endif ?>
						</div>
					<?php endif ?>
				</div>
			</div>
			<div class="col-lg-6">
				<?php if (!empty($settings['title_sec']) || !empty($settings['text_sec'])): ?>
					<div class="tp-about-5-heading tp-title-anim">
						<?php if (!empty($settings['title_sec'])): ?>
							<h3 class="tp-section-5-title"><?php echo wp_kses_post($settings['title_sec']); ?></h3>
						<?php endif ?>
						<?php if (!empty($settings['text_sec'])): ?>
							<p><?php echo wp_kses_post($settings['text_sec']); ?></p>
						<?php endif ?>
					</div>
				<?php endif ?>
				<div class="tp-about-5-content">
					<div class="row gx-0">
						<?php
						$i = 0;
						$total = count($settings['tabs']);
						foreach ($settings['tabs'] as $item) :
							$i++;
							$classes = [];
							if ($i % 2 != 0) {
								$classes[] = 'rft';
							}
							if (!($total % 2 == 0 && $i > $total - 2) && !($total % 2 != 0 && $i > $total - 1)) {
								$classes[] = 'btm';
							}
							$time = $item['num_count']/25;
						?>
							<div class="col-sm-6">
								<div class="tp-about-5-counter text-center <?php echo implode(' ', $classes); ?>">
									<h4 class="tp-about-5-counter-title">
										<?php if ($item['num_count'] > 100) { ?>
											<?php echo wp_kses_post($item['text_num_bf']); ?><span class="purecounter" data-purecounter-duration="4" data-purecounter-end="<?php echo wp_kses_post($item['num_count']); ?>"><?php echo wp_kses_post($item['num_count']); ?></span><?php echo wp_kses_post($item['text_num_af']); ?>
										<?php } elseif ($item['num_count'] < 25) { ?>
											<?php echo wp_kses_post($item['text_num_bf']); ?><span class="purecounter" data-purecounter-duration="1" data-purecounter-end="<?php echo wp_kses_post($item['num_count']); ?>"><?php echo wp_kses_post($item['num_count']); ?></span><?php echo wp_kses_post($item['text_num_af']); ?>
										<?php } else { ?>
											<?php echo wp_kses_post($item['text_num_bf']); ?><span class="purecounter" data-purecounter-duration="<?php echo($time); ?>" data-purecounter-end="<?php echo wp_kses_post($item['num_count']); ?>"><?php echo wp_kses_post($item['num_count']); ?></span><?php echo wp_kses_post($item['text_num_af']); ?>
										<?php } ?>
									</h4>
									<?php if (!empty($item['label_counter'])): ?>
										<p><?php echo wp_kses_post($item['label_counter']); ?></p>
									<?php endif ?>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-bg-color]").each(function () {
			jQuery(this).css("background-color", jQuery(this).attr("data-bg-color"));
		});

		var tp_img_reveal = document.querySelectorAll(".tp_img_reveal");
		tp_img_reveal.forEach((img_reveal) => {
			var image = img_reveal.querySelector("img");
			var tl = gsap.timeline({
				scrollTrigger: {
					trigger: img_reveal,
					start: "top 70%",
				}
			});
			tl.set(img_reveal, { autoAlpha: 1 });
			tl.from(img_reveal, 1.5, {
				xPercent: -100,
				ease: Power2.out
			});
			tl.from(image, 1.5, {
				xPercent: 100,
				scale: 1.5,
				duration: 3,
				delay: -1.5,
				ease: Power2.out
			});
		});

		if (jQuery('.tp-about-5-heading.tp-title-anim').length > 0) {
			var splitTitleLines = gsap.utils.toArray(".tp-about-5-heading.tp-title-anim");
			splitTitleLines.forEach(splitTextLine => {
				var tl = gsap.timeline({
				scrollTrigger: {
					trigger: splitTextLine,
					start: 'top 90%',
					end: 'bottom 60%',
					scrub: false,
					markers: false,
					toggleActions: 'play none none none'
				}
				});
				var itemSplitted = new SplitText(splitTextLine, { type: "words, lines" });
				gsap.set(splitTextLine, { perspective: 300});
				itemSplitted.split({ type: "lines" })
				tl.from(itemSplitted.lines, { duration: 1, delay: 0.3, opacity: 0, rotationX: -50, force3D: true, transformOrigin: "top center -50", stagger: 0.2 });
			});	
		}

		new PureCounter();
	</script>
<?php } ?>

<?php
}

}