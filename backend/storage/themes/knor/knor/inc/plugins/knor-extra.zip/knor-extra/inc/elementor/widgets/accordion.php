<?php

/**
 * Elementor Widget
 * @package Knor
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_accordion_section extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'custom-accordion-wid';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Accordion V.1', 'knor-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'knor_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {


		$this->start_controls_section( 'section_content', [
			'label' => __( 'Content', 'quiety-core' ),
		] );


		$this->add_control( 'theme-ctm-accordion', [
			'label'       => esc_html__( 'Accordion List', 'gazania-extra' ),
			'type'        => \Elementor\Controls_Manager::REPEATER,

			'fields'      => [

				[
					'name'        => 'accordion_title',
					'label'       => __( 'Title', 'quiety-core' ),
					'type'        => \Elementor\Controls_Manager::TEXT,
					'default'     => __( 'Give Accordion Title', 'quiety-core' ),
					'label_block' => true,
				],
	
				[
					'name'        => 'accordion_content',
					'label'      => __( 'Content', 'quiety-core' ),
					'type'       => \Elementor\Controls_Manager::WYSIWYG,
					'default'    => __( 'Give Accordion Content', 'quiety-core' ),
					'show_label' => false,
				],
				
				[
					'name'  => 'show_icon',
					'label' => __( 'Show Icon in Item', 'quiety-core' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => esc_html__( 'Show', 'textdomain' ),
					'label_off' => esc_html__( 'Hide', 'textdomain' ),
					'return_value' => 'yes',
					'default' => 'no',
				],

				[
					'name'  => 'accordion_icon',
					'label'     => __( 'Icon', 'quiety-core' ),
					'type'      => \Elementor\Controls_Manager::ICONS,
					'default'   => [
						'value'   => 'fas fa-star',
						'library' => 'solid',
					],
					'condition' => ['show_icon' => 'yes']
				],

			],

			'default'     => [
				[
					'accordion_title'   => __( 'What is Saaspark?', 'quiety-core' ),
					'accordion_content' => __( 'Management the nation or Saaspark is a powerful app for you to manage, create, or visualize your product and growth throughout the easiest and smoothest way possible. By giving you a simple yet amazing experience with our app.', 'quiety-core' ),
				],
				[
					'accordion_title'   => __( 'Are there any additional fees?', 'quiety-core' ),
					'accordion_content' => __( 'Management the nation or Saaspark is a powerful app for you to manage, create, or visualize your product and growth throughout the easiest and smoothest way possible. By giving you a simple yet amazing experience with our app.', 'quiety-core' ),
				],
				[
					'accordion_title'   => __( 'How can I get App?', 'quiety-core' ),
					'accordion_content' => __( 'Management the nation or Saaspark is a powerful app for you to manage, create, or visualize your product and growth throughout the easiest and smoothest way possible. By giving you a simple yet amazing experience with our app.', 'quiety-core' ),
				],
				[
					'accordion_title'   => __( 'What features do Saaspark have and other not?', 'quiety-core' ),
					'accordion_content' => __( 'Management the nation or Saaspark is a powerful app for you to manage, create, or visualize your product and growth throughout the easiest and smoothest way possible. By giving you a simple yet amazing experience with our app.', 'quiety-core' ),
				],

			],

			'title_field' => '{{{ accordion_title }}}',


		] );


		$this->end_controls_section();



		/**
	    * Title & Content Styling Options
	    */

		$this->start_controls_section( 'title_style_section', [
			'label' => __( 'Accordion Title', 'quiety-core' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		] );


		$this->add_group_control(
           \Elementor\Group_Control_Typography::get_type(),
           [
              'name' => 'ac_title_typo',
              'label' => esc_html__( 'Title Typography', 'minerva-extra' ),
              'selector' => '{{WRAPPER}} .theme-custom-accordion .accordion-button',
           ]
        );

        $this->add_control('ac_title_color', [
            'label' => esc_html__('Title Color', 'senatory-master'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .theme-custom-accordion .accordion-button.collapsed" => "color: {{VALUE}}"
            ]
        ]);

        $this->add_control('ac_title_color_active', [
            'label' => esc_html__('Title Active Color', 'senatory-master'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .theme-custom-accordion .accordion-button:not(.collapsed)" => "color: {{VALUE}}"
            ]
        ]);
		
		$this->add_control('ac_title_bg', [
			'label'     => __('Title Background Color', 'quiety-core'),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .theme-custom-accordion .accordion-item.active .accordion-header' => 'background: {{VALUE}}',
			],
		]);

		$this->add_responsive_control(
			'ac_title_padding',
			[
				'label' => esc_html__( 'Title Padding', 'quiety-core' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .theme-custom-accordion .accordion-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->end_controls_section();


		$this->start_controls_section( 'content_style_section', [
			'label' => __( 'Accordion Content', 'quiety-core' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		] );

		$this->add_group_control(
           \Elementor\Group_Control_Typography::get_type(),
           [
              'name' => 'ac_content_typo',
              'label' => esc_html__( 'Content Typography', 'minerva-extra' ),
              'selector' => '{{WRAPPER}} .theme-custom-accordion .accordion-body-wrap',
           ]
        );

        $this->add_control('ac_content_color', [
            'label' => esc_html__('Content Color', 'senatory-master'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
				'{{WRAPPER}} .theme-custom-accordion .accordion-body-wrap' => 'color: {{VALUE}}',
			],
        ]);

        $this->add_responsive_control(
			'ac_content_padding',
			[
				'label' => esc_html__('Content Padding', 'quiety-core'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .theme-custom-accordion .accordion-body-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};transition:0.4s;',
				],
			]
		);


        $this->end_controls_section();

 
        /**
	    * Icon Styling Options
	    */

	    $this->start_controls_section( 'icon_style_section', [
			'label' => __( 'Accordion Item Icon', 'quiety-core' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		] );

		$this->add_control(
            'toggle_icon_position',
            [
                'type' => \Elementor\Controls_Manager::SELECT,
                'label' => esc_html__( 'Accordion Toggle Icon Position', 'textdomain' ),
                'options' => [
                    '1' => esc_html__( 'Right', 'textdomain' ),
                    '2' => esc_html__( 'Left', 'textdomain' ),
                ],
                'default' => '1',
            ]
        );



		$this->add_control(
			'ac_normal_icon',
			[
				'label' => esc_html__('Normal ', 'quiety-core'),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control( 'ac_icon_color', [
			'label'     => __( 'Color', 'quiety-core' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .theme-custom-accordion .accordion-button.collapsed:after' => 'color: {{VALUE}}',
			],
		] );


		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'ac_icon_bg',
				'label' => esc_html__('Background', 'quiety-core'),
				'types' => ['classic', 'gradient'],
				'selector' => '{{WRAPPER}} .theme-custom-accordion .accordion-button.collapsed:after',
			]
		);

		$this->add_control(
			'ac_active_icon',
			[
				'label' => esc_html__('Active ', 'quiety-core'),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		
		$this->add_control( 'accordion_active_icon_color', [
			'label'     => __( 'Color', 'quiety-core' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .theme-custom-accordion .accordion-button:not(.collapsed):after' => 'color: {{VALUE}}',
			],
		] );
		
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'accordion_active_icon_bg',
				'label' => esc_html__('Item Background', 'quiety-core'),
				'types' => ['classic', 'gradient'],
				'selector' => '{{WRAPPER}} .theme-custom-accordion .accordion-button:not(.collapsed):after',
			]
		);

		$this->end_controls_section();


		$this->start_controls_section( 'box_style_section', [
			'label' => __( 'Wrapper Styling', 'quiety-core' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		] );



		$this->add_control(
			'wrap_border_radius',
			[
				'label' => __( 'Border Radius', 'quiety-core' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .theme-custom-accordion .accordion-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


        $this->add_responsive_control(
            'acc_box_padding',
            [
                'label' => esc_html__( 'Item Padding', 'restlycore' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .theme-custom-accordion .accordion-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


		$this->add_control(
			'ac_item_mb',
			[
				'label' => esc_html__( 'Space Between', 'quiety-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 50,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .theme-custom-accordion .accordion-item:not(:last-child)' => 'margin-bottom: {{SIZE}}{{UNIT}} !important;',
				],
			]
		);


		$this->start_controls_tabs(
			'style_tabs'
		);

		$this->start_controls_tab(
			'style_ntab',
			[
				'label' => esc_html__( 'Normal', 'quiety-core' ),
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'ac_normal_background',
				'label' => __( 'Background', 'quiety-core' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .theme-custom-accordion .accordion-item',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'ac_normal_border',
				'label' => __( 'Border', 'quiety-core' ),
				'selector' => '{{WRAPPER}} .theme-custom-accordion .accordion-item',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'ac_box_shadow',
				'label' => __( 'Box Shadow', 'quiety-core' ),
				'selector' => '{{WRAPPER}} .theme-custom-accordion .accordion-item',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'quiety-core' ),
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'ac_bg_active',
				'label' => __( 'Background', 'quiety-core' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .theme-custom-accordion .accordion-item.active',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'ac_border_active',
				'label' => __( 'Border', 'quiety-core' ),
				'selector' => '{{WRAPPER}} .theme-custom-accordion .accordion-item.active',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'ac_box_shadow_active',
				'label' => __( 'Box Shadow', 'quiety-core' ),
				'selector' => '{{WRAPPER}} .theme-custom-accordion .accordion-item.active',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();

		
	}
	


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

		$toggle_icon_position = $settings['toggle_icon_position'];

		$accordion = $settings['theme-ctm-accordion'];


		
		$faq_id = 'theme-accordion-' . substr( $this->get_id_int(), 0, 3 );
		$faq    = 'theme-acc-' . substr( $this->get_id_int(), 0, 3 );
		$faq_o  = 'theme-acco-' . substr( $this->get_id_int(), 0, 3 );
		?>

		
		<div class="theme-accordion-wrapper toggle-icon-pos-<?php echo esc_attr($toggle_icon_position);?> theme-custom-accordion" id="<?php echo esc_attr( $faq_id ); ?>">
			<?php foreach ( $accordion as $index => $item ) :
				$tab_btn_setting_key = $this->get_repeater_setting_key( 'accordion_title', '', $index );

				$this->add_render_attribute( $tab_btn_setting_key, [
					'class'          => [ $index == 0 ? 'accordion-button' : 'accordion-button collapsed' ],
					'data-bs-toggle' => 'collapse',
					'data-bs-target' => '#' . 'faq-collapse-' . $faq_o . '-' . $index,
					'aria-expanded'  => $index == 0 ? 'true' : 'false',
					'type'           => 'button',
					'aria-controls'  => $faq_o . '-' . $index
				] );

				$tab_body_setting_key = $this->get_repeater_setting_key( 'accordion_content', '', $index );

				$this->add_render_attribute( $tab_body_setting_key, [
					'id'             => 'faq-collapse-' . $faq_o . '-' . $index,
					'class'          => [ $index == 0 ? 'accordion-collapse collapse show' : 'accordion-collapse collapse' ],
					'data-bs-parent' => "#" . $faq_id
				] );
				?>

				<div class="accordion-item <?php echo $index == 0 ? 'active' : ''; ?>">

					<h2 class="accordion-header" id="<?php echo $faq_o . '-' . $index; ?>">
						<button <?php echo $this->get_render_attribute_string( $tab_btn_setting_key ); ?>>

							<?php if ( $item['show_icon'] === 'yes' && !empty( $item['accordion_icon'] ) ) : ?>
								<div class="accordion-icon-wrap">
									<?php \Elementor\Icons_Manager::render_icon( $item['accordion_icon'], [ 'aria-hidden' => 'true' ] ); ?>
								</div>
							<?php endif; ?>

							<?php echo $item['accordion_title']; ?>
						</button>
					</h2>

					<div <?php echo $this->get_render_attribute_string( $tab_body_setting_key ); ?>>
						<div class="accordion-body-wrap">
							<?php echo $item['accordion_content']; ?>
						</div>
					</div>

				</div>

			<?php endforeach; ?>

		</div>


		<?php



	}
				

}

