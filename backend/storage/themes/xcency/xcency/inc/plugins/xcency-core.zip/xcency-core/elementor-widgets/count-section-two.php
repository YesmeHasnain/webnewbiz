<?php
namespace Elementor;
class Xcency_Counter_Up_Section_Two_Widget extends Widget_Base {

	public function get_name() {

		return 'xcency_counter_up_section_two';
	}

	public function get_title() {
		return esc_html__( 'Count Up Section Two', 'xcency-core' );
	}

	public function get_icon() {

		return 'eicon-counter';
	}

	public function get_categories() {
		return [ 'xcency_core_elements' ];
	}

	public function get_script_depends() {
		return ['counterup'];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'counter_up_options',
			[
				'label' => esc_html__( 'Counter Up', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'       => __( 'Title', 'xcency-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Honorable Awards',
				'label_block' => true,
			]
		);

		$repeater->add_control(
            'desc',
            [
                'label'       => __( 'Description', 'xcency-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'rows'        => 5,
                'default'     => 'Completing a mobile app development.',
            ]
        );

		$repeater->add_control(
			'number',
			[
				'label'       => __( 'Number', 'xcency-core' ),
				'label_block'       => false,
				'type'        => Controls_Manager::TEXT,
				'default'     => '100',
			]
		);

		$repeater->add_control(
			'unit',
			[
				'label'   => 'Counter Unit',
				'type'    => Controls_Manager::TEXT,
				'default' => '%',
			]
		);

		$this->add_control(
			'count_boxes',
			[
				'label'       => __('Count Box List', 'xcency-core'),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title'        => 'Honorable Awards',
						'desc'        => 'Completing a mobile app development.',
						'unit' => '%',
						'number' => '100',
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

        $this->add_control(
            'image_one',
            [
                'label'       => esc_html__( 'Image One', 'xcency-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

		$this->end_controls_section();


		$this->start_controls_section(
			'counter_up_option',
			[
				'label' => esc_html__( 'Counter Up', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
            'box_background_color',
            [
                'label'       => esc_html__('Background Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .count-section-one-content' => 'background-color: {{VALUE}};',
                ],
            ]
        );

		$this->add_control(
			'number_unit_color',
			[
				'label'       => esc_html__('Number & Unit Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-counter-section-one-counter' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'       => esc_html__('Title Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-count-box-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_bg_color',
			[
				'label'       => esc_html__('Title Background', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-count-box-title' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'desc_color',
			[
				'label'       => esc_html__('Description Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .counter-box-one-desc' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'counter_up_wrapper',
			[
				'label' => esc_html__( 'Wrapper', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'wrapper_padding',
			[
				'label'      => esc_html__( 'Wrapper Padding', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .counter-up-section-one-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$count_id = rand(100, 100000);

		?>
		<div class="counter-up-section-two-wrapper counter-up-section-one-wrapper td-cover-bg xcency-counter-box-<?php echo esc_attr($count_id);?>">
            <div class="counter-up-section-one-bg xcency-cover-bg" style="background-image: url(<?php echo $settings['image_one']['url'];?>)"></div>
			<div class="container">
                <div class="count-section-one-content">
                    <div class="row">
                        <?php if ( $settings['count_boxes'] ) {
                            foreach ( $settings['count_boxes'] as $count_box ) {
                                ?>
                                <div class="col-xl-3 col-lg-4 col-md-6 col-12 p-0">
                                    <div class="xcency-counter-section-box">
                                        <div class="xcency-counter-section-one-counter">
                                            <span class="xcency-count-number"><?php echo esc_html( $count_box['number'] ) ?></span><?php echo esc_html( $count_box['unit'] ) ?>
                                        </div>

                                        <div class="xcency-count-box-title"><?php echo esc_html( $count_box['title'] ) ?></div>

                                        <div class="counter-box-one-desc">
                                            <?php echo $count_box['desc'];?>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                        } ?>
                    </div>
                </div>
			</div>
		</div>

		<script>
            (function ($) {
                "use strict";
                /*====  Document Ready Function =====*/
                jQuery(document).ready(function($){
                    $(".xcency-counter-box-<?php echo esc_attr($count_id);?> .xcency-count-number").counterUp({
                        delay: 10,
                        time: 2000
                    });
                });
            }(jQuery));
		</script>
		<?php

	}
}

Plugin::instance()->widgets_manager->register( new Xcency_Counter_Up_Section_Two_Widget );