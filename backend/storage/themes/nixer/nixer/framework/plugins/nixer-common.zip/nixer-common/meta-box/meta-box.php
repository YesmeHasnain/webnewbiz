<?php
/**
 * Plugin Name: Meta Box
 * Plugin URI:  https://metabox.io
 * Description: Create custom meta boxes and custom fields in WordPress.
 * Version:     5.10.3
 * Author:      MetaBox.io
 * Author URI:  https://metabox.io
 * License:     GPL2+
 * Text Domain: meta-box
 */

if ( defined( 'ABSPATH' ) && ! defined( 'RWMB_VER' ) ) {
	require_once __DIR__ . '/inc/loader.php';
	$rwmb_loader = new RWMB_Loader();
	$rwmb_loader->init();

	add_filter( 'rwmb_meta_boxes', function ( $meta_boxes ) {

	$prefix = '_cmb_';



	// Open Code


	$meta_boxes[] = array(
		'id'         => 'post_fomat',
		'title'      => 'Post Fomat',
		'pages'      => array('post'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		//'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
		'fields' => array(

			array(
				'name'			=> 'Choose Fomat Post',
				'desc'			=> 'Choose Fomat Post',
				'type'			=> 'select',
				'id'			=> $prefix . 'post_fomat',
				'default'		=> 'format1',
				'options'		=> [
					'format1'		=> 'Post Standar',
					'format2'		=> 'Post Gallery',
					'format3'		=> 'Post Video',
				]
			),

			array(
				'name'				=> 'Post Image Gallery',
				'desc'				=> 'Post image gallery', 
				'id'				=> $prefix . 'fm-img-gallery',
				'type'				=> 'image_advanced',
				'force_delete'     	=> false,
			    'max_file_uploads' 	=> 5,
			    'max_status'       	=> false,
			    'image_size'       	=> 'thumbnail',
			),

			array(
				'name'			=> 'Post Image Background Video',
				'desc'			=> 'Post image background video', 
				'id'			=> $prefix . 'fm-bg-video',
				'type'			=> 'image_advanced',
			),

			array(
				'name'			=> 'Post Link Background Video',
				'desc'			=> 'Post link background video', 
				'id'			=> $prefix . 'fm-link-video',
				'type'			=> 'textarea',
			),
			
		)
	);


	$meta_boxes[] = array(
		'id'         => 'post_setting',
		'title'      => 'Post Setting',
		'pages'      => array('post'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		//'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
		'fields' => array(

			array(
				'name'			=> 'Title Excerpt Show in Recent Post',
				'desc'			=> 'Show in sidebar recent post', 
				'id'			=> $prefix . 'post_rc_title',
				'type'			=> 'textarea',
			),

			array(
				'name'			=> 'Post Image Show in Recent Post',
				'desc'			=> 'Show in sidebar recent post', 
				'id'			=> $prefix . 'post_rc_image',
				'type'			=> 'single_image',
			),

			array(
				'name'			=> 'Post Excerpt Show in Blog Post',
				'desc'			=> 'Show in blog page',
				'id'			=> $prefix . 'post_blog_excerpt',
				'type'			=> 'textarea',
			),

			
		)
	);


	$meta_boxes[] = array(
		'id'         => 'post_setting_1',
		'title'      => 'Post Setting Show in Home Creative Agency',
		'pages'      => array('post'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		//'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
		'fields' => array(

			array(
				'name'			=> 'Post Image Show in Home Creative Agency',
				'desc'			=> 'Show in home creative agency', 
				'id'			=> $prefix . 'post_thumb_home_1',
				'type'			=> 'single_image',
			),

			array(
				'name'			=> 'Title Excerpt Show in Home Creative Agency',
				'desc'			=> 'Show in home creative agency', 
				'id'			=> $prefix . 'post_title_home_1',
				'type'			=> 'textarea',
			),
			
		)
	);


	$meta_boxes[] = array(
		'id'         => 'post_setting_2',
		'title'      => 'Post Setting Show in Home Creative Studio',
		'pages'      => array('post'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		//'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
		'fields' => array(

			array(
				'name'			=> 'Post Image Show in Home Creative Studio',
				'desc'			=> 'Show in home creative agency', 
				'id'			=> $prefix . 'post_thumb_home_3',
				'type'			=> 'single_image',
			),

			array(
				'name'			=> 'Title Excerpt Show in Home Creative Studio',
				'desc'			=> 'Show in home creative agency', 
				'id'			=> $prefix . 'post_title_home_3',
				'type'			=> 'textarea',
			),
			
		)
	);


	$meta_boxes[] = array(
		'id'         => 'post_setting_3',
		'title'      => 'Post Setting Show in Home Personal Portfolio',
		'pages'      => array('post'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		//'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
		'fields' => array(

			array(
				'name'			=> 'Post Image Show in Home Personal Portfolio',
				'desc'			=> 'Show in home personal portfolio', 
				'id'			=> $prefix . 'post_thumb_home_4',
				'type'			=> 'single_image',
			),

			array(
				'name'			=> 'Title Excerpt Show in Home Personal Portfolio',
				'desc'			=> 'Show in home personal portfolio', 
				'id'			=> $prefix . 'post_title_home_4',
				'type'			=> 'textarea',
			),
			
		)
	);


	$meta_boxes[] = array(
		'id'         => 'post_setting_4',
		'title'      => 'Post Setting Show in Home Law Firm Agency',
		'pages'      => array('post'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		//'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
		'fields' => array(

			array(
				'name'			=> 'Post Image Show in Home Law Firm Agency',
				'desc'			=> 'Show in home law firm agency', 
				'id'			=> $prefix . 'post_thumb_home_5',
				'type'			=> 'single_image',
			),

			array(
				'name'			=> 'Title Excerpt Show in Home Law Firm Agency',
				'desc'			=> 'Show in home law firm agency', 
				'id'			=> $prefix . 'post_title_home_5',
				'type'			=> 'textarea',
			),

			array(
				'name'			=> 'Post Excerpt Show in Home Law Firm Agency',
				'desc'			=> 'Show in home law firm agency', 
				'id'			=> $prefix . 'post_excerpt_home_5',
				'type'			=> 'textarea',
			),
			
		)
	);


	$meta_boxes[] = array(
		'id'         => 'service_setting',
		'title'      => 'Service Detail Setting',
		'pages'      => array('service'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		//'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
		'fields' => array(

			array(
				'name'			=> 'Service Title Excerpt Show In Service Detail',
				'desc'			=> 'Show in single service',
				'id'			=> $prefix . 'sv_title_excerpt',
				'type'			=> 'textarea',
			),

			array(
				'name'			=> 'Service Subtitle Show In Service Detail',
				'desc'			=> 'Show in single service',
				'id'			=> $prefix . 'sv_subtitle',
				'type'			=> 'textarea',
			),

			array(
				'name'			=> 'Service Text Effect Show In Service Detail',
				'desc'			=> 'Show in single service',
				'id'			=> $prefix . 'sv_text',
				'clone'			=> true,
				'type'			=> 'text',
			),

		)
	);


	$meta_boxes[] = array(
		'id'         => 'service_setting_1',
		'title'      => 'Service Home Creative Agency Setting',
		'pages'      => array('service'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		//'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
		'fields' => array(

			array(
				'name'			=> 'Service Image Show in Home Creative Agency',
				'desc'			=> 'Show in home creative agency', 
				'id'			=> $prefix . 'sv_thumb_home_1',
				'type'			=> 'single_image',
			),

			array(
				'name'			=> 'Service Title Excerpt Show In Home Creative Agency',
				'desc'			=> 'Show in home creative agency',
				'id'			=> $prefix . 'sv_title_home_1',
				'type'			=> 'textarea',
			),

		)
	);

	$meta_boxes[] = array(
		'id'         => 'service_setting_2',
		'title'      => 'Service Home Digital Agency Setting',
		'pages'      => array('service'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		//'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
		'fields' => array(

			array(
				'name'			=> 'Service Image Show in Home Digital Agency',
				'desc'			=> 'Show in home digital agency', 
				'id'			=> $prefix . 'sv_thumb_home_2',
				'type'			=> 'single_image',
			),

			array(
				'name'			=> 'Service Title Excerpt Show In Home Digital Agency',
				'desc'			=> 'Show in home digital agency',
				'id'			=> $prefix . 'sv_title_home_2',
				'type'			=> 'textarea',
			),

		)
	);


	$meta_boxes[] = array(
		'id'         => 'service_setting_3',
		'title'      => 'Service Home Law Firm Agency Setting',
		'pages'      => array('service'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		//'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
		'fields' => array(

			array(
				'name'			=> 'Service Image Icon Show in Home Law Firm Agency',
				'desc'			=> 'Show in home law firm agency', 
				'id'			=> $prefix . 'sv_icon_home_5',
				'type'			=> 'single_image',
			),

			array(
				'name'			=> 'Service Title Excerpt Show In Home Law Firm Agency',
				'desc'			=> 'Show in home law firm agency',
				'id'			=> $prefix . 'sv_title_home_5',
				'type'			=> 'textarea',
			),

			array(
				'name'			=> 'Service Excerpt Show In Home Law Firm Agency',
				'desc'			=> 'Show in home law firm agency',
				'id'			=> $prefix . 'sv_excerpt_home_5',
				'type'			=> 'textarea',
			),

		)
	);



	$meta_boxes[] = array(
		'id'         => 'portfolio_setting',
		'title'      => 'Portfolio Detail Setting',
		'pages'      => array('portfolio'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		//'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
		'fields' => array(

			array(
				'name'			=> 'Portfolio Thumbnail Image 1',
				'desc'			=> 'Show in single portfolio thumb detail top', 
				'id'			=> $prefix . 'port_thumb_1',
				'type'			=> 'single_image',
			),

			array(
				'name'			=> 'Portfolio Thumbnail Image 2',
				'desc'			=> 'Show in single portfolio thumb detail', 
				'id'			=> $prefix . 'port_thumb_2',
				'type'			=> 'single_image',
			),

			array(
				'name'			=> 'Portfolio Title Excerpt Show In Portfolio Detail',
				'desc'			=> 'Show in single portfolio',
				'id'			=> $prefix . 'port_title_excerpt',
				'type'			=> 'textarea',
			),

			array(
				'name'			=> 'Portfolio Client',
				'desc'			=> 'Show in single portfolio',
				'id'			=> $prefix . 'port_client',
				'type'			=> 'text',
			),

			array(
				'name'			=> 'Portfolio Link Website',
				'desc'			=> 'Show in single portfolio',
				'id'			=> $prefix . 'port_link',
				'type'			=> 'text',
			),

			array(
				'name'			=> 'Portfolio Introduction',
				'desc'			=> 'Show in single portfolio',
				'id'			=> $prefix . 'port_intro',
				'type'			=> 'textarea',
			),

			array(
				'name'			=> 'Portfolio Participants',
				'desc'			=> 'Show in single portfolio',
				'id'			=> $prefix . 'port_participants',
				'clone'			=> true,
				'type'			=> 'text',
			),

		)
	);


	$meta_boxes[] = array(
		'id'         => 'portfolio_setting_2',
		'title'      => 'Portfolio Show in Home Creative Agency',
		'pages'      => array('portfolio'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		//'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
		'fields' => array(

			array(
				'name'			=> 'Portfolio Thumbnail Image Home Creative Agency',
				'desc'			=> 'Show in home creative agency', 
				'id'			=> $prefix . 'port_thumb_home_1',
				'type'			=> 'single_image',
			),

			array(
				'name'			=> 'Portfolio Title Excerpt Show In Home Creative Agency',
				'desc'			=> 'Show in home creative agency',
				'id'			=> $prefix . 'port_title_home_1',
				'type'			=> 'textarea',
			),

			array(
				'name'			=> 'Post Excerpt Show In Home Creative Agency',
				'desc'			=> 'Show in home creative agency',
				'id'			=> $prefix . 'port_excerpt_home_1',
				'type'			=> 'textarea',
			),

		)
	);


	$meta_boxes[] = array(
		'id'         => 'portfolio_setting_3',
		'title'      => 'Portfolio Show In Home Digital Agency',
		'pages'      => array('portfolio'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		//'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
		'fields' => array(

			array(
				'name'			=> 'Portfolio Thumbnail Before Show in Home Digital Agency',
				'desc'			=> 'Show in home digital agency', 
				'id'			=> $prefix . 'port_thumb_home_21',
				'type'			=> 'single_image',
			),

			array(
				'name'			=> 'Portfolio Thumbnail After Show in Home Digital Agency',
				'desc'			=> 'Show in home digital agency', 
				'id'			=> $prefix . 'port_thumb_home_22',
				'type'			=> 'single_image',
			),

			array(
				'name'			=> 'Portfolio Title Excerpt Show In Home Digital Agency',
				'desc'			=> 'Show in home digital agency',
				'id'			=> $prefix . 'port_title_home_2',
				'type'			=> 'textarea',
			),

			array(
				'name'			=> 'Post Excerpt Show In Home Digital Agency',
				'desc'			=> 'Show in home digital agency',
				'id'			=> $prefix . 'port_excerpt_home_2',
				'type'			=> 'textarea',
			),

		)
	);


	$meta_boxes[] = array(
		'id'         => 'portfolio_setting_4',
		'title'      => 'Portfolio Show In Home Creative Studio',
		'pages'      => array('portfolio'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		//'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
		'fields' => array(

			array(
				'name'			=> 'Portfolio Thumbnail Show in Home Creative Studio',
				'desc'			=> 'Show in home creative studio', 
				'id'			=> $prefix . 'port_thumb_home_3',
				'type'			=> 'single_image',
			),

			array(
				'name'			=> 'Portfolio Title Excerpt Show In Home Creative Studio',
				'desc'			=> 'Show in home creative studio',
				'id'			=> $prefix . 'port_title_home_3',
				'type'			=> 'textarea',
			),

		)
	);


	$meta_boxes[] = array(
		'id'         => 'portfolio_setting_5',
		'title'      => 'Portfolio Show in Home Personal Portfolio',
		'pages'      => array('portfolio'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		//'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
		'fields' => array(

			array(
				'name'			=> 'Portfolio Thumbnail Image Home Personal Portfolio',
				'desc'			=> 'Show in home personal portfolio', 
				'id'			=> $prefix . 'port_thumb_home_4',
				'type'			=> 'single_image',
			),

			array(
				'name'			=> 'Portfolio Title Excerpt Show In Home Personal Portfolio',
				'desc'			=> 'Show in home personal portfolio',
				'id'			=> $prefix . 'port_title_home_4',
				'type'			=> 'textarea',
			),

			array(
				'name'			=> 'Post Excerpt Show In Home Personal Portfolio',
				'desc'			=> 'Show in home personal portfolio',
				'id'			=> $prefix . 'port_excerpt_home_4',
				'type'			=> 'textarea',
			),

		)
	);


	$meta_boxes[] = array(
		'id'         => 'portfolio_setting_6',
		'title'      => 'Portfolio Show in Home Creative Portfolio',
		'pages'      => array('portfolio'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		//'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
		'fields' => array(

			array(
				'name'			=> 'Portfolio Thumbnail Image Home Creative Portfolio',
				'desc'			=> 'Show in home personal portfolio', 
				'id'			=> $prefix . 'port_thumb_home_6',
				'type'			=> 'single_image',
			),

			array(
				'name'			=> 'Portfolio Title Excerpt Show In Home Personal Portfolio',
				'desc'			=> 'Show in home personal portfolio',
				'id'			=> $prefix . 'port_title_home_6',
				'type'			=> 'textarea',
			),

		)
	);


	$meta_boxes[] = array(
		'id'         => 'portfolio_setting_7',
		'title'      => 'Portfolio Show in Home Horizontal',
		'pages'      => array('portfolio'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		//'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
		'fields' => array(

			array(
				'name'			=> 'Portfolio Thumbnail Image Home Horizontal',
				'desc'			=> 'Show in home horizontal', 
				'id'			=> $prefix . 'port_thumb_home_8',
				'type'			=> 'single_image',
			),

			array(
				'name'			=> 'Portfolio Title Excerpt Show In Home Horizontal',
				'desc'			=> 'Show in home horizontal',
				'id'			=> $prefix . 'port_title_home_8',
				'type'			=> 'textarea',
			),

			array(
				'name'			=> 'Portfolio year Show In Home Horizontal',
				'desc'			=> 'Show in home horizontal',
				'id'			=> $prefix . 'port_year_home_8',
				'type'			=> 'text',
			),

		)
	);



	$meta_boxes[] = array(
		'id'         => 'team_setting',
		'title'      => 'Team Setting',
		'pages'      => array('team'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		'fields' => array(

			array(
				'name'			=> 'Team Thumbnail Image - Show In Single Team',
				'desc'			=> 'Show in single team thumb detail', 
				'id'			=> $prefix . 'team_thumbail',
				'type'			=> 'single_image',
			),

			array(
				'name'			=> 'Link Social',
				'id'			=> $prefix . 'team_link_social',
				'type'			=> 'textarea',
				'clone'			=> true,
				'attributes'  	=> array(
					'placeholder' 	=> 'Enter social link here.',
				),
			),

			array(
				'name'			=> 'Icon Social - SVG Link File or tag i',
				'id'			=> $prefix . 'Team_icon_social',
				'type'			=> 'textarea',
				'clone'			=> true,
				'attributes'  	=> array(
					'placeholder' 	=> 'Enter social icon here.',
				),
			),

			array(
				'name'			=> 'Team Introduce Show In Single Team',
				'id'			=> $prefix . 'team_introduce',
				'type'			=> 'textarea',
				'attributes'  	=> array(
					'placeholder' 	=> 'Enter introduce here',
				),
			),

			array(
				'name'			=> 'Team Location - Show In Single Team',
				'id'			=> $prefix . 'team_location',
				'type'			=> 'text',
				'attributes'  	=> array(
					'placeholder' 	=> 'Enter location here',
				),
			),
		)
	);


	$meta_boxes[] = array(
		'id'         => 'team_setting_1',
		'title'      => 'Team Show in Home Creative Agency',
		'pages'      => array('team'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		'fields' => array(

			array(
				'name'			=> 'Post Image Show in Home Creative Agency',
				'desc'			=> 'Show in home creative agency', 
				'id'			=> $prefix . 'team_thumb_home_1',
				'type'			=> 'single_image',
			),

			array(
				'name'			=> 'Title Excerpt Show in Home Creative Agency',
				'desc'			=> 'Show in home creative agency', 
				'id'			=> $prefix . 'team_title_home_1',
				'type'			=> 'textarea',
			),	
			
		)
	);


	$meta_boxes[] = array(
		'id'         => 'team_setting_2',
		'title'      => 'Team Show in Home Digital Agency',
		'pages'      => array('team'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		'fields' => array(

			array(
				'name'			=> 'Post Image Show in Home Digital Agency',
				'desc'			=> 'Show in home digital agency', 
				'id'			=> $prefix . 'team_thumb_home_2',
				'type'			=> 'single_image',
			),

			array(
				'name'			=> 'Title Excerpt Show in Home Digital Agency',
				'desc'			=> 'Show in home digital agency', 
				'id'			=> $prefix . 'team_title_home_2',
				'type'			=> 'textarea',
			),

			array(
				'name'			=> 'Team Excerpt Show in Home Digital Agency',
				'desc'			=> 'Show in home digital agency', 
				'id'			=> $prefix . 'team_excerpt_home_2',
				'type'			=> 'textarea',
			),

		)
	);


	$meta_boxes[] = array(
		'id'         => 'team_setting_3',
		'title'      => 'Team Show in Home Law Firm Agency',
		'pages'      => array('team'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		'fields' => array(

			array(
				'name'			=> 'Post Image Show in Home Law Firm Agency',
				'desc'			=> 'Show in home law firm agency', 
				'id'			=> $prefix . 'team_thumb_home_5',
				'type'			=> 'single_image',
			),

			array(
				'name'			=> 'Title Excerpt Show in Home Law Firm Agency',
				'desc'			=> 'Show in home law firm agency', 
				'id'			=> $prefix . 'team_title_home_5',
				'type'			=> 'textarea',
			),

		)
	);


	$meta_boxes[] = array(
		'id'         => 'product_setting',
		'title'      => 'Product Setting',
		'pages'      => array('product'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		'fields' => array(

			array(
				'name'			=> 'Link Social 1',
				'id'			=> $prefix . 'link_social_1',
				'type'			=> 'textarea',
				'attributes'  	=> array(
					'placeholder' 	=> 'Enter social link 1 here.',
				),
			),

			array(
				'name'			=> 'Icon Social 1',
				'id'			=> $prefix . 'icon_social_1',
				'type'			=> 'textarea',
				'attributes'  	=> array(
					'placeholder' 	=> 'Enter social icon 1 here.',
				),
			),

			array(
				'name'			=> 'Link Social 2',
				'id'			=> $prefix . 'link_social_2',
				'type'			=> 'textarea',
				'attributes'  	=> array(
					'placeholder' 	=> 'Enter social link 2 here.',
				),
			),

			array(
				'name'			=> 'Icon Social 2',
				'id'			=> $prefix . 'icon_social_2',
				'type'			=> 'textarea',
				'attributes'  	=> array(
					'placeholder' 	=> 'Enter social icon 2 here.',
				),
			),

			array(
				'name'			=> 'Link Social 3',
				'id'			=> $prefix . 'link_social_3',
				'type'			=> 'textarea',
				'attributes'  	=> array(
					'placeholder' 	=> 'Enter social link 3 here.',
				),
			),

			array(
				'name'			=> 'Icon Social 3',
				'id'			=> $prefix . 'icon_social_3',
				'type'			=> 'textarea',
				'attributes'  	=> array(
					'placeholder' 	=> 'Enter social icon 3 here.',
				),
			),

			array(
				'name'			=> 'Link Social 4',
				'id'			=> $prefix . 'link_social_4',
				'type'			=> 'textarea',
				'attributes'  	=> array(
					'placeholder' 	=> 'Enter social link 4 here.',
				),
			),

			array(
				'name'			=> 'Icon Social 4',
				'id'			=> $prefix . 'icon_social_4',
				'type'			=> 'textarea',
				'attributes'  	=> array(
					'placeholder' 	=> 'Enter social icon 4 here.',
				),
			),
		)
	);



	$meta_boxes[] = array(
		'id'         => 'header_setting',
		'title'      => 'Header Setting',
		'pages'      => array('page'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		'fields' => array(
			array(
				'name'      	=> 'Switch Header Default Or Custom',
				'id'        	=> 'switch_header_btn',
				'type'     	 	=> 'switch',
				'style'     	=> 'rounded',
				'on_label'  	=> 'Custom',
				'off_label' 	=> 'Default',
			),

			array(
				'name' 			=> 'Choose Style Header',
				'id'   			=> $prefix . 'choose_page_header',
				'type'    		=> 'image_select',
				'inline'  		=> false,
				'options' 		=> [
					'style0' => get_template_directory_uri() . '/assets/header/header-0.png',
					'style1' => get_template_directory_uri() . '/assets/header/header-1.png',
					'style2' => get_template_directory_uri() . '/assets/header/header-2.png',
					'style3' => get_template_directory_uri() . '/assets/header/header-3.png',
					'style4' => get_template_directory_uri() . '/assets/header/header-4.png',
					'style5' => get_template_directory_uri() . '/assets/header/header-5.png',
					'style6' => get_template_directory_uri() . '/assets/header/header-6.png',
					'style7' => get_template_directory_uri() . '/assets/header/header-7.png',
					'style8' => get_template_directory_uri() . '/assets/header/header-8.png',
					'style9' => get_template_directory_uri() . '/assets/header/header-9.png',
					'style10' => get_template_directory_uri() . '/assets/header/header-10.png',
				],
				'visible' => array(
					'when'     => array(array('switch_header_btn', '=', true)),
					'relation' => 'and',
				),
			),
		)
	);

	$meta_boxes[] = array(
		'id'         => 'footer_setting',
		'title'      => 'Footer Setting',
		'pages'      => array('page'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		'fields' => array(
			array(
				'name'      	=> 'Switch Footer Default Or Custom',
				'id'        	=> 'switch_footer_btn',
				'type'     	 	=> 'switch',
				'style'     	=> 'rounded',
				'on_label'  	=> 'Custom',
				'off_label' 	=> 'Default',
			),
			array(
				'name' 			=> 'Choose Style Footer',
				'id'   			=> $prefix . 'choose_page_footer',
				'type'    		=> 'image_select',
				'inline'  		=> false,
				'options' 		=> [
					'style0' => get_template_directory_uri() . '/assets/footer/footer-0.png',
					'style1' => get_template_directory_uri() . '/assets/footer/footer-1.png',
					'style2' => get_template_directory_uri() . '/assets/footer/footer-2.png',
					'style3' => get_template_directory_uri() . '/assets/footer/footer-3.png',
					'style4' => get_template_directory_uri() . '/assets/footer/footer-4.png',
					'style5' => get_template_directory_uri() . '/assets/footer/footer-5.png',
					'style6' => get_template_directory_uri() . '/assets/footer/footer-6.png',
				],
				'visible' => array(
					'when'     => array(array('switch_footer_btn', '=', true)),
					'relation' => 'and',
				),
			),
		)
	);




// End Code
	return $meta_boxes;
});
}

add_action('admin_footer', 'add_meta_box_script');
function add_meta_box_script() {
	$screen = get_current_screen();
	if ('post' === $screen->id) : ?>
		<script>
			jQuery(document).ready(function ($) {
				function toggleFields(switchId, classToToggle) {
					const isSwitchOn = $(switchId).prop('checked');
					if (isSwitchOn) {
						$(classToToggle).slideDown();
					} else {
						$(classToToggle).slideUp();
					}
				}
				$('#conclusion_switch').change(function () {
					toggleFields('#conclusion_switch', '.post-conclusion-switch');
				});

				toggleFields('#conclusion_switch', '.post-conclusion-switch');
			});
		</script>
	<?php endif;
}


add_action('admin_footer', 'nixer_style_switcher_logic');
function nixer_style_switcher_logic() {
	?>
	<script type="text/javascript">
		jQuery(document).ready(function($) {
			function toggleStyleField(switchBtn, styleField) {
				if ($(switchBtn).is(':checked')) {
					$(styleField).closest('.rwmb-field').show();
				} else {
					$(styleField).closest('.rwmb-field').hide();
				}
			}

			toggleStyleField('input[type="checkbox"][name="switch_header_btn"]', 'input[name="_cmb_choose_page_header"]');
			toggleStyleField('input[type="checkbox"][name="switch_footer_btn"]', 'input[name="_cmb_choose_page_footer"]');

			$('input[type="checkbox"][name="switch_header_btn"]').on('change', function() {
				toggleStyleField(this, 'input[name="_cmb_choose_page_header"]');
			});
			$('input[type="checkbox"][name="switch_footer_btn"]').on('change', function() {
				toggleStyleField(this, 'input[name="_cmb_choose_page_footer"]');
			});
		});
	</script>
	<?php
}


add_action( 'admin_footer', 'nixer_meta_box_js' );
function nixer_meta_box_js() {
	?>
	<script type="text/javascript">
		jQuery(document).ready(function($) {
			var switchMenuBtn = $('input#switch_menu_btn');
			var selectMenuField = $('select#_cmb_choose_page_menu').closest('.rwmb-field');

			function toggleSelectMenu() {
				if (switchMenuBtn.is(':checked')) {
					selectMenuField.show();
				} else {
					selectMenuField.hide();
				}
			}
			toggleSelectMenu();
			switchMenuBtn.on('change', function() {
				toggleSelectMenu();
			});
		});
	</script>
	<?php
}