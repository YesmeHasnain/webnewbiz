<?php
/**
 *
 * @Packge      Barab 
 * @Author      Themeholy
 * @Author URL  https://themeforest.net/user/themeholy
 * @version     1.0
 *
 */

/**
 * Enqueue style of child theme  
 */
function barab_child_enqueue_styles() {

    wp_enqueue_style( 'barab-style', get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'barab-child-style', get_stylesheet_directory_uri() . '/style.css',array( 'barab-style' ),wp_get_theme()->get('Version'));
}
add_action( 'wp_enqueue_scripts', 'barab_child_enqueue_styles', 100000 );   