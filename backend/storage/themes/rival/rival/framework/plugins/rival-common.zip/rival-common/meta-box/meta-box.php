  <?php
/**
 * Plugin Name: Meta Box
 * Plugin URI:  https://metabox.io
 * Description: Create custom meta boxes and custom fields in WordPress.
 * Version:     5.3.3
 * Author:      MetaBox.io
 * Author URI:  https://metabox.io
 * License:     GPL2+
 * Text Domain: meta-box
 * Domain Path: /languages/
 * 
 * @package Meta Box
 */

if ( defined( 'ABSPATH' ) && ! defined( 'RWMB_VER' ) ) {
	register_activation_hook( __FILE__, 'rwmb_check_php_version' );

	/**
	 * Display notice for old PHP version.
	 */
	function rwmb_check_php_version() {
		if ( version_compare( phpversion(), '5.3', '<' ) ) {
			die( esc_html__( 'Meta Box requires PHP version 5.3+. Please contact your host to upgrade.', 'meta-box' ) );
		}
	}




	require_once dirname( __FILE__ ) . '/inc/loader.php';
	$rwmb_loader = new RWMB_Loader();
	$rwmb_loader->init();


	add_filter( 'rwmb_meta_boxes', function ( $meta_boxes ) {

	$prefix = '_cmb_';


	//Add other metaboxs as needed

	


  // Open Code

	$meta_boxes[] = array( 
		'id'         => 'post_setting',
		'title'      => 'Post Setting',
		'pages'      => array('post'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		//'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
		'fields' => array(
            array(
				'name' 		=> ' Image Blog Post',
				'desc' 		=> ' Image show in Blog Post',
				'default' 	=> '',
				'id' 		=> $prefix . 'img_blog',
				'type' 		=> 'single-image'
			),
			array(
				'name' 		=> 'Link Video Blog ',
				'desc' 		=> 'Link Video Blog ',
				'default' 	=> '',
				'id' 		=> $prefix . 'link_video',
				'type' 		=> 'text'
			),
		)
	);

	$meta_boxes[] = array( 
		'id'         => 'projects_setting',
		'title'      => 'Projects Setting',
		'pages'      => array('projects'), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		//'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
		'fields' => array(
			array(
                'name' => 'Choose Select',
                'desc' => 'Select Choose Show Projects',
                'id'   => $prefix . 'choose_select',
                'type'    => 'select',
                'options'   => array(
                    'style1' => 'Demo style 01',
                ),
                'default' => '',

                'placeholder'     => 'Demo Post Type',
            ),
			array(
				'name' 		=> 'Category Projects ',
				'desc' 		=> 'Category Projects',
				'default' 	=> '',
				'id' 		=> $prefix . 'category_projects',
				'type' 		=> 'text'
			),
			array(
				'name' 		=> ' Image Projects 1',
				'desc' 		=> ' Image show in Projects',
				'default' 	=> '',
				'id' 		=> $prefix . 'img_projects1',
				'type' 		=> 'single-image'
			),
			array(
				'name' 		=> ' Image Projects 2',
				'desc' 		=> ' Image show in Projects',
				'default' 	=> '',
				'id' 		=> $prefix . 'img_projects2',
				'type' 		=> 'single-image'
			),
			array(
				'name' 		=> 'Video Projects ',
				'desc' 		=> 'Video Projects',
				'default' 	=> '',
				'id' 		=> $prefix . 'video_projects',
				'type' 		=> 'text'
			),
			array(
				'name' 		=> 'Heading Projects ',
				'desc' 		=> 'Heading Projects',
				'default' 	=> '',
				'id' 		=> $prefix . 'heading_projects',
				'type' 		=> 'text'
			),
			array(
				'name' 		=> 'Description Projects ',
				'desc' 		=> 'Description Projects',
				'default' 	=> '',
				'id' 		=> $prefix . 'desc_projects',
				'type' 		=> 'textarea'
			),
			array(
				'name' 		=> 'ID Projects ',
				'desc' 		=> 'ID Projects',
				'default' 	=> '',
				'id' 		=> $prefix . 'id_projects',
				'type' 		=> 'text'
			),
		)
	);
// End Code
	return $meta_boxes;
});
}