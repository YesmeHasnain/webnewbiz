<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsPricingTable extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-pricing-table';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Pricing Table', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-price-table';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-global' ];
	}

	public function get_keywords() {
		return [ 'pricingtable', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_pricing_table',
			[
				'label' => esc_html__( 'Pricing Table', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'bg_color',
			[
				'label' 		=> esc_html__( 'Background Color (Default: #f9f9f9)', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::COLOR,
				'default'		=> '#f9f9f9',
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'name_item',
			[
				'label' 		=> esc_html__( 'Name Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Starter' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'sub_item',
			[
				'label' 		=> esc_html__( 'SubText Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( 'SubText Item' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'price_item',
			[
				'label' 		=> esc_html__( 'Title Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '$ 199' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'duration_item',
			[
				'label' 		=> esc_html__( 'Duration Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '/Month' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater1 = new \Elementor\Repeater();
		$repeater1->add_control(
			'select_item',
			[
				'label'     	=> esc_html__( 'Select Text Icon', 'bdevs-elementor' ),
				'type'      	=> Controls_Manager::SELECT,
				'options'   	=> [
					'type1'  		=> esc_html__( 'Check', 'bdevs-elementor' ),
					'type2'  		=> esc_html__( 'X Mark', 'bdevs-elementor' ),
				],
				'default'   	=> 'type1',
			]
		);
		$repeater1->add_control(
			'text_item',
			[
				'label' 		=> esc_html__( 'Text Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Purveyors of big ideas' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'tab_item',
			[
				'label' 		=> esc_html__( 'List Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater1->get_controls(),
				'default' 		=> [
					[
						
					],
					[
						
					],
				],
				'title_field' 	=> '{{{ text_item }}}',
			]
		);
		$repeater->add_control(
			'text_btn_item',
			[
				'label' 		=> esc_html__( 'Text Button Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Choose Plan' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'link_btn_item',
			[
				'label' 		=> esc_html__( 'Link Button Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '#' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'tabs',
			[
				'label' 		=> esc_html__( 'List Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						
					],
					[
						
					],
				],
				'title_field' 	=> '{{{ name_item }}}',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-pricing-ptb pt-100 pb-100" data-bg-color="<?php echo wp_kses_post($settings['bg_color']); ?>">
	<div class="container">
		<div class="row">
			<?php
			$i = 0;
			foreach ($settings['tabs'] as $item) :
				$i++;
			?>
				<?php if ($i % 2 == 1) { ?>
					<div class="col-xl-4 col-md-6">
						<div class="tp-pricing-item mb-50">
							<div class="tp-pricing-item-top">
								<?php if (!empty($item['name_item']) || !empty($item['sub_item'])): ?>
									<div class="tp-pricing-item-heading">
										<?php if (!empty($item['name_item'])): ?>
											<h3 class="tp-pricing-item-title"><?php echo wp_kses_post($item['name_item']); ?></h3>
										<?php endif ?>
										<?php if (!empty($item['sub_item'])): ?>
											<p><?php echo wp_kses_post($item['sub_item']); ?></p>
										<?php endif ?>
									</div>
								<?php endif ?>
								<?php if (!empty($item['price_item']) || !empty($item['duration_item'])): ?>
									<div class="tp-pricing-item-price">
										<h2 class="tp-pricing-item-price-title">
											<?php if (!empty($item['price_item'])): ?>
												<span class="price"><?php echo wp_kses_post($item['price_item']); ?></span>
											<?php endif ?>
											<?php if (!empty($item['duration_item'])): ?>
												<span class="duration"><?php echo wp_kses_post($item['duration_item']); ?></span>
											<?php endif ?>
										</h2>
									</div>
								<?php endif ?>
							</div>
							<div class="tp-pricing-item-list">
								<ul>
									<?php
									foreach ($item['tab_item'] as $item1) :
									?>
										<?php if (!empty($item1['text_item'])): ?>
											<?php if ($item1['select_item'] == 'type1') { ?>
												<li><span><i class="fa-sharp fa-light fa-check"></i></span><?php echo wp_kses_post($item1['text_item']); ?></li>
											<?php } else { ?>
												<li><span><i class="fa-sharp fa-light fa-xmark"></i></span><?php echo wp_kses_post($item1['text_item']); ?></li>
											<?php } ?>
										<?php endif ?>
									<?php endforeach; ?>
								</ul>
							</div>
							<?php if (!empty($item['link_btn_item']) && !empty($item['text_btn_item'])): ?>
								<div class="tp-pricing-item-btn">
									<a href="<?php echo wp_kses_post($item['link_btn_item']); ?>" class="tp-pricing-btn w-100">
										<?php echo wp_kses_post($item['text_btn_item']); ?>
										<span>
											<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 10 10" fill="none">
												<path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
											</svg>
										</span>
									</a>
								</div>
							<?php endif ?>
						</div>
					</div>
				<?php } else { ?>
					<div class="col-xl-4 col-md-6">
						<div class="tp-pricing-item active mb-50">
							<div class="tp-pricing-item-top">
								<?php if (!empty($item['name_item']) || !empty($item['sub_item'])): ?>
									<div class="tp-pricing-item-heading">
										<?php if (!empty($item['name_item'])): ?>
											<h3 class="tp-pricing-item-title"><?php echo wp_kses_post($item['name_item']); ?></h3>
										<?php endif ?>
										<?php if (!empty($item['sub_item'])): ?>
											<p><?php echo wp_kses_post($item['sub_item']); ?></p>
										<?php endif ?>
									</div>
								<?php endif ?>
								<?php if (!empty($item['price_item']) || !empty($item['duration_item'])): ?>
									<div class="tp-pricing-item-price">
										<h2 class="tp-pricing-item-price-title">
											<?php if (!empty($item['price_item'])): ?>
												<span class="price"><?php echo wp_kses_post($item['price_item']); ?></span>
											<?php endif ?>
											<?php if (!empty($item['duration_item'])): ?>
												<span class="duration"><?php echo wp_kses_post($item['duration_item']); ?></span>
											<?php endif ?>
										</h2>
									</div>
								<?php endif ?>
							</div>
							<div class="tp-pricing-item-list">
								<ul>
									<?php
									foreach ($item['tab_item'] as $item1) :
									?>
										<?php if (!empty($item1['text_item'])): ?>
											<?php if ($item1['select_item'] == 'type1') { ?>
												<li><span><i class="fa-sharp fa-light fa-check"></i></span><?php echo wp_kses_post($item1['text_item']); ?></li>
											<?php } else { ?>
												<li><span><i class="fa-sharp fa-light fa-xmark"></i></span><?php echo wp_kses_post($item1['text_item']); ?></li>
											<?php } ?>
										<?php endif ?>
									<?php endforeach; ?>
								</ul>
							</div>
							<?php if (!empty($item['link_btn_item']) && !empty($item['text_btn_item'])): ?>
								<div class="tp-pricing-item-btn">
									<a href="<?php echo wp_kses_post($item['link_btn_item']); ?>" class="tp-pricing-btn w-100">
										<?php echo wp_kses_post($item['text_btn_item']); ?> 
										<span>
											<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 10 10" fill="none">
												<path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
											</svg>
										</span>
									</a>
								</div>
							<?php endif ?>
						</div>
					</div>
				<?php } ?>
			<?php endforeach; ?>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-bg-color]").each(function () {
			jQuery(this).css("background-color", jQuery(this).attr("data-bg-color"));
		});
	</script>
<?php } ?>

<?php
}

}