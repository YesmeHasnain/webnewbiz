<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome1TestimonialSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home1-testimonial-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 1 - Testimonial Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-testimonial-carousel';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home1' ];
	}

	public function get_keywords() {
		return [ 'home1testimonialsection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_testimonial_section',
			[
				'label' => esc_html__( 'Testimonial Section', 'bdevs-elementor' ),
			]
		);
		$rp_counter = new \Elementor\Repeater();
		$rp_counter->add_control(
			'img_user_item',
			[
				'label'       	=> esc_html__( 'Image User Item', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image user item', 'bdevs-elementor' ),
			]
		);
		$rp_counter->add_control(
			'user_title',
			[
				'label' 		=> esc_html__( 'User Title', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_counter->add_control(
			'user_subtitle',
			[
				'label' 		=> esc_html__( 'User SubTitle', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_counter->add_control(
			'text_item',
			[
				'label' 		=> esc_html__( 'Text Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'tabs',
			[
				'label' 		=> esc_html__( 'List Testimonial Content', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $rp_counter->get_controls(),
				'default' 		=> [
					[
						
					],
				],
				'title_field' 	=> '{{{ user_title }}}',
			]
		);
		$this->add_control(
			'show_btn_testi',
			[
				'label'   => esc_html__( 'Show Button Next/Previous', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-testimonial-ptb pt-160 pb-160">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="tp-testimonial-wrapper tp_fade_bottom p-relative">
					<div class="tp-testimonial-active swiper">
						<div class="swiper-wrapper">
							<?php
							foreach ($settings['tabs'] as $item) :
							?>
								<div class="swiper-slide">
									<div class="tp-testimonial-item">
										<?php if (!empty($item['text_item'])): ?>
											<span class="tp-testimonial-item-title"><?php echo wp_kses_post($item['text_item']); ?></span>
										<?php endif ?>
										<div class="tp-testimonial-user d-flex align-items-center">
											<?php if (!empty($item['img_user_item']['url'])): ?>
												<div class="tp-testimonial-user-thumb">
													<img src="<?php echo wp_kses_post($item['img_user_item']['url']); ?>" alt="<?php echo wp_kses_post($item['img_user_item']['alt']); ?>">
												</div>
											<?php endif ?>
											<?php if (!empty($item['user_title']) || !empty($item['user_subtitle'])): ?>
												<div class="tp-testimonial-user-content">
													<?php if (!empty($item['user_title'])): ?>
														<h5 class="tp-testimonial-user-title"><?php echo wp_kses_post($item['user_title']); ?></h5>
													<?php endif ?>
													<?php if (!empty($item['user_subtitle'])): ?>
														<span><?php echo wp_kses_post($item['user_subtitle']); ?></span>
													<?php endif ?>
												</div>
											<?php endif ?>
										</div>
									</div>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
					<?php if (!empty($settings['show_btn_testi'])): ?>
						<div class="tp-testimonial-navigation">
							<button class="tp-testimonial-prev">
								<svg xmlns="http://www.w3.org/2000/svg" width="33" height="26" viewBox="0 0 33 26" fill="none">
									<path d="M33.0019 13H2.2739M14.3769 0C14.3769 7.18558 7.94662 13 0 13C7.94662 13 14.3769 18.8146 14.3769 26.0002" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10"/>
								</svg>
							</button>
							<button class="tp-testimonial-next">
								<svg xmlns="http://www.w3.org/2000/svg" width="33" height="26" viewBox="0 0 33 26" fill="none">
									<path d="M0 13H30.728M18.625 0C18.625 7.18558 25.0552 13 33.0019 13C25.0552 13 18.625 18.8146 18.625 26.0002" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10"/>
								</svg>
							</button>
						</div>
					<?php endif ?>
				</div>
			</div>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">

		if (jQuery('.tp-testimonial-active').length > 0) {
			var slider = new Swiper('.tp-testimonial-active', {
				slidesPerView: 1,
				speed:1500,
				loop: true,
				spaceBetween: 30,
				navigation: {
					nextEl: ".tp-testimonial-next",
					prevEl: ".tp-testimonial-prev",
				},
				autoplay: {
					delay: 4000,
					},
			});
		}
	</script>
<?php } ?>

<?php
}

}