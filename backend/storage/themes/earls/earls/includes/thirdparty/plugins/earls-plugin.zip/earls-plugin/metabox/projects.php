<?php
return array(
	'title'      => 'Earls Project Setting',
	'id'         => 'earls_meta_projects',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'project' ),
	'sections'   => array(
		array(
			'id'     => 'earls_projects_meta_setting',
			'fields' => array(
				array(
					'id'       => 'gallery_imgs',
					'type'     => 'gallery',
					'url'      => true,
					'title'    => esc_html__('Project Images Image', 'earls'),
					'desc'     => esc_html__('Insert Project Images Image URl', 'earls'),
				),
				array(
                    'id' => 'show_project_info',
                    'type' => 'switch',
                    'title' => esc_html__('Show/Hide Project Information', 'earls'),
                    'desc' => esc_html__('Enable to Show Project Information', 'earls'),
                ),
				array(
					'id'    => 'project_category_title',
					'type'  => 'text',
					'title' => esc_html__( 'Enter Project Category Heading', 'earls' ),
					'required' => array('show_project_info', '=', true),
				),
				array(
					'id'    => 'project_date_title',
					'type'  => 'text',
					'title' => esc_html__( 'Enter Project Date Heading', 'earls' ),
					'required' => array('show_project_info', '=', true),
				),
				array(
					'id'    => 'project_tags_title',
					'type'  => 'text',
					'title' => esc_html__( 'Enter Project Tags Title', 'earls' ),
					'required' => array('show_project_info', '=', true),
				),
				array(
					'id'    => 'project_tags',
					'type'  => 'text',
					'title' => esc_html__( 'Enter Project Tags', 'earls' ),
					'required' => array('show_project_info', '=', true),
				),
				array(
					'id'    => 'project_social_title',
					'type'  => 'text',
					'title' => esc_html__( 'Enter Project Social Title', 'earls' ),
					'required' => array('show_project_info', '=', true),
				),
				array(
					'id'    => 'project_social_profile',
					'type'  => 'social_media',
					'title' => esc_html__( 'Social Profiles', 'earls' ),
					'required' => array('show_project_info', '=', true),
				),
			),
		),
	),
);