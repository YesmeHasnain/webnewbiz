<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsRegisterSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-register-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Register Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-form-horizontal';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-global' ];
	}

	public function get_keywords() {
		return [ 'registersection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_register_form',
			[
				'label' => esc_html__( 'Register Form', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'title_form',
			[
				'label'       	=> __( 'Title Form Register', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::TEXTAREA,
				'placeholder' 	=> __( 'Enter your title form register', 'bdevs-elementor' ),
				'default'     	=> __( 'Sing Up Nixer.', 'bdevs-elementor' ),
				'label_block' 	=> true,
			]
		);
		$this->add_control(
			'text_form_1',
			[
				'label'       	=> __( 'Text Form Register', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::TEXTAREA,
				'placeholder' 	=> __( 'Enter your text form register', 'bdevs-elementor' ),
				'default'     	=> __( 'You have an account.', 'bdevs-elementor' ),
				'label_block' 	=> true,
			]
		);
		$this->add_control(
			'text_2',
			[
				'label'       	=> __( 'Text Login', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::TEXTAREA,
				'placeholder' 	=> __( 'Enter your text login', 'bdevs-elementor' ),
				'default'     	=> __( 'Sign in', 'bdevs-elementor' ),
				'label_block' 	=> true,
			]
		);
		$this->add_control(
			'link_2',
			[
				'label'       	=> __( 'Link Text Create Account', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::TEXTAREA,
				'placeholder' 	=> __( 'Enter your link create account', 'bdevs-elementor' ),
				'default'     	=> __( '#', 'bdevs-elementor' ),
				'label_block' 	=> true,
			]
		);
		$this->add_control(
			'shortcode',
			[
				'label'       => __( 'Shortcode Login Form', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your shortcode login form', 'bdevs-elementor' ),
				'default'     => __( '[user_registration_form id="1757"]', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-login-area pt-180 pb-140 p-relative z-index-1 fix">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-xl-5 col-lg-8">
				<div class="tp-login-wrapper">
					<div class="tp-login-top text-center mb-30">
						<?php if (!empty($settings['title_form'])): ?>
							<h3 class="tp-login-title"><?php echo wp_kses_post($settings['title_form']); ?></h3>
						<?php endif ?>
						<?php if (!empty($settings['text_form_1']) || (!empty($settings['link_2']) && !empty($settings['text_2']))): ?>
							<p>
								<?php echo wp_kses_post($settings['text_form_1']); ?>
								<?php if (!empty($settings['link_2']) && !empty($settings['text_2'])): ?>
									<span>
										<a href="<?php echo wp_kses_post($settings['link_2']); ?>"><?php echo wp_kses_post($settings['text_2']); ?></a>
									</span>
								<?php endif ?>
							</p>
						<?php endif ?>
					</div>
					<div class="tp-login-option">
						<?php echo do_shortcode($settings['shortcode']); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		
	</script>
<?php } ?>

<?php
}

}