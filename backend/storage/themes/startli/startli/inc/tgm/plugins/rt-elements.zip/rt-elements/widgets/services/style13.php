<div class="react-addon-services services-<?php echo esc_attr( $settings['services_style'] ); ?>">
    <div class="service-area-main-wrapper-ten">
        <div class="thumbnail">
             <?php if(!empty($settings['select_image_style5'])) :?>
				<img src="<?php echo esc_url( $settings['select_image_style5']['url'] );?>" alt="image"/>
			<?php endif; ?>	

            <?php if( !empty($settings['selected_icon']) || !empty($settings['selected_image']['url'])){?>
                <div class="icon">
                    <?php if(!empty($settings['selected_icon'])) : ?>
                        <?php \Elementor\Icons_Manager::render_icon( $settings['selected_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                    <?php endif; ?>
                    <?php if(!empty($settings['selected_image'])) :?>
                        <img src="<?php echo esc_url( $settings['selected_image']['url'] );?>" alt="image"/>
                    <?php endif;?>
                </div>	
            <?php }?>
        </div>
        
        <div class="content-area-start">
            <?php if( !empty($settings['title']) ): ?>
                <h6 class="title"><?php echo wp_kses_post($settings['title']); ?></h6>
            <?php endif; ?>
            <?php if(!empty($settings['text'])) : ?>
                <p class="disc"><?php echo wp_kses_post($settings['text']); ?></p>
            <?php endif; ?>

            <a href="<?php echo esc_url($settings['services_btn_link']);?>" class="service_btn">
                <?php echo wp_kses_post($settings['services_btn_text']); ?>    
            </a>

        </div>
    </div>
</div>