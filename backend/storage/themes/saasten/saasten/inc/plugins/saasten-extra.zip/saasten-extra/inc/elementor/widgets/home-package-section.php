<?php

/**
 * Elementor Widget
 * @package Saasten
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_home_package extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'theme-package-sec';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Home Package', 'saasten-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saasten_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {


        $this->start_controls_section( 'section_content_about_inner_three', [
            'label' => esc_html__( 'About Content', 'saasten-extra' ),
        ] ); 


        $this->add_control( 'title', [
            'label'       => __( 'Title', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Invest in Startup', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type section title here.", 'saasten-extra' ),

        ] );


        $this->add_control( 'description', [
            'label'       => __( 'Description', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Our Sustainable Construction Advisors provide sustainable construction expertise', 'saasten-extra' ),
            'label_block' => true,
        ] );


        
        $this->add_control( 'about_feature_image1', [
            'label'   => __( 'Choose Image 1', 'saasten-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        $this->add_control( 'about_feature_image2', [
            'label'   => __( 'Choose Image 2', 'saasten-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        $this->add_control( 'about_feature_image3', [
            'label'   => __( 'Choose Image 3', 'saasten-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        $this->add_control( 'about_feature_image4', [
            'label'   => __( 'Choose Image 4', 'saasten-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );




        $this->end_controls_section();


        $this->start_controls_section( 'section_content_about3_featurelist', [
            'label' => esc_html__( 'About Skill List', 'saasten-extra' ),
        ] ); 

        $this->add_control( 'featureItems', [
            'label'       => esc_html__( 'About features items', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'default'     => [
                [
                    'feature-title'        => esc_html__( 'Website design', 'saasten-extra' ),
                ]
            ],

            'fields'      => [
                [
                    'name'        => 'feature-title',
                    'label'       => esc_html__( 'Skill Title', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'description' => esc_html__( 'Enter Skill Title', 'saasten-extra' )
                ],
                

            ],
            'title_field' => "{{name}}"
        ] );



        $this->end_controls_section();


        // ===================== Title ======================//

        $this->start_controls_section( 'title_style', [
            'label' => __( 'Title', 'saasten-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_typography',
            'label'    => __( 'Typography', 'saasten-extra' ),
            'selector' => '
                {{WRAPPER}} .theme-banner-startup-wrapper h1.banner-heading,
                {{WRAPPER}} .__title
            ',
        ] );


        $this->add_control( 'title_color', [
            'label'     => __( 'Color', 'saasten-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-startup-wrapper h1.banner-heading' => 'color: {{VALUE}}',
                '{{WRAPPER}} .__title' => 'color: {{VALUE}}',
            ],
        ] );

        $this->end_controls_section(); //End Title Style


        // ===================== Subtitle Style ========================//
        $this->start_controls_section( 'sub_title_style', [
            'label' => __( 'Sub Title', 'saasten-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_sub_typography',
            'label'    => __( 'Typography', 'saasten-extra' ),
            'selector' => '{{WRAPPER}} .theme-banner-startup-wrapper h4.banner-sub-heading',
        ] );

        $this->add_control( 'sub_title_color', [
            'label'     => __( 'Sub Title Color', 'saasten-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-startup-wrapper h4.banner-sub-heading' => 'color: {{VALUE}}',
            ],

        ] );

        $this->end_controls_section(); //End Subtitle Style

		
	}
	


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

        $featureItems = $settings['featureItems'];

        extract($settings); 


		
		?>



    <!-- Plan Area -->
    <section class="pd-btm-130">
      <div class="container">
        <div class="row">
          <div class="col-12 mg-btm-60">
            <div class="section-title-area text-center">
              <h2 class="section-title m-0 saastain-gsap-anim1">
                Get The Most our Plan with Unlimited <br />
                Question and Survey
              </h2>
              <p class="section-text m-0 mg-top-25 saastain-gsap-anim1">
                Collaborate, manage projects and reach new productivity
                peaks.From high rises to <br />
                the home office, accomplishit all with Saasify!
              </p>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12">
            <div class="overflow-auto">
              <table class="table plan-table p-4" data-aos="fade-in">
                <thead>
                  <tr>
                    <th class="text-start pl-30">Features</th>
                    <th class="active">
                      <img src="<?php echo esc_url( $settings['about_feature_image1']['url'] ); ?>" alt="#" />
                    </th>
                    <th><img src="<?php echo esc_url( $settings['about_feature_image2']['url'] ); ?>" alt="#" /></th>
                    <th><img src="<?php echo esc_url( $settings['about_feature_image3']['url'] ); ?>" alt="#" /></th>
                    <th><img src="<?php echo esc_url( $settings['about_feature_image4']['url'] ); ?>" alt="#" /></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="text-start pl-30">Start at</td>
                    <td class="active">10.50 USD</td>
                    <td>45.50 USD</td>
                    <td>125.50 USD</td>
                    <td>90.50 USD</td>
                  </tr>
                  <tr>
                    <td class="text-start pl-30">Content Templates</td>
                    <td class="active">20+ Template</td>
                    <td>05+ Template</td>
                    <td>12+ Template</td>
                    <td><img src="<?php echo SAASTEN_IMG ."/wrong.png"; ?>" alt="#" /></td>
                  </tr>
                  <tr>
                    <td class="text-start pl-30">Content Enhancement</td>
                    <td class="active">
                      <img src="<?php echo SAASTEN_IMG ."/right.png"; ?>" alt="#" />
                    </td>
                    <td><img src="<?php echo SAASTEN_IMG ."/wrong.png"; ?>" alt="#" /></td>
                    <td><img src="<?php echo SAASTEN_IMG ."/right.png"; ?>" alt="#" /></td>
                    <td><img src="<?php echo SAASTEN_IMG ."/wrong.png"; ?>" alt="#" /></td>
                  </tr>
                  <tr>
                    <td class="text-start pl-30">Content Customization</td>
                    <td class="active">
                      <img src="<?php echo SAASTEN_IMG ."/right.png"; ?>" alt="#" />
                    </td>
                    <td><img src="<?php echo SAASTEN_IMG ."/right.png"; ?>" alt="#" /></td>
                    <td><img src="<?php echo SAASTEN_IMG ."/wrong.png"; ?>" alt="#" /></td>
                    <td><img src="<?php echo SAASTEN_IMG ."/wrong.png"; ?>" alt="#" /></td>
                  </tr>
                  <tr>
                    <td class="text-start pl-30">Language Support</td>
                    <td class="active">
                      <img src="<?php echo SAASTEN_IMG ."/right.png"; ?>" alt="#" />
                    </td>
                    <td><img src="<?php echo SAASTEN_IMG ."/right.png"; ?>" alt="#" /></td>
                    <td><img src="<?php echo SAASTEN_IMG ."/right.png"; ?>" alt="#" /></td>
                    <td><img src="<?php echo SAASTEN_IMG ."/right.png"; ?>" alt="#" /></td>
                  </tr>
                  <tr>
                    <td class="text-start pl-30">Team Use</td>
                    <td class="active">5 User</td>
                    <td>2 User</td>
                    <td>1 User</td>
                    <td>3 User</td>
                  </tr>
                  <tr>
                    <td class="text-start pl-30">24/7 support security</td>
                    <td class="active">
                      <img src="<?php echo SAASTEN_IMG ."/wrong.png"; ?>" alt="#" />
                    </td>
                    <td><img src="<?php echo SAASTEN_IMG ."/wrong.png"; ?>" alt="#" /></td>
                    <td><img src="<?php echo SAASTEN_IMG ."/right.png"; ?>" alt="#" /></td>
                    <td><img src="<?php echo SAASTEN_IMG ."/wrong.png"; ?>" alt="#" /></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Plan Area -->



	<?php 


	}
				

}

