<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Megamenu Widget .
 *
 */
class Barab_Megamenu extends Widget_Base {

	public function get_name() {
		return 'barabmegamenu';
	}
	public function get_title() {
		return __( 'Megamenu Content', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		 $this->start_controls_section(
			'megamenu_section',
			[
				'label'		 	=> __( 'Megamenu Content', 'barab' ),
				'tab' 			=> Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style',[ 'Style One'] );

        $repeater = new Repeater();

		barab_media_fields($repeater, 'image', 'Choose Image');
		barab_general_fields($repeater, 'title', 'Title', 'TEXTAREA2', 'Home One');
        barab_general_fields( $repeater, 'button_text', 'Button Text', 'TEXT', 'Multipage' );
        barab_url_fields( $repeater, 'button_url', 'Button URL' );
        barab_general_fields( $repeater, 'button_text2', 'Button Text 2', 'TEXT', 'Onepage' );
        barab_url_fields( $repeater, 'button_url2', 'Button URL 2' );
		
		$this->add_control(
			'megamenu_list',
			[
				'label' 		=> __( 'Megamenu Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'Home', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['1']
				]
			]
		);

        $this->end_controls_section();

		
        //---------------------------------------
			//Style Section Start 
		//---------------------------------------

		barab_common_style_fields( $this, '01', 'Title', '{{WRAPPER}} .mega-menu-title a', ['1', '2'] );

	}

	protected function render() {

	$settings = $this->get_settings_for_display();

		if( $settings['layout_style'] == '1' ){
			echo '<li>';
                echo '<div class="container">';
	                echo '<div class="row gy-4">';
	                    foreach( $settings['megamenu_list'] as $key => $data ){ 
		                    echo '<div class="col-lg-4">';
								echo '<div class="mega-menu-box">';
									echo '<div class="mega-menu-img">'; 
										echo barab_img_tag( array(
                                            'url'   => esc_url( $data['image']['url'] ),
                                        )); 
										echo '<div class="btn-wrap">';
											if(!empty($data['button_text'])){
                                                echo '<a class="th-btn style3" '.barab_link_attrs($data['button_url']).'>'.esc_html($data['button_text']).'</a>';
											}
											if(!empty($data['button_text2'])){
                                                echo '<a class="th-btn style3" '.barab_link_attrs($data['button_url2']).'>'.esc_html($data['button_text2']).'</a>';
											}
										echo '</div>';
									echo '</div>';
									if(!empty( $data['title'] )){
										echo '<h3 class="mega-menu-title"><a '.barab_link_attrs($data['button_url']).'>'.wp_kses_post( $data['title'] ).'</a></h3>';
									}
								echo '</div>';
		                    echo '</div>';
		                }
	                echo '</div>';
                echo '</div>';
            echo '</li>';
		}
	}
}