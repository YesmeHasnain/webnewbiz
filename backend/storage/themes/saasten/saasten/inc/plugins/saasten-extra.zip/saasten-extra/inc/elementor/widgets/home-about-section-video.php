<?php

/**
 * Elementor Widget
 * @package Saasten
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_home_about_video extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'theme-about-vid';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Home About Video', 'saasten-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saasten_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {


        $this->start_controls_section( 'section_content_about_inner_vid', [
            'label' => esc_html__( 'About Content', 'saasten-extra' ),
        ] ); 


        $this->add_control( 'title', [
            'label'       => __( 'Title', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Invest in Startup', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type section title here.", 'saasten-extra' ),

        ] );


        $this->add_control( 'description', [
            'label'       => __( 'Description', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Our Sustainable Construction Advisors provide sustainable construction expertise', 'saasten-extra' ),
            'label_block' => true,
        ] );

        $this->add_control( 'video_feature_image', [
            'label'   => __( 'Choose Video Image', 'saasten-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        $this->add_control(
            'video_link', [
                'label' => __( 'Insert Self Hosted Video URL Link in Video format(eg. mp4/flv etc).', 'gazania-extra' ),
                'type'        => \Elementor\Controls_Manager::URL,

                'default'     => [
                    'url' => 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
                ],
                
                'description' => esc_html__( 'Enter Video URL', 'gazania-extra' )
            ]
        );


        $this->add_control( 'btn_text', [
            'label'       => __( 'Button Label', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'placeholder' => __( 'Type your button label here', 'saasten-extra' ),
            'default'     => __( 'KNOW MORE', 'saasten-extra' ),
        ] );

        $this->add_control( 'btn_link', [
            'label'       => __( 'Button Link', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::URL,
            'placeholder' => __( 'https://your-link.com', 'saasten-extra' ),
            'default'     => [
                'url' => '#',
            ],
        ] );



        $this->end_controls_section();


        $this->start_controls_section( 'section_content_about_featurelist', [
            'label' => esc_html__( 'About Skill List', 'saasten-extra' ),
        ] ); 

        $this->add_control( 'featureItems', [
            'label'       => esc_html__( 'About features items', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'default'     => [
                [
                    'feature-title'        => esc_html__( 'Website design', 'saasten-extra' ),
                ]
            ],

            'fields'      => [
                [
                    'name'        => 'feature-title',
                    'label'       => esc_html__( 'Skill Title', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'description' => esc_html__( 'Enter Skill Title', 'saasten-extra' )
                ],
                

            ],
            'title_field' => "{{name}}"
        ] );



        $this->end_controls_section();


        // ===================== Title ======================//

        $this->start_controls_section( 'title_style', [
            'label' => __( 'Title', 'saasten-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_typography',
            'label'    => __( 'Typography', 'saasten-extra' ),
            'selector' => '
                {{WRAPPER}} .theme-banner-startup-wrapper h1.banner-heading,
                {{WRAPPER}} .__title
            ',
        ] );


        $this->add_control( 'title_color', [
            'label'     => __( 'Color', 'saasten-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-startup-wrapper h1.banner-heading' => 'color: {{VALUE}}',
                '{{WRAPPER}} .__title' => 'color: {{VALUE}}',
            ],
        ] );

        $this->end_controls_section(); //End Title Style


        // ===================== Subtitle Style ========================//
        $this->start_controls_section( 'sub_title_style', [
            'label' => __( 'Sub Title', 'saasten-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_sub_typography',
            'label'    => __( 'Typography', 'saasten-extra' ),
            'selector' => '{{WRAPPER}} .theme-banner-startup-wrapper h4.banner-sub-heading',
        ] );

        $this->add_control( 'sub_title_color', [
            'label'     => __( 'Sub Title Color', 'saasten-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-startup-wrapper h4.banner-sub-heading' => 'color: {{VALUE}}',
            ],

        ] );

        $this->end_controls_section(); //End Subtitle Style

		
	}
	


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

        $featureItems = $settings['featureItems'];

        extract($settings); 


		
		?>



    <!-- About Area -->
    <section class="about-us-area pd-top-100 pd-btm-100">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6 col-md-6 col-12 mg-top-30" data-aos="fade-right">
            <div class="video-popup-img">
              <img src="<?php echo esc_url( $settings['video_feature_image']['url'] ); ?>" class="about-img" alt="" />
              <div class="video-popup-img__icon">
                <a href="<?php echo esc_url( $settings['video_link']['url'] ) ?>" class="js-video-btn" data-video-id="FzcfZyEhOoI">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="100"
                    height="100"
                    viewBox="0 0 100 100"
                    fill="none"
                  >
                    <path
                      fill-rule="evenodd"
                      clip-rule="evenodd"
                      d="M50 95.0001C74.8528 95.0001 95.0001 74.8533 95.0001 50C95.0001 25.1472 74.8533 4.9999 50 4.9999C25.1472 4.9999 4.9999 25.1472 4.9999 50C4.9999 74.8528 25.1472 95.0001 50 95.0001ZM50 100C77.6139 100 100 77.6139 100 50C100 22.3856 77.6139 0 50 0C22.3856 0 0 22.3856 0 50C0 77.6139 22.3856 100 50 100Z"
                      fill="white"
                    />
                    <path
                      fill-rule="evenodd"
                      clip-rule="evenodd"
                      d="M62.9926 49.9998L39.9997 34.6714V65.3288L62.9926 49.9998ZM67.6379 47.0878C69.7163 48.4734 69.7163 51.5268 67.6379 52.9124L40.4408 71.0441C38.115 72.5949 34.9993 70.927 34.9993 68.1316V31.8686C34.9993 29.0732 38.115 27.4058 40.4408 28.9566L67.6379 47.0878Z"
                      fill="white"
                    />
                  </svg>
                </a>
              </div>
            </div>
          </div>
          <div
            class="col-lg-6 col-md-6 col-12 pd-left-60-lg mg-top-30"
            data-aos="fade-up"
          >
            <!-- Section Title -->
            <div class="section-title-area text-left">
              <h2 class="section-title m-0 saastain-gsap-anim2">
                <?php echo wp_kses_post( $settings['title'] ); ?>
              </h2>
              <p class="section-text m-0 mg-top-25">
                <?php echo wp_kses_post( $settings['description'] ); ?>
              </p>
            </div>
            <!-- List Features -->
            <ul class="list-features m-0 mg-top-25">


            <?php
                foreach ( $featureItems as $item ):
            ?>

              <li>
                <span class="flex-shrink-0">
                  <img src="<?php echo SAASTEN_IMG ."/price-check-icon.svg"; ?>" />
                </span>
                <span class="text-color"><?php echo esc_html( $item['feature-title'] ); ?></span>
              </li>

            <?php endforeach; ?> 


            </ul>
            <a
              href="<?php echo esc_url( $settings['btn_link']['url'] ) ?>"
              class="saastain-btn mg-top-50 primary-bg py-20 pr-lg saastain-btn__v4 border-radius-31"
              ><?php echo $settings['btn_text'] ?></a
            >
          </div>
        </div>
      </div>
    </section>
    <!-- End About Area -->

	

	<?php 


	}
				

}

