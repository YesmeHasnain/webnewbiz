<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * features Widget .
 *
 */
class Barab_Features extends Widget_Base {

	public function get_name() {
		return 'barabfeatures';
	}
	public function get_title() {
		return __( 'Features', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'arrow_section',
			[
				'label'     => __( 'Features', 'barab' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two' ] );

		barab_general_fields( $this, 'sec_subtitle', 'Section Subtitle', 'TEXTAREA2', 'Order Online – Fast Delivery', ['1'] );
		barab_general_fields( $this, 'sec_title', 'Section Title', 'TEXTAREA2', 'We have good foods', ['1'] );
		barab_general_fields( $this, 'desc', 'Descripiton', 'TEXTAREA', '', ['1'] );

		$repeater = new Repeater();

		barab_general_fields($repeater, 'title', 'Title', 'TEXTAREA2', 'Initial process');
		barab_general_fields($repeater, 'description', 'Description', 'TEXTAREA', '');

		$this->add_control(
			'feature_list',
			[
				'label' 		=> __( 'Features Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'Initial Consultation', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['1']
				]
			]
		);

		$repeater = new Repeater();

		barab_media_fields($repeater, 'icon', 'Choose Icon' );
		barab_general_fields($repeater, 'title', 'Title', 'TEXTAREA2', 'Initial process');
		barab_general_fields($repeater, 'description', 'Description', 'TEXTAREA', '');

		$this->add_control(
			'feature_list2',
			[
				'label' 		=> __( 'Features Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'Initial Consultation', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['2']
				]
			]
		);

		barab_general_fields($this, 'button_text', 'Button Text', 'TEXT', 'Order Now', ['1']);
		barab_url_fields($this, 'button_url', 'Button URL', ['1']);

		barab_media_fields($this, 'image', 'Choose Image', ['1']);
		barab_media_fields($this, 'shape', 'Choose Bg Shape', ['1']);
		barab_media_fields($this, 'shape2', 'Choose Shape', ['1']);

        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------
		barab_common_style_fields( $this, '1', 'Section Subtitle', '{{WRAPPER}} .sub-title', ['1'] );
		barab_common_style_fields( $this, '2', 'Section Title', '{{WRAPPER}} .sec-title', ['1'] );
		barab_common_style_fields( $this, '3', 'Description', '{{WRAPPER}} .desc', ['1'] );

		barab_common_style_fields( $this, '011', 'Title', '{{WRAPPER}} .box-title', ['1', '2'] );
		barab_common_style_fields( $this, '012', 'Description', '{{WRAPPER}} .box-text', [ '1', '2'] );
		//------Button Style-------
		barab_button_style_fields( $this, '10', 'Button Styling', '{{WRAPPER}} .th-btn', ['1'] );

	}

	protected function render() {

    $settings = $this->get_settings_for_display(); 

		if( $settings['layout_style'] == '1' ){
			echo '<div class="order-online-container-wrap">';
                echo '<div class="order-bg-thumb" data-mask-src="'.BARAB_ASSETS.'img/bg/food-delivery-bg.png">';
                    echo barab_img_tag( array(
						'url'   => esc_url( $settings['shape']['url'] ),
					)); 
                echo '</div>';
				echo barab_img_tag( array(
					'url'   => esc_url( $settings['shape2']['url'] ),
					'class' => 'order-shape-long'
				)); 
                echo '<div class="row gy-40 align-items-center">';
                    echo '<div class="col-xl-6">';
                        echo '<div class="order-online-content pe-xl-5 me-xl-4">';
                            echo '<div class="title-area mb-40">';
								if(!empty($settings['sec_subtitle'])){
									echo '<span class="sub-title before-none style-2 text-anime-style-1">'.esc_html($settings['sec_subtitle']).'</span>';
								}
                                if(!empty($settings['sec_title'])){
									echo '<h2 class="sec-title text-anime-style-2">'.wp_kses_post($settings['sec_title']).'</h2>';
								}
                                if(!empty($settings['desc'])){
									echo '<p class="box-text text-anime-style-3 desc">'.esc_html($settings['desc']).'</p>';
								}
                            echo '</div>';
                            echo '<div class="delivery-item-wrap pe-xl-5">';
								foreach( $settings['feature_list'] as $key => $data ){
									echo '<div class="item wow fadeinup" data-wow-delay=".2s">';
										if(!empty($data['title'])){
											echo '<h4 class="box-title">'.esc_html($data['title']).'</h4>';
										}
										if(!empty($data['description'])){
											echo '<p class="box-text">'.esc_html($data['description']).'</p>';
										}
									echo '</div>';
								}
								if(!empty($settings['button_text'])){
									echo '<div class="item order wow fadeinup" data-wow-delay=".8s">';
										echo '<a '.barab_link_attrs($settings['button_url']).' class="th-btn btn-mask">'.wp_kses_post( $settings['button_text'] ).'</a>';
									echo '</div>';
								}
                            echo '</div>';
                        echo '</div>';
                    echo '</div>';
                    echo '<div class="col-xl-6">';
							if($settings['image']['url'] ){
								 echo '<div class="order-right wow fadeinright">';
									echo barab_img_tag( array(
										'url'   => esc_url( $settings['image']['url'] ),
									)); 
								echo '</div>';
							}
                    echo '</div>';
                echo '</div>';
            echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
			echo '<div class="row gy-30 gx-30 justify-content-center">';
				foreach( $settings['feature_list2'] as $key => $data ){
					$delay  = number_format(0.2 + ($key * 0.2), 1); 
					echo '<div class="col-lg-4 col-md-6">';
						echo '<div class="feature-card wow fadeinleft" data-wow-delay="'.$delay.'s">';
							echo '<div class="box-icon">';
								echo '<div class="feat-mask" data-mask-src="'.BARAB_ASSETS.'img/bg/about-feat-bg.png"></div>';
								echo barab_img_tag( array(
									'url'   => esc_url( $data['icon']['url'] ),
								));
							echo '</div>';
							echo '<div class="content">';
								if(!empty($data['title'])){
									echo '<h3 class="box-title">'.esc_html($data['title']).'</h3>';
								}
								if(!empty($data['description'])){
									echo '<p class="box-text pe-xl-4">'.esc_html($data['description']).'</p>';
								}
							echo '</div>';
						echo '</div>';
					echo '</div>';
				}
			echo '</div>';
		}
		
			
	}
}