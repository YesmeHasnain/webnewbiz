<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Service Widget .
 *
 */
class barab_Service extends Widget_Base {

	public function get_name() {
		return 'barabservice'; 
	}
	public function get_title() {
		return __( 'Services', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		 $this->start_controls_section(
			'service_section',
			[
				'label'     => __( 'Services', 'barab' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two' ] );

		// barab_media_fields($this, 'shape', 'Choose Shape', ['3']);

		$repeater = new Repeater();

		barab_media_fields($repeater, 'choose_img', 'Choose Image');
		barab_media_fields($repeater, 'choose_icon', 'Choose Icon');
		barab_general_fields($repeater, 'title', 'Title', 'TEXTAREA2', 'Interior Design');
		barab_general_fields($repeater, 'description', 'Description', 'TEXTAREA', 'The design process begins with a thorough analysis'); 
		barab_url_fields($repeater, 'button_url', 'Button URL');

		$this->add_control(
			'service_list',
			[
				'label' 		=> __( 'Service Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'Interior Design', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['1']
				]
			]
		);

		$repeater = new Repeater();

		barab_media_fields($repeater, 'choose_img', 'Choose Image');
		barab_general_fields($repeater, 'title', 'Title', 'TEXTAREA2', 'AI Development');
		barab_general_fields($repeater, 'description', 'Description', 'TEXTAREA', 'Creating & optimizing models using proprietary or customer data. AI model tailored to specific business.'); 
		barab_general_fields($repeater, 'button_text', 'Button Text', 'TEXT', 'More Information');
		barab_url_fields($repeater, 'button_url', 'Button URL');

		$this->add_control(
			'service_list2',
			[
				'label' 		=> __( 'Service Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'AI Development', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['2']
				]
			]
		);

        $this->end_controls_section();

		// Column Responsive controls
		if ( function_exists( 'barab_add_responsive_columns_controls' ) ) {
			barab_add_responsive_columns_controls( $this, ['layout_style' => ['2'] ] );
		}

        //---------------------------------------
			//Style Section Start
		//---------------------------------------

		barab_common2_style_fields( $this, '02', 'Title', '{{WRAPPER}} .box-title a', ['1', '2', '3'] );
		barab_common_style_fields( $this, '04', 'Description', '{{WRAPPER}} .box-text', ['1', '2', '3']  );

		//------Button Style-------
        $this->start_controls_section(
			'button_styling',
			[
				'label'     => __( 'Button Styling', 'barab' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition'	=> [
					'layout_style' => ['2']
				]
			]
        );

		barab_typography_fields( $this, '0001', 'Typography', '{{WRAPPER}} .line-btn' );
		barab_color_fields( $this, '0002', 'Color', '--title-color', '{{WRAPPER}} .line-btn' );
		barab_color_fields( $this, '0003', 'Hover Color', '--theme-color', '{{WRAPPER}} .line-btn:hover' );                

		$this->end_controls_section();

	}
 
	protected function render() {

        $settings = $this->get_settings_for_display();

		if( $settings['layout_style'] == '1' ){
			echo '<div class="slider-wrap">';
                echo '<div class="swiper th-slider serviceSlide1 has-shadow" id="serviceSlide1" data-slider-options=\'{"paginationType": "progressbar","spaceBetween": 70,"mousewheel": {"enabled": true,"sensitivity": 4},"breakpoints": {"0":{"slidesPerView": 1},"576": {"slidesPerView": 1},"768": {"slidesPerView": 1},"1200": {"slidesPerView": 2}}}\'>';
                    echo '<div class="swiper-wrapper">';
						foreach( $settings['service_list'] as $key => $data ){
							echo '<div class="swiper-slide">';
								echo '<div class="service-card">';
									if($data['choose_img']['url'] ){
										echo '<div class="box-img global-img">';
											echo barab_img_tag( array(
												'url'   => esc_url( $data['choose_img']['url'] ),
											));
										echo '</div>';
									}
									echo '<div class="box-content">';
										if($data['choose_icon']['url'] ){
											echo '<div class="box-icon">';
												echo barab_img_tag( array(
													'url'   => esc_url( $data['choose_icon']['url'] ),
												));
											echo '</div>';
										}
										if(!empty($data['title'])){
											echo '<h3 class="box-title"><a href="'.esc_url( $data['button_url']['url'] ).'">'.esc_html($data['title']).'</a></h3>';
										}
										if(!empty($data['description'])){
											echo '<p class="box-text">'.esc_html($data['description']).'</p>';
										}
									echo '</div>';
								echo '</div>';
							echo '</div>';
						}
                    echo '</div>';
                    echo '<div class="slider-controller">';
                        echo '<div class="slider-pagination" data-slider-id="#serviceSlide1"></div>';
                    echo '</div>';
                    echo '<button data-slider-prev="#serviceSlide1" class="slider-arrow default style2 slider-prev"><i class="far fa-arrow-right"></i></button>';
                echo '</div>';
            echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
			// Get Column Responsive controls Class
			if ( function_exists( 'barab_get_responsive_columns_class' ) ) {
				$column_class = barab_get_responsive_columns_class( $settings );
			} else {
				$column_class = 'col-lg-6 col-xl-4';
			}

           echo '<div class="row gy-5 justify-content-center">';
				foreach( $settings['service_list2'] as $key => $data ){
					$delay = 0.1 + ($key * 0.2);
    				$delay = number_format($delay, 1);

					echo '<div class="' . esc_attr( $column_class ) . '">';
						echo '<div class="service-box wow fadeInUp" data-wow-delay="'.$delay.'s">';
							if($data['choose_img']['url'] ){
								echo '<div class="box-img global-img">';
									echo barab_img_tag( array(
										'url'   => esc_url( $data['choose_img']['url'] ),
									));
								echo '</div>';
							}
							echo '<div class="box-content">';
								if(!empty($data['title'])){
									echo '<h3 class="box-title"><a href="'.esc_url( $data['button_url']['url'] ).'">'.esc_html($data['title']).'</a></h3>';
								}
								if(!empty($data['description'])){
									echo '<p class="box-text">'.esc_html($data['description']).'</p>';
								}
								if(!empty($data['button_text'])){
									echo '<a '.barab_link_attrs($data['button_url']).' class="line-btn">'.esc_html( $data['button_text'] ).'</a>';
								}
							echo '</div>';
						echo '</div>';
					echo '</div>';
				}
            echo '</div>';

		}elseif( $settings['layout_style'] == '3' ){
 	

		}


	}

}