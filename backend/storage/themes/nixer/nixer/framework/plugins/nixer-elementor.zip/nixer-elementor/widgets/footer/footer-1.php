<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsFooterSection1 extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-footer-1';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Footer Section 1', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-footer';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-footer' ];
	}

	public function get_keywords() {
		return [ 'footer1', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_footer_section',
			[
				'label' => esc_html__( 'Footer Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'bg_color',
			[
				'label' 		=> esc_html__( 'Background Color (Default: #121212)', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::COLOR,
				'default'		=> '#121212',
			]
		);
		$this->add_control(
			'ft_logo',
			[
				'label'       	=> esc_html__( 'Footer Logo', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image logo', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'ft_copyright',
			[
				'label'       => __( 'Footer Copyright', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your text footer copyright', 'bdevs-elementor' ),
				'default'     => __( '©2025- All Rights Reserved', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$rp_social = new \Elementor\Repeater();
		$rp_social->add_control(
			'text_sc_item',
			[
				'label' 		=> esc_html__( 'Text Social Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Text Social' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_social->add_control(
			'link_sc_item',
			[
				'label' 		=> esc_html__( 'Link Social Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '#' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'tab_sc',
			[
				'label' 		=> esc_html__( 'List Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $rp_social->get_controls(),
				'default' 		=> [
					[
					],
				],
				'title_field' 	=> '{{{ text_sc_item }}}',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_wrapper_footer',
			[
				'label' => esc_html__( 'Wrapper Footer Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'switch_wrapper_footer',
			[
				'label'   		=> esc_html__( 'Switch Show/Hide Wrapper Footer', 'bdevs-elementor' ),
				'type'    		=> Controls_Manager::SWITCHER,
				'label_on' 		=> esc_html__( 'Show', 'bdevs-elementor' ),
				'label_off' 	=> esc_html__( 'Hide', 'bdevs-elementor' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);
		$this->add_control(
			'ft_img_wp',
			[
				'label'       	=> esc_html__( 'Footer Image Wrapper', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload footer image wrapper', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'ft_text_wp',
			[
				'label' 		=> esc_html__( 'Fotoer Text Wrapper', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( "Let's <br> connect!" , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_wp = new \Elementor\Repeater();
		$rp_wp->add_control(
			'rp_label_item',
			[
				'label' 		=> esc_html__( 'Wrapper Label Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Lable Item' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_wp->add_control(
			'rp_text_item',
			[
				'label' 		=> esc_html__( 'Wrapper Text Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Text Item' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_wp->add_control(
			'rp_link_item',
			[
				'label' 		=> esc_html__( 'Wrapper Link Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '#' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'tab_wp',
			[
				'label' 		=> esc_html__( 'List Column 2 Content', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $rp_wp->get_controls(),
				'default' 		=> [
					[
						
					],
				],
				'title_field' 	=> '{{{ rp_label_item }}}',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>

<?php if (!empty($settings['switch_wrapper_footer'])) { ?>
	<footer class="tp-footer-ptb pt-150" data-bg-color="<?php echo wp_kses_post($settings['bg_color']); ?>">
<?php } else { ?>
	<footer class="tp-footer-ptb pt-50" data-bg-color="<?php echo wp_kses_post($settings['bg_color']); ?>">
<?php } ?>
		<?php if (!empty($settings['switch_wrapper_footer'])): ?>
			<div class="container container-1760">
				<div class="row">
					<div class="col-lg-8">
						<div class="tp-footer-wrapper pb-150">
							<div class="tp-footer-text d-flex">
								<div class="tp-footer-text-thumb">
									<?php if (!empty($settings['ft_img_wp']['url'])): ?>
										<img src="<?php echo wp_kses_post($settings['ft_img_wp']['url']); ?>" alt="<?php echo wp_kses_post($settings['ft_img_wp']['alt']); ?>">
									<?php endif ?>
								</div>
								<div class="tp-footer-text-heading">
									<?php if (!empty($settings['ft_text_wp'])): ?>
										<h3 class="tp-footer-text-title footer-big-text">
											<?php echo wp_kses_post($settings['ft_text_wp']); ?>
										</h3>
									<?php endif ?>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-4">
						<div class="tp-footer-wrapper-right pb-150">
							<div class="tp-footer-info">
								<?php
								foreach ($settings['tab_wp'] as $itemwp) :
								?>
									<div class="tp-footer-info-item">
										<?php if (!empty($itemwp['rp_label_item'])): ?>
											<span><?php echo wp_kses_post($itemwp['rp_label_item']); ?></span>
										<?php endif ?>
										<?php if (!empty($itemwp['rp_link_item']) && !empty($itemwp['rp_text_item'])): ?>
											<a href="<?php echo wp_kses_post($itemwp['rp_link_item']); ?>">
												<?php echo wp_kses_post($itemwp['rp_text_item']); ?>
											</a>
										<?php endif ?>
									</div>
								<?php endforeach; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php endif ?>
		<div class="container-fluid">
			<div class="tp-footer-copyright">
				<div class="row">
					<div class="col-lg-3">
						<div class="tp-footer-copyright-logo">
							<?php if (!empty($settings['ft_logo']['url'])): ?>
								<a href="<?php echo esc_url(home_url('/')); ?>">
									<img data-width="90" src="<?php echo wp_kses_post($settings['ft_logo']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
								</a>
							<?php endif ?>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="tp-footer-copyright-social text-start text-lg-center">
							<?php
							foreach ($settings['tab_sc'] as $items) :
							?>
								<?php if (!empty($items['link_sc_item']) && !empty($items['text_sc_item'])): ?>
									<a href="<?php echo wp_kses_post($items['link_sc_item']); ?>">
										<?php echo wp_kses_post($items['text_sc_item']); ?>
									</a>
								<?php endif ?>
							<?php endforeach; ?>
						</div>
					</div>
					<div class="col-lg-3">
						<div class="tp-footer-copyright-text text-start text-lg-end">
							<?php if (!empty($settings['ft_copyright'])): ?>
								<p><?php echo wp_kses_post($settings['ft_copyright']); ?></p>
							<?php endif ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-bg-color]").each(function () {
			jQuery(this).css("background-color", jQuery(this).attr("data-bg-color"));
		});

		jQuery("[data-width], [data-height]").each(function () {
			const $this = jQuery(this);
			
			// Set the width if data-width is present
			if ($this.attr("data-width")) {
					$this.css("width", $this.attr("data-width"));
			}
	
			// Set the height if data-height is present
			if ($this.attr("data-height")) {
					$this.css("height", $this.attr("data-height"));
			}
		});

		if (jQuery('.footer-big-text').length > 0) {

			var cta = gsap.timeline({
				repeat: -1,
				delay: 0.5,
				scrollTrigger: {
					trigger: '.footer-big-text',
					start: 'bottom 100%-=50px'
				}
			});
			gsap.set('.footer-big-text', {
				opacity: 0
			});
			gsap.to('.footer-big-text', {
				opacity: 1,
				duration: 1,
				ease: 'power1.out',
				scrollTrigger: {
					trigger: '.footer-big-text',
					start: 'bottom 100%-=50px',
					once: true
				}
			});
		
			var mySplitText = new SplitText(".footer-big-text", { type: "words,chars" });
			var chars = mySplitText.chars;
			var endGradient = chroma.scale(['#FFF', '#FFF', '#FFF', '#FFF', '#FFF']);
			cta.to(chars, {
				duration: 0.5,
				scaleY: 0.6,
				ease: "power1.out",
				stagger: 0.04,
				transformOrigin: 'center bottom'
			});
			cta.to(chars, {
				yPercent: -20,
				ease: "elastic",
				stagger: 0.03,
				duration: 0.8
			}, 0.5);
			cta.to(chars, {
				scaleY: 1,
				ease: "elastic.out",
				stagger: 0.03,
				duration: 1.5
			}, 0.5);
			cta.to(chars, {
				color: (i, el, arr) => {
					return endGradient(i / arr.length).hex();
				},
				ease: "power1.out",
				stagger: 0.03,
				duration: 0.3
			}, 0.5);
			cta.to(chars, {
				yPercent: 0,
				ease: "back",
				stagger: 0.03,
				duration: 0.8
			}, 0.7);
			cta.to(chars, {
				color: '#fff',
				duration: 1.4,
				stagger: 0.05
			});
		}
	</script>
<?php } ?>

<?php
}

}