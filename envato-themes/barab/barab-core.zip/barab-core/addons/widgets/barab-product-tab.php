<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Product Tab Widget .
 *
 */
class Barab_Product_Tab extends Widget_Base {

	public function get_name() {
		return 'barabproducttab';
	}
	public function get_title() {
		return __( 'Product Tab', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'arrow_section',
			[
				'label'     => __( 'Product Tab', 'barab' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two', 'Style Three', 'Style Four' ] ); 

        barab_media_fields( $this, 'image1', 'Choose Image', ['1'] );
		barab_media_fields( $this, 'image2', 'Choose Image', ['1'] );

        $repeater = new Repeater();

        $repeater->add_control(
			'product_type',
			[
				'label'     => __( 'Menus Type', 'pizzer' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default'  	=> __( 'Healty Food', 'pizzer' )
			]
        );

        $repeater->add_control(
			'product_cats',
			[
				'label' 		=> __( 'Product Categories', 'pizzer' ),
                'type' 			=> Controls_Manager::SELECT2,
                'multiple' 		=> true,
                'label_block'   => true,
                'options' 		=> $this->product_cats_get(),
			]
        );
        
        $repeater->add_control(
			'product_count',
			[
				'label' 		=> __( 'Product Count', 'pizzer' ),
				'type' 			=> Controls_Manager::NUMBER,
				'min' 			=> 1,
				'max' 			=> 50,
				'step' 			=> 1,
				'default' 		=> 6,
			]
		);
        $this->add_control(
			'advance_products',
			[
				'label' 		=> __( 'Products', 'pizzer' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'product_type' 		=> __( 'title', 'pizzer' ),
					],
				],
				'title_field' 	=> '{{{ product_type }}}',
			]
		);

        // Get all registered image sizes
        $image_sizes = get_intermediate_image_sizes(); 

        $options = [];
        foreach ( $image_sizes as $size ) {
            $options[ $size ] = ucfirst( str_replace( '_', ' ', $size ) );
        }

        $this->add_control(
            'image_resolution',
            [
                'label'       => __( 'Image Resolution', 'barab' ),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'default'     => 'thumbnail',
                'options'     => $options,
            ]
        ); 

        barab_switcher_fields( $this, 'show_product_content', 'Show Product Content?', ['1', '2', '3'] );

        $this->end_controls_section();

        // Column Responsive controls
        if ( function_exists( 'barab_add_responsive_columns_controls' ) ) {
            barab_add_responsive_columns_controls( $this, ['layout_style' => ['2', '3', '4'] ] );
        }

        //---------------------------------------
			//Style Section Start
		//--------------------------------------- 
		barab_common2_style_fields( $this, '10', 'Product Title', '{{WRAPPER}} .box-title a', ['1', '2', '3'] );
		barab_common2_style_fields( $this, '12', 'Product Title', '{{WRAPPER}} .box-title3 a', ['4'] );
		barab_common_style_fields( $this, '11', 'Product Price', '{{WRAPPER}} .woocommerce-Price-amount.amount', ['1', '2', '3', '4'] );
        barab_common_style_fields( $this, '12', 'Product Content', '{{WRAPPER}} .box-text', ['1', '2', '3'] );

	}

    protected function product_cats_get() {
        $terms = get_terms( array( 'taxonomy' => 'product_cat' ) );
        $term_array = array();
        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
            foreach ( $terms as $term ) {
                $term_array[$term->slug] = $term->name;
            }
        }

        return $term_array;
    }

    protected function product_tags_get() {
        $terms = get_terms( array( 'taxonomy' => 'product_tag' ) );
        $term_array = array();
    
        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
            foreach ( $terms as $term ) {
                $term_array[$term->slug] = $term->name;
            }
        }
    
        return $term_array;
    }

	protected function render() {

    // ✅ WooCommerce check
    if ( ! class_exists( 'WooCommerce' ) ) {
        echo '<p>WooCommerce is not installed or activated.</p>';
        return;
    }

    $settings = $this->get_settings_for_display(); 


    // Get the dynamic image resolution setting
    $image_resolution = !empty($settings['image_resolution']) ? $settings['image_resolution'] : 'robor-shop-small-image';

		if( $settings['layout_style'] == '1' ){ 
            echo '<div class="row gy-4 justify-content-center">';
                if($settings['image1']['url'] ){
                    echo '<div class="col-lg-3">';
                        echo '<div class="menu-img-1-1 gsap-scroll-float-down2">';
                            echo barab_img_tag( array(
                                'url'   => esc_url( $settings['image1']['url'] ),
                            ));
                        echo '</div>';
                    echo '</div>';
                }

                echo '<div class="col-lg-6">'; 
                    echo '<div class="menu-1-content-wrap ps-xl-3 pe-xl-5">';
                        echo '<ul class="nav nav-tabs wow fadeinup" id="myTab" role="tablist">';
                            $i = 0;
                            foreach( $settings['advance_products'] as $data ) { 
                                $i++;
                                $active_class = ($i == 1) ? 'active' : '';
                                echo '<li class="nav-item" role="presentation">';
                                    echo '<button class="nav-link '.esc_attr($active_class).'" id="event-creating-tab'.esc_attr($i).'" data-bs-toggle="tab" data-bs-target="#event-creating'.esc_attr($i).'" type="button" role="tab" aria-controls="event-creating'.esc_attr($i).'" aria-selected="true">'.esc_html($data['product_type']).'</button>';
                                echo '</li>';
                            }
                        echo '</ul>';

                        echo '<div class="tab-content" id="myTabContent">';
                            $i = 0;
                            foreach( $settings['advance_products'] as $data ) { 
                            $i++;
                            $active_show_class = ($i == 1) ? 'active show' : '';

                                echo '<div class="tab-pane fade '.esc_attr($active_show_class).'" id="event-creating'.esc_attr($i).'" role="tabpanel" aria-labelledby="event-creating-tab'.esc_attr($i).'">';

                                    $args = array(
                                        "posts_per_page"    => -1,
                                        "post_type"         => "product",
                                    );
                                    if( ! empty( $data['product_cats'] ) ) {
                                        $args['tax_query'] = array(
                                            array(
                                                'taxonomy' => 'product_cat',
                                                'field'    => 'slug',
                                                'terms'    => $data['product_cats'],
                                            ),
                                        );
                                    }
                                    $prods = new WP_Query( $args );

                                    $counter = 0;
                                    while( $prods->have_posts() ) {
                                        $prods->the_post();
                                        $delay = number_format(0.2 + ($counter * 0.2), 1);
                                        
                                        echo '<div class="menu-item-1 wow fadeinup" data-wow-delay="' . $delay . 's">';
                                            echo '<div class="thumb" data-mask-src="'.BARAB_ASSETS.'img/bg/menu-1-msk-bg.jpg">';
                                                if ( has_post_thumbnail() ) {
                                                    the_post_thumbnail( $image_resolution );
                                                }
                                            echo '</div>';
                                            echo '<div class="content">';
                                                echo '<div class="left">';
                                                    echo '<h3 class="box-title"><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h3>';
                                                    if(!empty( $settings['show_product_content'])){
                                                        $short_description = barab_meta( 'extra_description' );
                                                        echo '<p class="box-text">';
                                                            woocommerce_new_short_description($short_description);
                                                        echo '</p>';
                                                    }
                                                echo '</div>';
                                                echo '<div class="right">';
                                                    // Product Pricing
                                                    echo woocommerce_template_loop_price();
                                                echo '</div>';
                                            echo '</div>';
                                        echo '</div>';

                                        $counter++;  
                                        if ($counter == $data['product_count']){
                                            break;   
                                        }
                                    }wp_reset_postdata();
                                echo '</div>';
                            }
                        echo '</div>';
                    echo '</div>';
                echo '</div>';

                if($settings['image2']['url'] ){
                    echo '<div class="col-lg-3">';
                        echo '<div class="menu-img-1-2 gsap-scroll-float-up">';
                            echo barab_img_tag( array(
                                'url'   => esc_url( $settings['image2']['url'] ),
                            ));
                        echo '</div>';
                    echo '</div>';
                }
            echo '</div>';

		}elseif( $settings['layout_style'] == '2' || $settings['layout_style'] == '3' ){
            // Get Column Responsive controls Class
            if ( function_exists( 'barab_get_responsive_columns_class' ) ) {
                $column_class = barab_get_responsive_columns_class( $settings );
            } else {
                $column_class = 'col-xl-3 col-lg-6 col-md-6';
            }

            echo '<div class="row gy-30 justify-content-center">';
                echo '<div class="menu-1-content-wrap style-2 pt-0 border-0 ps-xl-3 pe-xl-5"> ';
                    echo '<div class="row">';
                        echo '<div class="col-12">';
                            echo '<div class="title-area text-center mb-2">';
                                echo '<ul class="nav nav-tabs mb-50 wow fadeinup" id="myTab" role="tablist">';
                                    $i = 0;
                                    foreach( $settings['advance_products'] as $data ) { 
                                        $i++;
                                        $active_class = ($i == 1) ? 'active' : '';
                                        echo '<li class="nav-item" role="presentation">';
                                            echo '<button class="nav-link th-btn btn-mask '.esc_attr($active_class).'" id="burger-tab'.esc_attr($i).'" data-bs-toggle="tab" data-bs-target="#burger'.esc_attr($i).'" type="button" role="tab" aria-controls="burger'.esc_attr($i).'" aria-selected="true">'.esc_html($data['product_type']).'</button>';
                                        echo '</li>';
                                    }
                                echo '</ul>';
                            echo '</div>';
                        echo '</div>';
                    echo '</div>';

                    echo '<div class="tab-content" id="myTabContent">';
                        $i = 0;
                        foreach( $settings['advance_products'] as $data ) { 
                            $i++;
                            $active_show_class = ($i == 1) ? 'active show' : '';

                            echo '<div class="tab-pane fade '.esc_attr($active_show_class).'" id="burger'.esc_attr($i).'" role="tabpanel" aria-labelledby="burger-tab'.esc_attr($i).'">';
                                echo '<div class="row gy-4">';
                                    $args = array(
                                        "posts_per_page"    => -1,
                                        "post_type"         => "product",
                                    );
                                    if( ! empty( $data['product_cats'] ) ) {
                                        $args['tax_query'] = array(
                                            array(
                                                'taxonomy' => 'product_cat',
                                                'field'    => 'slug',
                                                'terms'    => $data['product_cats'],
                                            ),
                                        );
                                    }
                                    $prods = new WP_Query( $args );

                                    $counter = 0;
                                    while( $prods->have_posts() ) {
                                        $prods->the_post();

                                        $delay = number_format(0.2 + ($counter * 0.2), 1);

                                        echo '<div class="' . esc_attr( $column_class ) . '">';
                                            if( $settings['layout_style'] == '2' ){ 
                                                echo '<div class="food-card-1 style-2 wow fadeinup" data-wow-delay="' . $delay . 's">';
                                                    echo '<div class="thumb">';
                                                        echo '<div class="food-mask" data-mask-src="'.BARAB_ASSETS.'img/bg/menu-1-msk-bg.png"></div>';
                                                        if ( has_post_thumbnail() ) {
                                                            the_post_thumbnail( $image_resolution );
                                                        }
                                                        echo '<div class="actions">';
                                                            // Wishlist Button
                                                            if ( class_exists( 'WPCleverWoosw' ) ) { 
                                                                echo do_shortcode( '[woosw]' );
                                                            }
                                                            // Cart Button
                                                            woocommerce_template_loop_add_to_cart();
                                                            // Quick View Button
                                                            if ( class_exists( 'WPCleverWoosq' ) ) {
                                                                echo do_shortcode( '[woosq]' );
                                                            }
                                                        echo '</div>';
                                                    echo '</div>';
                                                    echo '<div class="content">';
                                                        // Product Pricing
                                                        echo woocommerce_template_loop_price();

                                                        echo '<h4 class="box-title"><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h4>';
                                                        if(!empty( $settings['show_product_content'])){
                                                            $short_description = barab_meta( 'extra_description' );
                                                            echo '<p class="box-text">';
                                                                woocommerce_new_short_description($short_description);
                                                            echo '</p>';
                                                        }
                                                    echo '</div>';
                                                echo '</div>';
                                            }else{
                                                  echo '<div class="food-card-1 style-2 style-3" data-mask-src="'.BARAB_ASSETS.'img/bg/menu-list-mask-bg.png">';
                                                    echo '<div class="thumb">';
                                                        echo '<div class="food-mask" data-mask-src="'.BARAB_ASSETS.'img/bg/menu-1-msk-bg.png"></div>';
                                                        if ( has_post_thumbnail() ) {
                                                            the_post_thumbnail( $image_resolution );
                                                        }
                                                        echo '<div class="actions">';
                                                            // Wishlist Button
                                                            if ( class_exists( 'WPCleverWoosw' ) ) { 
                                                                echo do_shortcode( '[woosw]' );
                                                            }
                                                            // Cart Button
                                                            woocommerce_template_loop_add_to_cart();
                                                            // Quick View Button
                                                            if ( class_exists( 'WPCleverWoosq' ) ) {
                                                                echo do_shortcode( '[woosq]' );
                                                            }
                                                        echo '</div>';
                                                    echo '</div>';
                                                    echo '<div class="content">';
                                                        echo '<h4 class="box-title"><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h4>';
                                                        if(!empty( $settings['show_product_content'])){
                                                            $short_description = barab_meta( 'extra_description' );
                                                            echo '<p class="box-text">';
                                                                woocommerce_new_short_description($short_description);
                                                            echo '</p>';
                                                        }
                                                        // Product Pricing
                                                        echo woocommerce_template_loop_price();
                                                    echo '</div>';
                                                echo '</div>';
                                            }
                                        echo '</div>';

                                        $counter++;  
                                        if ($counter == $data['product_count']){
                                            break;   
                                        }
                                    } wp_reset_postdata();
                                echo '</div>';
                            echo '</div>';
                        }
                    echo '</div>';
                echo '</div>';
            echo '</div>';

		}elseif( $settings['layout_style'] == '4' ){
            // Get Column Responsive controls Class
            if ( function_exists( 'barab_get_responsive_columns_class' ) ) {
                $column_class = barab_get_responsive_columns_class( $settings );
            } else {
                $column_class = 'col-xxl-4 col-xl-4 col-lg-6';
            }

            echo '<div class="row justify-content-center align-items-center mb-0">';
                echo '<div class="col-lg-7">';
                    echo '<ul class="nav nav-tabs menu-5-tab wow fadeinup" id="myTab" role="tablist">';
                        $i = 0;
                        foreach( $settings['advance_products'] as $data ) { 
                            $i++;
                            $active_class = ($i == 1) ? 'active' : '';
                            echo '<li class="nav-item" role="presentation">';
                                echo '<button class="nav-link '.esc_attr($active_class).'" id="burger-tab'.esc_attr($i).'" data-bs-toggle="tab" data-bs-target="#burger'.esc_attr($i).'" type="button" role="tab" aria-controls="burger'.esc_attr($i).'" aria-selected="true">'.esc_html($data['product_type']).'</button>';
                            echo '</li>';
                        }
                    echo '</ul>';
                echo '</div>';
            echo '</div>';

             echo '<div class="tab-content" id="myTabContent">';
                $i = 0;
                foreach( $settings['advance_products'] as $data ) { 
                    $i++;
                    $active_show_class = ($i == 1) ? 'active show' : '';

                    echo '<div class="tab-pane fade '.esc_attr($active_show_class).'" id="burger'.esc_attr($i).'" role="tabpanel" aria-labelledby="burger-tab'.esc_attr($i).'">';
                        echo '<div class="row gy-4">';
                            $args = array(
                                "posts_per_page"    => -1,
                                "post_type"         => "product",
                            );
                            if( ! empty( $data['product_cats'] ) ) {
                                $args['tax_query'] = array(
                                    array(
                                        'taxonomy' => 'product_cat',
                                        'field'    => 'slug',
                                        'terms'    => $data['product_cats'],
                                    ),
                                );
                            }
                            $prods = new WP_Query( $args );

                            $counter = 0;
                            while( $prods->have_posts() ) {
                                $prods->the_post();

                                // get product object
                                global $product;
                                $product = wc_get_product( get_the_ID() );

                                echo '<div class="' . esc_attr( $column_class ) . '">';
                                    echo '<div class="food-card2 style-2">';
                                        echo '<div class="food-img2">';
                                            if ( has_post_thumbnail() ) {
                                                the_post_thumbnail( $image_resolution );
                                            }
                                            // Wishlist Button
                                            if ( class_exists( 'WPCleverWoosw' ) ) { 
                                                echo do_shortcode( '[woosw]' );
                                            }
                                        echo '</div>';
                                        echo '<div class="food-card2-content">';
                                            echo '<h4 class="box-title3"><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h4>';
                                            echo '<div class="reating">';
                                                echo '<div class="woocommerce-product-rating product-rating">';
                                                    echo woocommerce_template_loop_rating();
                                                echo '</div>';
                                            echo '</div>';
                                            // Product Pricing
                                            echo '<p>';
                                                echo woocommerce_template_loop_price();
                                            echo '</p>';
                                            // Cart Button
                                            // ✅ Dynamic Add to Cart Button
                                            echo sprintf(
                                                '<a href="%s" data-quantity="1" class="th-btn %s" %s>%s</a>',
                                                esc_url( $product->add_to_cart_url() ),
                                                esc_attr( implode( ' ', array_filter( (array) $product->get_type(), 'esc_attr' ) ) ),
                                                wc_implode_html_attributes( array(
                                                    'data-product_id'  => $product->get_id(),
                                                    'data-product_sku' => $product->get_sku(),
                                                    'aria-label'       => $product->add_to_cart_description(),
                                                    'rel'              => 'nofollow'
                                                ) ),
                                                esc_html( $product->add_to_cart_text() )
                                            );
                                        echo '</div>';
                                    echo '</div>';
                                echo '</div>';

                                $counter++;  
                                if ($counter == $data['product_count']){
                                    break;   
                                }
                            } wp_reset_postdata();
                        echo '</div>';
                    echo '</div>';
                }
            echo '</div>';

        }
		
			
	}
}