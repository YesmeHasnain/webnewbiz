<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/*
 * Post Share
 */

require_once ('post-share.php');

/*
 * Hide Meta Box On Blog & WooCommerce page
 */

if ( ! function_exists( 'xcency_core_hide_metabox' ) ) {
	function xcency_core_hide_metabox() {

		global $post, $post_type;

		if( class_exists( 'WooCommerce' ) && is_object( $post ) && $post_type === 'page' ) {
			$exclude   = array();
			$exclude[] = get_option( 'woocommerce_shop_page_id' );
			$exclude[] = get_option( 'woocommerce_cart_page_id' );
			$exclude[] = get_option( 'woocommerce_checkout_page_id' );
			$exclude[] = get_option( 'woocommerce_myaccount_page_id' );
			$exclude[] = get_option( 'page_for_posts' );
			$exclude[] = get_option( 'wishlist_page_id' );
			if( in_array( $post->ID, $exclude ) ) {
				echo '<style type="text/css">';
				echo '#xcency_common_meta{ display: none !important; }';
				echo '</style>';
			}
		}else{
			if(is_object( $post ) && $post_type === 'page'){
				$exclude   = array();
				$exclude[] = get_option( 'page_for_posts' );
				if( in_array( $post->ID, $exclude ) ) {
					echo '<style type="text/css">';
					echo '#xcency_common_meta{ display: none !important; }';
					echo '</style>';
				}
			}
		}

		echo '<style type="text/css">';
		echo '
		.elementor-editor-active .edit-post-visual-editor .block-editor-writing-flow__click-redirect{min-height:5vh}
		';
		echo '</style>';

	}

	add_action( 'admin_head', 'xcency_core_hide_metabox' );
}


// Team Member List
if(! function_exists('xcency_core_team_member_list')){
	function xcency_core_team_member_list() {
		$team_list = array();
		$team_query = new WP_Query(array(
			'post_type' =>  array('xcency_team'),
			'posts_per_page'    =>  -1,
		));

		$team_list[''] = esc_html__('None', 'xcency-core');
		while ($team_query->have_posts()) :
			$team_query->the_post();
			$team_list[get_the_id()]  = get_the_title();
		endwhile;
		wp_reset_postdata();
		return $team_list;
	}
}

// Change Team Title Placeholder
function xcency_core_change_team_title_placeholder( $title ){
	$screen = get_current_screen();

	if  ( 'xcency_team' == $screen->post_type ) {
		$title = __('Member Name', 'xcency-core');
	}

	return $title;
}

add_filter( 'enter_title_here', 'xcency_core_change_team_title_placeholder' );

//Post Category
function xcency_core_post_categories() {
	$terms = get_terms( array(
		'taxonomy'   => 'category',
		'hide_empty' => true,
	) );

	if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
		foreach ( $terms as $term ) {
			$options[ $term->slug ] = $term->name;
		}
	}

	return $options;
}

//Project Category
function xcency_portfolio_categories(){
	$terms = get_terms( array(
		'taxonomy' => 'xcency_portfolio_cat',
		'hide_empty' => true,
	));

	if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
		foreach ( $terms as $term ) {
			$options[ $term->slug ] = $term->name;
		}
	}

	if(!empty($options)){
		$project_cat =  $options;
	}else{
		$project_cat =  '';
	}
	return $project_cat;
}

//Post Order By
function xcency_core_post_orderby_options() {
	$orderby = array(
		'ID'            => __( 'Post ID', 'xcency-core' ),
		'author'        => __( 'Post Author', 'xcency-core' ),
		'title'         => __( 'Title', 'xcency-core' ),
		'date'          => __( 'Date', 'xcency-core' ),
		'modified'      => __( 'Last Modified Date', 'xcency-core' ),
		'parent'        => __( 'Parent Id', 'xcency-core' ),
		'rand'          => __( 'Random', 'xcency-core' ),
		'comment_count' => __( 'Comment Count', 'xcency-core' ),
		'menu_order'    => __( 'Menu Order', 'xcency-core' )
	);

	return $orderby;
}


/* Get Menu List*/

if (!function_exists('xcency_core_get_custom_menu')) {
	/**
	 * Retrieves all registered navigation menu.
	 */
	function xcency_core_get_custom_menu()
	{
		$nav_menus = [];
		$terms = get_terms('nav_menu');
		foreach ($terms as $term) {
			$nav_menus[$term->name] = $term->name;
		}

		return $nav_menus;
	}
}

// Allow SVG
add_filter( 'wp_check_filetype_and_ext', function($data, $file, $filename, $mimes) {

	global $wp_version;
	if ( $wp_version !== '4.7.1' ) {
		return $data;
	}

	$filetype = wp_check_filetype( $filename, $mimes );

	return [
		'ext'             => $filetype['ext'],
		'type'            => $filetype['type'],
		'proper_filename' => $data['proper_filename']
	];

}, 10, 4 );

add_filter( 'doing_it_wrong_trigger_error', function( $status, $function_name ) {
	if ( '_load_textdomain_just_in_time' === $function_name ) {
		return false;
	}
	return $status;
}, 10, 2 );

function xcency_core_mime_types( $mimes ){
	$mimes['svg'] = 'image/svg+xml';
	return $mimes;
}
add_filter( 'upload_mimes', 'xcency_core_mime_types' );

function xcency_get_excerpt( $post_id, $excerpt_length ) {
	$the_post = get_post( $post_id ); //Gets post ID

	$the_excerpt = null;
	if ( $the_post ) {
		$the_excerpt = $the_post->post_excerpt ? $the_post->post_excerpt : $the_post->post_content;
	}

	$the_excerpt = strip_tags( strip_shortcodes( $the_excerpt ) ); //Strips tags and images
	$words       = explode( ' ', $the_excerpt, $excerpt_length + 1 );

	if ( count( $words ) > $excerpt_length ) :
		array_pop( $words );
		array_push( $words, '…' );
		$the_excerpt = implode( ' ', $words );
	endif;

	return $the_excerpt;
}

function xcency_core_class_sorter( $string ) {
	$class_sorter = strtolower( $string );
	$class_sorter = str_replace( ' ', '-', $class_sorter );
	$class_sorter = str_replace( '&', 'and', $class_sorter );
	$class_sorter = str_replace( 'amp;', '', $class_sorter );
	$class_sorter = str_replace( '/', 'slash', $class_sorter );

	$class_sorter = str_replace( ',-', ' ', $class_sorter );
	$class_sorter = str_replace( '.', '-', $class_sorter );
	$class_sorter = str_replace( ',', ' ', $class_sorter );

	return $class_sorter;
}
