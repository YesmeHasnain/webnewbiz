<div class="swiper-slide">
    <div  class="single--item">
        <div class="content--box">
            <div class="banner-image">
                    <img class="banner-img" src="<?php echo esc_url($image); ?>" alt="Product Image">
                    
            </div>
            <div class="description">
                <?php if(!empty($title)):?>
                    <h2 class="slider-title"><?php echo wp_kses_post($title); ?></h2>
                <?php endif;?>
                <?php if(!empty($sub_title)):?>
                    <p class="slider-subtitle"><?php echo wp_kses_post($sub_title); ?></p>
                <?php endif;?>
               
            </div>            
        </div>
        <div class="review-body">
            <div class="desc">
                <?php echo wp_kses_post($description); ?>
            </div>
            <div class="review-end">          
            <img class="banner-img2" src="<?php echo esc_url($image2); ?>" alt="Product Image">
            <?php if(!empty($sub_img_link)): ?>
                            <img class="quote" src="<?php echo $sub_img_link;?>" alt="quote">
                <?php endif; ?>   
            </div>  
                
        </div>
    </div>
</div> 