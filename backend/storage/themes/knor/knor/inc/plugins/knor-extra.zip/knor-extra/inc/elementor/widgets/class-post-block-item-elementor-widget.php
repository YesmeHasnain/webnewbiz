<?php

/**
 * Elementor Widget
 * @package Knor
 * @since 1.0.0
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class knor_post_block_item extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'posts-block-item';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Post Block Item', 'knor-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'knor_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {
		$this->layout_options();		
		$this->post_query_options();	
		$this->meta_options();	
		$this->design_options();
	}
	
	/**
    * Layout Options
    */
    private function layout_options() {
	
	
		$this->start_controls_section(
            'layout_option',
            [
                'label' => __( 'Layout Options', 'knor-extra' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
		

		$this->add_responsive_control(
			'grid_img_height',
			[
				'label' =>esc_html__( 'Set Post Image Height', 'knor-extra' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 515,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 400,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 400,
					'unit' => 'px',
				],
				
				'default'  => [
					'unit' => 'px',
					'size' => 515,
				],
				
				'selectors' => [
					'{{WRAPPER}} .blog-post-tab-wrap.post-block-item.post-block-item-one .news-post-grid-thumbnail a img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);		
		
		
		$this->end_controls_section();
	
	}
	
	/**
    * Post Query Options
    */
    private function post_query_options() {
	
	
		$this->start_controls_section(
            'post_query_option',
            [
                'label' => __( 'Post Options', 'knor-extra' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
		
		
		// Post Sort
		
        $this->add_control(
            'post_sorting',
            [
                'type'    => Controls_Manager::SELECT2,
                'label' => esc_html__('Post Sorting', 'knor-extra'),
                'default' => 'date',
                'options' => [
					'date' => esc_html__('Recent Post', 'knor-extra'),
                    'rand' => esc_html__('Random Post', 'knor-extra'),
					'title'         => __( 'Title Sorting Post', 'knor-extra' ),
                    'modified' => esc_html__('Last Modified Post', 'knor-extra'),
                    'comment_count' => esc_html__('Most Commented Post', 'knor-extra'),
					
                ],
            ]
        );		
		
		// Post Order
		
        $this->add_control(
            'post_ordering',
            [
                'type'    => Controls_Manager::SELECT2,
                'label' => esc_html__('Post Ordering', 'knor-extra'),
                'default' => 'DESC',
                'options' => [
					'DESC' => esc_html__('Desecending', 'knor-extra'),
                    'ASC' => esc_html__('Ascending', 'knor-extra'),
                ],
            ]
        );
		
		
		// Post Categories
		
		$this->add_control(
            'post_categories',
            [
                'type'      => Controls_Manager::SELECT2,
				'label' =>esc_html__('Select Categories', 'knor-extra'),
                'options'   => $this->posts_cat_list(),
                'label_block' => true,
                'multiple'  => true,
            ]
        );
	
		
		
		// Post Items.
		
        $this->add_control(
            'post_number',
			[
				'label'         => esc_html__( 'Number Of Posts', 'knor-extra' ),
				'type'          => Controls_Manager::NUMBER,
				'default'       => '2',
			]
        );
		
		$this->add_control(
            'enable_offset_post',
            [
               'label' => esc_html__('Enable Skip Post', 'knor-extra'),
               'type' => Controls_Manager::SWITCHER,
               'label_on' => esc_html__('Yes', 'knor-extra'),
               'label_off' => esc_html__('No', 'knor-extra'),
               'default' => 'no',
               
            ]
        );
      
        $this->add_control(
			'post_offset_count',
			  [
			   'label'         => esc_html__( 'Skip Post Count', 'knor-extra' ),
			   'type'          => Controls_Manager::NUMBER,
			   'default'       => '1',
			   'condition' => [ 'enable_offset_post' => 'yes' ]

			  ]
        );
		
		
		$this->end_controls_section();
	
	}	
	
	/**
    * Meta Options
    */
    private function meta_options() {
	
	
		$this->start_controls_section(
            'meta_option',
            [
                'label' => __( 'Meta Options', 'knor-extra' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
		
		$this->add_control(
            'display_excerpt',
            [
                'label' => esc_html__('Display Post Excerpt', 'ennlil-extra'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'ennlil-extra'),
                'label_off' => esc_html__('No', 'ennlil-extra'),
                'default' => 'yes',
            ]
        );

		$this->add_control(
         	'display_author',
         	[
				 'label' => esc_html__('Display Author', 'knor-extra'),
				 'type' => Controls_Manager::SWITCHER,
				 'label_on' => esc_html__('Yes', 'knor-extra'),
				 'label_off' => esc_html__('No', 'knor-extra'),
				 'default' => 'yes',
         	]
     	);

     	$this->add_control(
            'display_cat',
            [
                'label' => esc_html__('Display Category Name', 'knor-extra'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'knor-extra'),
                'label_off' => esc_html__('No', 'knor-extra'),
                'default' => 'yes',
            ]
        );
		
		$this->add_control(
            'display_date',
            [
                'label' => esc_html__('Display Date', 'knor-extra'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'knor-extra'),
                'label_off' => esc_html__('No', 'knor-extra'),
                'default' => 'yes',
            ]
        );
		
		
		$this->add_control(
            'display_read_time',
            [
                'label' => esc_html__('Display Post Read Time', 'knor-extra'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'knor-extra'),
                'label_off' => esc_html__('No', 'knor-extra'),
                'default' => 'no',
            ]
        );

 
		
	
		$this->end_controls_section();
	
	}	
	
	/**
    * Design Options
    */
    private function design_options() {
	
	
		$this->start_controls_section(
            'design_option',
            [
                'label' => __( 'Slider Typography', 'knor-extra' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
		

		$this->add_group_control(
           Group_Control_Typography::get_type(),
           [
              'name' => 'block_one_title_typography',
              'label' => esc_html__( 'Post Title Typography', 'knor-extra' ),
              'selector' => '{{WRAPPER}} .blog-post-tab-wrap.post-block-item.post-block-item-one .grid-content-bottom h3.post-title',
           ]
        );		
		
		
		$this->add_group_control(
           Group_Control_Typography::get_type(),
           [
              'name' => 'block_one_excerpt_typography',
              'label' => esc_html__( 'Post Excerpt Typography', 'knor-extra' ),
              'selector' => '{{WRAPPER}}.blog-post-tab-wrap.post-block-item.post-block-item-one .grid-content-bottom .post-excerpt-box p',
           ]
        );	
		
		$this->add_control('block_one_title_color', [
            'label' => esc_html__('Large Post Title Color', 'senatory-master'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .blog-post-tab-wrap.post-block-item.post-block-item-one .grid-content-bottom h3.post-title a" => "color: {{VALUE}}"
            ]
        ]);
		
		
		$this->add_group_control(
           Group_Control_Typography::get_type(),
           [
              'name' => 'meta_typography',
              'label' => esc_html__( 'Post Meta Typography', 'knor-extra' ),
              'selector' => '{{WRAPPER}} .theme_post_grid__Slider .blog-post-grid-wrapper .post-meta-items div',
           ]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
			   'name' => 'author_box_typography',
			   'label' => esc_html__( 'Author Box Typography', 'knor-extra' ),
			   'selector' => '{{WRAPPER}} .theme_post_grid__Slider .blog-post-grid-wrapper .post_grid_author_img',
			]
		 );


		
		$this->add_control(
          'title_length',
          [
            'label'         => esc_html__( 'Post Title Length', 'knor-extra' ),
            'type'          => Controls_Manager::NUMBER,
            'default'       => '10',
          ]
        );

        $this->add_control(
          'content_length',
          [
            'label'         => esc_html__( 'Post Excerpt Length', 'ennlil-extra' ),
            'type'          => Controls_Manager::NUMBER,
            'default'       => '20',
          ]
        );
		

		
		$this->end_controls_section();
	
	}	
		


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

		$title_limit = $settings['title_length'];
		$content_limit = $settings['content_length'];
		$post_count = $settings['post_number'];
		$post_order  = $settings['post_ordering'];
		$post_sortby = $settings['post_sorting']; 
		$display_blog_excerpt = $settings['display_excerpt'];
		$display_blog_cat = $settings['display_cat'];
		$display_blog_author = $settings['display_author'];
		$display_blog_date = $settings['display_date'];

		
		$display_read_time = $settings['display_read_time'];

		
		$args = [
            'post_type' => 'post',
            'post_status' => 'publish',
			'order' => $settings['post_ordering'],
			'posts_per_page' => $settings['post_number'],
			'ignore_sticky_posts' => 1,
        ];
		
		// Category
        if ( ! empty( $settings['post_categories'] ) ) {
            $args['category_name'] = implode(',', $settings['post_categories']);
        }
		
		// Post Sorting
        if ( ! empty( $settings['post_sorting'] ) ) {
            $args['orderby'] = $settings['post_sorting'];
        }	
		
		// Post Offset		
		if($settings['enable_offset_post'] == 'yes') {
			$args['offset'] = $settings['post_offset_count'];
		}

		// Query
        $query = new \WP_Query( $args ); ?>
		
		

		
		<?php if ( $query->have_posts() ) : ?>

			<?php while ($query->have_posts()) : $query->the_post(); ?>

				<div class="blog-post-tab-wrap post-block-item post-block-item-one">
					
					<div class="news-post-grid-thumbnail">
						<a href="<?php the_permalink(); ?>" class="news-post-grid-thumbnail-wrap">
							<img src="<?php echo esc_attr(esc_url(get_the_post_thumbnail_url(null, 'full'))); ?>" alt="<?php the_title_attribute(); ?>">
						</a>
					</div>
					
					<div class="news-post-grid-content grid-content-bottom">
					
						<?php if($display_blog_cat=='yes'): ?>	
						<div class="slider-category-box tab-cat-box">
						<?php require KNOR_THEME_DIR . '/template-parts/cat-alt-template.php'; ?>
						</div>
						<?php endif; ?>		

						<h3 class="post-title">
							<a href="<?php the_permalink(); ?>"><?php echo esc_html( wp_trim_words(get_the_title(), $title_limit,'') ); ?></a>
						</h3>
						
						<?php if($display_blog_excerpt =='yes'): ?> 
						<div class="post-excerpt-box">
							<p><?php echo esc_html( wp_trim_words(get_the_excerpt(), $content_limit ,'') );?></p>
						</div>
						<?php endif; ?>	
						
						<div class="slider-post-meta-items tab-large-col-meta">
							<div class="slider-meta-left">

								<div class="slider-meta-left-author">
									<?php echo get_avatar( get_the_author_meta( 'ID' ), 48 ); ?>
								</div>
								
								<div class="slider-meta-left-content">

									<h4 class="post-author-name">
										<?php echo get_the_author_link(); ?>
									</h4>

									<ul class="slider-bottom-meta-list">

										<?php if($display_blog_date=='yes'): ?>

										<li class="slider-meta-date"><?php echo esc_html( get_the_date( 'F j, Y' ) ); ?></li>

										<?php endif; ?>	

										<?php if($display_read_time=='yes'): ?>

										<li class="slider-meta-time"><?php echo knor_reading_time(); ?></li>

										<?php endif; ?>	

									</ul>
								</div>
							</div>
							
							<!--
							<div class="slider-meta-right">
								<div class="post-fav-box">
									3k
								</div>
								<div class="post-comment-box">
									63
								</div>
							</div>
							-->
							
						</div>
					</div>
					
					
				<div class="post-loved-count">
					50
				</div>

				</div>


			<?php endwhile; ?>
		
		<?php wp_reset_postdata(); ?>
		
		<?php endif; ?>
		

	
	<?php 
}
		
   
   	public function posts_cat_list() {
		
		$terms = get_terms( array(
			'taxonomy'    => 'category',
			'hide_empty'  => true
		) );

		$cat_list = [];
		foreach($terms as $post) {
		$cat_list[$post->slug]  = [$post->name];
		}
		return $cat_list;
	  
	}		
	
}


Plugin::instance()->widgets_manager->register_widget_type( new knor_post_block_item() );