<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Utils;
/**
 *
 * Blog Post Widget .
 *
 */
class Barab_Blog extends Widget_Base {

	public function get_name() {
		return 'barabblog';
	}
	public function get_title() {
		return __( 'Blog Post', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'blog_post_section',
			[
				'label' => __( 'Blog Post', 'barab' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

        barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two' ] );

        $this->add_control(
			'blog_post_count',
			[
				'label' 	=> __( 'No of Post to show', 'barab' ),
                'type' 		=> Controls_Manager::NUMBER,
                'min'       => 1,
                'max'       => count( get_posts( array('post_type' => 'post', 'post_status' => 'publish', 'fields' => 'ids', 'posts_per_page' => '-1') ) ),
                'default'  	=> __( '3', 'barab' )
			]
        );

        barab_general_fields( $this, 'title_count', 'Title Length', 'TEXT2', '6');
        barab_general_fields( $this, 'excerpt_count', 'Excerpt Length', 'TEXT2', '14' );
        // barab_general_fields( $this, 'title_count2', 'Big Title Length', 'TEXT2', '6', ['3']);
        // barab_general_fields( $this, 'excerpt_count2', 'Big Excerpt Length', 'TEXT2', '14', ['3'] );

        $this->add_control(
			'blog_post_order',
			[
				'label' 	=> __( 'Order', 'barab' ),
                'type' 		=> Controls_Manager::SELECT,
                'options'   => [
                    'ASC'   	=> __('ASC','barab'),
                    'DESC'   	=> __('DESC','barab'),
                ],
                'default'  	=> 'DESC'
			]
        );
        $this->add_control(
			'blog_post_order_by',
			[
				'label' 	=> __( 'Order By', 'barab' ),
                'type' 		=> Controls_Manager::SELECT,
                'options'   => [
                    'ID'    	=> __( 'ID', 'barab' ),
                    'author'    => __( 'Author', 'barab' ),
                    'title'    	=> __( 'Title', 'barab' ),
                    'date'    	=> __( 'Date', 'barab' ),
                    'rand'    	=> __( 'Random', 'barab' ),
                ],
                'default'  	=> 'ID'
			]
        );
       
        $this->add_control(
            'post_display_type',
            [
                'label'   => __( 'Post Display Type', 'barab' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'all'      => __( 'All Posts', 'barab' ),
                    'category' => __( 'Category', 'barab' ),
                    'tags'     => __( 'Tags', 'barab' ),
                ],
                'default' => 'category',
            ]
        );        

        $this->add_control(
            'post_customization_note',
            [
                'type'    => \Elementor\Controls_Manager::RAW_HTML,
                'raw'     => __( '<strong>All posts are displayed by default.</strong><br>Use the "Include" or "Exclude" options below to customize which categories, tags, or specific posts should be shown or hidden.', 'barab' ),
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
                'condition'     => [
                    'post_display_type' => 'all',
                ],
            ]
        );
        $this->add_control(
            'include_exclude_option',
            [
                'label'   => __( 'Include or Exclude', 'barab' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'include' => __( 'Include', 'barab' ),
                    'exclude' => __( 'Exclude', 'barab' ),
                ],
                'default' => 'exclude',
                'condition'     => [
                    'post_display_type' => 'all',
                ],
            ]
        );
        
        $this->add_control(
            'blog_categories',
            [
                'label'         => __( 'Categories', 'barab' ),
                'type'          => Controls_Manager::SELECT2,
                'multiple'      => true,
                'options'       => $this->barab_get_categories(),
                'label_block'   => true,
                'condition'     => [
                    'post_display_type' => ['category', 'all'],
                ],
            ]
        );
        $this->add_control(
            'blog_tags',
            [
                'label'         => __( 'Tags', 'barab' ),
                'type'          => Controls_Manager::SELECT2,
                'multiple'      => true,
                'options'       => $this->barab_get_tags(),
                'label_block'   => true,
                'condition'     => [
                    'post_display_type' => ['tags', 'all'],
                ],
            ]
        );
        $this->add_control(
            'blog_posts',
            [
                'label'         => __( 'Posts', 'barab' ),
                'type'          => Controls_Manager::SELECT2,
                'multiple'      => true,
                'options'       => $this->barab_post_id(),
                'label_block'   => true,
                'condition'     => [
                    'post_display_type' => 'all',
                ],
            ]
        );

        barab_general_fields( $this, 'button_text', 'Read More Text', 'TEXTAREA2', 'Read More' );

        // Get all registered image sizes
        $image_sizes = get_intermediate_image_sizes(); 
        $options = [];
        foreach ( $image_sizes as $size ) {
            $options[ $size ] = ucfirst( str_replace( '_', ' ', $size ) );
        }
        $this->add_control(
            'image_resolution',
            [
                'label'       => __( 'Image Resolution', 'barab' ),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'default'     => 'large',
                'options'     => $options,
            ]
        ); 

        barab_switcher_fields( $this, 'show_post_meta_icons', 'Display Post Meta Icons?' );
        barab_switcher_fields( $this, 'show_author', 'Display Post Author?' );
        barab_switcher_fields( $this, 'show_date', 'Display Post Date?' );
        barab_switcher_fields( $this, 'show_category', 'Display Post Category?' );
        barab_switcher_fields( $this, 'show_comment', 'Display Post Comment?' );
        barab_switcher_fields( $this, 'show_min_read', 'Display Read Minute?' );

        $this->end_controls_section();

        // Column Responsive controls
		if ( function_exists( 'barab_add_responsive_columns_controls' ) ) {
			barab_add_responsive_columns_controls( $this, ['layout_style' => ['3'] ] );
		}

		//---------------------------------------
			//Style Section Start
		//--------------------------------------- 
		barab_common2_style_fields( $this, '011', 'Title', '{{WRAPPER}} .box-title a', ['1'] );
		barab_common3_style_fields( $this, '012', 'Title', '{{WRAPPER}} .box-title a', ['2'], 'color', 'color', '--theme-color' );
		barab_common_style_fields( $this, '022', 'Content', '{{WRAPPER}} .box-text' );
        //------Meta Style-------
        $this->start_controls_section(
            'meta_styling',
            [
                'label'     => __( 'Meta Styling', 'barab' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition'	=> [
                    'layout_style' => ['1', '2']
                ]
            ]
        );

        barab_color_fields( $this, '0001', 'Color', 'color', '{{WRAPPER}} .blog-meta a' );
        barab_color_fields( $this, '0002', 'Hover Color', 'color', '{{WRAPPER}} .blog-meta a:hover');  
        barab_color_fields( $this, '0003', 'Icon Color', '--theme-color', '{{WRAPPER}} .blog-meta i' );

        $this->end_controls_section();
		//------Button Style-------
		barab_button_style_fields( $this, '11', 'Button Styling', '{{WRAPPER}} .th-btn', ['1'] );


    }

    public function barab_get_categories() {
        $cats = get_terms(array(
            'taxonomy' => 'category',
            'hide_empty' => true,
        ));

        $cat = [];

        foreach( $cats as $singlecat ) {
            $cat[$singlecat->term_id] = __($singlecat->name,'barab');
        }

        return $cat;
    }

    public function barab_get_tags() {
        $tags = get_terms(array(
            'taxonomy' => 'post_tag',
            'hide_empty' => true,
        ));

        $tag = [];

        foreach( $tags as $singletag ) {
            $tag[$singletag->term_id] = __($singletag->name,'barab');
        }

        return $tag;
    }

    // Get Specific Post
    public function barab_post_id(){
        $args = array(
            'post_type'         => 'post',
            'posts_per_page'    => -1,
        );

        $barab_post = new WP_Query( $args );

        $postarray = [];

        while( $barab_post->have_posts() ){
            $barab_post->the_post();
            $postarray[get_the_Id()] = get_the_title();
        }
        wp_reset_postdata();
        return $postarray;
    }

    protected function render_blog_meta($settings) {
        echo '<div class="blog-meta">';
            if ( ! empty( $settings['show_author'] ) ) {
                echo '<a href="' . esc_url( get_author_posts_url( get_the_author_meta('ID') ) ) . '">';
                if ( ! empty( $settings['show_post_meta_icons'] ) ) {
                    echo '<i class="fal fa-user"></i>';
                }
                echo esc_html__( 'By ', 'barab' ) . esc_html( ucwords( get_the_author() ) );
                echo '</a>';
            }
            if ( ! empty( $settings['show_date'] ) ) {
                echo '<a href="' . esc_url( barab_blog_date_permalink() ) . '">';
                if ( ! empty( $settings['show_post_meta_icons'] ) ) {
                    echo '<i class="fal fa-calendar"></i>';
                }
                echo esc_html( get_the_date() );
                echo '</a>';
            }
            if ( ! empty( $settings['show_category'] ) ) {
                $categories = get_the_category();
                if ( ! empty( $categories ) ) {
                    echo '<a href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">';
                    if ( ! empty( $settings['show_post_meta_icons'] ) ) {
                        echo '<i class="fal fa-tag"></i>';
                    }
                    echo esc_html( $categories[0]->name );
                    echo '</a>';
                }
            }
            if ( ! empty( $settings['show_comment'] ) ) {
                echo '<a href="' . esc_url( get_comments_link() ) . '">';
                if ( ! empty( $settings['show_post_meta_icons'] ) ) {
                    echo '<i class="fal fa-comments"></i>';
                }
                echo get_comments_number() . ' ' . esc_html__( 'Comments', 'barab' );
                echo '</a>';
            }
            if ( ! empty( $settings['show_min_read'] ) ) {
                $content = get_post_field( 'post_content', get_the_ID() );
                $word_count = str_word_count( strip_tags( $content ) );
                $read_time = ceil( $word_count / 200 ); // Assuming 200 wpm
                echo '<span>';
                if ( ! empty( $settings['show_post_meta_icons'] ) ) {
                    echo '<i class="fal fa-clock"></i>';
                }
                echo esc_html( $read_time ) . esc_html__( ' min read', 'barab' );
                echo '</span>';
            }
        echo '</div>';
    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        $post_display_type = $settings['post_display_type'];
        $include_exclude_option = isset($settings['include_exclude_option']) ? $settings['include_exclude_option'] : 'exclude';
        $blog_posts = !empty($settings['blog_posts']) ? $settings['blog_posts'] : [];
        $blog_categories = !empty($settings['blog_categories']) ? $settings['blog_categories'] : [];
        $blog_tags = !empty($settings['blog_tags']) ? $settings['blog_tags'] : [];
        
        // Default query arguments
        $args = [
            'post_type'             => 'post',
            'posts_per_page'        => !empty($settings['blog_post_count']) ? esc_attr($settings['blog_post_count']) : 3,
            'order'                 => !empty($settings['blog_post_order']) ? esc_attr($settings['blog_post_order']) : 'DESC',
            'orderby'               => !empty($settings['blog_post_order_by']) ? esc_attr($settings['blog_post_order_by']) : 'ID',
            'ignore_sticky_posts'   => true,
        ];
        
        // Modify query based on `post_display_type` and `include_exclude_option`
        if ($post_display_type === 'all') {
            if ($include_exclude_option === 'include') {
                if (!empty($blog_posts)) {
                    $args['post__in'] = $blog_posts;
                }
                if (!empty($blog_categories)) {
                    $args['category__in'] = $blog_categories;
                }
                if (!empty($blog_tags)) {
                    $args['tag__in'] = $blog_tags;
                }
            } elseif ($include_exclude_option === 'exclude') {
                if (!empty($blog_posts)) {
                    $args['post__not_in'] = $blog_posts;
                }
                if (!empty($blog_categories)) {
                    $args['category__not_in'] = $blog_categories;
                }
                if (!empty($blog_tags)) {
                    $args['tag__not_in'] = $blog_tags;
                }
            }
        } elseif ($post_display_type === 'category') {
            // Show posts only from selected categories
            $args['category__in'] = $blog_categories;

        } elseif ($post_display_type === 'tags') {
            // Show posts only from selected tags
            $args['tag__in'] = $blog_tags;
            
        }
        
        // Create the WP_Query
        $blogpost = new WP_Query($args);     
        
        // Get the dynamic image resolution setting
        $image_resolution = !empty($settings['image_resolution']) ? $settings['image_resolution'] : 'large';
        

		if( $settings['layout_style'] == '1'  ){
            echo '<div class="slider-area">';
                echo '<div class="swiper th-slider has-shadow" id="blogSlider1" data-slider-options=\'{"breakpoints":{"0":{"slidesPerView":1},"576":{"slidesPerView":"1"},"768":{"slidesPerView":"1"},"992":{"slidesPerView":"2"},"1200":{"slidesPerView":"3"}}, "autoHeight": "true"}\'>';
                    echo '<div class="swiper-wrapper">';
                        while( $blogpost->have_posts() ){
                            $blogpost->the_post(); 
                            $categories = get_the_category();
                            $content = get_the_content();
                            $title_count =  $settings['title_count'];
                            $excerpt_count =  $settings['excerpt_count'];

                            echo '<div class="swiper-slide">';
                                echo '<div class="blog-card">';
                                    echo '<div class="blog-img">';
                                        echo '<a href="'.esc_url( get_permalink() ).'">';
                                            the_post_thumbnail( $image_resolution );
                                        echo '</a>';
                                    echo '</div>';
                                    echo '<div class="blog-content">';
                                        // blog meta render
                                        $this->render_blog_meta($settings);
                                        echo '<h3 class="box-title"><a href="'.esc_url( get_permalink() ).'">'.esc_html( wp_trim_words( get_the_title( ),  $title_count , '' ) ).'</a></h3>';
                                        if ( ! empty( $content && $excerpt_count ) ) {
                                            echo '<p class="box-text pb-4">' . esc_html( wp_trim_words( $content, $excerpt_count , '' ) ) . '</p>';
                                        }
                                        if(!empty($settings['button_text'])){
                                            echo '<a href="'.esc_url( get_permalink() ).'" class="th-btn btn-mask">'.esc_html($settings['button_text']).'</a>';
                                        }
                                    echo '</div>';
                                echo '</div>';
                            echo '</div>';
                        }wp_reset_postdata(); 
                    echo '</div>';
                echo '</div>';
                echo '<button data-slider-prev="#blogSlider1" class="slider-arrow slider-prev">';
					echo '<img src="'.BARAB_ASSETS.'img/icon/left-arrow.svg" alt="">';
				echo '</button>';
                echo '<button data-slider-next="#blogSlider1" class="slider-arrow slider-next">';
					echo '<img src="'.BARAB_ASSETS.'img/icon/right-arrow.svg" alt="">';
				echo '</button>';
            echo '</div>';
            
		}elseif( $settings['layout_style'] == '2' ){
            echo '<div class="slider-area">';
                echo '<div class="swiper th-slider has-shadow" id="blogSlider1" data-slider-options=\'{"breakpoints":{"0":{"slidesPerView":1},"576":{"slidesPerView":"1"},"768":{"slidesPerView":"1"},"992":{"slidesPerView":"2"},"1200":{"slidesPerView":"2"}}, "autoHeight": "true"}\'>';
                    echo '<div class="swiper-wrapper">';
                        while( $blogpost->have_posts() ){
                            $blogpost->the_post(); 
                            $categories = get_the_category();
                            $content = get_the_content();
                            $title_count =  $settings['title_count'];
                            $excerpt_count =  $settings['excerpt_count'];

                            echo '<div class="swiper-slide">';
                                echo '<div class="blog-card style-2">';
                                    echo '<div class="blog-img">';
                                        echo '<a href="'.esc_url( get_permalink() ).'">';
                                            the_post_thumbnail( $image_resolution );
                                        echo '</a>';
                                    echo '</div>';
                                    echo '<div class="blog-content">';
                                        // blog meta render
                                        $this->render_blog_meta($settings);
                                        echo '<h3 class="box-title"><a href="'.esc_url( get_permalink() ).'">'.esc_html( wp_trim_words( get_the_title( ),  $title_count , '' ) ).'</a></h3>';
                                        if ( ! empty( $content && $excerpt_count ) ) {
                                            echo '<p class="box-text pb-4">' . esc_html( wp_trim_words( $content, $excerpt_count , '' ) ) . '</p>';
                                        }
                                        if(!empty($settings['button_text'])){
                                            echo '<a href="'.esc_url( get_permalink() ).'" class="th-btn btn-mask">'.esc_html($settings['button_text']).'</a>';
                                        }
                                    echo '</div>';
                                echo '</div>';
                            echo '</div>';
                        }wp_reset_postdata(); 
                    echo '</div>';
                echo '</div>';
                echo '<button data-slider-prev="#blogSlider1" class="slider-arrow slider-prev">';
					echo '<img src="'.BARAB_ASSETS.'img/icon/left-arrow.svg" alt="">';
				echo '</button>';
                echo '<button data-slider-next="#blogSlider1" class="slider-arrow slider-next">';
					echo '<img src="'.BARAB_ASSETS.'img/icon/right-arrow.svg" alt="">';
				echo '</button>';
            echo '</div>';

        }elseif( $settings['layout_style'] == '3' ){

            echo '<div class="row gx-24 gy-30">';
                echo '<div class="col-12">';
                    $delay_counter = 0;
                    while( $blogpost->have_posts() ){
                        $blogpost->the_post(); 
                        $categories = get_the_category();
                        $content = get_the_content();
                        $title_count =  $settings['title_count'];
                        $excerpt_count =  $settings['excerpt_count'];

                        // Calculate delay: 0.3s + (0.2 * N)
                        $delay = 0.3 + (0.2 * $delay_counter);
                        $delay_formatted = number_format($delay, 1) . 's';
                        $mt30 = ($delay_counter > 0) ? 'mt-30':'';

                        echo '<div class="blog-card '.esc_attr($mt30).' style2 wow fadeInUp" data-wow-delay="'. esc_attr($delay_formatted) .'">';
                            echo '<div class="blog-img global-img">';
                                echo '<a href="'.esc_url( get_permalink() ).'">';
                                    the_post_thumbnail( $image_resolution );
                                echo '</a>';
                            echo '</div>';
                            echo '<div class="box-content">';
                                echo '<div>';
                                    // blog meta render
                                    $this->render_blog_meta($settings);

                                    echo '<h3 class="box-title"><a href="'.esc_url( get_permalink() ).'">'.esc_html( wp_trim_words( get_the_title( ),  $title_count , '' ) ).'</a></h3>';
                                    if ( ! empty( $content && $excerpt_count ) ) {
                                        echo '<p class="box-text pb-4">' . esc_html( wp_trim_words( $content, $excerpt_count , '' ) ) . '</p>';
                                    }
                                echo '</div>';
                                 echo '<div class="box-wrapp">';
                                    if ( ! empty( $settings['show_date'] ) ) {
                                        echo '<span class="date">'.esc_html( get_the_date() ).'</span>';
                                    }
                                    if(!empty($settings['button_text'])){
                                        echo '<a href="'.esc_url( get_permalink() ).'" class="th-btn black-border">'.esc_html($settings['button_text']).' </a>';
                                    }
                                echo '</div>';
                            echo '</div>';
                        echo '</div>';
                        $delay_counter++;
                    }wp_reset_postdata(); 
                echo '</div>';
            echo '</div>';

        }
	
      
	}
}