<?php

// Exit if accessed directly
if (! defined('ABSPATH')) {
	exit;
}


/**
 * Portfolio: Custom Post Types
 *
 *
 */
class glint_portfolio_Post_Types
{

	public function __construct()
	{
		$this->register_post_type();
	}

	public function register_post_type()
	{
		$args = array();

		// Portfolio
		$args['post-type-portfolio'] = array(
			'labels' => array(
				'name' => __('Portfolios', 'glint-extra'),
				'singular_name' => __('Item', 'glint-extra'),
				'add_new' => __('Add Portfolio', 'glint-extra'),
				'add_new_item' => __('Add Portfolio', 'glint-extra'),
				'edit_item' => __('Edit Portfolio', 'glint-extra'),
				'new_item' => __('New Portfolio', 'glint-extra'),
				'view_item' => __('View Portfolio', 'glint-extra'),
				'search_items' => __('Search Through portfolio', 'glint-extra'),
				'not_found' => __('No Portfolio found', 'glint-extra'),
				'not_found_in_trash' => __('No Portfolio found in Trash', 'glint-extra'),
				'parent_item_colon' => __('Parent Portfolio:', 'glint-extra'),
				'menu_name' => __('Portfolio', 'glint-extra'),
			),
			'hierarchical' => false,
			'description' => __('Add a Portfolio Item', 'glint-extra'),
			'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
			'menu_icon' =>  'dashicons-images-alt',
			'public' => true,
			'publicly_queryable' => true,
			'exclude_from_search' => true,
			'query_var' => true,
			'rewrite' => array('slug' => 'portfolio'),
			// This is where we add taxonomies to our CPT
			//'taxonomies'          => array( 'category' ),
		);

		// Register post type: name, arguments
		register_post_type('portfolio', $args['post-type-portfolio']);
	}
}

function glint_portfolio_types()
{
	new glint_portfolio_Post_Types();
}

add_action('init', 'glint_portfolio_types');

/*-----------------------------------------------------------------------------------*/
/*	Creating Custom Taxonomy 
/*-----------------------------------------------------------------------------------*/
// hook into the init action and call create_book_taxonomies when it fires
add_action('init', 'growthcore_create_portfolio_taxonomies', 0);

// create two taxonomies, genres and writers for the post type "book"
function growthcore_create_portfolio_taxonomies()
{
	// Add new taxonomy, make it hierarchical (like categories)
	$labels = array(
		'name'              => _x('Categories', 'taxonomy general name', 'glint-extra'),
		'singular_name'     => _x('Category', 'taxonomy singular name', 'glint-extra'),
		'search_items'      => __('Search Categories', 'glint-extra'),
		'all_items'         => __('Categories', 'glint-extra'),
		'parent_item'       => __('Parent Category', 'glint-extra'),
		'parent_item_colon' => __('Parent Category:', 'glint-extra'),
		'edit_item'         => __('Edit Category', 'glint-extra'),
		'update_item'       => __('Update Category', 'glint-extra'),
		'add_new_item'      => __('Add New Category', 'glint-extra'),
		'new_item_name'     => __('New Category', 'glint-extra'),
		'menu_name'         => __('Categories', 'glint-extra'),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array('slug' => 'portfoliocategory'),
	);

	register_taxonomy('portfoliocats', array('portfolio'), $args);
}
