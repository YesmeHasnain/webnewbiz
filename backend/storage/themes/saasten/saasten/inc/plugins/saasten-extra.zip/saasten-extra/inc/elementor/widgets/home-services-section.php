<?php

/**
 * Elementor Widget
 * @package Saasten
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_home_services_one extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'theme-services-onee';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Home Services 1', 'saasten-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saasten_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {



        $this->start_controls_section( 'section_content_faeturess_one1', [
            'label' => esc_html__( 'Featured Item Content 1', 'saasten-extra' ),
        ] ); 

        $this->add_control( 'title1', [
            'label'       => __( 'Title', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Invest in Startup', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type section title here.", 'saasten-extra' ),

        ] );

        $this->add_control( 'description1', [
            'label'       => __( 'Description', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Our Sustainable Construction Advisors provide sustainable construction expertise', 'saasten-extra' ),
            'label_block' => true,
        ] );

        $this->add_control( 'feature_icon1', [
            'label'   => __( 'Choose Icon', 'saasten-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        $this->add_control( 'feature_image1', [
            'label'   => __( 'Choose Image', 'saasten-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );


        $this->add_control( 'btn_text1', [
            'label'       => __( 'Button Label', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'placeholder' => __( 'Type your button label here', 'saasten-extra' ),
            'default'     => __( 'Read More', 'saasten-extra' ),
        ] );

        $this->add_control( 'btn_link1', [
            'label'       => __( 'Button Link', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::URL,
            'placeholder' => __( 'https://your-link.com', 'saasten-extra' ),
            'default'     => [
                'url' => '#',
            ],
        ] );

        $this->end_controls_section();


        $this->start_controls_section( 'section_content_faeturess_one2', [
            'label' => esc_html__( 'Featured Item Content 2', 'saasten-extra' ),
        ] ); 

        $this->add_control( 'title2', [
            'label'       => __( 'Title', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Invest in Startup', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type section title here.", 'saasten-extra' ),

        ] );

        $this->add_control( 'description2', [
            'label'       => __( 'Description', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Our Sustainable Construction Advisors provide sustainable construction expertise', 'saasten-extra' ),
            'label_block' => true,
        ] );

        $this->add_control( 'feature_icon2', [
            'label'   => __( 'Choose Icon', 'saasten-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        $this->add_control( 'feature_image2', [
            'label'   => __( 'Choose Image', 'saasten-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );


        $this->add_control( 'btn_text2', [
            'label'       => __( 'Button Label', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'placeholder' => __( 'Type your button label here', 'saasten-extra' ),
            'default'     => __( 'Read More', 'saasten-extra' ),
        ] );

        $this->add_control( 'btn_link2', [
            'label'       => __( 'Button Link', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::URL,
            'placeholder' => __( 'https://your-link.com', 'saasten-extra' ),
            'default'     => [
                'url' => '#',
            ],
        ] );

        $this->end_controls_section();


        $this->start_controls_section( 'section_content_faeturess_one3', [
            'label' => esc_html__( 'Featured Item Content 3', 'saasten-extra' ),
        ] ); 

        $this->add_control( 'title3', [
            'label'       => __( 'Title', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Invest in Startup', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type section title here.", 'saasten-extra' ),

        ] );

        $this->add_control( 'description3', [
            'label'       => __( 'Description', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Our Sustainable Construction Advisors provide sustainable construction expertise', 'saasten-extra' ),
            'label_block' => true,
        ] );

        $this->add_control( 'feature_icon3', [
            'label'   => __( 'Choose Icon', 'saasten-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        $this->add_control( 'feature_image3', [
            'label'   => __( 'Choose Image', 'saasten-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );


        $this->add_control( 'btn_text3', [
            'label'       => __( 'Button Label', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'placeholder' => __( 'Type your button label here', 'saasten-extra' ),
            'default'     => __( 'Read More', 'saasten-extra' ),
        ] );

        $this->add_control( 'btn_link3', [
            'label'       => __( 'Button Link', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::URL,
            'placeholder' => __( 'https://your-link.com', 'saasten-extra' ),
            'default'     => [
                'url' => '#',
            ],
        ] );

        $this->end_controls_section();

        $this->start_controls_section( 'section_content_faeturess_one4', [
            'label' => esc_html__( 'Featured Item Content 4', 'saasten-extra' ),
        ] ); 

        $this->add_control( 'title4', [
            'label'       => __( 'Title', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Invest in Startup', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type section title here.", 'saasten-extra' ),

        ] );

        $this->add_control( 'description4', [
            'label'       => __( 'Description', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Our Sustainable Construction Advisors provide sustainable construction expertise', 'saasten-extra' ),
            'label_block' => true,
        ] );

        $this->add_control( 'feature_icon4', [
            'label'   => __( 'Choose Icon', 'saasten-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        $this->add_control( 'feature_image4', [
            'label'   => __( 'Choose Image', 'saasten-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );


        $this->add_control( 'btn_text4', [
            'label'       => __( 'Button Label', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'placeholder' => __( 'Type your button label here', 'saasten-extra' ),
            'default'     => __( 'Read More', 'saasten-extra' ),
        ] );

        $this->add_control( 'btn_link4', [
            'label'       => __( 'Button Link', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::URL,
            'placeholder' => __( 'https://your-link.com', 'saasten-extra' ),
            'default'     => [
                'url' => '#',
            ],
        ] );

        $this->end_controls_section();



        $this->start_controls_section( 'section_content_faeturess_one5', [
            'label' => esc_html__( 'Featured Item Content 5', 'saasten-extra' ),
        ] ); 

        $this->add_control( 'title5', [
            'label'       => __( 'Title', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Invest in Startup', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type section title here.", 'saasten-extra' ),

        ] );

        $this->add_control( 'description5', [
            'label'       => __( 'Description', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Our Sustainable Construction Advisors provide sustainable construction expertise', 'saasten-extra' ),
            'label_block' => true,
        ] );

        $this->add_control( 'feature_icon5', [
            'label'   => __( 'Choose Icon', 'saasten-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        $this->add_control( 'feature_image5', [
            'label'   => __( 'Choose Image', 'saasten-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );


        $this->add_control( 'btn_text5', [
            'label'       => __( 'Button Label', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'placeholder' => __( 'Type your button label here', 'saasten-extra' ),
            'default'     => __( 'Read More', 'saasten-extra' ),
        ] );

        $this->add_control( 'btn_link5', [
            'label'       => __( 'Button Link', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::URL,
            'placeholder' => __( 'https://your-link.com', 'saasten-extra' ),
            'default'     => [
                'url' => '#',
            ],
        ] );

        $this->end_controls_section();


        // ===================== Title ======================//

        $this->start_controls_section( 'title_style', [
            'label' => __( 'Title', 'saasten-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_typography',
            'label'    => __( 'Typography', 'saasten-extra' ),
            'selector' => '
                {{WRAPPER}} .theme-banner-startup-wrapper h1.banner-heading,
                {{WRAPPER}} .__title
            ',
        ] );


        $this->add_control( 'title_color', [
            'label'     => __( 'Color', 'saasten-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-startup-wrapper h1.banner-heading' => 'color: {{VALUE}}',
                '{{WRAPPER}} .__title' => 'color: {{VALUE}}',
            ],
        ] );

        $this->end_controls_section(); //End Title Style


        // ===================== Subtitle Style ========================//
        $this->start_controls_section( 'sub_title_style', [
            'label' => __( 'Sub Title', 'saasten-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_sub_typography',
            'label'    => __( 'Typography', 'saasten-extra' ),
            'selector' => '{{WRAPPER}} .theme-banner-startup-wrapper h4.banner-sub-heading',
        ] );

        $this->add_control( 'sub_title_color', [
            'label'     => __( 'Sub Title Color', 'saasten-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-startup-wrapper h4.banner-sub-heading' => 'color: {{VALUE}}',
            ],

        ] );

        $this->end_controls_section(); //End Subtitle Style

		
	}
	


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

        $serviceItems = $settings['serviceItems'];

        extract($settings); 


		
		?>





    <!-- Ux Features -->
    <section class="ux-features pd-top-100 pd-btm-100">
      <div class="ux-features__main">
        <div class="ux-features-list list-group" role="tablist">



          <!-- Single Feature -->
          <div
            class="ux-features-list__single list-group-item active"
            data-bs-toggle="list"
            data-aos="fade-up"
            href="#saastain-tab1"
            role="tab"
          >
            <div class="ux-features-list__main">
              <div class="ux-features-list__icon">
                <img src="<?php echo esc_url( $settings['feature_icon1']['url'] ); ?>" />
              </div>
              <div class="ux-features-list__content">
                <h4 class="ux-features-list__title"><?php echo wp_kses_post( $settings['title1'] ); ?></h4>
                <p class="ux-features-list__text">
                  <?php echo wp_kses_post( $settings['description1'] ); ?>
                </p>
              </div>
            </div>
            <div class="ux-features-list__button">
              <a href="<?php echo esc_url( $settings['btn_link1']['url'] ) ?>"
                ><?php echo esc_html( $settings['btn_text1'] ); ?> <img src="<?php echo SAASTEN_IMG ."/arrow-right.svg"; ?>"
              /></a>
            </div>
          </div>
          <!-- End Single Feature -->




          <!-- Single Feature -->
          <div
            class="ux-features-list__single list-group-item"
            data-bs-toggle="list"
            data-aos="fade-up"
            data-aos-delay="100"
            href="#saastain-tab2"
            role="tab"
          >
            
            <div class="ux-features-list__main">
              <div class="ux-features-list__icon">
                <img src="<?php echo esc_url( $settings['feature_icon2']['url'] ); ?>" />
              </div>
              <div class="ux-features-list__content">
                <h4 class="ux-features-list__title"><?php echo wp_kses_post( $settings['title2'] ); ?></h4>
                <p class="ux-features-list__text">
                  <?php echo wp_kses_post( $settings['description2'] ); ?>
                </p>
              </div>
            </div>
            <div class="ux-features-list__button">
              <a href="<?php echo esc_url( $settings['btn_link2']['url'] ) ?>"
                ><?php echo esc_html( $settings['btn_text2'] ); ?> <img src="<?php echo SAASTEN_IMG ."/arrow-right.svg"; ?>"
              /></a>
            </div>


          </div>
          <!-- End Single Feature -->
          <!-- Single Feature -->
          <div
            class="ux-features-list__single list-group-item"
            data-bs-toggle="list"
            data-aos="fade-up"
            data-aos-delay="200"
            href="#saastain-tab3"
            role="tab"
          >

          <div class="ux-features-list__main">
              <div class="ux-features-list__icon">
                <img src="<?php echo esc_url( $settings['feature_icon3']['url'] ); ?>" />
              </div>
              <div class="ux-features-list__content">
                <h4 class="ux-features-list__title"><?php echo wp_kses_post( $settings['title3'] ); ?></h4>
                <p class="ux-features-list__text">
                  <?php echo wp_kses_post( $settings['description3'] ); ?>
                </p>
              </div>
            </div>
            <div class="ux-features-list__button">
              <a href="<?php echo esc_url( $settings['btn_link3']['url'] ) ?>"
                ><?php echo esc_html( $settings['btn_text3'] ); ?> <img src="<?php echo SAASTEN_IMG ."/arrow-right.svg"; ?>"
              /></a>
            </div>


          </div>
          <!-- End Single Feature -->
          <!-- Single Feature -->
          <div
            class="ux-features-list__single list-group-item"
            data-bs-toggle="list"
            data-aos="fade-up"
            data-aos-delay="300"
            href="#saastain-tab4"
            role="tab"
          >


            <div class="ux-features-list__main">
              <div class="ux-features-list__icon">
                <img src="<?php echo esc_url( $settings['feature_icon4']['url'] ); ?>" />
              </div>
              <div class="ux-features-list__content">
                <h4 class="ux-features-list__title"><?php echo wp_kses_post( $settings['title4'] ); ?></h4>
                <p class="ux-features-list__text">
                  <?php echo wp_kses_post( $settings['description4'] ); ?>
                </p>
              </div>
            </div>
            <div class="ux-features-list__button">
              <a href="<?php echo esc_url( $settings['btn_link4']['url'] ) ?>"
                ><?php echo esc_html( $settings['btn_text4'] ); ?> <img src="<?php echo SAASTEN_IMG ."/arrow-right.svg"; ?>"
              /></a>
            </div>


          </div>
          <!-- End Single Feature -->
          <!-- Single Feature -->
          <div
            class="ux-features-list__single list-group-item"
            data-bs-toggle="list"
            data-aos="fade-up"
            data-aos-delay="400"
            href="#saastain-tab5"
            role="tab"
          >


            <div class="ux-features-list__main">
              <div class="ux-features-list__icon">
                <img src="<?php echo esc_url( $settings['feature_icon5']['url'] ); ?>" />
              </div>
              <div class="ux-features-list__content">
                <h4 class="ux-features-list__title"><?php echo wp_kses_post( $settings['title5'] ); ?></h4>
                <p class="ux-features-list__text">
                  <?php echo wp_kses_post( $settings['description5'] ); ?>
                </p>
              </div>
            </div>
            <div class="ux-features-list__button">
              <a href="<?php echo esc_url( $settings['btn_link5']['url'] ) ?>"
                ><?php echo esc_html( $settings['btn_text5'] ); ?> <img src="<?php echo SAASTEN_IMG ."/arrow-right.svg"; ?>"
              /></a>
            </div>


          </div>
          <!-- End Single Feature -->
        </div>
        <div data-aos="fade-left" class="ux-images">
          <div class="tab-content" id="nav-tabContent">


            <div
              class="tab-pane fade show active"
              id="saastain-tab1"
              role="tabpanel"
            >
              <img src="<?php echo esc_url( $settings['feature_image1']['url'] ); ?>" />
            </div>


            <div class="tab-pane fade" id="saastain-tab2" role="tabpanel">
              <img src="<?php echo esc_url( $settings['feature_image2']['url'] ); ?>" />
            </div>

            <div class="tab-pane fade" id="saastain-tab3" role="tabpanel">
              <img src="<?php echo esc_url( $settings['feature_image3']['url'] ); ?>" />
            </div>

            <div class="tab-pane fade" id="saastain-tab4" role="tabpanel">
              <img src="<?php echo esc_url( $settings['feature_image4']['url'] ); ?>" />
            </div>

            <div class="tab-pane fade" id="saastain-tab5" role="tabpanel">
              <img src="<?php echo esc_url( $settings['feature_image5']['url'] ); ?>" />
            </div>


          </div>
        </div>
      </div>
    </section>
    <!-- End UX Features -->







	<?php 


	}
				

}

