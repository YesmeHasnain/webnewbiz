<?php
// register post type service
add_action( 'init', 'register_nixer_service' );
function register_nixer_service() {
	$labels = array( 
		'name' 					=> __( 'Service', 'nixer' ),
		'singular_name' 		=> __( 'Service', 'nixer' ),
		'add_new' 				=> __( 'Add New Service', 'nixer' ),
		'add_new_item' 			=> __( 'Add New Service', 'nixer' ),
		'edit_item' 			=> __( 'Edit Service', 'nixer' ),
		'new_item' 				=> __( 'New Service', 'nixer' ),
		'view_item' 			=> __( 'View Service', 'nixer' ),
		'search_items' 			=> __( 'Search Service', 'nixer' ),
		'not_found' 			=> __( 'No Service found', 'nixer' ),
		'not_found_in_trash' 	=> __( 'No Service found in Trash', 'nixer', 'Location' ),
		'parent_item_colon' 	=> __( 'Parent Service:', 'nixer' ),
		'menu_name' 			=> __( 'Service', 'nixer' ),
	);
	$args = array( 
		'labels' 				=> $labels,
		'hierarchical' 			=> true,
		'description' 			=> 'List Service',
		'supports' 				=> array( 'title', 'authors','editor', 'thumbnail'),
		'taxonomies' 			=> array( 'service' ),
		'public' 				=> true,
		'show_ui' 				=> true,
		'show_in_menu' 			=> true,
		'menu_position' 		=> 5,
		'menu_icon' 			=> 'dashicons-portfolio', 
		'show_in_nav_menus' 	=> true,
		'publicly_queryable'	=> true,
		'exclude_from_search' 	=> false,
		'has_archive' 			=> true,
		'query_var' 			=> true,
		'can_export' 			=> true,
		'rewrite' 				=> true,
		'capability_type' 		=> 'post'
	);
	register_post_type( 'service', $args );
}
add_action( 'init', 'create_service_cat_hierarchical_taxonomy', 0 );
function create_service_cat_hierarchical_taxonomy() {
// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI
	$labels = array(
		'name' 					=> __( 'Service Category', 'nixer' ),
		'singular_name' 		=> __( 'Service Category', 'nixer' ),
		'search_items'	 		=> __( 'Search Service Category','nixer' ),
		'all_items' 			=> __( 'All Service Category','nixer' ),
		'parent_item' 			=> __( 'Parent Service Category','nixer' ),
		'parent_item_colon' 	=> __( 'Parent Service Category:','nixer' ),
		'edit_item' 			=> __( 'Edit Service Category','nixer' ), 
		'update_item' 			=> __( 'Update Service Category','nixer' ),
		'add_new_item' 			=> __( 'Add New Service Category','nixer' ),
		'new_item_name' 		=> __( 'New Category Name','nixer' ),
		'menu_name' 			=> __( 'Service Category','nixer' ),
	);
// Now register the taxonomy
	register_taxonomy('service-cat',array('service'), array(
		'hierarchical' 			=> true,
		'labels' 				=> $labels,
		'show_ui' 				=> true,
		'show_admin_column' 	=> true,
		'query_var' 			=> true,
		'rewrite' 				=> array( 'slug' => 'service-cat' ),
	));
}



// register post type portfolio
add_action( 'init', 'register_nixer_portfolio' );
function register_nixer_portfolio() {
	$labels = array( 
		'name' 					=> __( 'Portfolio', 'nixer' ),
		'singular_name' 		=> __( 'Portfolio', 'nixer' ),
		'add_new' 				=> __( 'Add New Portfolio', 'nixer' ),
		'add_new_item' 			=> __( 'Add New Portfolio', 'nixer' ),
		'edit_item' 			=> __( 'Edit Portfolio', 'nixer' ),
		'new_item' 				=> __( 'New Portfolio', 'nixer' ),
		'view_item' 			=> __( 'View Portfolio', 'nixer' ),
		'search_items' 			=> __( 'Search Portfolio', 'nixer' ),
		'not_found' 			=> __( 'No Portfolio found', 'nixer' ),
		'not_found_in_trash' 	=> __( 'No Portfolio found in Trash', 'nixer', 'Location' ),
		'parent_item_colon' 	=> __( 'Parent portfolio:', 'nixer' ),
		'menu_name' 			=> __( 'Portfolio', 'nixer' ),
	);
	$args = array( 
		'labels' 				=> $labels,
		'hierarchical' 			=> true,
		'description' 			=> 'List portfolio',
		'supports' 				=> array( 'title', 'authors','editor', 'thumbnail', 'comments'),
		'taxonomies' 			=> array( 'portfolio', 'portfolio-cat', 'portfolio-client' ),
		'public' 				=> true,
		'show_ui' 				=> true,
		'show_in_menu' 			=> true,
		'menu_position' 		=> 5,
		'menu_icon' 			=> 'dashicons-portfolio', 
		'show_in_nav_menus' 	=> true,
		'publicly_queryable'	=> true,
		'exclude_from_search' 	=> false,
		'has_archive' 			=> true,
		'query_var' 			=> true,
		'can_export' 			=> true,
		'rewrite' 				=> true,
		'capability_type' 		=> 'post'
	);
	register_post_type( 'portfolio', $args );
}
add_action( 'init', 'create_portfolio_cat_hierarchical_taxonomy', 0 );
function create_portfolio_cat_hierarchical_taxonomy() {
// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI
	$labels = array(
		'name' 					=> __( 'Portfolio Category', 'nixer' ),
		'singular_name' 		=> __( 'Portfolio Category', 'nixer' ),
		'search_items'	 		=> __( 'Search Portfolio Category','nixer' ),
		'all_items' 			=> __( 'All Portfolio Category','nixer' ),
		'parent_item' 			=> __( 'Parent Portfolio Category','nixer' ),
		'parent_item_colon' 	=> __( 'Parent Portfolio Category:','nixer' ),
		'edit_item' 			=> __( 'Edit Portfolio Category','nixer' ), 
		'update_item' 			=> __( 'Update Portfolio Category','nixer' ),
		'add_new_item' 			=> __( 'Add New Portfolio Category','nixer' ),
		'new_item_name' 		=> __( 'New Category Name','nixer' ),
		'menu_name' 			=> __( 'Portfolio Category','nixer' ),
	);
// Now register the taxonomy
	register_taxonomy('portfolio-cat',array('portfolio'), array(
		'hierarchical' 			=> true,
		'labels' 				=> $labels,
		'show_ui' 				=> true,
		'show_admin_column' 	=> true,
		'query_var' 			=> true,
		'rewrite' 				=> array( 'slug' => 'portfolio-cat' ),
	));
}

add_action( 'init', 'create_portfolio_role_hierarchical_taxonomy', 0 );
function create_portfolio_role_hierarchical_taxonomy() {
// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI
	$labels = array(
		'name' 					=> __( 'Portfolio Role', 'nixer' ),
		'singular_name' 		=> __( 'Portfolio Role', 'nixer' ),
		'search_items'	 		=> __( 'Search Portfolio Role','nixer' ),
		'all_items' 			=> __( 'All Portfolio Role','nixer' ),
		'parent_item' 			=> __( 'Parent Portfolio Role','nixer' ),
		'parent_item_colon' 	=> __( 'Parent Portfolio Role:','nixer' ),
		'edit_item' 			=> __( 'Edit Portfolio Role','nixer' ), 
		'update_item' 			=> __( 'Update Portfolio Role','nixer' ),
		'add_new_item' 			=> __( 'Add New Portfolio Role','nixer' ),
		'new_item_name' 		=> __( 'New Role Name','nixer' ),
		'menu_name' 			=> __( 'Portfolio Role','nixer' ),
	);
// Now register the taxonomy
	register_taxonomy('portfolio-role',array('portfolio'), array(
		'hierarchical' 			=> true,
		'labels' 				=> $labels,
		'show_ui' 				=> true,
		'show_admin_column' 	=> true,
		'query_var' 			=> true,
		'rewrite' 				=> array( 'slug' => 'portfolio-role' ),
	));
}

add_action( 'init', 'create_portfolio_tag_hierarchical_taxonomy', 0 );
function create_portfolio_tag_hierarchical_taxonomy() {
// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI
	$labels = array(
		'name' 					=> __( 'Portfolio Tag', 'nixer' ),
		'singular_name' 		=> __( 'Portfolio Tag', 'nixer' ),
		'search_items'	 		=> __( 'Search Portfolio Tag','nixer' ),
		'all_items' 			=> __( 'All Portfolio Tag','nixer' ),
		'parent_item' 			=> __( 'Parent Portfolio Tag','nixer' ),
		'parent_item_colon' 	=> __( 'Parent Portfolio Tag:','nixer' ),
		'edit_item' 			=> __( 'Edit Portfolio Tag','nixer' ), 
		'update_item' 			=> __( 'Update Portfolio Tag','nixer' ),
		'add_new_item' 			=> __( 'Add New Portfolio Tag','nixer' ),
		'new_item_name' 		=> __( 'New Tag Name','nixer' ),
		'menu_name' 			=> __( 'Portfolio Tag','nixer' ),
	);
// Now register the taxonomy
	register_taxonomy('portfolio-tag',array('portfolio'), array(
		'hierarchical' 			=> true,
		'labels' 				=> $labels,
		'show_ui' 				=> true,
		'show_admin_column' 	=> true,
		'query_var' 			=> true,
		'rewrite' 				=> array( 'slug' => 'portfolio-tag' ),
	));
}


// register post type team
add_action( 'init', 'register_nixer_team' );
function register_nixer_team() {
	$labels = array( 
		'name' 					=> __( 'Team', 'nixer' ),
		'singular_name' 		=> __( 'Team', 'nixer' ),
		'add_new' 				=> __( 'Add New Team', 'nixer' ),
		'add_new_item' 			=> __( 'Add New Team', 'nixer' ),
		'edit_item' 			=> __( 'Edit Team', 'nixer' ),
		'new_item' 				=> __( 'New Team', 'nixer' ),
		'view_item' 			=> __( 'View Team', 'nixer' ),
		'search_items' 			=> __( 'Search Team', 'nixer' ),
		'not_found' 			=> __( 'No Team found', 'nixer' ),
		'not_found_in_trash' 	=> __( 'No Team found in Trash', 'nixer' ),
		'parent_item_colon' 	=> __( 'Parent Team:', 'nixer' ),
		'menu_name' 			=> __( 'Team', 'nixer' ),
	);
	$args = array( 
		'labels' 				=> $labels,
		'hierarchical' 			=> true,
		'description' 			=> 'List Team',
		'supports' 				=> array( 'title', 'authors','editor', 'thumbnail', 'comments'),
		'taxonomies' 			=> array( 'team', 'team-job' ),
		'public' 				=> true,
		'show_ui' 				=> true,
		'show_in_menu' 			=> true,
		'menu_position' 		=> 5,
		'menu_icon' 			=> 'dashicons-groups', 
		'show_in_nav_menus' 	=> true,
		'publicly_queryable' 	=> true,
		'exclude_from_search' 	=> false,
		'has_archive' 			=> true,
		'query_var' 			=> true,
		'can_export' 			=> true,
		'rewrite' 				=> true,
		'capability_type' 		=> 'post'
	);
	register_post_type( 'team', $args );
}
add_action( 'init', 'create_job_hierarchical_taxonomy', 0 );
//create a custom taxonomy name it Skillss for your posts
function create_job_hierarchical_taxonomy() {
// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI
  $labels = array(
	'name' 						=> __( 'Job', 'nixer' ),
	'singular_name' 			=> __( 'Job', 'nixer' ),
	'search_items' 				=>  __( 'Search Job','nixer' ),
	'all_items' 				=> __( 'All Job','nixer' ),
	'parent_item' 				=> __( 'Parent Job','nixer' ),
	'parent_item_colon' 		=> __( 'Parent Job:','nixer' ),
	'edit_item' 				=> __( 'Edit Job','nixer' ), 
	'update_item' 				=> __( 'Update Job','nixer' ),
	'add_new_item' 				=> __( 'Add New Job','nixer' ),
	'new_item_name' 			=> __( 'New Job Name','nixer' ),
	'menu_name' 				=> __( 'Job','nixer' ),
  );
// Now register the taxonomy
  register_taxonomy('team-job',array('team'), array(
	'hierarchical' 				=> true,
	'labels' 					=> $labels,
	'show_ui' 					=> true,
	'show_admin_column' 		=> true,
	'query_var' 				=> true,
	'rewrite' 					=> array( 'slug' => 'team-job' ),
  ));
}

function create_footer_cpt() {
    $args = [
        'label'        => 'Footers',
        'public'       => true,
        'show_ui'      => true,
        'show_in_menu' => true,
        'menu_icon'    => 'dashicons-editor-insertmore',
        'supports'     => ['title', 'editor'],
    ];
    register_post_type('custom_footer', $args);
}
add_action('init', 'create_footer_cpt');
