<?php 



//CMB2 metabox
add_action( 'cmb2_admin_init', 'mancink_register_header_metabox' );
function mancink_register_header_metabox() {
	

	/**
	 * CUSTOM HEADER SETTINGS
	 */
	$mancink_header_metabox_cmb2 = new_cmb2_box( array(
		'id'            => 'mancink_header_metabox',
		'title'         => esc_html__( 'Header Settings', 'mancink_plugin' ),
		'object_types'  => array( 'header' ), // Post type
	) );

	$mancink_header_metabox_cmb2->add_field( array(
		'name'             => esc_html__( 'Please Read:', 'mancink_plugin' ),
		'id'            => 'mancink_title_text',
		'desc' => wp_kses_post( 'You can build your custom header with <strong>elementor</strong> and use it in any page using the <strong>page settings</strong>.<br> For <strong>global settings</strong>, you can set it on <strong>the customizer -> Header Settings</strong>. <br>
		To be able to edit this header with <strong>elementor</strong>, make sure you have checklist the <strong>Custom Header</strong> in <strong>Elementor Settings -> Post Type</strong>', 'mancink_plugin' ),
		'type'             => 'title',
	) );
	
	$mancink_header_metabox_cmb2->add_field( array(
		'name'             => esc_html__( 'Header Position', 'mancink_plugin' ),
		'desc'             => esc_html__( 'Choose the Header Position', 'mancink_plugin' ),
		'id'               => 'mancink_header_position',
		'type'             => 'select',
		'default' => 'default',
		'options'          => array(
			'default' => esc_html__( 'Relative Header', 'mancink_plugin' ),
			'custom-absolute-menu'   => esc_html__( 'Absolute Header', 'mancink_plugin' ),
			'custom-fixed-menu'   => esc_html__( 'Fixed Header', 'mancink_plugin' ),
			'custom-sticky-menu'     => esc_html__( 'Sticky Header', 'mancink_plugin' ),
			'custom-sticky-menu custom-absolute-menu'     => esc_html__( 'Absolute then Sticky(on scroll) Header', 'mancink_plugin' ),
		),
	) );
	
	$mancink_header_metabox_cmb2->add_field( array(
		'name'             => esc_html__( 'Use Dark Background Page', 'mancink_plugin' ),
		'desc'             => esc_html__( 'Only for preview/editor purpose only. For better preview in header element with white/bright color or with opacity.', 'mancink_plugin' ),
		'id'               => 'mancink_dark_bg',
		'type'             => 'select',
		'default' => 'default',
		'options'          => array(
			'default' => esc_html__( 'Use Default Background', 'mancink_plugin' ),
			'dark-page'   => esc_html__( 'Use Dark Background', 'mancink_plugin' ),
		),
	) );
	
	
}




