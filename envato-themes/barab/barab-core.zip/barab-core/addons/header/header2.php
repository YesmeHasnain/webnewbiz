<?php

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
/**
 *
 * Header Widget . 
 *
 */
class Barab_Header2 extends Widget_Base {

	public function get_name() {
		return 'barabheader2';
	}
	public function get_title() {
		return __( 'Header V2', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab_header_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'layout_section',
			[
				'label' 	=> __( 'Header', 'barab' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', ['Style One', 'Style Two', 'Style Three', 'Style Four'] );

		$this->add_control(
			'logo_image',
			[
				'label' 		=> __( 'Upload Logo', 'barab' ),
				'type' 			=> Controls_Manager::MEDIA,
			]
		);	
		$this->add_control(
			'bottom_shape',
			[
				'label' 		=> __( 'Bottom Shape', 'barab' ),
				'type' 			=> Controls_Manager::MEDIA,
				'condition'	=> [
					'layout_style' => ['3', '4']
				]
			]
		);				

		$menus = $this->barab_menu_select();

		if( !empty( $menus ) ){
	        $this->add_control(
				'barab_menu_select',
				[
					'label'     	=> __( 'Select barab Menu', 'barab' ),
					'type'      	=> Controls_Manager::SELECT,
					'options'   	=> $menus,
					'description' 	=> sprintf( __( 'Go to the <a href="%s" target="_blank">Menus screen</a> to manage your menus.', 'barab' ), admin_url( 'nav-menus.php' ) ),
				]
			);
		}else {
			$this->add_control(
				'no_menu',
				[
					'type' 				=> Controls_Manager::RAW_HTML,
					'raw' 				=> '<strong>' . __( 'There are no menus in your site.', 'barab' ) . '</strong><br>' . sprintf( __( 'Go to the <a href="%s" target="_blank">Menus screen</a> to create one.', 'barab' ), admin_url( 'nav-menus.php?action=edit&menu=0' ) ),
					'separator' 		=> 'after',
					'content_classes' 	=> 'elementor-panel-alert elementor-panel-alert-info',
				]
			);
		}
		
		barab_switcher_fields( $this, 'show_search_btn', 'Show Search Button?', ['1', '4'] );
		barab_switcher_fields( $this, 'show_cart_btn', 'Show Cart Button?', ['1', '4'] );

		barab_general_fields( $this, 'button_text', 'Button Text', 'TEXT', 'RESERVE A TABLE', ['1', '4'] );
		barab_url_fields( $this, 'button_url', 'Button URL', ['1', '4'] );

		barab_media_fields( $this, 'icon', 'Choose Icon', ['2', '3'] );
		barab_general_fields( $this, 'label', 'Label', 'TEXT', 'Contact us for reservation', ['2', '3'] );
		barab_general_fields( $this, 'content', 'Content', 'TEXTAREA', '+256-5682-1801', ['2', '3'] );

		barab_switcher_fields( $this, 'show_offcanvas_btn', 'Show OffCanvas Button?', ['2', '3'] );

        $this->end_controls_section();

		//---------------------------------------
			//Style Section Start
		//---------------------------------------

		//-------General Style-------
		 $this->start_controls_section(
			'general_styling',
			[
				'label'     => __( 'Background Styling', 'barab' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
        );

		barab_color_fields( $this, 'menu_bg', 'Background', 'background', '{{WRAPPER}} .menu-area', ['1', '2', '3', '4'] ); 

		$this->end_controls_section();

		//------Menu Bar Style-------
        $this->start_controls_section(
			'menubar_styling2',
			[
				'label'     => __( 'Menu Styling', 'barab' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
        );

		barab_color_fields( $this, 'menu_color1', 'Color', 'color', '{{WRAPPER}} .main-menu>ul>li>a' );
		barab_color_fields( $this, 'menu_color2', 'Hover Color', 'color', '{{WRAPPER}} .main-menu>ul>li>a:hover' );
		barab_color_fields( $this, 'menu_color3', 'Dropdown Color', 'color', '{{WRAPPER}} .main-menu ul.sub-menu li a' );
		barab_color_fields( $this, 'menu_color4', 'Dropdown Hover Color', 'color', '{{WRAPPER}} .main-menu ul.sub-menu li a:hover' );
		barab_color_fields( $this, 'menu_color5', 'Menu Icon Color', 'color', '{{WRAPPER}} .main-menu ul.sub-menu li a:before, {{WRAPPER}} .main-menu ul li.menu-item-has-children > a:after' );

		barab_typography_fields( $this, 'menu_font', 'Menu Trpography', '{{WRAPPER}} .main-menu>ul>li>a, {{WRAPPER}} .main-menu ul.sub-menu li a' );

		barab_dimensions_fields( $this, 'menu_margin', 'Menu Margin', 'margin', '{{WRAPPER}} .main-menu>ul>li>a' );
		barab_dimensions_fields( $this, 'menu_padding', 'Menu Padding', 'padding', '{{WRAPPER}} .main-menu>ul>li>a' );

		$this->end_controls_section();

		//------Button Style-------
		barab_button_style_fields( $this, '11', 'Button Styling', '{{WRAPPER}} .th-btn', ['1', '4'] );

    }

    public function barab_menu_select(){
	    $barab_menu = wp_get_nav_menus();
	    $menu_array  = array();
		$menu_array[''] = __( 'Select A Menu', 'barab' );
	    foreach( $barab_menu as $menu ){
	        $menu_array[ $menu->slug ] = $menu->name;
	    }
	    return $menu_array;
	}

	protected function render() {

        $settings = $this->get_settings_for_display();

		global $woocommerce;

        //Menu by menu select
        $barab_avaiable_menu   = $this->barab_menu_select();
		if( ! $barab_avaiable_menu ){
			return;
		}
		$args = [
			'menu' 			=> $settings['barab_menu_select'],
			'menu_class' 	=> 'barab-menu',
			'container' 	=> '',
		];

		//Mobile menu, Offcanvas, Search
        echo barab_mobile_menu();
		if( class_exists( 'woocommerce' ) ){
			if(!empty($settings['show_cart_btn'])){
				echo barab_header_cart_offcanvas();
			}
		}
		if(!empty( $settings['show_offcanvas_btn'])){
			echo barab_header_offcanvas();
		}
		if(!empty( $settings['show_search_btn'])){
			echo barab_search_box();
		}
		// Header sub-menu icon
		if( class_exists( 'ReduxFramework' ) ){ 
			if(barab_opt('barab_header_sticky')){
                $sticky = '';
            }else{
                $sticky = '-no';
            }

			if(barab_opt('barab_menu_icon')){
				$menu_icon = '';
			}else{
				$menu_icon = 'hide-icon';
			}
		}

		if( $settings['layout_style'] == '1' ){
			echo '<div class="th-header header-default style-2 onepage-nav">';
				echo '<div class="sticky-wrapper'.esc_attr($sticky).'">';
					echo '<div class="menu-area">';
						echo '<div class="container">';
							echo '<div class="row align-items-center justify-content-between">';
								echo '<div class="col-auto">';
									echo '<div class="header-logo">';
										echo '<a href="'.esc_url( home_url( '/' ) ).'">';
											echo barab_img_tag( array(
												'url'   => esc_url( $settings['logo_image']['url'] ),
											));
										echo '</a>';
									echo '</div>';
								echo '</div>';
								echo '<div class="col-auto">';
									echo '<nav class="main-menu d-none d-lg-inline-block '.esc_attr($menu_icon).'">';
										if( ! empty( $settings['barab_menu_select'] ) ){
											wp_nav_menu( $args );
										}else{
											wp_nav_menu( array(
												"theme_location"    => 'primary-menu',
												"container"         => '',
												"menu_class"        => ''
											) );
										}
									echo '</nav>';
									echo '<div class="header-button d-flex d-lg-none">';
										if(!empty($settings['show_cart_btn'])){
											if( class_exists( 'woocommerce' ) ){
												global $woocommerce;
												if( ! empty( $woocommerce->cart->cart_contents_count ) ){
													$count = $woocommerce->cart->cart_contents_count;
												}else{
													$count = "0";
												}
												echo '<button type="button" class="icon-btn sideMenuToggler">';
													echo '<span class="badge cart_badge">'.esc_html( $count ).'</span>';
													echo '<i class="fa-regular fa-cart-shopping"></i>';
												echo '</button>';
											}
										}
										echo '<button type="button" class="icon-btn th-menu-toggle"><i class="far fa-bars"></i></button>';
									echo '</div>';
								echo '</div>';
								echo '<div class="col-auto d-none d-xl-block">';
									echo '<div class="header-button">';
										if(!empty($settings['show_search_btn'])){
											echo '<button type="button" class="icon-btn searchBoxToggler"><i class="far fa-search"></i></button>';
										}
										if(!empty($settings['show_cart_btn'])){
											if( class_exists( 'woocommerce' ) ){
												global $woocommerce;
												if( ! empty( $woocommerce->cart->cart_contents_count ) ){
													$count = $woocommerce->cart->cart_contents_count;
												}else{
													$count = "0";
												}
												echo '<button type="button" class="icon-btn sideMenuToggler">';
													echo '<span class="badge cart_badge">'.esc_html( $count ).'</span>';
													echo '<i class="fa-regular fa-cart-shopping"></i>';
												echo '</button>';
											}
										}
										if(!empty( $settings['button_text'])){
											echo '<a '.barab_link_attrs($settings['button_url']).' class="th-btn btn-mask">'.esc_html($settings['button_text']).'</a>';
										}
									echo '</div>';
								echo '</div>';
							echo '</div>';
						echo '</div>';
					echo '</div>';
				echo '</div>';
			echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
			echo '<div class="th-header header-default style-3 onepage-nav">';
				echo '<div class="sticky-wrapper'.esc_attr($sticky).'">';
					echo '<!-- Main Menu Area -->';
					echo '<div class="menu-area">';
						echo '<div class="container-fluid">';
							echo '<div class="row align-items-center justify-content-between">';
								echo '<div class="col-auto">';
									echo '<div class="header-logo">';
										echo '<a href="'.esc_url( home_url( '/' ) ).'">';
											echo barab_img_tag( array(
												'url'   => esc_url( $settings['logo_image']['url'] ),
											));
										echo '</a>';
									echo '</div>';
								echo '</div>';
								echo '<div class="col-auto">';
									echo '<nav class="main-menu d-none d-lg-inline-block '.esc_attr($menu_icon).'">';
										if( ! empty( $settings['barab_menu_select'] ) ){
											wp_nav_menu( $args );
										}else{
											wp_nav_menu( array(
												"theme_location"    => 'primary-menu',
												"container"         => '',
												"menu_class"        => ''
											) );
										}
									echo '</nav>';
									echo '<div class="header-button d-flex d-lg-none">';
										echo '<button type="button" class="icon-btn th-menu-toggle"><i class="far fa-bars"></i></button>';
									echo '</div>';
								echo '</div>';
								echo '<div class="col-auto d-none d-xl-block">';
									echo '<div class="header-button">';
										echo '<div class="call-wrapper">';
											if($settings['icon']['url'] ){
												echo '<div class="icon">';
													echo barab_img_tag( array(
														'url'   => esc_url( $settings['icon']['url'] ),
													));
												echo '</div>';
											}
											echo '<div class="content">';
												if(!empty( $settings['label'])){
													echo '<p>'.esc_html($settings['label']).'</p>';
												}
												if(!empty( $settings['content'])){
													echo wp_kses_post($settings['content']);
												}
											echo '</div>';
										echo '</div>';
										if(!empty($settings['show_offcanvas_btn'])){
											echo '<button type="button" class="simple-icon sideMenuInfo">
												<!-- <i class="fa-solid fa-bars"></i> -->
												<div class="bar-wrap">
													<span></span>
													<span></span>
													<span></span>
												</div>
											</button>';
										}
									echo '</div>';
								echo '</div>';
							echo '</div>';
						echo '</div>';
					echo '</div>';
				echo '</div>';
			echo '</div>';

		}elseif( $settings['layout_style'] == '3' ){
			echo '<div class="th-header header-default style-3 style-4 onepage-nav">';
				if(!empty($settings['bottom_shape']['url'])){
					echo '<div class="header-4-bottom-shape">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['bottom_shape']['url'] ),
						));
					echo '</div>';
				}
				echo '<div class="sticky-wrapper'.esc_attr($sticky).'">';
					echo '<!-- Main Menu Area -->';
					echo '<div class="menu-area">';
						echo '<div class="container-fluid">';
							echo '<div class="row align-items-center justify-content-between">';
								echo '<div class="col-auto">';
									echo '<div class="header-logo">';
										echo '<a href="'.esc_url( home_url( '/' ) ).'">';
											echo barab_img_tag( array(
												'url'   => esc_url( $settings['logo_image']['url'] ),
											));
										echo '</a>';
									echo '</div>';
								echo '</div>';
								echo '<div class="col-auto">';
									echo '<nav class="main-menu d-none d-lg-inline-block '.esc_attr($menu_icon).'">';
										if( ! empty( $settings['barab_menu_select'] ) ){
											wp_nav_menu( $args );
										}else{
											wp_nav_menu( array(
												"theme_location"    => 'primary-menu',
												"container"         => '',
												"menu_class"        => ''
											) );
										}
									echo '</nav>';
									echo '<div class="header-button d-flex d-lg-none">';
										echo '<button type="button" class="icon-btn th-menu-toggle"><i class="far fa-bars"></i></button>';
									echo '</div>';
								echo '</div>';
								echo '<div class="col-auto d-none d-xl-block">';
									echo '<div class="header-button">';
										echo '<div class="call-wrapper">';
											if($settings['icon']['url'] ){
												echo '<div class="icon">';
													echo barab_img_tag( array(
														'url'   => esc_url( $settings['icon']['url'] ),
													));
												echo '</div>';
											}
											echo '<div class="content">';
												if(!empty( $settings['label'])){
													echo '<p>'.esc_html($settings['label']).'</p>';
												}
												if(!empty( $settings['content'])){
													echo wp_kses_post($settings['content']);
												}
											echo '</div>';
										echo '</div>';
										if(!empty($settings['show_offcanvas_btn'])){
											echo '<button type="button" class="simple-icon sideMenuInfo">
												<!-- <i class="fa-solid fa-bars"></i> -->
												<div class="bar-wrap">
													<span></span>
													<span></span>
													<span></span>
												</div>
											</button>';
										}
									echo '</div>';
								echo '</div>';
							echo '</div>';
						echo '</div>';
					echo '</div>';
				echo '</div>';
			echo '</div>';

		}elseif( $settings['layout_style'] == '4' ){
			echo '<div class="th-header header-default style-3 style-4 style-5 onepage-nav">';
				echo '<div class="sticky-wrapper'.esc_attr($sticky).'">';
					echo '<div class="menu-area">';
						echo '<div class="container-fluid">';
							echo '<div class="row align-items-center justify-content-between">';
								echo '<div class="col-auto">';
									echo '<div class="header-logo">';
										echo '<a href="'.esc_url( home_url( '/' ) ).'">';
											echo barab_img_tag( array(
												'url'   => esc_url( $settings['logo_image']['url'] ),
											));
										echo '</a>';
									echo '</div>';
								echo '</div>';
								echo '<div class="col-auto">';
									echo '<nav class="main-menu d-none d-lg-inline-block '.esc_attr($menu_icon).'">';
										if( ! empty( $settings['barab_menu_select'] ) ){
											wp_nav_menu( $args );
										}else{
											wp_nav_menu( array(
												"theme_location"    => 'primary-menu',
												"container"         => '',
												"menu_class"        => ''
											) );
										}
									echo '</nav>';
									echo '<div class="header-button d-flex d-lg-none">';
										if(!empty($settings['show_cart_btn'])){
											if( class_exists( 'woocommerce' ) ){
												global $woocommerce;
												if( ! empty( $woocommerce->cart->cart_contents_count ) ){
													$count = $woocommerce->cart->cart_contents_count;
												}else{
													$count = "0";
												}
												echo '<button type="button" class="icon-btn sideMenuToggler">';
													echo '<span class="badge cart_badge">'.esc_html( $count ).'</span>';
													echo '<i class="fa-regular fa-cart-shopping"></i>';
												echo '</button>';
											}
										}
										echo '<button type="button" class="icon-btn th-menu-toggle"><i class="far fa-bars"></i></button>';
									echo '</div>';
								echo '</div>';
								echo '<div class="col-auto d-none d-xl-block">';
									echo '<div class="header-button">';
										if(!empty($settings['show_search_btn'])){
											echo '<button type="button" class="icon-btn searchBoxToggler"><i class="far fa-search"></i></button>';
										}
										if(!empty($settings['show_cart_btn'])){
											if( class_exists( 'woocommerce' ) ){
												global $woocommerce;
												if( ! empty( $woocommerce->cart->cart_contents_count ) ){
													$count = $woocommerce->cart->cart_contents_count;
												}else{
													$count = "0";
												}
												echo '<button type="button" class="icon-btn sideMenuToggler">';
													echo '<span class="badge cart_badge">'.esc_html( $count ).'</span>';
													echo '<i class="fa-regular fa-cart-shopping"></i>';
												echo '</button>';
											}
										}
										if(!empty( $settings['button_text'])){
											echo '<a '.barab_link_attrs($settings['button_url']).' class="th-btn btn-mask">'.esc_html($settings['button_text']).'</a>';
										}
									echo '</div>';
								echo '</div>';
							echo '</div>';
						echo '</div>';
					echo '</div>';
					if(!empty($settings['bottom_shape']['url'])){
						echo '<div class="hero-5-top-shape">';
							echo barab_img_tag( array(
								'url'   => esc_url( $settings['bottom_shape']['url'] ),
							));
						echo '</div>';
					}
				echo '</div>';
			echo '</div>';

		}


	}
}