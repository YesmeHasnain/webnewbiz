<?php
namespace EARLSPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Image_Widget extends Widget_Base {
	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'earls_image_widget';
	}
	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Earls Image Widget', 'earls' );
	}
	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-image-hotspot';
	}
	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'earls' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'image_widget',
			[
				'label' => esc_html__( 'Earls Image Widget', 'earls' ),
			]
		);
		
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'earls' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'earls'),
					'2' => esc_html__( 'Style Two ', 'earls'),
					'3' => esc_html__( 'Style Three ', 'earls'),
				),
			]
		);
		
		$this->add_control(
			'image',
			[
				'label' => esc_html__( 'Choose Image', 'elementor' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		
		$this->end_controls_section();
		
    }
	
	/**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post'); 
		$layout = $settings[ 'layout_control' ];
	?>
		<?php if($layout == '3'): ?>
		<!-- menu-banner --> 
        <section class="menu__banner__page m-0" >
            <div class="bg-layer parallax-bg" data-parallax='{"y": 50}' style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>);"></div>
         </section>
         <!-- menu-banner end -->
		
		<?php elseif($layout == '2'): ?>
        
        <section class="food__section p-0 m-0">
        	<div class="food__right__img " style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>);">
                <div class="food__right__img_feature_image">
                    <img class="d-block " src="<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','earls');?>">
                </div>
            </div>
        </section>
        
        <?php else: ?>
        <!-- team-text-section --> 
        <section class="team__text__slider two p-0 m-0">
            <div class="team__text__slider__left p_relative wow zoomIn animated" data-wow-delay="00ms" data-wow-duration="1500ms" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>);">
                <div class="team__left__feture__img">
                    <img class="d-block  " src="<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','earls');?>">
                </div>
            </div>
        </section>
        
    <?php endif; 
	}
}