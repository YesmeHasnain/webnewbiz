<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * CTA Widget .
 *
 */
class barab_Cta extends Widget_Base {

	public function get_name() {
		return 'barabcta';
	}
	public function get_title() {
		return __( 'CTA', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_title_section',
			[
				'label'		 	=> __( 'CTA', 'barab' ),
				'tab' 			=> Controls_Manager::TAB_CONTENT, 
				
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two', 'Style Three', 'Style Four' ] );

		barab_general_fields( $this, 'subtitle', 'Subtitle', 'TEXTAREA2', 'save up to 50%', ['1', '4'] );
		barab_general_fields( $this, 'title', 'Title', 'TEXTAREA2', 'Super', ['1', '4'] );
		barab_general_fields( $this, 'title2', 'Title 2', 'TEXTAREA2', 'Burger', ['1', '4'] );
		barab_general_fields( $this, 'desc', 'Description', 'TEXTAREA2', 'Limited Time Offer', ['1', '4'] );

		barab_media_fields( $this, 'image', 'Choose Image', ['1', '4'] );
		barab_media_fields( $this, 'image2', 'Choose Image', ['1', '4'] );
		barab_media_fields( $this, 'section_curve_shape', 'Section Curve Shape', ['1', '4'] );

		barab_switcher_fields( $this, 'show_date', 'Show Countdown?', ['1', '4'] );
		
        $this->add_control(
			'date', [
				'label' 		=> __( 'Offer End Date With Time', 'barab' ),
				'type' 			=> Controls_Manager::DATE_TIME,
				'label_block' 	=> true,
				'condition'	=> [
					'layout_style' => ['1', '4']
				]
			]
        );

		$repeater = new Repeater();

		barab_media_fields( $repeater, 'bg', 'Choose Background' );
		barab_media_fields( $repeater, 'image', 'Choose Image' );
		barab_media_fields( $repeater, 'image2', 'Choose Image 2' );
		barab_general_fields($repeater, 'button_text', 'Button Text', 'TEXT', 'ORDER NOW');
		barab_url_fields($repeater, 'button_url', 'Button URL');

		$this->add_control(
			'cta_lists',
			[
				'label' 		=> __( 'Cta Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'condition'		=> [ 
					'layout_style' => [ '2' ],
				],
			]
		);

		$repeater = new Repeater();

		barab_general_fields( $repeater, 'subtitle', 'Subtitle', 'TEXTAREA2', 'Super Delicious' );
		barab_general_fields( $repeater, 'title', 'Title', 'TEXTAREA2', 'BURGER' );
		barab_general_fields( $repeater, 'desc', 'Content', 'TEXTAREA2', 'Today Special Menu' );
		barab_general_fields( $repeater, 'offer', 'Offer Content', 'TEXTAREA2', '40%' );

		barab_general_fields($repeater, 'button_text', 'Button Text', 'TEXT', 'ORDER NOW');
		barab_url_fields($repeater, 'button_url', 'Button URL');
		barab_media_fields( $repeater, 'image', 'Choose Image' );
		barab_media_fields( $repeater, 'image2', 'Choose Arrow image' );

		$this->add_control(
			'cta_lists2',
			[
				'label' 		=> __( 'Cta Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'condition'		=> [ 
					'layout_style' => [ '3' ],
				],
			]
		);

			
        $this->end_controls_section();

		// Column Responsive controls
		if ( function_exists( 'barab_add_responsive_columns_controls' ) ) {
			barab_add_responsive_columns_controls( $this, ['layout_style' => ['2'] ] );
		}

        //---------------------------------------
			//Style Section Start
		//--------------------------------------- 

		barab_common_style_fields( $this, '010', 'Subtitle', '{{WRAPPER}} .coming-top-title', ['1', '4'] );
		barab_common_style_fields( $this, '011', 'Title', '{{WRAPPER}} .coming-middle-title', ['1', '4'] );
		barab_common_style_fields( $this, '012', 'Title 2', '{{WRAPPER}} .coming-title', ['1', '4'] );
		barab_common_style_fields( $this, '013', 'Description', '{{WRAPPER}} .box-text', ['1', '4'] );

		barab_common_style_fields( $this, '021', 'Number', '{{WRAPPER}} .count-number', ['1', '4'] );
		barab_common_style_fields( $this, '022', 'Text', '{{WRAPPER}} .count-name', ['1', '4'] );
		//------Button Style-------
		barab_button_style_fields( $this, '10', 'Button Styling', '{{WRAPPER}} .th-btn', ['2'] );

	}

	protected function render() {

	$settings = $this->get_settings_for_display();

		if( $settings['layout_style'] == '1' ){
			$offer_date_end = $settings['date'];
            $replace 	= array('-');
            $with 		= array('/');
    
            $date 	= str_replace( $replace, $with, $offer_date_end );

			echo '<div class="coming-soon-sec-1 bg-theme3 overflow-hidden">';
				echo barab_img_tag( array(
					'url'   => esc_url( $settings['section_curve_shape']['url'] ),
					'class' => 'round-shape-top'
				));
				echo '<div class="container">';
					echo '<div class="row gy-40 align-items-center">';
						echo '<div class="col-xl-4 col-lg-4">';
							if(!empty($settings['image']['url'])){
								echo '<div class="coming-left">';
									echo barab_img_tag( array(
										'url'   => esc_url( $settings['image']['url'] ),
									));
								echo '</div>';
							}
						echo '</div>';

						echo '<div class="col-xl-4 col-lg-4">';
							echo '<div class="coming-soon">';
								if(!empty($settings['subtitle'])){
									echo '<h5 class="coming-top-title text-anime-style-2">'.wp_kses_post($settings['subtitle']).'</h5>';
								}
								if(!empty($settings['title'])){
									echo '<h2 class="coming-middle-title text-anime-style-1">'.wp_kses_post($settings['title']).'</h2>';
								}
								if(!empty($settings['title2'])){
									echo '<h2 class="coming-title text-anime-style-1">'.wp_kses_post($settings['title2']).'</h2>';
								}
								echo '<div class="upcoming-counter-wrap">';
									if(!empty($settings['desc'])){
										echo '<p class="box-text wow fadeinleft">'.wp_kses_post($settings['desc']).'</p>';
									}
									if($settings['show_date'] == 'yes'){
										echo '<ul class="upcoming-counter counter-list" data-offer-date="'.esc_attr($date).'">';
											echo '<li class="wow fadeinup" data-wow-delay=".4s">';
												echo '<div class="day count-number">00</div>';
												echo '<span class="count-name">'.esc_html__('Days', 'barab').'</span>';
											echo '</li>';
											echo '<li class="wow fadeinup" data-wow-delay=".5s">';
												echo '<div class="hour count-number">00</div>';
												echo '<span class="count-name">'.esc_html__('Hours', 'barab').'</span>';
											echo '</li>';
											echo '<li class="wow fadeinup" data-wow-delay=".6s">';
												echo '<div class="minute count-number">00</div>';
												echo '<span class="count-name">'.esc_html__('Minutes', 'barab').'</span>';
											echo '</li>';
											echo '<li class="wow fadeinup" data-wow-delay=".7s">';
												echo '<div class="seconds count-number">00</div>';
												echo '<span class="count-name">'.esc_html__('Seconds', 'barab').'</span>';
											echo '</li>';
										echo '</ul>';
									}
								echo '</div>';
							echo '</div>';
						echo '</div>';

						echo '<div class="col-xl-4 col-lg-4">';
							if(!empty($settings['image2']['url'])){
								echo '<div class="coming-right wow fadeinright">';
									echo barab_img_tag( array(
										'url'   => esc_url( $settings['image2']['url'] ),
									));
								echo '</div>';
							}
						echo '</div>';
					echo '</div>';
				echo '</div>';
			echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
			// Get Column Responsive controls Class
			if ( function_exists( 'barab_get_responsive_columns_class' ) ) {
				$column_class = barab_get_responsive_columns_class( $settings );
			} else {
				$column_class = 'ccol-xl-6 col-lg-12';
			}

			echo '<div class="row gy-40">';
				foreach( $settings['cta_lists'] as $key => $data ){
					$delay = number_format(0.4 + (floor($key / 2) * 0.2), 1);
					$animation = ($key % 2 == 0) ? 'fadeinleft' : 'fadeinright';

					echo '<div class="' . esc_attr( $column_class ) . '">';
						echo '<div class="cta-card-2-wrap wow ' . esc_attr($animation) . '" data-wow-delay="' . $delay . 's" data-bg-src="'.esc_url( $data['bg']['url'] ).'">';
							echo '<div class="card-content">';
								echo barab_img_tag( array(
									'url'   => esc_url( $data['image']['url'] ),
								));
								if(!empty($data['button_text'])){
									echo '<a '.barab_link_attrs($data['button_url']).' class="th-btn btn-mask th-btn">'.wp_kses_post( $data['button_text'] ).'</a>';
								}
							echo '</div>';
							if($data['image2']['url'] ){
								echo '<div class="card-thumb tilt-active">';
									echo barab_img_tag( array(
										'url'   => esc_url( $data['image2']['url'] ),
									));
								echo '</div>';
							}
						echo '</div>';
					echo '</div> ';
				}
            echo '</div>';

		}elseif( $settings['layout_style'] == '3' ){
			echo '<div class="row g-0 justify-content-center">';
				foreach( $settings['cta_lists2'] as $key => $data ){
					echo '<div class="col-xl-4 col-lg-6 col-md-12 offer-box3-wrap">';
						echo '<div class="offer-box3">';
							if(!empty($data['subtitle'])){
								echo '<h4 class="box-title">'.esc_html($data['subtitle']).'</h4>';
							}
							if(!empty($data['title'])){
								echo '<h3 class="sect-tile">'.esc_html($data['title']).'</h3>';
							}
							if(!empty($data['desc'])){
								echo '<p class="box-text">'.esc_html($data['desc']).'</p>';
							}
							if(!empty($data['button_text'])){
								echo '<a '.barab_link_attrs($data['button_url']).' class="th-btn btn-sm bg-black th-btn">'.esc_html( $data['button_text'] ).'</a>';
							}
							if(!empty($data['offer'])){
							echo '<div class="offer-3-wrap">';
								echo '<div class="offer-3">';
									echo '<h4 class="box-title">'.esc_html($data['offer']).'</h4>';
								echo '</div>';
							echo '</div>';
							}
							if($data['image']['url'] ){
								echo '<div class="cta-img3-1">';
									echo barab_img_tag( array(
										'url'   => esc_url( $data['image']['url'] ),
									));
								echo '</div>';
							}
							if($data['image2']['url'] ){
								echo '<div class="cta-3-icon">';
									echo barab_img_tag( array(
										'url'   => esc_url( $data['image2']['url'] ),
									));
								echo '</div>';
							}
						echo '</div>';
					echo '</div>';
				} 
            echo '</div>';
	
		}elseif( $settings['layout_style'] == '4' ){
			$offer_date_end = $settings['date'];
            $replace 	= array('-');
            $with 		= array('/');
    
            $date 	= str_replace( $replace, $with, $offer_date_end );

			echo '<div class="coming-soon-sec-1 bg-theme overflow-hidden">';
				echo barab_img_tag( array(
					'url'   => esc_url( $settings['section_curve_shape']['url'] ),
					'class' => 'round-shape-top'
				));
				echo '<div class="container">';
					echo '<div class="row gy-40 align-items-center">';
						echo '<div class="col-xl-4 col-lg-4">';
							if(!empty($settings['image']['url'])){
								echo '<div class="coming-left">';
									echo barab_img_tag( array(
										'url'   => esc_url( $settings['image']['url'] ),
									));
								echo '</div>';
							}
						echo '</div>';

						echo '<div class="col-xl-4 col-lg-4">';
							echo '<div class="coming-soon style-2">';
								if(!empty($settings['subtitle'])){
									echo '<h5 class="coming-top-title text-anime-style-2">'.wp_kses_post($settings['subtitle']).'</h5>';
								}
								if(!empty($settings['title'])){
									echo '<h2 class="coming-middle-title text-anime-style-1">'.wp_kses_post($settings['title']).'</h2>';
								}
								if(!empty($settings['title2'])){
									echo '<h2 class="coming-title text-anime-style-1 ">'.wp_kses_post($settings['title2']).'</h2>';
								}
								echo '<div class="upcoming-counter-wrap">';
									if(!empty($settings['desc'])){
										echo '<p class="box-text wow fadeinleft">'.wp_kses_post($settings['desc']).'</p>';
									}
									if($settings['show_date'] == 'yes'){
										echo '<ul class="upcoming-counter counter-list" data-offer-date="'.esc_attr($date).'">';
											echo '<li class="wow fadeinup" data-wow-delay=".4s">';
												echo '<div class="day count-number">00</div>';
												echo '<span class="count-name">'.esc_html__('Days', 'barab').'</span>';
											echo '</li>';
											echo '<li class="wow fadeinup" data-wow-delay=".5s">';
												echo '<div class="hour count-number">00</div>';
												echo '<span class="count-name">'.esc_html__('Hours', 'barab').'</span>';
											echo '</li>';
											echo '<li class="wow fadeinup" data-wow-delay=".6s">';
												echo '<div class="minute count-number">00</div>';
												echo '<span class="count-name">'.esc_html__('Minutes', 'barab').'</span>';
											echo '</li>';
											echo '<li class="wow fadeinup" data-wow-delay=".7s">';
												echo '<div class="seconds count-number">00</div>';
												echo '<span class="count-name">'.esc_html__('Seconds', 'barab').'</span>';
											echo '</li>';
										echo '</ul>';
									}
								echo '</div>';
							echo '</div>';
						echo '</div>';

						echo '<div class="col-xl-4 col-lg-4">';
							if(!empty($settings['image2']['url'])){
								echo '<div class="coming-right style-2 wow fadeinright">';
									echo barab_img_tag( array(
										'url'   => esc_url( $settings['image2']['url'] ),
									));
								echo '</div>';
							}
						echo '</div>';
					echo '</div>';
				echo '</div>';
			echo '</div>';

		}
		

	}

}