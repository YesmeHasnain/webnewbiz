<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Utils;
/**
 *
 * Blog Post Widget .
 *
 */
class Barab_Blog_Page extends Widget_Base {

	public function get_name() {
		return 'barabblogpage'; 
	}
	public function get_title() {
		return __( 'Blog Post with Pagination', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'blog_post_section',
			[
				'label' => __( 'Blog Post', 'barab' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

        barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style Grid' ] );

        $this->add_control(
			'blog_post_count',
			[
				'label' 	=> __( 'No of Post to show', 'barab' ),
                'type' 		=> Controls_Manager::NUMBER,
                'min'       => 1,
                'max'       => count( get_posts( array('post_type' => 'post', 'post_status' => 'publish', 'fields' => 'ids', 'posts_per_page' => '-1') ) ),
                'default'  	=> __( '3', 'barab' )
			]
        );

        barab_general_fields( $this, 'title_count', 'Title Length', 'TEXT2', '6' );
        barab_general_fields( $this, 'excerpt_count', 'Excerpt Length', 'TEXT2', '14' );

        $this->add_control(
			'blog_post_order',
			[
				'label' 	=> __( 'Order', 'barab' ),
                'type' 		=> Controls_Manager::SELECT,
                'options'   => [
                    'ASC'   	=> __('ASC','barab'),
                    'DESC'   	=> __('DESC','barab'),
                ],
                'default'  	=> 'DESC'
			]
        );
        $this->add_control(
			'blog_post_order_by',
			[
				'label' 	=> __( 'Order By', 'barab' ),
                'type' 		=> Controls_Manager::SELECT,
                'options'   => [
                    'ID'    	=> __( 'ID', 'barab' ),
                    'author'    => __( 'Author', 'barab' ),
                    'title'    	=> __( 'Title', 'barab' ),
                    'date'    	=> __( 'Date', 'barab' ),
                    'rand'    	=> __( 'Random', 'barab' ),
                ],
                'default'  	=> 'date'
			]
        );
        $this->add_control(
            'blog_post_cats',
            [
                'label'    => __( 'Select Categories (Show Category Posts)', 'barab' ),
                'type'     => Controls_Manager::SELECT2,
                'multiple' => true,
                'options'  => $this->barab_get_categories(),
                'default'  => [], // Default to no categories selected
                'label_block' => true,
            ]
        );

        // Get all registered image sizes
        $image_sizes = get_intermediate_image_sizes(); 
        $options = [];
        foreach ( $image_sizes as $size ) {
            $options[ $size ] = ucfirst( str_replace( '_', ' ', $size ) );
        }
        $this->add_control(
            'image_resolution',
            [
                'label'       => __( 'Image Resolution', 'barab' ),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'default'     => 'large',
                'options'     => $options,
            ]
        ); 

        // barab_switcher_fields( $this, 'show_post_meta_icons', 'Display Post Meta Icons?' );
        barab_switcher_fields( $this, 'show_author', 'Display Post Author?' );
        barab_switcher_fields( $this, 'show_date', 'Display Post Date?' );
        barab_switcher_fields( $this, 'show_category', 'Display Post Category?' );
        barab_switcher_fields( $this, 'show_comment', 'Display Post Comment?' );
        barab_switcher_fields( $this, 'show_min_read', 'Display Read Minute?' );

        barab_general_fields( $this, 'button_text', 'Read More Text', 'TEXTAREA2', 'Read More' );

        $options = [
            ''   => esc_html__('Default', 'barab'),
            '12' => '1 Column',
            '6'  => '2 Column',
            '4'  => '3 Column',
            '3'  => '4 Column',
            '2'  => '6 Column',
        ];

        $this->add_control(
            'col_xl',
            [
                'label'   => esc_html__('Extra large Column', 'barab'),
                'type'    => Controls_Manager::SELECT,
                'options' => $options,
                'default' => '3',
                'description' => esc_html__('Screen width: 1200px and above (desktops, large monitors)', 'barab'),
            ]
        );
        $this->add_control(
            'col_lg',
            [
                'label'   => esc_html__('Large Column', 'barab'),
                'type'    => Controls_Manager::SELECT,
                'options' => $options,
                'default' => '4',
                'description' => esc_html__('Screen width: 992px to 1199px (standard desktops)', 'barab'),
            ]
        );
        $this->add_control(
            'col_md',
            [
                'label'   => esc_html__('Medium Column', 'barab'),
                'type'    => Controls_Manager::SELECT,
                'options' => $options,
                'default' => '6',
                'description' => esc_html__('Screen width: 768px to 991px (tablets)', 'barab'),
            ]
        );
        $this->add_control(
            'col_sm',
            [
                'label'   => esc_html__('Small Column', 'barab'),
                'type'    => Controls_Manager::SELECT,
                'options' => $options,
                'default' => '6',
                'description' => esc_html__('Screen width: 576px to 767px (mobile landscape)', 'barab'),
            ]
        );
        $this->add_control(
            'col_xs',
            [
                'label'   => esc_html__('Extra small Column', 'barab'),
                'type'    => Controls_Manager::SELECT,
                'options' => $options,
                'default' => '12',
                'description' => esc_html__('Screen width: less than 576px (mobile phones)', 'barab'),
            ]
        );

        $this->add_responsive_control(
			'section_align',
			[
				'label' 		=> __( 'Pagination Alignment', 'barab' ),
				'type' 			=> Controls_Manager::CHOOSE,
				'options' 		=> [
					'left' 	=> [
						'title' 		=> __( 'Left', 'barab' ),
						'icon' 			=> 'eicon-text-align-left',
					],
					'center' 	=> [
						'title' 		=> __( 'Center', 'barab' ),
						'icon' 			=> 'eicon-text-align-center',
					],
					'right' 	=> [
						'title' 		=> __( 'Right', 'barab' ),
						'icon' 			=> 'eicon-text-align-right',
					],
				],
				'default' 	=> '',
				'toggle' 	=> true,
			]
		);
        
        $this->end_controls_section();

		//---------------------------------------
			//Style Section Start
		//--------------------------------------- 

		barab_common2_style_fields( $this, '01', 'Title', '{{WRAPPER}} .box-title a' );
		barab_common_style_fields( $this, '02', 'Content', '{{WRAPPER}} .box-text' );

        //-------Meta Style-------
		$this->start_controls_section(
			'meta_styling',
			[
				'label'     => __( 'Meta Styling', 'barab' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
        );

		barab_color_fields( $this, '002', 'Meta Icon Color', 'color', '{{WRAPPER}} .blog-meta a i' );
		barab_color_fields( $this, '003', 'Meta Color', 'color', '{{WRAPPER}} .blog-meta a' );
		barab_color_fields( $this, '004', 'Meta Hover Color', 'color', '{{WRAPPER}} .blog-meta a:hover' );        

		$this->end_controls_section();

		//------Button Style-------
        $this->start_controls_section(
			'button_styling',
			[
				'label'     => __( 'Button Styling', 'barab' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
        );

		barab_color_fields( $this, '0001', 'Color', '--title-color', '{{WRAPPER}} .link-btn' );
		barab_color_fields( $this, '0002', 'Hover Color', '--theme-color', '{{WRAPPER}} .link-btn:hover' );                

		$this->end_controls_section();

    }

    public function barab_get_categories() {
        $cats = get_terms(array(
            'taxonomy' => 'category',
            'hide_empty' => true,
        ));
        $cat = [];
        foreach( $cats as $singlecat ) {
            $cat[$singlecat->slug] = __($singlecat->name, 'barab');
        }
        return $cat;
    }    
   
    protected function render_blog_meta($settings) {
        echo '<div class="blog-meta">';
            if ( ! empty( $settings['show_author'] ) ) {
                echo '<a class="author" href="' . esc_url( get_author_posts_url( get_the_author_meta('ID') ) ) . '">';
                if ( ! empty( $settings['show_post_meta_icons'] ) ) {
                    echo '<i class="far fa-user"></i>';
                }
                echo esc_html__( 'By ', 'barab' ) . esc_html( ucwords( get_the_author() ) );
                echo '</a>';
            }
            // if ( ! empty( $settings['show_date'] ) ) {
            //     echo '<a href="' . esc_url( barab_blog_date_permalink() ) . '">';
            //     if ( ! empty( $settings['show_post_meta_icons'] ) ) {
            //         echo '<i class="far fa-calendar"></i>';
            //     }
            //     echo esc_html( get_the_date() );
            //     echo '</a>';
            // }
            if ( ! empty( $settings['show_category'] ) ) {
                $categories = get_the_category();
                if ( ! empty( $categories ) ) {
                    echo '<a class="author" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">';
                    if ( ! empty( $settings['show_post_meta_icons'] ) ) {
                        echo '<i class="far fa-tag"></i>';
                    }
                    echo esc_html( $categories[0]->name );
                    echo '</a>';
                }
            }
            if ( ! empty( $settings['show_comment'] ) ) {
                echo '<span class="author">';
                if ( ! empty( $settings['show_post_meta_icons'] ) ) {
                    echo '<i class="far fa-comments"></i>';
                }
                echo get_comments_number() . ' ' . esc_html__( 'Comments', 'barab' );
                echo '</span>';
            }
            if ( ! empty( $settings['show_min_read'] ) ) {
                $content = get_post_field( 'post_content', get_the_ID() );
                $word_count = str_word_count( strip_tags( $content ) );
                $read_time = ceil( $word_count / 200 ); // Assuming 200 wpm
                echo '<span class="author">';
                    if ( ! empty( $settings['show_post_meta_icons'] ) ) {
                        echo '<i class="far fa-clock"></i>';
                    }
                    echo esc_html( $read_time ) . esc_html__( ' min read', 'barab' );
                echo '</span>';
            }
        echo '</div>';
    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        if (isset($settings['section_align'])) {
            if ($settings['section_align'] == 'left') {
                $wrap_align_class = 'text-left';
            } elseif ($settings['section_align'] == 'center') {
                $wrap_align_class = 'text-center';
            } elseif ($settings['section_align'] == 'right') {
                $wrap_align_class = 'text-end';
            } else {
                $wrap_align_class = '';
            }
        } else {
            // Default value if 'section_align' is not set
            $wrap_align_class = 'text-left';
        }
 
        // Get the dynamic image resolution setting
        $image_resolution = !empty($settings['image_resolution']) ? $settings['image_resolution'] : 'large';

        $classes = [];

        if (!empty($settings['col_xl'])) {
            $classes[] = 'col-xl-' . $settings['col_xl'];
        }
        if (!empty($settings['col_lg'])) {
            $classes[] = 'col-lg-' . $settings['col_lg'];
        }
        if (!empty($settings['col_md'])) {
            $classes[] = 'col-md-' . $settings['col_md'];
        }
        if (!empty($settings['col_sm'])) {
            $classes[] = 'col-sm-' . $settings['col_sm'];
        }
        if (!empty($settings['col_xs'])) {
            $classes[] = 'col-' . $settings['col_xs'];
        }
        if (empty($classes)) {
            $classes[] = 'col-12';
        }

        $column_class = implode(' ', $classes);

		if( $settings['layout_style'] == '1' || $settings['layout_style'] == '2' ){
            echo '<div class="row">';
                $blog_post_query_paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

                $blog_post_query_args = array(
                    'post_type' => 'post', 
                    'post_status' => 'publish',
                    'ignore_sticky_posts' => true,
                    'order'   => $settings['blog_post_order'],
                    'orderby' => $settings['blog_post_order_by'],
                    'posts_per_page' => $settings['blog_post_count'],
                    'paged'          => $blog_post_query_paged,
                );
                
                // Check if categories are selected in Elementor settings
                if ( !empty( $settings['blog_post_cats'] ) ) {
                    $blog_post_query_args['tax_query'] = array(
                        array(
                            'taxonomy' => 'category',
                            'field'    => 'slug',
                            'terms'    => $settings['blog_post_cats'], 
                            'operator' => 'IN',
                        )
                    );
                }

                // Run the query with the arguments
                $blog_post_query = new WP_Query( $blog_post_query_args );
            

                while ($blog_post_query->have_posts()) {
                    $blog_post_query->the_post();
                    $categories = get_the_category(); 

                    echo '<div class="' . esc_attr($column_class) . '">';
                        echo '<div class="th-blog blog-single has-post-thumbnail single-grid">';
                            echo '<div class="blog-img global-img">';
                                echo '<a href="'.esc_url( get_permalink() ).'">';
                                    the_post_thumbnail( $image_resolution );
                                echo '</a>';                              
                            echo '</div>';
                            echo '<div class="blog-content">';
                                // blog meta render
                                $this->render_blog_meta($settings);

                                echo '<h3 class="box-title"><a href="'.esc_url( get_permalink() ).'">'.esc_html( wp_trim_words( get_the_title( ), $settings['title_count'], '' ) ).'</a></h3>';

                                $content = wp_trim_words( get_the_content(), $settings['excerpt_count'], '' );
                                if ( !empty( $content ) ) {
                                    echo '<p class="box-text mb-3">'. esc_html( $content ) .'</p>';
                                }
                                echo '<div class="btn-group justify-content-between">';
                                    if(!empty($settings['button_text'])){
                                        echo '<a href="'.esc_url( get_permalink() ).'" class="th-btn th-border">'.esc_html($settings['button_text']).'</a>';
                                    }
                                    if ( ! empty( $settings['show_date'] ) ) {
                                        echo '<div class="blog-date">';
                                            echo '<span class="date">' . get_the_date('d') . '</span>';
                                            echo '<span class="month">' . strtoupper( get_the_date('F Y') ) . '</span>';
                                        echo '</div>';
                                    }
                                echo '</div>';
                            echo '</div>';
                        echo '</div>';
                    echo '</div>';
                }
                echo '<div class="'.esc_attr($wrap_align_class).'">'; 
                        barab_custom_query_pagination($blog_post_query_paged, $blog_post_query->max_num_pages);
                echo '</div>';

                wp_reset_postdata(); 

            echo '</div>';

		}elseif( $settings['layout_style'] == '3' ){


        }
	
      
	}
}