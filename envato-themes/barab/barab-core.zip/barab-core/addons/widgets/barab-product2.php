<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Product Widget .
 *
 */
class Barab_Product2 extends Widget_Base {

	public function get_name() {
		return 'barabproduct2';
	}
	public function get_title() {
		return __( 'Product Slider', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'arrow_section',
			[
				'label'     => __( 'Product Slider', 'barab' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two' ] ); 

        barab_general_fields($this, 'subtitle', 'Section Subtitle', 'TEXTAREA2', 'Our Delicious Pizzas', ['1', '2'] );
		barab_general_fields($this, 'title', 'Section Title', 'TEXTAREA', 'Our Signature Pizza', ['1', '2'] );
        barab_media_fields( $this, 'shape_bottom', 'Choose Shape Bottom', ['2'] );

        $this->add_control(
			'product_count',
			[
				'label' 		=> __( 'Product Count', 'barab' ),
				'type' 			=> Controls_Manager::NUMBER,
				'min' 			=> 1,
				'max' 			=> 50,
				'step' 			=> 1,
				'default' 		=> 4,
			]
		);
        $this->add_control(
            'order',
            [
                'label'   => __( 'Order', 'barab' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'DESC', // Default value
                'options' => [
                    'ASC'  => __( 'Ascending', 'barab' ),
                    'DESC' => __( 'Descending', 'barab' ),
                ],
            ]
        );
        $this->add_control(
            'orderby',
            [
                'label'   => __( 'Order By', 'barab' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'date', // Default value
                'options' => [
                    'title'        => __( 'Title', 'barab' ),
                    'date'         => __( 'Date', 'barab' ),
                    'ID'           => __( 'ID', 'barab' ),
                    'modified'     => __( 'Modified', 'barab' ),
                    'rand'         => __( 'Random', 'barab' ),
                ],
            ]
        );
        // Add a control to select either "Category" or "Tag"
        $this->add_control(
            'product_type',
            [
                'label'       => __( 'Product Show By', 'barab' ),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'default'     => 'all', // Default to show all products if none selected
                'options'     => [
                    'all'       => __( 'Show All Products', 'barab' ),
                    'category'  => __( 'Category', 'barab' ),
                    'tag'       => __( 'Tag', 'barab' ),
                ],
            ]
        );
        $this->add_control(
            'product_cats',
            [
                'label'       => __( 'Product Categories', 'barab' ),
                'type'        => \Elementor\Controls_Manager::SELECT2,
                'multiple'    => true,
                'label_block' => true,
                'options'     => $this->product_cats_get(),
                'condition'   => [
                    'product_type' => 'category',
                ],
            ]
        );

        $this->add_control(
            'product_tags',
            [
                'label'       => __( 'Product Tags', 'barab' ),
                'type'        => \Elementor\Controls_Manager::SELECT2,
                'multiple'    => true,
                'label_block' => true,
                'options'     => $this->product_tags_get(),
                'condition'   => [
                    'product_type' => 'tag',
                ],
            ]
        );
        // Get all registered image sizes
        $image_sizes = get_intermediate_image_sizes(); 

        $options = [];
        foreach ( $image_sizes as $size ) {
            $options[ $size ] = ucfirst( str_replace( '_', ' ', $size ) );
        }

        $this->add_control(
            'image_resolution',
            [
                'label'       => __( 'Image Resolution', 'barab' ),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'default'     => 'thumbnail',
                'options'     => $options,
            ]
        ); 

        $this->end_controls_section();

        // Swiper Slider responsive control
        barab_elementor_slider_options($this, ['1', '2']);

        //---------------------------------------
			//Style Section Start
		//---------------------------------------
		barab_common_style_fields( $this, '01', 'Section Subtitle', '{{WRAPPER}} .sub-title', ['1', '2'] );
		barab_common_style_fields( $this, '02', 'Section Title', '{{WRAPPER}} .sec-title', ['1'] );
		barab_common_style_fields( $this, '03', 'Section Title', '{{WRAPPER}} .sec-title3', ['2'] );

		barab_common2_style_fields( $this, '10', 'Product Title', '{{WRAPPER}} .box-title a', ['1', '2'] );
		barab_common_style_fields( $this, '11', 'Product Price', '{{WRAPPER}} .woocommerce-Price-amount.amount', ['1', '2'] );

	}

    protected function product_cats_get() {
        $terms = get_terms( array( 'taxonomy' => 'product_cat' ) );
        $term_array = array();
        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
            foreach ( $terms as $term ) {
                $term_array[$term->slug] = $term->name;
            }
        }

        return $term_array;
    }

    protected function product_tags_get() {
        $terms = get_terms( array( 'taxonomy' => 'product_tag' ) );
        $term_array = array();
    
        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
            foreach ( $terms as $term ) {
                $term_array[$term->slug] = $term->name;
            }
        }
    
        return $term_array;
    }

	protected function render() {

    // ✅ WooCommerce check
    if ( ! class_exists( 'WooCommerce' ) ) {
        echo '<p>WooCommerce is not installed or activated.</p>';
        return;
    }

    $settings = $this->get_settings_for_display(); 

    $product_type = $settings['product_type'];
    
    // Default query arguments
    $args = array(
        'post_type'      => 'product',
        'posts_per_page' => esc_attr($settings['product_count']),
        'order'          => $settings['order'],
        'orderby'        => $settings['orderby'],
    );
    
    // Initialize arrays for tax_query
    $tax_query = array();
    
    // Handle Product Show By (Category/Tag) Logic
    if ($product_type === 'category') {
        $selected_cats = !empty($settings['product_cats']) ? $settings['product_cats'] : [];
        if (!empty($selected_cats)) {
            $tax_query[] = array(
                'taxonomy' => 'product_cat',
                'field'    => 'slug',
                'terms'    => $selected_cats,
            );
        }
    } elseif ($product_type === 'tag') {
        $selected_tags = !empty($settings['product_tags']) ? $settings['product_tags'] : [];
        if (!empty($selected_tags)) {
            $tax_query[] = array(
                'taxonomy' => 'product_tag',
                'field'    => 'slug',
                'terms'    => $selected_tags,
            );
        }
    }
    
    // Apply tax_query if it has conditions
    if (!empty($tax_query)) {
        $args['tax_query'] = $tax_query;
    }

    // Execute the query
    $prods = new WP_Query($args);

    // Get the dynamic image resolution setting
    $image_resolution = !empty($settings['image_resolution']) ? $settings['image_resolution'] : 'robor-shop-small-image';

		if( $settings['layout_style'] == '1' ){ 
            // Fetch responsive controls
            $desktop_items = $settings['desktop_items']['size'];
            $l_laptop_items = $settings['large_laptop_items']['size'];
            $laptop_items = $settings['laptop_items']['size'];
            $tablet_items = $settings['tablet_items']['size'];
            $mobile_items = $settings['mobile_items']['size'];
            $s_mobile_items = $settings['small_mobile_items']['size'];

            echo '<div class="row justify-content-between align-items-center">';
                echo '<div class="col-lg-8">';
                    echo '<div class="title-area ">';
                        if(!empty($settings['subtitle'])){
                            echo '<span class="sub-title style-2 before-none text-anime-style-1">'.esc_html($settings['subtitle']).'</span>';
                        }
                        if(!empty($settings['title'])){
                            echo '<h2 class="sec-title text-anime-style-2">'.wp_kses_post($settings['title']).'</h2>';
                        }
                    echo '</div>';
                echo '</div>';
                echo '<div class="col-auto">';
                    echo '<div class="sec-btn">';
                        echo '<div class="icon-box wow fadeinup" data-wow-delay=".4s">';
                            echo '<button data-slider-prev="#catSlider2" class="slider-arrow style6 default slider-prev">';
                                echo '<img src="'.BARAB_ASSETS.'img/icon/left-arrow.svg" alt="'.esc_attr__('Arrow', 'barab').'">';
                            echo '</button>';
                            echo '<button data-slider-next="#catSlider2" class="slider-arrow style6 default slider-next">';
                                echo '<img src="'.BARAB_ASSETS.'img/icon/right-arrow.svg" alt="'.esc_attr__('Arrow', 'barab').'">';
                            echo '</button>';
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
            echo '</div>';
            
            echo '<div class="slider-area">'; 
                echo '<div class="swiper th-slider" id="catSlider2" data-slider-options=\'{"autoplay":true,"loop":true,"breakpoints":{"0":{"slidesPerView":'.$s_mobile_items.'},"431":{"slidesPerView":"'.$mobile_items.'"},"768":{"slidesPerView":"'.$tablet_items.'"},"992":{"slidesPerView":"'.$laptop_items.'"},"1200":{"slidesPerView":"'.$l_laptop_items.'"},"1400":{"slidesPerView":"'.$desktop_items.'"}}}\'>';
                    echo '<div class="swiper-wrapper">';
                        $x = 0;
                        while( $prods->have_posts() ) { 
                        $x++;
                        $prods->the_post();
                        $product = wc_get_product(get_the_ID());
                        $count = $product->get_review_count();
                            echo '<div class="swiper-slide">';
                                echo '<div class="category-card style-2">';
                                    echo '<div class="box-icon">';
                                        if ( has_post_thumbnail() ) {
                                            the_post_thumbnail( $image_resolution );
                                        }
                                        echo '<div class="actions">';
                                            // Wishlist Button
                                            if ( class_exists( 'WPCleverWoosw' ) ) { 
                                                echo do_shortcode( '[woosw]' );
                                            }
                                            // Cart Button
                                            woocommerce_template_loop_add_to_cart();
                                            // Quick View Button
                                            if ( class_exists( 'WPCleverWoosq' ) ) {
                                                echo do_shortcode( '[woosq]' );
                                            }
                                        echo '</div>';
                                    echo '</div>';
                                    echo '<div class="th-social">';
                                        echo '<div class="woocommerce-product-rating product-rating">';
                                            echo woocommerce_template_loop_rating();
                                        echo '</div>';
                                    echo '</div>';
                                    echo '<h3 class="box-title"><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h3>';
                                    // Product Pricing
                                    echo woocommerce_template_loop_price();
                                echo '</div>';
                            echo '</div>';
                        } wp_reset_postdata();
                    echo '</div>';
                echo '</div>';
            echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
            // Fetch responsive controls
            $desktop_items = $settings['desktop_items']['size'];
            $l_laptop_items = $settings['large_laptop_items']['size'];
            $laptop_items = $settings['laptop_items']['size'];
            $tablet_items = $settings['tablet_items']['size'];
            $mobile_items = $settings['mobile_items']['size'];
            $s_mobile_items = $settings['small_mobile_items']['size'];

            echo '<div class="row justify-content-lg-between justify-content-center align-items-center mb-30">';
                echo '<div class="col-lg-7">';
                    echo '<div class="title-area style-4 mb-2">';
                        if(!empty($settings['subtitle'])){
                            echo '<span class="sub-title text-anime-style-1">'.esc_html($settings['subtitle']).'</span>';
                        }
                        if(!empty($settings['title'])){
                            echo '<h2 class="sec-title3 text-anime-style-2">'.wp_kses_post($settings['title']).'</h2>';
                        }
                    echo '</div>';
                echo '</div>';
                echo '<div class="col-auto d-none d-lg-block">';
                    echo '<div class="sec-btn">';
                        echo '<div class="food2-icon-arrow">';
                            echo '<button data-slider-prev="#food2Slider1" class="slider-arrow style3 default slider-prev">';
                                echo '<img src="'.BARAB_ASSETS.'img/icon/left-arrow.svg" alt="'.esc_attr__('Arrow', 'barab').'">';
                            echo '</button>';
                            echo '<button data-slider-next="#food2Slider1" class="slider-arrow style3 default slider-next">';
                                echo '<img src="'.BARAB_ASSETS.'img/icon/right-arrow.svg" alt="'.esc_attr__('Arrow', 'barab').'">';
                            echo '</button>';
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
            echo '</div>';
            
            echo '<div class="slider-area">'; 
                echo '<div class="swiper th-slider" id="food2Slider1" data-slider-options=\'{"autoplay":true,"loop":true,"breakpoints":{"0":{"slidesPerView":'.$s_mobile_items.'},"431":{"slidesPerView":"'.$mobile_items.'"},"768":{"slidesPerView":"'.$tablet_items.'"},"992":{"slidesPerView":"'.$laptop_items.'"},"1200":{"slidesPerView":"'.$l_laptop_items.'"},"1400":{"slidesPerView":"'.$desktop_items.'"}}}\'>';
                    echo '<div class="swiper-wrapper">';
                        $x = 0;
                        while( $prods->have_posts() ) { 
                        $x++;
                        $prods->the_post();
                        $product = wc_get_product(get_the_ID());
                        $count = $product->get_review_count();
                            echo '<div class="swiper-slide">';
                                echo '<div class="food-card2">';
                                    if($settings['shape_bottom']['url'] ){
                                        echo '<div class="food-2-bottom">';
                                           echo barab_img_tag( array(
                                                'url'   => esc_url( $settings['shape_bottom']['url'] ),
                                            )); 
                                        echo '</div>';
                                    }
                                    echo '<div class="food-img2">';
                                        if ( has_post_thumbnail() ) {
                                            the_post_thumbnail( $image_resolution );
                                        }
                                        // Wishlist Button
                                        if ( class_exists( 'WPCleverWoosw' ) ) { 
                                            echo do_shortcode( '[woosw]' );
                                        }
                                    echo '</div>';
                                    echo '<div class="food-card2-content">';
                                        echo '<h3 class="box-title3"><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h3>';
                                        echo '<div class="reating">';
                                            echo '<div class="woocommerce-product-rating product-rating">';
                                                echo woocommerce_template_loop_rating();
                                            echo '</div>';
                                        echo '</div>';
                                        // Product Pricing
                                         echo '<p>';
                                            echo woocommerce_template_loop_price();
                                        echo '</p>';
                                        // Cart Button
                                        // ✅ Dynamic Add to Cart Button
                                        echo sprintf(
                                            '<a href="%s" data-quantity="1" class="th-btn %s" %s>%s</a>',
                                            esc_url( $product->add_to_cart_url() ),
                                            esc_attr( implode( ' ', array_filter( (array) $product->get_type(), 'esc_attr' ) ) ),
                                            wc_implode_html_attributes( array(
                                                'data-product_id'  => $product->get_id(),
                                                'data-product_sku' => $product->get_sku(),
                                                'aria-label'       => $product->add_to_cart_description(),
                                                'rel'              => 'nofollow'
                                            ) ),
                                            esc_html( $product->add_to_cart_text() )
                                        );
                                    echo '</div>';
                                echo '</div>';
                            echo '</div>';
                        } wp_reset_postdata();
                    echo '</div>';
                echo '</div>';
            echo '</div>';

		}
		
			
	}
}