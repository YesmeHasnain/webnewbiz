<?php
namespace Elementor;

class Xcency_Cta_One_Widget extends Widget_Base {

	public function get_name() {

		return 'xcency_cta_one';
	}

	public function get_title() {
		return esc_html__( 'CTA One', 'xcency-core' );
	}

	public function get_icon() {

		return 'eicon-button';
	}

	public function get_categories() {
		return [ 'xcency_core_elements' ];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
			'cta_option',
			[
				'label' => esc_html__( 'CTA Options', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
            'title_text',
            [
                'label'       => esc_html__( 'Title', 'xcency-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'rows'        => 5,
                'default'     => esc_html__( 'Have Any Project on Your Mind! Let’s Talk Your Projects', 'xcency-core' ),
            ]
        );

        $this->add_control(
            'desc_text', [
                'label' => esc_html__( 'Description', 'xcency-core' ),
                'type' => Controls_Manager::WYSIWYG,
                'default' => 'Website traffic has increased significantly, and we\'ve seen they substantial boost in engagement
across all our social media best platforms SEO improvements they implemented',
                'label_block' => true,
            ]
        );

        $this->add_control(
            'btn_text',
            [
                'label'       => __( 'Button Text', 'xcency-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => 'Get Consultations'
            ]
        );

        $this->add_control(
            'btn_details',
            [
                'label'         => __( 'Button URL', 'xcency-core' ),
                'type'          => Controls_Manager::URL,
                'placeholder'   => __( 'https://your-link.com', 'xcency-core' ),
                'show_external' => true,
                'default'       => [
                    'url'         => '',
                    'is_external' => false,
                    'nofollow'    => false,
                ],
            ]
        );

		$this->add_control(
		    'top_left_image',
		    [
		        'label'       => esc_html__( 'Top Left Image', 'xcency-core' ),
		        'type'        => Controls_Manager::MEDIA,
		        'label_block' => true,
		        'default'     => [
		            'url' => Utils::get_placeholder_image_src(),
		        ],
		    ]
		);

		$this->add_control(
		    'bottom_right_image',
		    [
		        'label'       => esc_html__( 'Bottom Right Image', 'xcency-core' ),
		        'type'        => Controls_Manager::MEDIA,
		        'label_block' => true,
		        'default'     => [
		            'url' => Utils::get_placeholder_image_src(),
		        ],
		    ]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'cta_style_option',
			[
				'label' => esc_html__( 'CTA Style', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
            'wrapper_bg_color',
            [
                'label'       => esc_html__('Wrapper Background', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .cta-one-wrapper' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'wrapper_padding',
            [
                'label'      => esc_html__( 'Wrapper Padding', 'xcency-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .cta-one-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'wrapper_margin',
            [
                'label'      => esc_html__( 'Wrapper Margin', 'xcency-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .cta-one-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'wrapper_text_align',
            [
                'label'       => esc_html__('Wrapper Text Align', 'xcency-core'),
                'type'        => Controls_Manager::CHOOSE,
                'label_block' => false,

                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'xcency-core'),
                        'icon'  => 'eicon-text-align-left',
                    ],

                    'center' => [
                        'title' => esc_html__('Center', 'xcency-core'),
                        'icon'  => 'eicon-text-align-center',
                    ],

                    'right' => [
                        'title' => esc_html__('Right', 'xcency-core'),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],

                'devices' => ['desktop', 'tablet', 'mobile'],

                'selectors' => [
                    '{{WRAPPER}} .cta-one-wrapper' => 'text-align: {{VALUE}};',
                ],

            ]
        );

        $this->add_responsive_control(
            'content_width',
            [
                'label' => esc_html__( 'Content Width', 'xcency-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['%'],
                'range' => [
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],

                'selectors' => [
                    '{{WRAPPER}} .cta-one-content' => 'width: {{SIZE}}%;',
                ],
            ]
        );

        $this->add_control(
            'button_bg_color',
            [
                'label'       => esc_html__('Button Background', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .cta-one-button-wrapper .xcency-button' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_hover_bg_color',
            [
                'label'       => esc_html__('Button Hover Background', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .cta-one-button-wrapper .xcency-button:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label'       => esc_html__('Button Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .cta-one-button-wrapper .xcency-button' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_hover_color',
            [
                'label'       => esc_html__('Button Hover Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .cta-one-button-wrapper .xcency-button:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

		$this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
        $image_1_src = $settings['top_left_image']['url'];
        $image_1_alt = get_post_meta( $settings['top_left_image']['id'], '_wp_attachment_image_alt', true );
        $image_2_src = $settings['bottom_right_image']['url'];
        $image_2_alt = get_post_meta( $settings['bottom_right_image']['id'], '_wp_attachment_image_alt', true );
		?>

        <div class="cta-one-wrapper">
            <div class="cta-one-img-one cta-one-image">
                <img src="<?php echo $image_1_src;?>" alt="<?php echo $image_1_alt;?>">
            </div>
            <div class="cta-one-img-two cta-one-image">
                <img src="<?php echo $image_2_src;?>" alt="<?php echo $image_2_alt;?>">
            </div>
            <div class="cta-one-content">
                <h2 class="cta-one-title"><?php echo $settings['title_text'];?></h2>

                <div class="cta-one-desc td-last-p-0">
		            <?php echo $settings['desc_text'];?>
                </div>

                <div class="cta-one-button-wrapper">
                    <a class="xcency-button" href="<?php echo $settings['btn_details']['url'];?>"><?php echo $settings['btn_text'];?></a>
                </div>
            </div>
        </div>
        <?php
	}
}

Plugin::instance()->widgets_manager->register( new Xcency_Cta_One_Widget );