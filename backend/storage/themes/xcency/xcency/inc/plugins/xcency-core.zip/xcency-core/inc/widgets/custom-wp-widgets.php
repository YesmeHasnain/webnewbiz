<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/*
 *  Recent Post Widget
 */
require_once ('recent-post-widget.php');

/*
 *  Navigation Widget
 */
require_once ('custom-navigation-widget.php');

/*
 *  CTA Button Widget
 */
require_once( 'cta-button-widget.php' );