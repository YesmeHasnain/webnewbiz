<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsAboutMeSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-about-me-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'About Me Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-alert';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-global' ];
	}

	public function get_keywords() {
		return [ 'aboutmesection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_about_me_section',
			[
				'label' => esc_html__( 'About Me Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'img_bg_sec',
			[
				'label'       	=> esc_html__( 'Image Background Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image background section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'heading_sec',
			[
				'label' 		=> esc_html__( 'Heading Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( "Hi, I’m Vanilla" , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'img_shape_1',
			[
				'label'       	=> esc_html__( 'Image Shape Section 1', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image shape section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'title_wrap_1',
			[
				'label' 		=> esc_html__( 'Title Wrap 1', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Title Wrap 1' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_wrap_1',
			[
				'label' 		=> esc_html__( 'Text Wrap 1', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Text Wrap 1' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'img_shape_2',
			[
				'label'       	=> esc_html__( 'Image Shape Section 2', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image shape section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'title_wrap_2',
			[
				'label' 		=> esc_html__( 'Title Wrap 2', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Title Wrap 2' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_wrap_2',
			[
				'label' 		=> esc_html__( 'Text Wrap 2', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Text Wrap 2' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'img_thumb',
			[
				'label'       	=> esc_html__( 'Image About Me Thumbnail', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image about me thumbnail', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'subtitle_sec',
			[
				'label' 		=> esc_html__( 'Subtitle Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'About Me' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Title Section' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'label_item',
			[
				'label' 		=> esc_html__( 'Label Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Label Item' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'text_item',
			[
				'label' 		=> esc_html__( 'Text Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Text Item' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'title_item',
			[
				'label' 		=> esc_html__( 'Title Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Title Item' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'tabs',
			[
				'label' 		=> esc_html__( 'List Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
					],
				],
				'title_field' 	=> '{{{ title_item }}}',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-about-me-ptb tp-btn-trigger pt-200 pb-140 p-relative">
	<?php if (!empty($settings['img_bg_sec']['url'])): ?>
		<div class="tp-about-me-bg" data-background="<?php echo wp_kses_post($settings['img_bg_sec']['url']); ?>"></div>
	<?php endif ?>
	<div class="tp-about-me-wrapper pb-100">
		<div class="container container-1430">
			<?php if (!empty($settings['heading_sec'])): ?>
				<div class="row">
					<div class="col-lg-12">
						<div class="tp-about-me-heading text-center">
							<h2 class="tp-about-me-title tp-char-animation"><?php echo wp_kses_post($settings['heading_sec']); ?></h2>
						</div>
					</div>
				</div>
			<?php endif ?>
			<div class="row">
				<div class="col-lg-3 order-lg-1 order-md-2">
					<div class="tp-about-me-heading">
						<?php if (!empty($settings['img_shape_1']['url'])): ?>
							<div class="tp-about-me-shape-1 tp-btn-bounce text-center">
								<img src="<?php echo wp_kses_post($settings['img_shape_1']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_shape_1']['alt']); ?>">
							</div>
						<?php endif ?>
						<div class="tp-about-me-wrap">
							<?php if (!empty($settings['title_wrap_1'])): ?>
								<h4 class="tp-about-me-title2"><?php echo wp_kses_post($settings['title_wrap_1']); ?></h4>
							<?php endif ?>
							<?php if (!empty($settings['text_wrap_1'])): ?>
								<span class="tp-about-me-subtitle"><?php echo wp_kses_post($settings['text_wrap_1']); ?></span>
							<?php endif ?>
						</div>
					</div>
				</div>
				<div class="col-lg-6 order-lg-2 order-md-1">
					<div class="tp-about-me-thumb text-center">
						<?php if (!empty($settings['img_thumb']['url'])): ?>
							<img src="<?php echo wp_kses_post($settings['img_thumb']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_thumb']['url']); ?>">
						<?php endif ?>
					</div>
				</div>
				<div class="col-lg-3 order-md-3">
					<div class="tp-about-me-wrap">
						<?php if (!empty($settings['title_wrap_2'])): ?>
							<h4 class="tp-about-me-title2"><?php echo wp_kses_post($settings['title_wrap_2']); ?></h4>
						<?php endif ?>
						<?php if (!empty($settings['text_wrap_2'])): ?>
							<span class="tp-about-me-subtitle"><?php echo wp_kses_post($settings['text_wrap_2']); ?></span>
						<?php endif ?>
						<?php if (!empty($settings['img_shape_2']['url'])): ?>
							<div class="tp-about-me-shape-2 tp-btn-bounce">
								<img src="<?php echo wp_kses_post($settings['img_shape_2']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_shape_2']['alt']); ?>">
							</div>
						<?php endif ?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row">
			<div class="col-lg-2">
				<?php if (!empty($settings['subtitle_sec'])): ?>
					<div class="tp-about-me-us">
						<h4 class="tp-about-me-us-subtitle"><?php echo wp_kses_post($settings['subtitle_sec']); ?></h4>
					</div>
				<?php endif ?>
			</div>
			<div class="col-lg-10">
				<?php if (!empty($settings['title_sec'])): ?>
					<div class="tp-about-me-us-heading mb-80">
						<h4 class="tp-about-me-us-title tp-title-anim"><?php echo wp_kses_post($settings['title_sec']); ?></h4>
					</div>
				<?php endif ?>
				<div class="row">
					<?php
					$i = 0;
					foreach ($settings['tabs'] as $item) :
						$i++;
					?>
						<div class="col-lg-4 col-md-4 col-sm-6">
							<div class="tp-about-me-us-item">
								<span>
									<?php echo sprintf("%02d.", $i); ?> <br> 
									<?php echo wp_kses_post($item['label_item']); ?>
								</span>
								<?php if (!empty($item['text_item'])): ?>
									<p><?php echo wp_kses_post($item['text_item']); ?></p>
								<?php endif ?>
								<?php if (!empty($item['title_item'])): ?>
									<h4 class="tp-about-me-us-item-title"><?php echo wp_kses_post($item['title_item']); ?></h4>
								<?php endif ?>
							</div>
						</div> 
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-background]").each(function () {
			jQuery(this).css("background-image", "url( " + jQuery(this).attr("data-background") + "  )");
		});

		if (jQuery('.tp-about-me-heading .tp-char-animation').length > 0) {
			var char_come = gsap.utils.toArray(".tp-about-me-heading .tp-char-animation");
			char_come.forEach(splitTextLine => {
				var tl = gsap.timeline({
					scrollTrigger: {
						trigger: splitTextLine,
						start: 'top 90%',
						end: 'bottom 60%',
						scrub: false,
						markers: false,
						toggleActions: 'play none none none'
					}
				});

				var itemSplitted = new SplitText(splitTextLine, { type: "chars, words" });
				gsap.set(splitTextLine, { perspective: 300 });
				itemSplitted.split({ type: "chars, words" })
				tl.from(itemSplitted.chars,
					{
						duration: 1,
						delay: 0.5,
						x: 100,
						autoAlpha: 0,
						stagger: 0.05
					});
			});
		}

		if (jQuery('.tp-title-anim').length > 0) {
			let splitTitleLines = gsap.utils.toArray(".tp-title-anim");
			splitTitleLines.forEach(splitTextLine => {
				const tl = gsap.timeline({
				scrollTrigger: {
					trigger: splitTextLine,
					start: 'top 90%',
					end: 'bottom 60%',
					scrub: false,
					markers: false,
					toggleActions: 'play none none none'
				}
				});
	
				const itemSplitted = new SplitText(splitTextLine, { type: "words, lines" });
				gsap.set(splitTextLine, { perspective: 300});
				itemSplitted.split({ type: "lines" })
				tl.from(itemSplitted.lines, { duration: 1, delay: 0.3, opacity: 0, rotationX: -50, force3D: true, transformOrigin: "top center -50", stagger: 0.2 });
			});	
		}

		if (jQuery('.tp-btn-trigger').length > 0) {

			gsap.set(".tp-btn-bounce", { y: -100, opacity: 0 });
			var mybtn = gsap.utils.toArray(".tp-btn-bounce");
			mybtn.forEach((btn) => {
				var $this = $(btn);
				gsap.to(btn, {
					scrollTrigger: {
						trigger: $this.closest('.tp-btn-trigger'),
						start: "top center",
						markers: false
					},
					duration: 1,
					ease: "bounce.out",
					y: 0,
					opacity: 1,
				})
			});
	
		}
	</script>
<?php } ?>

<?php
}

}