<?php
namespace Elementor;
class Xcency_Counter_Up_Two_Widget extends Widget_Base {

	public function get_name() {

		return 'xcency_counter_up_two';
	}

	public function get_title() {
		return esc_html__( 'Count Up Two', 'xcency-core' );
	}

	public function get_icon() {

		return 'eicon-counter';
	}

	public function get_categories() {
		return [ 'xcency_core_elements' ];
	}

	public function get_script_depends() {
		return ['counterup'];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'counter_up_options',
			[
				'label' => esc_html__( 'Counter Up', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'       => __( 'Title', 'xcency-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Customer Satisfaction',
				'label_block' => true,
			]
		);

		$repeater->add_control(
            'selected_icon',
            [
                'label'            => esc_html__( 'Select Icon', 'xcency-core' ),
                'type'             => Controls_Manager::ICONS,
                'fa4compatibility' => 'icon',
                'label_block'      => true,
                'default'          => [
                    'value'   => 'flaticon-software',
                    'library' => 'xcency-icon',
                ],
            ]
        );

		$repeater->add_control(
			'number',
			[
				'label'       => __( 'Number', 'xcency-core' ),
				'label_block'       => false,
				'type'        => Controls_Manager::TEXT,
				'default'     => '100',
			]
		);

		$repeater->add_control(
			'unit',
			[
				'label'   => 'Counter Unit',
				'type'    => Controls_Manager::TEXT,
				'default' => '%',
			]
		);

		$this->add_control(
			'count_boxes',
			[
				'label'       => __('Count Box List', 'xcency-core'),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title'        => 'Customer Satisfaction',
						'unit' => '%',
						'number' => '100',
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'count_box_column',
			[
				'label' => esc_html__( 'Column', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'xl_col',
			[
				'label'   => __( 'Columns On Desktop', 'xcency-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-xl-3',
				'options' => [
					'col-xl-12' => __( '1 Column', 'xcency-core' ),
					'col-xl-6'  => __( '2 Column', 'xcency-core' ),
					'col-xl-4'  => __( '3 Column', 'xcency-core' ),
					'col-xl-3'  => __( '4 Column', 'xcency-core' ),
				],
			]
		);

		$this->add_control(
			'lg_col',
			[
				'label'   => __( 'Columns On iPad Pro', 'xcency-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-lg-4',
				'options' => [
					'col-lg-12' => __( '1 Column', 'xcency-core' ),
					'col-lg-6'  => __( '2 Column', 'xcency-core' ),
					'col-lg-4'  => __( '3 Column', 'xcency-core' ),
					'col-lg-3'  => __( '4 Column', 'xcency-core' ),
				],
			]
		);

		$this->add_control(
			'md_col',
			[
				'label'   => __( 'Columns On iPad', 'xcency-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-md-6',
				'options' => [
					'col-md-12' => __( '1 Column', 'xcency-core' ),
					'col-md-6'  => __( '2 Column', 'xcency-core' ),
					'col-md-4'  => __( '3 Column', 'xcency-core' ),
					'col-md-3'  => __( '4 Column', 'xcency-core' ),
				],
			]
		);

		$this->add_control(
			'sm_col',
			[
				'label'   => __( 'Columns On  Mobile', 'xcency-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-12',
				'options' => [
					'col-12' => __( '1 Column', 'xcency-core' ),
					'col-6'  => __( '2 Column', 'xcency-core' ),
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'counter_up_option',
			[
				'label' => esc_html__( 'Counter Up', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
            'box_bg_color',
            [
                'label'       => esc_html__('Background Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .xcency-counter-box-two' => 'background-color: {{VALUE}};',
                ],
            ]
        );

		$this->add_control(
			'number_unit_color',
			[
				'label'       => esc_html__('Number & Unit Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-counter-box-two-counter' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'       => esc_html__('Title Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-count-two-title' => 'color: {{VALUE}};',
				],
			]
		);

        $this->add_control(
            'border_color',
            [
                'label'       => esc_html__('Border Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .count-two-border' => 'border-color: {{VALUE}};',
                ],
            ]
        );

		$this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$count_id = rand(100, 100000);
		$col = $settings['xl_col'] . ' ' . $settings['lg_col'] . ' ' . $settings['md_col'] . ' ' . $settings['sm_col'];
		?>
		<div class="counter-up-two-wrapper td-cover-bg xcency-counter-box-<?php echo esc_attr($count_id);?>">
			<div class="row">
				<?php if ( $settings['count_boxes'] ) {
					foreach ( $settings['count_boxes'] as $count_box ) {
						?>
						<div class="<?php echo $col;?>">
							<div class="xcency-counter-box-two">
                                <div class="count-box-two-icon">
	                                <?php xcency_custom_icon_render( $count_box, 'icon', 'selected_icon' );?>
                                </div>

								<div class="xcency-counter-box-two-counter">
									<span class="xcency-count-number"><?php echo esc_html( $count_box['number'] ) ?></span><?php echo esc_html( $count_box['unit'] ) ?>
								</div>

                                <div class="count-two-border"></div>

								<div class="xcency-count-two-title"><?php echo esc_html( $count_box['title'] ) ?></div>
							</div>
						</div>
						<?php
					}
				} ?>
			</div>

		</div>

		<script>
            (function ($) {
                "use strict";
                /*====  Document Ready Function =====*/
                jQuery(document).ready(function($){
                    $(".xcency-counter-box-<?php echo esc_attr($count_id);?> .xcency-count-number").counterUp({
                        delay: 10,
                        time: 2000
                    });
                });
            }(jQuery));
		</script>
		<?php

	}
}

Plugin::instance()->widgets_manager->register( new Xcency_Counter_Up_Two_Widget );