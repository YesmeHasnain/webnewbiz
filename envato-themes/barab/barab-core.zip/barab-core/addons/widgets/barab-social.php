<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Social Widget .
 *
 */
class Barab_Social extends Widget_Base { 

	public function get_name() {
		return 'barabsocial';
	}
	public function get_title() {
		return __( 'Social', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		 $this->start_controls_section(
			'social_section',
			[
				'label'     => __( 'Social', 'barab' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', ['Style One', 'Style Two'] );

		barab_social_fields($this, 'social_icon_list', 'Social List', ['1', '2', '3']);
		barab_general_fields( $this, 'title', 'Title', 'TEXTAREA', 'Download Our App', ['2'] );
		barab_media_fields( $this, 'app', 'Choose Image', ['2'] );
		barab_url_fields($this, 'app_url', 'Image URL', ['2']);


        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------

	}

	protected function render() {

        $settings = $this->get_settings_for_display();

		if( $settings['layout_style'] == '1' ){
			echo '<div class="th-social">';
				foreach ( $settings['social_icon_list'] as $index => $social_icon ) {
					$link_key = 'social_icon_list_' . $index . '_icon_link';

					if ( ! empty( $social_icon['icon_link']['url'] ) ) {
						$this->add_link_attributes( $link_key, $social_icon['icon_link'] );

						echo '<a ' . $this->get_render_attribute_string( $link_key ) . '>';
						\Elementor\Icons_Manager::render_icon( $social_icon['social_icon'], [ 'aria-hidden' => 'true' ] );
						echo '</a>';
					}
				}
			echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
			echo '<div class="container">'; 
				echo '<div class="footer-bottom">';
					echo '<div class="row justify-content-between">';
						echo '<div class="col-lg-5">';
							echo '<div class="social-links">';
								echo '<div class="icon-group">';
									foreach ( $settings['social_icon_list'] as $index => $social_icon ) {
										$link_key = 'social_icon_list_' . $index . '_icon_link';

										if ( ! empty( $social_icon['icon_link']['url'] ) ) {
											$this->add_link_attributes( $link_key, $social_icon['icon_link'] );

											echo '<a ' . $this->get_render_attribute_string( $link_key ) . '>';
											\Elementor\Icons_Manager::render_icon( $social_icon['social_icon'], [ 'aria-hidden' => 'true' ] );
											echo '</a>';
										}
									}
								echo '</div>';
							echo '</div>';
						echo '</div>';
						if($settings['app']['url'] ){
						echo '<div class="col-lg-7 text-center text-lg-end">';
							echo '<div class="app-download">';
								echo '<a '.barab_link_attrs($settings['app_url']).'>';
									echo barab_img_tag( array(
										'url'   => esc_url( $settings['app']['url'] ),
									)); 
								echo '</a>';
							echo '</div>';
						echo '</div>';
						}
					echo '</div>';
				echo '</div>';
			echo '</div>';

		}


	}

}