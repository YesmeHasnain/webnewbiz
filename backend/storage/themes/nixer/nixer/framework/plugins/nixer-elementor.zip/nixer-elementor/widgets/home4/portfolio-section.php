<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome4PortfolioSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home-4-portfolio-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 4 - Portfolio Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-accordion';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home4' ];
	}

	public function get_keywords() {
		return [ 'home4portfoliosection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_portfolio_section',
			[
				'label' => esc_html__( 'Portfolio Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'switch_top',
			[
				'label'   		=> esc_html__( 'Switch Show/Hide Top Content Section', 'bdevs-elementor' ),
				'type'    		=> Controls_Manager::SWITCHER,
				'label_on' 		=> esc_html__( 'Show', 'bdevs-elementor' ),
				'label_off' 	=> esc_html__( 'Hide', 'bdevs-elementor' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Some of the <br> most impressive <br> projects i have <br> worked' , 'bdevs-elementor' ),
				'show_label' 	=> true,
				'condition' 	=> [
					'switch_top' 	=> 'yes',
				],
			]
		);
		$this->add_control(
			'text_sec',
			[
				'label' 		=> esc_html__( 'Text Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'These are just a few projects that...' , 'bdevs-elementor' ),
				'show_label' 	=> true,
				'condition' 	=> [
					'switch_top' 	=> 'yes',
				],
			]
		);
		$this->add_control(
			'text_btn',
			[
				'label' 		=> esc_html__( 'Text Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'All projects' , 'bdevs-elementor' ),
				'show_label' 	=> true,
				'condition' 	=> [
					'switch_top' 	=> 'yes',
				],
			]
		);
		$this->add_control(
			'link_btn',
			[
				'label' 		=> esc_html__( 'Link Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '#' , 'bdevs-elementor' ),
				'show_label' 	=> true,
				'condition' 	=> [
					'switch_top' 	=> 'yes',
				],
			]
		);
		$this->add_control(
			'post_number',
			[
				'label'       => __( 'Post Number', 'bdevs-elementor' ),
				'type'        => Controls_Manager::NUMBER,
				'placeholder' => __( 'Enter your post number', 'bdevs-elementor' ),
				'min'		  => 0,
				'default'     => __( '4', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order_by',
			[
				'label'       => __( 'Post Order By', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text post order by', 'bdevs-elementor' ),
				'default'     => __( 'ID', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
				],
				'default'   => 'desc',
			]
		);
		$this->add_control(
			'bg_color',
			[
				'label' 		=> esc_html__( 'Background Color (Default: #121212)', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::COLOR,
				'default'		=> '#121212',
			]
		);
		$this->add_control(
			'text_label_1',
			[
				'label'       => __( 'Text Label Category', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text label category', 'bdevs-elementor' ),
				'default'     => __( 'Category:', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'text_label_2',
			[
				'label'       => __( 'Text Label Role', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text label role', 'bdevs-elementor' ),
				'default'     => __( 'Role:', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'text_label_3',
			[
				'label'       => __( 'Text Label Tag', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text label tag', 'bdevs-elementor' ),
				'default'     => __( 'Tag:', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'switch_btn_read',
			[
				'label'   		=> esc_html__( 'Switch Show/Hide Button Details', 'bdevs-elementor' ),
				'type'    		=> Controls_Manager::SWITCHER,
				'label_on' 		=> esc_html__( 'Show', 'bdevs-elementor' ),
				'label_off' 	=> esc_html__( 'Hide', 'bdevs-elementor' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);
		$this->add_control(
			'text_btn_read',
			[
				'label'       => __( 'Text Button Portfolio Details', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text button portfolio details', 'bdevs-elementor' ),
				'default'     => __( 'Project details', 'bdevs-elementor' ),
				'label_block' => true,
				'condition' 	=> [
					'switch_btn_read' 	=> 'yes',
				],
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-project-4-ptb tp-project-panel pt-160">
	<?php if (!empty($settings['switch_top'])): ?>
		<div class="container container-1520">
			<div class="row">
				<div class="col-lg-7">
					<?php if (!empty($settings['title_sec'])): ?>
						<div class="tp-project-4-heading pb-100">
							<h3 class="tp-section-4-title tp-title-anim"><?php echo wp_kses_post($settings['title_sec']); ?></h3>
						</div>
					<?php endif ?>
				</div>
				<div class="col-lg-5">
					<div class="tp-project-4-heading tp-title-anim pb-100">
						<?php if (!empty($settings['text_sec'])): ?>
							<p><?php echo wp_kses_post($settings['text_sec']); ?></p>
						<?php endif ?>
						<?php if (!empty($settings['link_btn']) && !empty($settings['text_btn'])): ?>
							<div class="tp-project-4-btn">
								<a href="<?php echo wp_kses_post($settings['link_btn']); ?>">
									<?php echo wp_kses_post($settings['text_btn']); ?>
									<span>
										<svg xmlns="http://www.w3.org/2000/svg" width="17" height="16" viewBox="0 0 17 16" fill="none">
											<path d="M1.51562 14.7968L14.6838 1.62864M3.83594 1.16205C6.96385 4.28996 12.2505 4.06539 15.656 0.659936M15.6533 0.655273C12.2478 4.06072 12.0232 9.34739 15.1511 12.4753" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10"/>
										</svg>
									</span>
								</a>
							</div>
						<?php endif ?>
					</div>
				</div>
			</div>
		</div>
	<?php endif ?>
	<?php
	$wp_query = new \WP_Query([
		'post_type'      => 'portfolio',
		'posts_per_page' => intval($settings['post_number']),
		'orderby'        => sanitize_text_field($settings['post_order_by']),
		'order'          => sanitize_text_field($settings['post_order']),
	]);
	$i = 0;
	while($wp_query->have_posts()): $wp_query->the_post();
		$i++;
		$post_id = get_the_ID();

		$port_title 	= get_post_meta($post_id,'_cmb_port_title_home_4', true);
		$port_excerpt 	= get_post_meta($post_id,'_cmb_port_excerpt_home_4', true);
		$img_id 		= get_post_meta($post_id,'_cmb_port_thumb_home_4', true);

		$title = !empty($port_title) ? $port_title : get_the_title();
		$img_url = '';

		if (!empty($img_id)) {
			$img_url = wp_get_attachment_url($img_id);
		} else {
			$img_url = get_the_post_thumbnail_url();
		}
	?>
		<div class="tp-project-4-item-wrapper project-panel" data-bg-color="<?php echo wp_kses_post($settings['bg_color']); ?>">
			<div class="container container-1520">
				<div class="row">
					<div class="col-lg-5">
						<div class="tp-project-4-item-content tp_fade_left">
							<h4 class="tp-project-4-item-title">
								<a href="<?php the_permalink(); ?>"><?php echo wp_kses_post($title); ?></a>
							</h4>
							<p>
								<?php if ( '' !== wp_specialchars_decode($port_excerpt)): ?>
									<?php print wp_specialchars_decode($port_excerpt); ?>
								<?php else:?>
									<?php if(isset($nixer_redux_demo['blog_excerpt'])){?>
									<?php echo esc_attr(nixer_excerpt($nixer_redux_demo['blog_excerpt'])); ?>
									<?php }else{?>
									<?php echo esc_attr(nixer_excerpt(35)); 
									}?>
								<?php endif ?>
							</p>
							<div class="tp-project-4-item-list pb-170">
								<ul>
									<?php 
									$terms1 = get_the_terms( get_the_ID(), 'portfolio-cat' );
									if ( ! empty( $terms1 ) && ! is_wp_error( $terms1 ) ) {
									?>
										<li>
											<span>
												<?php if ( ! empty( $settings['text_label_1'] ) ) { ?>
													<?php echo wp_kses_post( $settings['text_label_1'] ); ?>
												<?php } else { ?>
													<?php echo esc_html__( 'Category:', 'nixer' ); ?>
												<?php } ?>
											</span> 
											<?php
											$term_links1 = [];
											foreach ( $terms1 as $term1 ) {
												$term_link1 = get_term_link( $term1 );
												if ( ! is_wp_error( $term_link1 ) ) {
													$term_links1[] = '<a href="' . esc_url( $term_link1 ) . '">' . esc_html( $term1->name ) . '</a>';
												}
											}
											echo implode( ', ', $term_links1 );
											?>
										</li>
									<?php } ?>
									<?php 
									$terms2 = get_the_terms( get_the_ID(), 'portfolio-role' );
									if ( ! empty( $terms2 ) && ! is_wp_error( $terms2 ) ) {
									?>
										<li>
											<span>
												<?php if (!empty($settings['text_label_2'])) { ?>
													<?php echo wp_kses_post($settings['text_label_2']); ?>
												<?php } else { ?>
													<?php echo esc_html__( 'Role:', 'nixer' ); ?>
												<?php } ?>
											</span> 
											<?php
											$term_links2 = [];
											foreach ( $terms2 as $term2 ) {
												$term_link2 = get_term_link( $term2 );
												if ( ! is_wp_error( $term_link2 ) ) {
													$term_links2[] = '<a href="' . esc_url( $term_link2 ) . '">' . esc_html( $term2->name ) . '</a>';
												}
											}
											echo implode( ', ', $term_links2 );
											?>
										</li>
									<?php } ?>
									<?php 
									$terms3 = get_the_terms( get_the_ID(), 'portfolio-tag' );
									if ( ! empty( $terms3 ) && ! is_wp_error( $terms3 ) ) {
									?>
										<li>
											<span>
												<?php if (!empty($settings['text_label_3'])) { ?>
													<?php echo wp_kses_post($settings['text_label_3']); ?>
												<?php } else { ?>
													<?php echo esc_html__( 'Tag:', 'nixer' ); ?>
												<?php } ?>
											</span> 
											<?php
											$term_links3 = [];
											foreach ( $terms3 as $term3 ) {
												$term_link3 = get_term_link( $term3 );
												if ( ! is_wp_error( $term_link3 ) ) {
													$term_links3[] = '<a href="' . esc_url( $term_link3 ) . '">' . esc_html( $term3->name ) . '</a>';
												}
											}
											echo implode( ', ', $term_links3 );
											?>
										</li>
									<?php } ?>
								</ul>
							</div>
							<?php if (!empty($settings['switch_btn_read'])): ?>
								<div class="tp-project-4-btn">
									<a href="<?php the_permalink(); ?>">
										<?php echo wp_kses_post($settings['text_btn_read']); ?>
										<span>
											<svg xmlns="http://www.w3.org/2000/svg" width="17" height="16" viewBox="0 0 17 16" fill="none">
												<path d="M1.51562 14.7968L14.6838 1.62864M3.83594 1.16205C6.96385 4.28996 12.2505 4.06539 15.656 0.659936M15.6533 0.655273C12.2478 4.06072 12.0232 9.34739 15.1511 12.4753" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10"/>
											</svg>
										</span>
									</a>
								</div>
							<?php endif ?>
						</div>
					</div>
					<div class="col-lg-7">
						<div class="anim-zoomin-wrap">
							<div class="tp-project-4-item-thumb anim-zoomin">
								<?php if (!empty($img_url)): ?>
									<a href="<?php the_permalink(); ?>">
										<img src="<?php echo esc_url($img_url); ?>" alt="<?php the_title_attribute(); ?>">
									</a>
								<?php endif ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php endwhile; ?>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-bg-color]").each(function () {
			jQuery(this).css("background-color", jQuery(this).attr("data-bg-color"));
		});

		var pr = gsap.matchMedia();
		pr.add("(min-width: 991px)", () => {

			var tl = gsap.timeline();
			var projectpanels = document.querySelectorAll('.project-panel')
			projectpanels.forEach((section, index) => {
				tl.to(section, {
					scrollTrigger: {
						trigger: section,
						pin: section,
						scrub: 1,
						start: 'top top',
						end: "bottom 100%",
						endTrigger: '.tp-project-panel',
						pinSpacing: false,
						markers: false,
					},
				})
			})
		});

		gsap.set(".tp_fade_left", { x: -100, opacity: 0 });
		var fadeleftArray = gsap.utils.toArray(".tp_fade_left")
		fadeleftArray.forEach((item, i) => {
			var fadeTl = gsap.timeline({
				scrollTrigger: {
					trigger: item,
					start: "top center+=100",
				}
			})
			fadeTl.to(item, {
				x: 0,
				opacity: 1,
				ease: "power2.out",
				duration: 2.5,
			})
		})

		jQuery(".anim-zoomin").each(function() {

			// Add wrap <div>.
			jQuery(this).wrap('<div class="anim-zoomin-wrap"></div>');

			// Add overflow hidden.
			jQuery(".anim-zoomin-wrap").css({ "overflow": "hidden" })

			var $this = $(this);
			var $asiWrap = $this.parents(".anim-zoomin-wrap");

			var tp_ZoomIn = gsap.timeline({
				scrollTrigger: {
					trigger: $asiWrap,
					start: "top 100%",
					markers: false,
				}
			});
			tp_ZoomIn.from($this, { duration: 1.5, autoAlpha: 0, scale: 1.2, ease: Power2.easeOut, clearProps:"all" });

		});
	</script>
<?php } ?>

<?php
}

}