<?php
namespace Elementor;

class ThemeDraft_Widget extends Widget_Base {

	public function get_name() {
		return 'xcency_working_process';
	}

	public function get_title() {
		return esc_html__( 'Working Process', 'xcency-core' );
	}

	public function get_icon() {
		return 'eicon-post-excerpt';
	}

	public function get_categories() {
		return [ 'xcency_core_elements' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'working_process_options',
			[
				'label' => esc_html__( 'Working Process', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
		    'subtitle',
		    [
		        'label'       => esc_html__( 'Subtitle', 'xcency-core' ),
		        'type'        => Controls_Manager::TEXT,
		        'default'     => esc_html__( 'Step 1', 'xcency-core' ),
		        'label_block' => true,
		    ]
		);

		$repeater->add_control(
		    'title',
		    [
		        'label'       => esc_html__( 'Title', 'xcency-core' ),
		        'type'        => Controls_Manager::TEXTAREA,
		        'rows'        => 5,
		        'default'     => esc_html__( 'Discovery & Planning', 'xcency-core' ),
		    ]
		);

		$repeater->add_control(
		    'desc',
		    [
		        'label'       => esc_html__( 'Title', 'xcency-core' ),
		        'type'        => Controls_Manager::TEXTAREA,
		        'rows'        => 5,
		        'default'     => esc_html__( 'Discovery and Planning ios the initial and critical pase digital project sets.', 'xcency-core' ),
		    ]
		);


		$repeater->add_control(
		    'image',
		    [
		        'label'       => esc_html__( 'Box Image', 'xcency-core' ),
		        'type'        => Controls_Manager::MEDIA,
		        'label_block' => true,
		        'default'     => [
		            'url' => Utils::get_placeholder_image_src(),
		        ],
		    ]
		);

		$this->add_control(
		    'process_boxes',
		    [
		        'label'       => esc_html__( 'Working Process List', 'xcency-core' ),
		        'type'        => Controls_Manager::REPEATER,
		        'fields'      => $repeater->get_controls(),
		        'default'     => [
			        [
				        'subtitle' => esc_html__('Step 1', 'xcency-core'),
				        'title'    => esc_html__('Discovery & Planning', 'xcency-core'),
				        'desc'     => esc_html__('Discovery and Planning ios the initial and critical pase digital project sets.', 'xcency-core'),
			        ],
		        ],
		        'title_field' => '{{{ title }}}',
		    ]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'working_process_style',
            [
                'label' => esc_html__( 'Working Process', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs('td_default_and_hover_style_tabs_start');

        //Default style tab start
        $this->start_controls_tab(
            'td_working_process_style_default',
            [
                'label' => esc_html__('Default', 'xcency-core'),
            ]
        );

        $this->add_control(
            'default_bg_color',
            [
                'label'       => esc_html__('Background Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .xcency-working-process-box-content' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'default_subtitle_bg_color',
            [
                'label'       => esc_html__('Background Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .process-box-subtitle' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();//Default style tab end

        //Hover style tab start
        $this->start_controls_tab(
            'td_team_style_hover',
            [
                'label' => esc_html__('Hover', 'xcency-core'),
            ]
        );

		$this->add_control(
			'hover_bg_color',
			[
				'label'       => esc_html__('Background Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-working-process-box:hover .xcency-working-process-box-content' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'hover_subtitle_bg_color',
			[
				'label'       => esc_html__('Background Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-working-process-box:hover .process-box-subtitle' => 'background-color: {{VALUE}};',
				],
			]
		);

        $this->end_controls_tabs();//Hover style tab end

        $this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<div class="xcency-working-process-wrapper">
			<div class="row">
				<?php if($settings['process_boxes']){
				    foreach ($settings['process_boxes'] as $process_box){ ?>
					<div class="col-xl-3 col-lg-6 col-md-6">
						<div class="xcency-working-process-box">
                            <div class="xcency-working-process-box-image top-image" style="background-image: url(<?php echo $process_box['image']['url'];?>)"></div>
                            <div class="xcency-working-process-box-content">
                                <div class="process-box-subtitle"><?php echo $process_box['subtitle'];?></div>
								<h4 class="process-box-title"><?php echo $process_box['title'];?></h4>
								<div class="process-box-desc xcency-last-p-0"><?php echo $process_box['desc'];?></div>
							</div>
                            <div class="xcency-working-process-box-image bottom-image" style="background-image: url(<?php echo $process_box['image']['url'];?>)"></div>
						</div>
					</div>
				<?php	}
				} ?>
			</div>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Widget );