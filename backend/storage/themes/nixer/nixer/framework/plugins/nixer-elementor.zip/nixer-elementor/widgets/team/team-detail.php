<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsTeamDetail extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-team-detail';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Team Detail', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-single-page';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-team' ];
	}

	public function get_keywords() {
		return [ 'teamdetail', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_team_detail',
			[
				'label' => esc_html__( 'Team Detail', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'thumb_team',
			[
				'label'       	=> esc_html__( 'Thumbnail Team - If this field empty then use featured image team', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image team', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'title_team',
			[
				'label' 		=> esc_html__( 'Title Team - If this field empty then use title team', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'meta_loca',
			[
				'label' 		=> esc_html__( 'Country', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( 'USA' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_sec',
			[
				'label' 		=> esc_html__( 'Text Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'sc_select',
			[
				'label'     	=> esc_html__( 'Choose Source Social', 'bdevs-elementor' ),
				'type'      	=> Controls_Manager::SELECT,
				'options'   	=> [
					'type1'  		=> esc_html__( 'Auto Social Metabox', 'bdevs-elementor' ),
					'type2'  		=> esc_html__( 'Custom Social', 'bdevs-elementor' ),
					'type3'  		=> esc_html__( 'Hide Social', 'bdevs-elementor' ),
				],
				'default'   	=> 'type1',
			]
		);
		$rp_social = new \Elementor\Repeater();
		$rp_social->add_control(
			'rp_social_icon',
			[
				'label'       => __( 'Choose Icon Item', 'bdevs-elementor' ),
				'type'        => Controls_Manager::ICONS,
				'placeholder' => __( 'Choose your icon item', 'bdevs-elementor' ),
				'default' 	  => [
									'value' 	=> '',
									'library' 	=> 'fa-brands',
								],
				'label_block' => true,
			]	
		);
		$rp_social->add_control(
			'rp_social_text_icon',
			[
				'label'       	=> __( 'Text Icon Item', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::TEXTAREA,
				'placeholder' 	=> __( 'Enter your text icon item', 'bdevs-elementor' ),
				'default'     	=> __( '', 'bdevs-elementor' ),
				'label_block' 	=> true,
			]
		);
		$rp_social->add_control(
			'rp_social_link',
			[
				'label'       	=> __( 'Link Item', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::TEXTAREA,
				'placeholder' 	=> __( 'Enter your link item', 'bdevs-elementor' ),
				'default'     	=> __( '', 'bdevs-elementor' ),
				'label_block' 	=> true,
			]
		);
		$this->add_control(
			'tab_social',
			[
				'label' 		=> esc_html__( 'List Content Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $rp_social->get_controls(),
				'default' 		=> [
					[
						
					],
				],
				'condition' 	=> [
					'sc_select' 	=> 'type2',
				],
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-team-details-ptb p-relative pt-80">
	<div class="container container-1480">
		<div class="row align-items-center">
			<div class="col-lg-7 order-2 order-lg-1">
				<div class="tp-team-details-thumb p-relative z-index-1">
					<?php if (!empty($settings['thumb_team']['url'])) { ?>
						<img src="<?php echo wp_kses_post($settings['thumb_team']['url']); ?>" alt="<?php the_title_attribute(); ?>">
					<?php } else { ?>
						<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title_attribute(); ?>">
					<?php } ?>
				</div>
			</div>
			<div class="col-lg-5 order-1 order-lg-2">
				<div class="tp-team-details-content p-relative z-index-1">
					<h4 class="tp-team-details-title tp-char-animation">
						<?php if (!empty($settings['title_team'])) { ?>
							<?php echo wp_kses_post($settings['title_team']); ?>
						<?php } else { ?>
							<?php the_title(); ?>
						<?php } ?>
					</h4>
					<?php $terms = get_the_terms( get_the_ID(), 'team-job' ); ?>
					<?php if ((!empty( $terms ) && !is_wp_error( $terms )) || !empty($settings['meta_loca'])): ?>
						<span>
							<?php echo get_the_term_list( get_the_ID(), 'team-job', '', ', ', '' ); ?>
							<?php if (!empty( $terms ) && !is_wp_error( $terms ) && !empty($settings['meta_loca'])): ?>
								<?php echo esc_html__( '|', 'nixer' )?>
							<?php endif ?>
							<?php echo wp_kses_post($settings['meta_loca']); ?>
						</span>
					<?php endif ?>
					<?php if (!empty($settings['text_sec'])): ?>
						<p><?php echo wp_kses_post($settings['text_sec']); ?></p>
					<?php endif ?>
					<?php if ($settings['sc_select'] == 'type1') { ?>
						<?php 
						$social_links = [
							['link' => get_post_meta(get_the_ID(), '_cmb_link_social_1', true), 'icon' => get_post_meta(get_the_ID(), '_cmb_icon_social_1', true)],
							['link' => get_post_meta(get_the_ID(), '_cmb_link_social_2', true), 'icon' => get_post_meta(get_the_ID(), '_cmb_icon_social_2', true)],
							['link' => get_post_meta(get_the_ID(), '_cmb_link_social_3', true), 'icon' => get_post_meta(get_the_ID(), '_cmb_icon_social_3', true)],
							['link' => get_post_meta(get_the_ID(), '_cmb_link_social_4', true), 'icon' => get_post_meta(get_the_ID(), '_cmb_icon_social_4', true)],
						]; ?>
						<div class="tp-team-details-social">
							<?php foreach ($social_links as $social) :
								if (!empty($social['link']) && !empty($social['icon'])) : ?>
									<a href="<?php echo esc_url($social['link']); ?>">
										<span><?php echo nixer_inline_svg_from_url($social['icon']); ?></span>
									</a>
								<?php endif;
							endforeach; ?>
						</div>
					<?php } elseif ($settings['sc_select'] == 'type2') { ?>
						<div class="tp-team-details-social">
							<?php 
							foreach ($settings['tab_social'] as $itemsc) :
							?>
								<?php if (!empty($itemsc['rp_social_link']) && (!empty($itemsc['rp_social_icon']) || !empty($itemsc['rp_social_text_icon']))): ?>
									<a href="<?php echo wp_kses_post($itemsc['rp_social_link']); ?>">
										<span>
											<?php if (!empty($itemsc['rp_social_icon']['value'])) { ?>
												<?php \Elementor\Icons_Manager::render_icon( $itemsc['rp_social_icon'], [ 'aria-hidden' => 'true' ] ); ?>
											<?php } else { ?>
												<?php echo wp_kses_post($itemsc['rp_social_text_icon']); ?>
											<?php } ?>
										</span>
									</a>
								<?php endif ?>
							<?php endforeach; ?>
						</div>
					<?php } else { ?>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		if (jQuery('.tp-team-details-content .tp-char-animation').length > 0) {
			var char_come = gsap.utils.toArray(".tp-team-details-content .tp-char-animation");
			char_come.forEach(splitTextLine => {
				var tl = gsap.timeline({
					scrollTrigger: {
						trigger: splitTextLine,
						start: 'top 90%',
						end: 'bottom 60%',
						scrub: false,
						markers: false,
						toggleActions: 'play none none none'
					}
				});

				var itemSplitted = new SplitText(splitTextLine, { type: "chars, words" });
				gsap.set(splitTextLine, { perspective: 300 });
				itemSplitted.split({ type: "chars, words" })
				tl.from(itemSplitted.chars,
					{
						duration: 1,
						delay: 0.5,
						x: 100,
						autoAlpha: 0,
						stagger: 0.05
					});
			});
		}
	</script>
<?php } ?>

<?php
}

}