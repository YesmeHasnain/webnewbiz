<?php
namespace EARLSPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Css_Filter;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class About_Image extends Widget_Base {
	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'earls_about_image';
	}
	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Earls About Image', 'earls' );
	}
	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-image-rollover';
	}
	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'earls' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'about_image',
			[
				'label' => esc_html__( 'Earls About Image', 'earls' ),
			]
		);
		$this->add_control(
			'image',
			[
				'label' => esc_html__( 'Choose Image', 'earls' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		
		$this->add_control(
			'image2',
			[
				'label' => esc_html__( 'Choose Image', 'earls' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		
		$this->add_control(
			'year_title',
			[
				'label'       => __( 'Year Title ', 'earls' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Year Title', 'earls' ),
			]
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name' => 'image', // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `image_size` and `image_custom_dimension`.
				'default' => 'large',
				'separator' => 'none',
			]
		);
		$this->end_controls_section();
		
		/************************************************************************
								Tab Style Start
		*************************************************************************/
		
		$this->start_controls_section(
			'section_style_image',
			[
				'label' => esc_html__( 'Image Setting', 'earls' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label' => esc_html__( 'Alignment', 'earls' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'earls' ),
						'icon' => 'eicon-text-align-left',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'earls' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} img' => 'float: {{VALUE}};',
				],
			]
		);
		
		$this->add_responsive_control(
			'width',
			[
				'label' => esc_html__( 'Width', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'unit' => '%',
				],
				'tablet_default' => [
					'unit' => '%',
				],
				'mobile_default' => [
					'unit' => '%',
				],
				'size_units' => [ '%', 'px', 'vw' ],
				'range' => [
					'%' => [
						'min' => 1,
						'max' => 100,
					],
					'px' => [
						'min' => 1,
						'max' => 1000,
					],
					'vw' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'space',
			[
				'label' => esc_html__( 'Max Width', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'unit' => '%',
				],
				'tablet_default' => [
					'unit' => '%',
				],
				'mobile_default' => [
					'unit' => '%',
				],
				'size_units' => [ '%', 'px', 'vw' ],
				'range' => [
					'%' => [
						'min' => 1,
						'max' => 100,
					],
					'px' => [
						'min' => 1,
						'max' => 1000,
					],
					'vw' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} img' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'height',
			[
				'label' => esc_html__( 'Height', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'unit' => 'px',
				],
				'tablet_default' => [
					'unit' => 'px',
				],
				'mobile_default' => [
					'unit' => 'px',
				],
				'size_units' => [ 'px', 'vh' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 500,
					],
					'vh' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'object-fit',
			[
				'label' => esc_html__( 'Object Fit', 'earls' ),
				'type' => Controls_Manager::SELECT,
				'condition' => [
					'height[size]!' => '',
				],
				'options' => [
					'' => esc_html__( 'Default', 'earls' ),
					'fill' => esc_html__( 'Fill', 'earls' ),
					'cover' => esc_html__( 'Cover', 'earls' ),
					'contain' => esc_html__( 'Contain', 'earls' ),
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} img' => 'object-fit: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'separator_panel_style',
			[
				'type' => Controls_Manager::DIVIDER,
				'style' => 'thick',
			]
		);

		$this->start_controls_tabs( 'image_effects' );

		$this->start_controls_tab( 'normal',
			[
				'label' => esc_html__( 'Normal', 'earls' ),
			]
		);

		$this->add_control(
			'opacity',
			[
				'label' => esc_html__( 'Opacity', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 1,
						'min' => 0.10,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} img' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			[
				'name' => 'css_filters',
				'selector' => '{{WRAPPER}} img',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab( 'hover',
			[
				'label' => esc_html__( 'Hover', 'earls' ),
			]
		);

		$this->add_control(
			'opacity_hover',
			[
				'label' => esc_html__( 'Opacity', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 1,
						'min' => 0.10,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}}:hover img' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			[
				'name' => 'css_filters_hover',
				'selector' => '{{WRAPPER}}:hover img',
			]
		);

		$this->add_control(
			'background_hover_transition',
			[
				'label' => esc_html__( 'Transition Duration', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 3,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} img' => 'transition-duration: {{SIZE}}s',
				],
			]
		);

		$this->add_control(
			'hover_animation',
			[
				'label' => esc_html__( 'Hover Animation', 'earls' ),
				'type' => Controls_Manager::HOVER_ANIMATION,
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'image_border',
				'selector' => '{{WRAPPER}} img',
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'image_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'earls' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'image_box_shadow',
				'exclude' => [
					'box_shadow_position',
				],
				'selector' => '{{WRAPPER}} img',
			]
		);

		$this->end_controls_section();
		
		/**Video Icon Style**/
		$this->start_controls_section(
			'video_style',
			[
				'label' => esc_html__('Video Box Setting', 'earls'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'video_position',
			[
				'label' => esc_html__( 'Position', 'earls' ),
				'type' => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					'' => esc_html__( 'Default', 'earls' ),
					'absolute' => esc_html__( 'Absolute', 'earls' ),
					'fixed' => esc_html__( 'Fixed', 'earls' ),
				],
				'selectors' => [
					'{{WRAPPER}} .about-one__video' => 'position: {{VALUE}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_control(
			'video_offset_orientation_h',
			[
				'label' => esc_html__( 'Horizontal Orientation', 'earls' ),
				'type' => Controls_Manager::CHOOSE,
				'toggle' => false,
				'default' => 'end',
				'options' => [
					'start' => [
						'title' => 'left',
						'icon' => 'eicon-h-align-left',
					],
					'end' => [
						'title' => 'right',
						'icon' => 'eicon-h-align-right',
					],
				],
				'classes' => 'earls-control-start-end',
				'render_type' => 'ui',
				'condition' => [
					'video_position!' => '',
				],
			]
		);
		
		$this->add_responsive_control(
			'video_offset_x',
			[
				'label' => esc_html__( 'Offset', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'default' => [
					'size' => '0',
				],
				'size_units' => [ 'px', '%', 'vw', 'vh', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .about-one__video' => 'left: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'video_offset_orientation_h!' => 'end',
					'video_position!' => '',
				],
			]
		);
		
		$this->add_responsive_control(
			'video_offset_x_end',
			[
				'label' => esc_html__( 'Offset', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 0.1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'default' => [
					'size' => '0',
				],
				'size_units' => [ 'px', '%', 'vw', 'vh', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .about-one__video' => 'right: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'video_offset_orientation_h' => 'end',
					'video_position!' => '',
				],
			]
		);
		
		$this->add_control(
			'video_offset_orientation_v',
			[
				'label' => esc_html__( 'Vertical Orientation', 'earls' ),
				'type' => Controls_Manager::CHOOSE,
				'toggle' => false,
				'default' => 'start',
				'options' => [
					'start' => [
						'title' => esc_html__( 'Top', 'earls' ),
						'icon' => 'eicon-v-align-top',
					],
					'end' => [
						'title' => esc_html__( 'Bottom', 'earls' ),
						'icon' => 'eicon-v-align-bottom',
					],
				],
				'render_type' => 'ui',
				'condition' => [
					'video_position!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'video_offset_y',
			[
				'label' => esc_html__( 'Offset', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'size_units' => [ 'px', '%', 'vh', 'vw', 'custom' ],
				'default' => [
					'size' => '0',
				],
				'selectors' => [
					'{{WRAPPER}} .about-one__video' => 'top: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'video_offset_orientation_v!' => 'end',
					'video_position!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'video_offset_y_end',
			[
				'label' => esc_html__( 'Offset', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'size_units' => [ 'px', '%', 'vh', 'vw', 'custom' ],
				'default' => [
					'size' => '0',
				],
				'selectors' => [
					'{{WRAPPER}} .about-one__video' => 'bottom: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'video_offset_orientation_v' => 'end',
					'video_position!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'_z_index',
			[
				'label' => esc_html__( 'Z-Index', 'earls' ),
				'type' => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .about-one__video' => 'z-index: {{VALUE}};',
				],
			]
		);
		
		$this->start_controls_tabs( 'earls_tabs_btn' );
	
			$this->start_controls_tab(
				'earls_tab_btn_normal',
				[
					'label' => __( 'Normal', 'earls' ),
				]
			);
				//background
				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'video_bgtype',
						'label' => __( 'Background', 'earls' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' => 
							'{{WRAPPER}} .about-one__video',				
					]
				);
				
				//color
				$this->add_control(
					'video_title_color',
					[
						'label' => __('Text Color', 'earls'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .about-one__video span' => 'color: {{VALUE}}',
						],
						'separator' => 'before',
					]
				);
				
				//typography
				$this->add_group_control(
					Group_Control_Typography::get_type(),
					[
						'name' => 'video_title_typography',
						'label' => __('Text Typography', 'earls'),
						'selector' => 
							'{{WRAPPER}} .about-one__video span',				
						'separator' => 'before',
					]
				);
				
				//width
				$this->add_responsive_control(
					'vido_space',
					[
						'label' => __( 'Space', 'earls' ),
						'type' => Controls_Manager::SLIDER,
						'size_units' => [ 'px', 'em', '%', 'custom' ],
						'range' => [
							'px' => [
								'min' => 0,
								'max' => 500,
							],
							'%' => [
								'min' => 0,
								'max' => 100,
							],
						],
						'selectors' => [
							'{{WRAPPER}} .about-one__video span' => 'margin-top: {{SIZE}}{{UNIT}};'
						],
					]
				);
				
				//width
				$this->add_responsive_control(
					'vido_width_size',
					[
						'label' => __( 'Width', 'earls' ),
						'type' => Controls_Manager::SLIDER,
						'size_units' => [ 'px', 'em', '%', 'custom' ],
						'range' => [
							'px' => [
								'min' => 0,
								'max' => 500,
							],
							'%' => [
								'min' => 0,
								'max' => 100,
							],
						],
						'selectors' => [
							'{{WRAPPER}} .about-one__video' => 'width: {{SIZE}}{{UNIT}};'
						],
					]
				);
				
				//height
				$this->add_responsive_control(
					'video_height_size',
					[
						'label' => __( 'Height', 'earls' ),
						'type' => Controls_Manager::SLIDER,
						'size_units' => [ 'px', 'em', '%', 'custom' ],
						'range' => [
							'px' => [
								'min' => 0,
								'max' => 500,
							],
							'%' => [
								'min' => 0,
								'max' => 100,
							],
						],
						'selectors' => [
							'{{WRAPPER}} .about-one__video' => 'height: {{SIZE}}{{UNIT}};'
						],
					]
				);
				
				//border
				$this->add_group_control(
					Group_Control_Border::get_type(),
					[
						'name' => 'video_border_type',
						'selector' => 
							'{{WRAPPER}} .about-one__video',				
						'separator' => 'before',
					]
				);
				
				//border
				$this->add_control(
					'video_border_radius',
					[
						'label' => esc_html__('Border Radius', 'earls'),
						'type' => Controls_Manager::DIMENSIONS,
						'separator' => 'before',
						'size_units' => ['px'],
						'selectors' => [
							'{{WRAPPER}} .about-one__video' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				
				//box shadow
				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name' => 'border_box_shadow',
						'selector' => 
							'{{WRAPPER}} .about-one__video',				
						'separator' => 'before',
					]
				);
				
				//Video Icon Color
				$this->add_control(
					'video_icon_color',
					[
						'label' => __('Video Icon Color', 'earls'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .about-one__video i' => 'color: {{VALUE}}'
						],
						'separator' => 'before',
						'condition'             => [
							'show_video_style'    => 'yes',
						]
					]
				);
			$this->end_controls_tab();
			
			$this->start_controls_tab(
				'earls_tab_btn_hover',
				[
					'label' => __( 'Hover', 'earls' ),
				]
			);
			
				//background
				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'video_hover_bgtype',
						'label' => __( 'Background', 'earls' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' => 
							'{{WRAPPER}} .about-one__video:hover',				
					]
				);
				
				//color
				$this->add_control(
					'video_hover_title_color',
					[
						'label' => __('Text Color', 'earls'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .about-one__video:hover span' => 'color: {{VALUE}}',
						],
						'separator' => 'before',
					]
				);
				
				//Video Icon Hover Color
				$this->add_control(
					'video_icon_hover_color',
					[
						'label' => __('Video Icon Hover Color', 'earls'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .about-one__video:hover i' => 'color: {{VALUE}}'
						],
						'separator' => 'before',
						'condition'             => [
							'show_video_style'    => 'yes',
						]
					]
				);
			
			$this->end_controls_tab();
			
		$this->end_controls_tabs();   
		
		$this->end_controls_section();
		
		/**Image Caption Style**/
		$this->start_controls_section(
			'image_caption_style',
			[
				'label' => esc_html__('Caption Setting', 'earls'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_responsive_control(
			'caption_padding',
			[
				'label'              => __( 'Padding', 'earls' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', 'em', '%' ],
				'selectors'          => [
					'{{WRAPPER}} .about-five__image__caption' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
				
				'frontend_available' => true,
			]
		);
		
		$this->add_control(
			'caption_position',
			[
				'label' => esc_html__( 'Position', 'earls' ),
				'type' => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					'' => esc_html__( 'Default', 'earls' ),
					'absolute' => esc_html__( 'Absolute', 'earls' ),
					'fixed' => esc_html__( 'Fixed', 'earls' ),
				],
				'selectors' => [
					'{{WRAPPER}} .about-five__image__caption' => 'position: {{VALUE}};',
				],
				'frontend_available' => true,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'caption_offset_orientation_h',
			[
				'label' => esc_html__( 'Horizontal Orientation', 'earls' ),
				'type' => Controls_Manager::CHOOSE,
				'toggle' => false,
				'default' => 'start',
				'options' => [
					'start' => [
						'title' => 'left',
						'icon' => 'eicon-h-align-left',
					],
					'end' => [
						'title' => 'right',
						'icon' => 'eicon-h-align-right',
					],
				],
				'classes' => 'earls-control-start-end',
				'render_type' => 'ui',
				'condition' => [
					'caption_position!' => '',
				],
			]
		);
		
		$this->add_responsive_control(
			'caption_offset_x',
			[
				'label' => esc_html__( 'Offset', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'default' => [
					'size' => '0',
				],
				'size_units' => [ 'px', '%', 'vw', 'vh', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .about-five__image__caption' => 'left: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'caption_offset_orientation_h!' => 'end',
					'caption_position!' => '',
				],
			]
		);
		
		$this->add_responsive_control(
			'caption_offset_x_end',
			[
				'label' => esc_html__( 'Offset', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 0.1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'default' => [
					'size' => '0',
				],
				'size_units' => [ 'px', '%', 'vw', 'vh', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .about-five__image__caption' => 'right: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'caption_offset_orientation_h' => 'end',
					'caption_position!' => '',
				],
			]
		);
		
		$this->add_control(
			'caption_offset_orientation_v',
			[
				'label' => esc_html__( 'Vertical Orientation', 'earls' ),
				'type' => Controls_Manager::CHOOSE,
				'toggle' => false,
				'default' => 'start',
				'options' => [
					'start' => [
						'title' => esc_html__( 'Top', 'earls' ),
						'icon' => 'eicon-v-align-top',
					],
					'end' => [
						'title' => esc_html__( 'Bottom', 'earls' ),
						'icon' => 'eicon-v-align-bottom',
					],
				],
				'render_type' => 'ui',
				'condition' => [
					'caption_position!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'caption_offset_y',
			[
				'label' => esc_html__( 'Offset', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'size_units' => [ 'px', '%', 'vh', 'vw', 'custom' ],
				'default' => [
					'size' => '0',
				],
				'selectors' => [
					'{{WRAPPER}} .about-five__image__caption' => 'top: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'caption_offset_orientation_v!' => 'end',
					'caption_position!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'caption_offset_y_end',
			[
				'label' => esc_html__( 'Offset', 'earls' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'size_units' => [ 'px', '%', 'vh', 'vw', 'custom' ],
				'default' => [
					'size' => '0',
				],
				'selectors' => [
					'{{WRAPPER}} .about-five__image__caption' => 'bottom: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'caption_offset_orientation_v' => 'end',
					'caption_position!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'caption_z_index',
			[
				'label' => esc_html__( 'Z-Index', 'earls' ),
				'type' => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .about-five__image__caption' => 'z-index: {{VALUE}};',
				],
			]
		);
		
		//Image Caption BG Color
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'image_caption_bgcolor',
				'label' => __( 'Image Caption Background', 'earls' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => 
					'{{WRAPPER}} .about-five__image__caption',				
			]
		);
		//Image Caption Title
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'image_caption_typography',
                'label' => __('Caption Title Typography', 'earls'),
                'selector' => 
                    '{{WRAPPER}} .about-five__image__caption__title',                 
                'separator' => 'before',
			]
        );
		$this->add_control(
            'image_caption_color',
            [
                'label' => __('Caption Title Color', 'earls'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .about-five__image__caption__title' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
			]
        );
		//Image Caption Designation
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'image_caption_designaion_typography',
                'label' => __('Designation Typography', 'earls'),
                'selector' => 
                    '{{WRAPPER}} .about-five__image__caption__text',                 
                'separator' => 'before',
				'condition'             => [
					'show_image_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'image_caption_designaion_color',
            [
                'label' => __('Caption Designation Color', 'earls'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .about-five__image__caption__text' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_image_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();
		
	}
	/**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post'); 
	?>
	
    <div class="about__right__img">
        <?php if($settings['image']['id']){ ?>
        <div class="about__right__img__one p_absolute">
            <figure>
                <img class="rotate-me" src="<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','earls');?>">
            </figure>
        </div>
        <?php } ?>
        <?php if($settings['image2']['id']){ ?>
        <div class="about__right__img__two wow slideInRight animated animated" data-wow-delay="200ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 200ms; animation-name: slideInRight;">
            <figure>
                <img src="<?php echo esc_url(wp_get_attachment_url($settings['image2']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','earls');?>">
            </figure>
            <span class="te-years"><?php echo wp_kses($settings['year_title'], true);?></span>
        </div>
        <?php } ?>
    </div>
    
    <?php 
	}
}