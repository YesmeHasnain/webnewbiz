<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome2CounterSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home2-counter-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 2 - Counter Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-counter';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home2' ];
	}

	public function get_keywords() {
		return [ 'home2countersection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_counter_section',
			[
				'label' => esc_html__( 'Counter Section', 'bdevs-elementor' ),
			]
		);
		$rp_counter = new \Elementor\Repeater();
		$rp_counter->add_control(
			'label_counter',
			[
				'label' 		=> esc_html__( 'Label Counter Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Label Counter' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_counter->add_control(
			'num_count',
			[
				'label' 		=> esc_html__( 'Number Counter', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::NUMBER,
				'min' 			=> 0,
				'default' 		=> 235,
			]
		);
		$rp_counter->add_control(
			'text_num_bf',
			[
				'label' 		=> esc_html__( 'Text Befoter Number Counter', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXT,
				'default' 		=> __( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_counter->add_control(
			'text_num_af',
			[
				'label' 		=> esc_html__( 'Text After Number Counter', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXT,
				'default' 		=> __( '' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'tabs',
			[
				'label' 		=> esc_html__( 'List Counter Content', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $rp_counter->get_controls(),
				'default' 		=> [
					[
						
					],
				],
				'title_field' 	=> '{{{ label_counter }}}',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-counter-ptb pb-110">
	<div class="container container-1610">
		<div class="row">
			<div class="col-lg-12">
				<div class="tp-counter-wrapper d-flex align-items-center">
					<?php
					foreach ($settings['tabs'] as $item) :
					?>
						<div class="tp-counter-item">
							<?php if (!empty($item['num_count'])): ?>
								<h4 class="tp-counter-item-title">
									<?php echo wp_kses_post($item['text_num_bf']); ?><span class="purecounter" data-purecounter-duration="2" data-purecounter-end="<?php echo wp_kses_post($item['num_count']); ?>"><?php echo wp_kses_post($item['num_count']); ?></span><?php echo wp_kses_post($item['text_num_af']); ?>
								</h4>
							<?php endif ?>
							<?php if (!empty($item['label_counter'])): ?>
								<p><?php echo wp_kses_post($item['label_counter']); ?></p>
							<?php endif ?>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		new PureCounter();
	</script>
<?php } ?>

<?php
}

}