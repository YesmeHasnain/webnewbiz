(function ($) {
    "use strict";
    $(window).on("load", function () {
        // makes sure the whole site is loaded

        //isotope setting(event)
        $(".event-body").imagesLoaded(function () {
            $(".event-body").isotope();
        });
        // filter items when filter link is clicked
        $(".port-filter a").on("click", function () {
            var selector = $(this).attr("data-filter");
            $(".event-body").isotope({
                itemSelector: ".port-item",
                filter: selector
            });
            $(".port-filter a").removeClass("active");
            $(this).addClass("active");
            return false;
        });
    });
})(jQuery);
