
<div class="hero-wrapper hero-2">
    <div class="hero-slider-2 hero-slider-active slider-<?php echo $dynamic_id; ?>">
    <?php if (!empty($hero_slides)) { $i = 0;
        foreach ($hero_slides as $item) { $i++; ?>
        <div class="single-slide bg-cover" style="background-image: url('<?php echo esc_url($item['hero_image']['url']); ?>')">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-xxl-9 col-md-10">
                        <div class="hero-contents">
                            <h1 class="fs-lg animated" data-animation-in="fadeInUp" data-delay-in="0.1"><?php echo htmlspecialchars_decode(esc_html($item['hero_heading'])); ?></h1>

                            <?php if( !empty( $item['hero_subtitle'] ) ) : ?>
                            <p class="pe-lg-5 animated" data-animation-in="fadeInUp" data-delay-in="0.5"><?php echo htmlspecialchars_decode( esc_html( $item['hero_subtitle'] ) ); ?></p>
                            <?php endif; ?>

                            <?php if( !empty( $item['btn_link1']['url'] && $item['button_text1'] ) ) : ?>
                            <a href="<?php echo esc_url($item['btn_link1']['url']); ?>" <?php modina_is_external($item['btn_link1']); ?> <?php modina_is_nofollow($item['btn_link1']); ?> class="theme-btn me-sm-4 " data-animation-in="fadeInUp" data-delay-in="0.8"><?php echo esc_html( $item['button_text1'] ); ?></a>
                            <?php endif; ?>

                            <?php if( !empty( $item['btn_link2']['url'] &&  $item['button_text2'] ) ) : ?>
                            <a href="<?php echo esc_url($item['btn_link2']['url']); ?>" <?php modina_is_external($item['btn_link2']); ?> <?php modina_is_nofollow($item['btn_link2']); ?> class="theme-btn me-sm-4 " data-animation-in="fadeInUp" data-delay-in="0.95"><?php echo esc_html( $item['button_text2'] ); ?></a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php if( !empty( $item['watermark']['url'] ) ) : ?>
            <div class="site-watermark-icon d-none d-lg-block">
                <img src="<?php echo esc_url( $item['watermark']['url'] ); ?>" alt="">
            </div>
            <?php endif; ?>
        </div>
    <?php }
    } ?>
    </div>
    <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
        <symbol xmlns="http://www.w3.org/2000/svg" viewBox="0 0 44 44" width="44px" height="44px" id="circle" fill="none" stroke="currentColor">
            <circle r="20" cy="22" cx="22" id="translandcircle" />
        </symbol>
    </svg>
</div>