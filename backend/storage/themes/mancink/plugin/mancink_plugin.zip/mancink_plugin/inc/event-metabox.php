<?php
/**
 * Initialize the Event Post Meta Boxes. 
 */


add_action( 'cmb2_admin_init', 'event_mb' );
function event_mb() {
	
	
	$mancink_event_metabox_cmb2 = new_cmb2_box( array(
		'id'            => 'mancink_event_metabox',
		'title'         => esc_html__( 'Event Settings', 'mancink_plugin' ),
		'object_types'  => array( 'event' ), // Post type
		'priority'      => 'high',
	) );
  
  	$mancink_event_metabox_cmb2->add_field( array(
		'name'             => esc_html__( 'Please Read:', 'mancink_plugin' ),
		'id'            => 'mancink_ptitle_text',
		'desc' => wp_kses_post( 'Recommended size for event <strong>featured images</strong> is <strong>800x582px</strong> or <strong>800x1164px</strong>
		<br> To be able to edit this event with <strong>elementor</strong>, make sure you have checklist the <strong>Event</strong> in <strong>Elementor Settings -> Post Type</strong>. 
		<br>You choose the <strong>Blank Page Builder</strong> template if you want to build this event using only the <strong>elementor</strong> page builder.', 'mancink_plugin' ),
		'type'             => 'title',
	) );
	
	$mancink_event_metabox_cmb2->add_field( array(
		'name'             => esc_html__( 'Event Format', 'mancink_plugin' ),
		'desc'             => esc_html__( 'Choose Event Format Here', 'mancink_plugin' ),
		'id'               => 'port_format',
		'type'             => 'select',
		'default' => 'port_standard',
		'options'          => array(
			'port_standard' => esc_html__( 'Event Gallery at Top', 'mancink_plugin' ),
			'port_two'   => esc_html__( 'Event Gallery at Right', 'mancink_plugin' )
		),
	) );
	
	$mancink_event_metabox_cmb2->add_field( array(
		'name'             => esc_html__( 'Top Content Format', 'mancink_plugin' ),
		'desc'             => esc_html__( 'Choose Event Format Here', 'mancink_plugin' ),
		'id'               => 'top_type',
		'type'             => 'select',
		'default' => 'top_content_slider',
		'options'          => array(
			'top_content_slider' => esc_html__( 'Images Background', 'mancink_plugin' ),
		),
	) );
	
	
	
	
	$mancink_event_metabox_cmb2->add_field( array(
		'name'             => esc_html__( 'Event Top Image', 'mancink_plugin' ),
		'desc'             => wp_kses_post( 'Upload Your Top Image here.', 'mancink_plugin' ),
		'id'      => 'port_slider_setting',
		'type'    => 'file',
		// Optional:
		'options' => array(
			'url' => false, // Hide the text input for the url
			),
		'text'    => array(
			'add_upload_file_text' => 'Add Image' // Change upload button text. Default: "Add or Upload File"
			),
		'query_args' => array(
			'type' => array(
				'image/gif',
				'image/jpeg',
				'image/png',	
				),
		),
		'preview_size' => 'large', // Image size to use when previewing in the admin.
	) );
	
	
	$mancink_event_metabox_cmb2->add_field( array(
		'name'             => esc_html__( 'Event Gallery Images', 'mancink_plugin' ),
		'desc'             => esc_html__( 'Create your gallery here. You can leave it blank if you don\'t want it.', 'mancink_plugin' ),
		'id'   => 'gallery_list',
		'type' => 'file_list',
		'text' => array(
			'add_upload_files_text' => 'Upload images',
		),
		'preview_size' => array( 100, 100 ), // Default: array( 50, 50 )
		'query_args' => array( 'type' => 'image' ), // Only images attachment
	) );
	
	$mancink_event_metabox_cmb2->add_field( array(
		'name'             => esc_html__( 'Event Button Link', 'mancink_plugin' ),
		'desc'             => esc_html__( 'Insert your button link here. Leave it blank if you dont want it.', 'mancink_plugin' ),
		'id'               => 'port_item_btn_link',
		'type'             => 'text',
	) );
	
	
	$mancink_event_metabox_cmb2->add_field( array(
		'name'             => esc_html__( 'Event Button Text', 'mancink_plugin' ),
		'desc'             => esc_html__( 'Insert your button text here. Leave it blank if you dont want it.', 'mancink_plugin' ),
		'id'               => 'port_item_btn_text',
		'type'             => 'text',
	) );
	
	
 

}

add_action( 'cmb2_admin_init', 'event_detail' );
function event_detail() {
	$mancink_event_metabox_cmb2 = new_cmb2_box( array(
		'id'            => 'mancink_event_detail',
		'title'         => esc_html__( 'Event Detail', 'mancink_plugin' ),
		'object_types'  => array( 'event' ), // Post type
		'priority'      => 'high',
	) );

	$mancink_event_metabox_cmb2->add_field( array(
		'name'             => esc_html__( 'Event Location', 'mancink_plugin' ),
		'desc'             => esc_html__( 'Insert your event location here. Leave it blank if you dont want it.', 'mancink_plugin' ),
		'id'               => 'eventmb_location',
		'type'             => 'text',
	) );

	$mancink_event_metabox_cmb2->add_field( array(
		'name'             => esc_html__( 'Event Date', 'mancink_plugin' ),
		'desc'             => esc_html__( 'Insert your event date here. Leave it blank if you dont want it.', 'mancink_plugin' ),
		'id'               => 'eventmb_date',
		'type'             => 'text',
	) );

	$mancink_event_metabox_cmb2->add_field( array(
		'name'             => esc_html__( 'Event Time', 'mancink_plugin' ),
		'desc'             => esc_html__( 'Insert your event time here. Leave it blank if you dont want it.', 'mancink_plugin' ),
		'id'               => 'eventmb_time',
		'type'             => 'text',
	) );


	$mancink_event_metabox_cmb2->add_field( array(
		'name'             => esc_html__( 'Event Location', 'mancink_plugin' ),
		'desc'             => esc_html__( 'Insert your event location here. Leave it blank if you dont want it.', 'mancink_plugin' ),
		'id'               => 'eventmb_location',
		'type'             => 'text',
	) );
}