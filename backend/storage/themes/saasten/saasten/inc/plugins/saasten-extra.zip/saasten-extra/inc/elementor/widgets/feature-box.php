<?php

/**
 * Elementor Widget
 * @package Knor
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_feature_box_one extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'custom-featbox-wid';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Feature Box V.1', 'knor-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'knor_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {


		$this->start_controls_section(
            'feature_box_icon_options',
            [
                'label' => esc_html__( 'Feature Box Content', 'knor-extra' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );


        $this->add_control(
            'feature_box_enable_icon',
            [
                'label' => esc_html__( 'Enable Icon', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'knor-extra' ),
                'label_off' => esc_html__( 'Hide', 'knor-extra' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );



         $this->add_control(
			'feature_box_icon_type',
			[
			    'label' => esc_html__('Feature Icon Type','knor-extra'),
			    'type' => \Elementor\Controls_Manager::CHOOSE,
			    'options' =>[
				  'img' =>[
					'title' => esc_html__('Image','knor-extra'),
					'icon' => 'fa fa-picture-o',
				  ],
				  'icon' =>[
					'title' => esc_html__('Icon','knor-extra'),
					'icon' => 'fa fa-info',
				  ]
			    ],
			    'default' => 'icon',
			]
		);

        $this->add_control(
			'feature_box_icon_img',
			[
			    'label' => esc_html__('Image Icon','knor-extra'),
			    'type'=> \Elementor\Controls_Manager::MEDIA,
			    'default' => [
				  'url' => \Elementor\Utils::get_placeholder_image_src(),
			    ],
                'label_block' => true,
			    'condition' => [
				  'feature_box_icon_type' => 'img',
			    ]
			]
		);

		$this->add_control(
            'feature_box_icon_self',
            [
                'label' => esc_html__( 'Icon', 'knor-extra' ),
                'type'     => \Elementor\Controls_Manager::ICONS,
                'default'  => [
					'value'   => 'fas fa-star',
					'library' => 'solid',
				],
                'condition' => [
                    'feature_box_icon_type' => 'icon',
                  ]
            ]
        );

        $this->add_control(
            'feature_box_title',
            [
                'label' => esc_html__( 'Title', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__( 'Web Development', 'knor-extra' ),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'feature_box_des',
            [
                'label' => esc_html__( 'Short Description', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__( 'Content', 'knor-extra' ),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'feature_box_enable_link',
            [
                'label' => esc_html__( 'Enable Link', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'knor-extra' ),
                'label_off' => esc_html__( 'Hide', 'knor-extra' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );


        $this->add_control(
			'feature_box_enable_link_select',
			[
				'label' => esc_html__( 'Select Link', 'knor-extra' ),
				'type'  => \Elementor\Controls_Manager::SELECT,
				'default'	=> 'external',
				'options' => [
					'external' => esc_html__( 'External', 'knor-extra' ),
					'page' =>  esc_html__( 'Page', 'knor-extra' ),
				],
                'condition' => [
                    'feature_box_enable_link' => 'yes',
                ],
				'label_block' => true,
			]
		);
		

        $this->add_control(
			'feature_box_enable_link_extra',
			[
				'label' => esc_html__( 'Giver External Link', 'knor-extra' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'condition' => [
					'feature_box_enable_link_select' => 'extranal',
					'feature_box_enable_link' => 'yes',
				],
				'placeholder' => esc_html__( 'Add External Link', 'knor-extra' ),
				'label_block' => true,
			]
		);


		$this->add_control(
			'feature_box_enable_link_pages',
			[
				'label' => esc_html__( 'Page Link', 'knor-extra' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => knor_page_list(),
				'condition' => [
					'feature_box_enable_link_select' => 'page',
					'feature_box_enable_link' => 'yes',
				],
				'label_block' => true,
			]
		);


        $this->add_control(
			'feature_box_enable_link_new_tab',
			[
				'label' => __( 'Open in New Window?', 'knor-extra' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'knor-extra' ),
				'label_off' => __( 'Hide', 'knor-extra' ),
				'return_value' => 'yes',
				'default' => 'no',
                'condition' => [
                    'feature_box_enable_link' => 'yes',
                ],
			]
		);

        $this->add_control(
			'feature_box_enable_link_nofollow',
			[
				'label' => __( 'Add nofollow?', 'knor-extra' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'knor-extra' ),
				'label_off' => __( 'Hide', 'knor-extra' ),
				'return_value' => 'yes',
				'default' => 'no',
                'condition' => [
                    'feature_box_enable_link' => 'yes',
                ],
			]
		);







        $this->end_controls_section();



        // ===================== Buttons ================//

        $this->start_controls_section( 'button_section', [
            'label' => esc_html__( 'Button', 'knor-extra' ),
        ] );

        $this->add_control(
            'pbtnn_button_options', [
                'label' => __( 'Feature Box Button', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control( 'btn_text', [
            'label'       => __( 'Button Label', 'knor-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'placeholder' => __( 'Type your button label here', 'knor-extra' ),
            'default'     => __( 'Learn More', 'knor-extra' ),
        ] );

        $this->add_control( 'btn_link', [
            'label'       => __( 'Button Link', 'knor-extra' ),
            'type'        => \Elementor\Controls_Manager::URL,
            'placeholder' => __( 'https://your-link.com', 'knor-extra' ),
            'default'     => [
                'url' => '#',
            ],
        ] );


        $this->add_control(
            'feature_box_btn_iconn',
            [
                'label' => esc_html__( 'Button Icon', 'knor-extra' ),
                'type'     => \Elementor\Controls_Manager::ICONS,
                'default'  => [
                    'value'   => 'fas fa-star',
                    'library' => 'solid',
                ],
            ]
        );

        $this->end_controls_section(); //End Buttons



        $this->start_controls_section(
            'feature_box_wrapper_options',
            [
                'label' => esc_html__( 'Wrapper Styling', 'knor-extra' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );


        $this->add_control(
            'feature_box_align_select',
            [
                'label' => __( 'Select Alignment', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'knor-extra' ),
                        'icon' => 'fa fa-align-left',
                    ],

                    'center' => [
                        'title' => __( 'Center', 'knor-extra' ),
                        'icon' => 'fa fa-align-center',
                    ],

                    'right' => [
                        'title' => __( 'Right', 'knor-extra' ),
                        'icon' => 'fa fa-align-right',
                    ],

                ],

                'default' => 'center',

                'toggle' => true,

                'selectors' => [
                    '{{WRAPPER}} .theme-feature-box-one-wrapper' => 'text-align: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'feature_box_padding',
            [
                'label' => esc_html__( 'Padding', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .theme-feature-box-one-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'feature_box_bg',
                'label' => esc_html__( 'Select Box Background', 'knor-extra' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .theme-feature-box-one-wrapper',
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'feature_box_bg_hover',
                'label' => esc_html__( 'Select Box Hover Background', 'knor-extra' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .theme-feature-box-one-wrapper:hover',
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'feature_box_border',
                'label' => esc_html__( 'Border', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .theme-feature-box-one-wrapper',
            ]
        );

        $this->add_responsive_control(
            'feature_box_border_radius',
            [
                'label' => __( 'Border Radius', 'knor-extra' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .theme-feature-box-one-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
            ]
        );


       	$this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'feature_box_shadow',
                'label' => esc_html__( 'Box Shadow', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .restly-freature-icon-title-box',
            ]
        );

        $this->end_controls_section();



       $this->start_controls_section(
            'feature__box_content_options',
            [
                'label' => esc_html__( 'Content', 'knor-extra' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );   

        $this->start_controls_tabs(
            'feature_box_content_tabs'
        );
		
        $this->start_controls_tab(
            'feature_box_content_tabs_icon',
            [
                'label' => __( 'Icon', 'knor-extra' ),
            ]
        );



         $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'feature_box_iconn_bg',
                'label' => esc_html__( 'Select Background', 'knor-extra' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .theme-feature-box-one-wrapper .theme-feature-box-icon',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'feature_box_iccon_border',
                'label' => esc_html__( 'Border', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .theme-feature-box-one-wrapper .theme-feature-box-icon',
            ]
        );

        $this->add_responsive_control(
            'feature_box_iconn_border_radius',
            [
                'label' => __( 'Border Radius', 'knor-extra' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .theme-feature-box-one-wrapper .theme-feature-box-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
            ]
        );


       	$this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'feature_box_iconn_shadow',
                'label' => esc_html__( 'Box Shadow', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .theme-feature-box-one-wrapper .theme-feature-box-icon',
            ]
        );


        $this->add_responsive_control(
            'feature_boxx_icon_color',
            [
                'label' => esc_html__( 'Color', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .theme-feature-box-icon i' => 'color: {{VALUE}}',
                ],
            ]
        );




        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'feature_boxx_icon_typo',
                'label' => esc_html__( 'Typography', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .theme-feature-box-icon i',
                'exclude' => [
                    'letter_spacing',
                    'text_transform',
                ],
            ]
        );

        $this->add_responsive_control(
            'feature_boxx_icon_margin',
            [
                'label' => esc_html__( 'Margin', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .theme-feature-box-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		
        $this->add_responsive_control(
            'feature_boxx_icon_padding',
            [
                'label' => esc_html__( 'Padding', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .theme-feature-box-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		
        $this->end_controls_tab();


        $this->start_controls_tab(
            'feature_boxx_title',
            [
                'label' => __( 'Title', 'knor-extra' ),
            ]
        );
        
        $this->add_responsive_control(
            'feature_boxx_title_color',
            [
                'label' => esc_html__( 'Color', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} h3.feature-box-title a, .theme-feature-box-one-wrapper h3.feature-box-title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'feature_boxx_title_hcolor',
            [
                'label' => esc_html__( 'Hover Color', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} h3.feature-box-title a:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'feature_boxx_title_typo',
                'label' => esc_html__( 'Typography', 'knor-extra' ),
                'selector' => '{{WRAPPER}} h3.feature-box-title',
                'exclude' => [
                    'letter_spacing',
                    'text_transform',
                ],
            ]
        );

        $this->add_responsive_control(
            'feature_boxx_title_margin',
            [
                'label' => esc_html__( 'Margin', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .theme-feature-box-one-wrapper h3.feature-box-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->end_controls_tab();


        $this->start_controls_tab(
            'feature_boxx_contentt',
            [
                'label' => __( 'Content', 'knor-extra' ),
            ]
        );
        $this->add_responsive_control(
            'feature_boxx_contentt_color',
            [
                'label' => esc_html__( 'Color', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .feature-box-content' => 'color: {{VALUE}}',
                ],
            ]
        );



        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'feature_boxx_contentt_typo',
                'label' => esc_html__( 'Typography', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .feature-box-content',
                'exclude' => [
                    'letter_spacing',
                    'text_transform',
                ],
            ]
        );
        $this->add_responsive_control(
            'feature_boxx_contentt_margin',
            [
                'label' => esc_html__( 'Margin', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .feature-box-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();


		
	}
	


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

		if( $settings['feature_box_enable_link'] == 'yes' && $settings['feature_box_enable_link_select'] == 'page' ){
			$link = get_page_link($settings['feature_box_enable_link_pages']);
		}else{
			$link = $settings['feature_box_enable_link_extra'];
		}
		
		?>


		<div class="theme-feature-box-one-wrapper theme_featured_box__Wrapper">

            <?php if ( $settings['feature_box_enable_icon'] === 'yes' ) : ?>

            <div class="theme-feature-box-icon theme_featured_box__Iconn">

                <?php if($settings['feature_box_icon_type'] == 'img' ) : ?>
                    <div class="theme-feature-box-icon-img theme_featured_box__Thumbnail">
                        <?php echo wp_get_attachment_image( $settings['feature_box_icon_img']['id'], 'full' ); ?>
                    </div>

                <?php else : ?>

                    <?php \Elementor\Icons_Manager::render_icon( $settings['feature_box_icon_self'], [ 'aria-hidden' => 'true' ] ); ?>

                <?php endif; ?>

            </div>

            <?php endif; ?>


            <div class="theme-feature-box-inner theme_featured_box__Wrapinner">

                <h3 class="feature-box-title theme_featured_box__Title">
                    <?php if($settings['feature_box_enable_link'] == 'yes' ){
                        ?>
                        <a href="<?php echo esc_url($link); ?>" <?php if($settings['feature_box_enable_link_new_tab'] == 'yes' ) : ?> target="_blank"<?php endif; ?> <?php if($settings['feature_box_enable_link_nofollow'] == 'yes' ) : ?> rel="nofollow" <?php endif; ?>>
                        <?php 
                    }echo esc_html($settings['feature_box_title']);if($settings['feature_box_enable_link'] == 'yes' ){
                        echo '</a>';
                    } ?>
                </h3>

                <div class="feature-box-content theme_featured_box__Innercontent">
                	<?php echo wp_kses_post( $settings['feature_box_des'] ); ?>
                </div>

                <div class="feature-box-btn theme_featured_box__Button">
                    <?php if ( ! empty( $settings['btn_link']['url'] ) ) : ?>
                        <a href="<?php echo esc_url( $settings['btn_link']['url'] ) ?>"  class="feature-box-btn theme_featured_box__Buttonlink">
                            <?php echo $settings['btn_text'] ?>
                            <?php \Elementor\Icons_Manager::render_icon( $settings['feature_box_btn_iconn'], [ 'aria-hidden' => 'true' ] ); ?>
                        </a>
                    <?php endif; ?>
                </div>

            </div>

            
        </div>
	

	<?php 


	}
				

}

