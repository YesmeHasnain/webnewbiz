<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Repeater;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Background;
/**
 * 
 * Footer Widgets .
 *
 */
class Barab_Footer_Widgets extends Widget_Base {

	public function get_name() {
		return 'barabfooterwidgets';
	}
	public function get_title() {
		return __( 'Footer Widgets', 'barab' ); 
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}
	
	protected function register_controls() { 

		$this->start_controls_section(
			'layout_section',
			[
				'label'     => __( 'Footer Widget Style', 'barab' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two' ] );
 
        barab_media_fields( $this, 'logo', 'Choose Logo', ['2'] );
		barab_general_fields( $this, 'icon', 'Icon', 'TEXT', '', ['1'] );
		barab_general_fields( $this, 'title', 'Title', 'TEXT', 'Title', ['1'] );
		barab_general_fields( $this, 'content', 'Content', 'TEXTAREA', 'Content', ['1', '2'] );
		barab_general_fields( $this, 'content2', 'Content 2', 'TEXTAREA', '', ['1'] );

        barab_social_fields($this, 'social_icon_list', 'Social List', ['1', '2']);

        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------

		barab_common_style_fields( $this, '01', 'Title', '{{WRAPPER}} .top-text', ['1'] );
        barab_common_style_fields( $this, '22', 'Content', '{{WRAPPER}} .opening-text', ['1'] );
        barab_common_style_fields( $this, '23', 'Content', '{{WRAPPER}} .footer-text', ['2'] );

	}

	protected function render() {

        $settings = $this->get_settings_for_display();

		if( $settings['layout_style'] == '1' ){
            echo '<div class="widget widget_info footer-widget">';
                echo '<div class="opening-time">';
                    echo '<div class="event-info-mask" data-mask-src="'.BARAB_ASSETS.'img/bg/footer-1-open-border.png"></div>';
                    echo '<div class="content-wrap">';
                        if($settings['icon']){
                            echo '<div class="icon">'.wp_kses_post($settings['icon']).'</div>';
                        }
                        if($settings['title']){
                            echo '<p class="top-text">'.esc_html($settings['title']).'</p>';
                        }
                        if($settings['content']){
                            echo '<p class="opening-text">'.esc_html($settings['content']).'</p>';
                        }
                        if($settings['content2']){
                            echo '<p class="opening-text">'.esc_html($settings['content2']).'</p>';
                        }
                    echo '</div>';
                echo '</div>';

                echo '<div class="th-social">';
                    foreach( $settings['social_icon_list'] as $social_icon ){
                        $social_target    = $social_icon['icon_link']['is_external'] ? ' target="_blank"' : '';
                        $social_nofollow  = $social_icon['icon_link']['nofollow'] ? ' rel="nofollow"' : '';
    
                        echo '<a '.wp_kses_post( $social_target.$social_nofollow ).' href="'.esc_url( $social_icon['icon_link']['url'] ).'">';
    
                        \Elementor\Icons_Manager::render_icon( $social_icon['social_icon'], [ 'aria-hidden' => 'true' ] );
    
                        echo '</a> ';
                    }
                echo '</div>';
            echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
            echo '<div class="widget footer-widget wow fadeinup">';
                echo '<div class="th-widget-about">';
                    if(!empty($settings['logo']['url'])){
                        echo '<div class="about-logo">';
                            echo '<a href="'.esc_url( home_url('/') ).'">';
                                echo barab_img_tag( array(
                                    'url'   => esc_url( $settings['logo']['url'] ),
                                ));
                            echo '</a>';
                        echo '</div>';
                    }
                    if($settings['content']){
                        echo '<p class="footer-text">'.esc_html($settings['content']).'</p>';
                    }
                    echo '<div class="th-social">';
                        foreach( $settings['social_icon_list'] as $social_icon ){
                            $social_target    = $social_icon['icon_link']['is_external'] ? ' target="_blank"' : '';
                            $social_nofollow  = $social_icon['icon_link']['nofollow'] ? ' rel="nofollow"' : '';
        
                            echo '<a '.wp_kses_post( $social_target.$social_nofollow ).' href="'.esc_url( $social_icon['icon_link']['url'] ).'">';
        
                            \Elementor\Icons_Manager::render_icon( $social_icon['social_icon'], [ 'aria-hidden' => 'true' ] );
        
                            echo '</a> ';
                        }
                    echo '</div>';
                echo '</div>';
            echo '</div>';
            
		}elseif( $settings['layout_style'] == '3' ){


        }elseif( $settings['layout_style'] == '4' ){


        }
	

	}
}
						