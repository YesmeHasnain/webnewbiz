<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome5PracticeSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home5-practice-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 5 - Practice Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-posts-grid';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home5' ];
	}

	public function get_keywords() {
		return [ 'home5practicesection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_practice_section',
			[
				'label' => esc_html__( 'Practice Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Our practice areas' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'show_btn',
			[
				'label'   => esc_html__( 'Show Button Read More', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'text_btn_read',
			[
				'label' 		=> esc_html__( 'Text Button Read More', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Read More' , 'bdevs-elementor' ),
				'show_label' 	=> true,
				'condition' 	=> [
					'show_btn' 	=> 'yes',
				],
			]
		);
		$this->add_control(
			'item_column',
			[
				'label'     	=> esc_html__( 'Item Column', 'bdevs-elementor' ),
				'type'      	=> Controls_Manager::SELECT,
				'options'   	=> [
					'type1'  		=> esc_html__( 'Two Columns', 'bdevs-elementor' ),
					'type2'  		=> esc_html__( 'Three Columns', 'bdevs-elementor' ),
					'type3'  		=> esc_html__( 'Four Columns', 'bdevs-elementor' ),
				],
				'default'   	=> 'type1',
			]
		);
		$this->add_control(
			'post_number',
			[
				'label'       => __( 'Post Number', 'bdevs-elementor' ),
				'type'        => Controls_Manager::NUMBER,
				'placeholder' => __( 'Enter your post number', 'bdevs-elementor' ),
				'min'		  => 0,
				'default'     => __( '6', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order_by',
			[
				'label'       => __( 'Post Order By', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text post order by', 'bdevs-elementor' ),
				'default'     => __( 'ID', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
				],
				'default'   => 'desc',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-practice-ptb pt-160 pb-120 p-relative">
	<div class="container">
		<?php if (!empty($settings['title_sec'])): ?>
			<div class="row">
				<div class="col-lg-12">
					<div class="tp-practice-heading text-center pb-100">
						<h3 class="tp-section-5-title tp-char-animation"><?php echo wp_kses_post($settings['title_sec']); ?></h3>
					</div>
				</div>
			</div>
		<?php endif ?>
		<div class="row tp-gx-50">
			<?php
			$wp_query = new \WP_Query([
				'post_type'      => 'service',
				'posts_per_page' => intval($settings['post_number']),
				'orderby'        => sanitize_text_field($settings['post_order_by']),
				'order'          => sanitize_text_field($settings['post_order']),
			]);
			$i = 0;
			while($wp_query->have_posts()): $wp_query->the_post();
				$i++;
				$post_id = get_the_ID();

				$sv_title 		= get_post_meta($post_id,'_cmb_sv_title_home_5', true);
				$sv_excerpt 	= get_post_meta($post_id,'_cmb_sv_excerpt_home_5', true);
				$img_id 		= get_post_meta($post_id,'_cmb_sv_icon_home_5', true);

				$title = !empty($sv_title) ? $sv_title : get_the_title();
			?>
				<?php if ($settings['item_column'] === 'type2') { ?>
					<div class="col-lg-4">
				<?php } elseif ($settings['item_column'] === 'type3') { ?>
					<div class="col-lg-3">
				<?php } else { ?>
					<div class="col-lg-6">
				<?php } ?>
						<div class="tp-practice-item mb-50 tp_fade_bottom">
							<div class="tp-practice-item-content">
								<?php if (!empty($img_id)): ?>
									<div class="tp-practice-item-icon">
										<img src="<?php echo wp_get_attachment_url($img_id); ?>" alt="<?php the_title_attribute(); ?>">
									</div>
								<?php endif ?>
								<h4 class="tp-practice-item-title">
									<a href="<?php the_permalink(); ?>"><?php echo wp_kses_post($title); ?></a>
								</h4>
								<p>
									<?php if ( '' !== wp_specialchars_decode($sv_excerpt)): ?>
										<?php print wp_specialchars_decode($sv_excerpt); ?>
									<?php else:?>
										<?php if(isset($nixer_redux_demo['blog_excerpt'])){?>
										<?php echo esc_attr(nixer_excerpt($nixer_redux_demo['blog_excerpt'])); ?>
										<?php }else{?>
										<?php echo esc_attr(nixer_excerpt(35)); 
										}?>
									<?php endif ?>
								</p>
							</div>
							<?php if (!empty($settings['show_btn'])): ?>
								<div class="tp-practice-item-btn">
									<a href="<?php the_permalink(); ?>">
										<?php echo wp_kses_post($settings['text_btn_read']); ?>
										<span>
											<svg width="19" height="16" viewBox="0 0 19 16" fill="none" xmlns="http://www.w3.org/2000/svg">
												<path d="M0 7.68652H17.6902M10.7188 0C10.7188 4.25031 14.4207 7.68957 18.9956 7.68957M18.9956 7.68652C14.4207 7.68652 10.7188 11.1258 10.7188 15.3761" stroke="#F5F7F5" stroke-width="1.5" stroke-miterlimit="10"/>
											</svg>
										</span>
									</a>
								</div>
							<?php endif ?>
						</div>
					</div>
			<?php endwhile; ?>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		if (jQuery('.tp-practice-heading .tp-char-animation').length > 0) {
			var char_come = gsap.utils.toArray(".tp-practice-heading .tp-char-animation");
			char_come.forEach(splitTextLine => {
				var tl = gsap.timeline({
					scrollTrigger: {
						trigger: splitTextLine,
						start: 'top 90%',
						end: 'bottom 60%',
						scrub: false,
						markers: false,
						toggleActions: 'play none none none'
					}
				});
				var itemSplitted = new SplitText(splitTextLine, { type: "chars, words" });
				gsap.set(splitTextLine, { perspective: 300 });
				itemSplitted.split({ type: "chars, words" })
				tl.from(itemSplitted.chars,
					{
						duration: 1,
						delay: 0.5,
						x: 100,
						autoAlpha: 0,
						stagger: 0.05
					});
			});
		}

		gsap.set(".tp_fade_bottom", { y: 100, opacity: 0 });
		const fadeArray = gsap.utils.toArray(".tp_fade_bottom")
		fadeArray.forEach((item, i) => {
			let fadeTl = gsap.timeline({
				scrollTrigger: {
					trigger: item,
					start: "top center+=400",
				}
			})
			fadeTl.to(item, {
				y: 0,
				opacity: 1,
				ease: "power2.out",
				duration: 1.5,
			})
		})
	</script>
<?php } ?>

<?php
}

}