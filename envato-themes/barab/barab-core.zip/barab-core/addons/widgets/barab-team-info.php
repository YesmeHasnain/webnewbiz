<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Repeater;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Image_Size;
use Elementor\Icons_Manager;
/**
 *
 * Team Info Widget
 *
 */
class barab_Team_info extends Widget_Base{

	public function get_name() {
		return 'barabteaminfo';
	}
	public function get_title() {
		return esc_html__( 'Team Member Info', 'barab' ); 
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}
 
	protected function register_controls() {

		$this->start_controls_section(
			'team_member_content',
			[
				'label'		=> esc_html__( 'Member Info','barab' ),
				'tab'		=> Controls_Manager::TAB_CONTENT,
			]
		);

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One' ] );

		barab_media_fields( $this, 'image', 'Member Image', ['1'] );
		barab_general_fields( $this, 'number', 'Member Experience', 'TEXT', 'Years of Experience', ['1'] );
		barab_general_fields( $this, 'name', 'Member Name', 'TEXT', 'Michel Clark', ['1'] );
		barab_general_fields( $this, 'designation', 'Member Designation', 'TEXT', 'Expert Chef', ['1'] ); 

		barab_general_fields( $this, 'content', 'Content', 'TEXTAREA', '', ['1'] ); 
		barab_general_fields( $this, 'content2', 'Content', 'TEXTAREA', '', ['1'] ); 

		barab_general_fields( $this, 'label', 'Label', 'TEXT', 'Get In Touch', ['1'] ); 

		$repeater = new Repeater();

		barab_media_fields($repeater, 'icon', 'Choose Image');
		barab_general_fields($repeater, 'title', 'Title', 'TEXTAREA2', 'Label');
		barab_general_fields($repeater, 'desc', 'Content', 'TEXTAREA', 'Content');
		
		$this->add_control(
			'contact_lists',
			[
				'label' 		=> __( 'Contact Info', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'Label', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['1']
				]
			]
		);

		barab_general_fields( $this, 'label2', 'Social Label', 'TEXT', 'Social Media:', ['1'] );
		barab_social_fields( $this, 'social_icon_list', 'Social Media', ['1'] ); 

		$this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------
		
		barab_common_style_fields( $this, '01', 'Name', '{{WRAPPER}} .about-card_title'  );
		barab_common_style_fields( $this, '02', 'Designation', '{{WRAPPER}} .about-card_desig' );
		barab_common_style_fields( $this, '03', 'Content', '{{WRAPPER}} .about-card_text' );
		
		barab_common_style_fields( $this, '011', 'Features Title', '{{WRAPPER}} .contact-feature_label', ['1'] );
		barab_common_style_fields( $this, '022', 'Features Content', '{{WRAPPER}} .contact-feature2 a, {{WRAPPER}} .contact-feature2', ['1'] );

		barab_common_style_fields( $this, '11', 'Label', '{{WRAPPER}} .box-title' );

	}

	protected function render() {

	$settings = $this->get_settings_for_display(); 

		if( $settings['layout_style'] == '1' ){
            echo '<div class="row gx-60 gy-60">';
                echo '<div class="col-xl-6">';
					if(!empty($settings['image']['url'])){
						echo '<div class="about-card-img">';
							echo barab_img_tag( array(
								'url'   => esc_url( $settings['image']['url'] ), 
								'class' => 'w-100'
							));
						echo '</div>';
					}
					if(!empty($settings['number'])){
                    	echo '<div class="experience-wrap">';
							echo '<h4 class="experience-title mb-0">'.wp_kses_post($settings['number']).'</h4>';
						echo '</div>';
					}
                echo '</div>';

                echo '<div class="col-xl-6">';
                    echo '<div class="about-card">';
						if(!empty($settings['name'])){
							echo '<h2 class="about-card_title fw-semibold mt-n3">'.esc_html($settings['name']).'</h2>';
						}
						if(!empty($settings['designation'])){
							echo '<p class="about-card_desig">'.esc_html($settings['designation']).'</p>';
						}
						if(!empty($settings['content'])){
							echo '<p class="about-card_text">'.esc_html($settings['content']).'</p>';
						}
						if(!empty($settings['content2'])){
							echo '<p class="about-card_text">'.esc_html($settings['content2']).'</p>';
						}

                        echo '<div class="team-details-about-info">';
							if(!empty($settings['label'])){
								echo '<h4 class="box-title">'.esc_html($settings['label']).'</h4>';
							}
                            echo '<div class="team-contact-wrap mb-40">';
								foreach( $settings['contact_lists'] as $data ){
									echo '<div class="contact-feature2">';
										if($data['icon']['url'] ){
											echo '<div class="box-icon">';
												echo barab_img_tag( array(
													'url'   => esc_url( $data['icon']['url'] ),
												));
											echo '</div>';
										}
										echo '<div class="media-body">';
											if(!empty($data['title'])){
												echo '<p class="contact-feature_label">'.esc_html($data['title']).'</p>';
											}
											if(!empty($data['desc'])){
												echo wp_kses_post($data['desc']);
											}
										echo '</div>';
									echo '</div>';
								}
                            echo '</div>';

							if(!empty($settings['label2'])){
								echo '<h4 class="box-title">'.esc_html($settings['label2']).'</h4>';
							}
                            echo '<div class="th-social">';
								foreach ( $settings['social_icon_list'] as $index => $social_icon ) {
									$link_key = 'social_icon_list_' . $index . '_icon_link';

									if ( ! empty( $social_icon['icon_link']['url'] ) ) {
										$this->add_link_attributes( $link_key, $social_icon['icon_link'] );

										echo '<a ' . $this->get_render_attribute_string( $link_key ) . '>';
										\Elementor\Icons_Manager::render_icon( $social_icon['social_icon'], [ 'aria-hidden' => 'true' ] );
										echo '</a>';
									}
								}
                            echo '</div>';
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
            echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
	

		}
		
		
	}
}