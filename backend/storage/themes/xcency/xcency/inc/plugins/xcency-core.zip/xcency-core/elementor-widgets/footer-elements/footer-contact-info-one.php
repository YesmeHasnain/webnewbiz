<?php
namespace Elementor;

class Xcency_Footer_Contact_Info_One_Widget extends Widget_Base {

	public function get_name() {

		return 'xcency_footer_contact_info_one';
	}

	public function get_title() {
		return esc_html__( 'Footer Contact Info One', 'xcency-core' );
	}

	public function get_icon() {

		return 'eicon-post-list';
	}

	public function get_categories() {
		return [ 'xcency_core_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'contact_info_option',
			[
				'label' => esc_html__( 'Contact Info', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'xcency-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Contact Us',
			]
		);

		$this->add_control(
			'desc_text', [
				'label' => esc_html__( 'Description', 'xcency-core' ),
				'type' => Controls_Manager::WYSIWYG,
				'default' => '55 Main Street, 2nd block Malborne, Australia',
				'label_block' => true,
			]
		);

		$this->add_control(
			'title_two',
			[
				'label'       => __( 'Title Two', 'xcency-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Contact Info',
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'info_text', [
				'label' => esc_html__( 'Info', 'xcency-core' ),
				'type' => Controls_Manager::WYSIWYG,
				'default' => '<a href="mailto:info@quintexbd.com">info@quintexbd.com</a>',
				'label_block' => true,
			]
		);

		$this->add_control(
			'info_items',
			[
				'label'       => __( 'Info Items', 'xcency-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'info_text' => '<a href="mailto:info@quintexbd.com">info@quintexbd.com</a>',
					],
					[
						'info_text' => '<a href="tel:1234">+880 (123) 456 88</a>',
					],
				],
				'title_field' => '{{{ info_text }}}',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'title!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typo',
				'label' => esc_html__( 'Typography', 'xcency-core' ),
				'selector' => '{{WRAPPER}} .widget-title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'       => esc_html__('Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .widget-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_margin',
			[
				'label'      => esc_html__( 'Title Margin', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .widget-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'desc_text_style',
			[
				'label' => esc_html__( 'Description', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'desc_text!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'desc_text_typo',
				'label' => esc_html__( 'Typography', 'xcency-core' ),
				'selector' => '{{WRAPPER}} .desc-text',
			]
		);

		$this->add_control(
			'desc_text_color',
			[
				'label'       => esc_html__('Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .desc-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'desc_text_margin',
			[
				'label'      => esc_html__( 'Title Margin', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .desc-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'title_two_style',
			[
				'label' => esc_html__( 'Title Two', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'title_two!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_two_typo',
				'label' => esc_html__( 'Typography', 'xcency-core' ),
				'selector' => '{{WRAPPER}} .widget-title-two',
			]
		);

		$this->add_control(
			'title_two_color',
			[
				'label'       => esc_html__('Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .widget-title-two' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_two_margin',
			[
				'label'      => esc_html__( 'Title Margin', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .widget-title-two' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Start List Style section
		$this->start_controls_section(
			'xcency_contact_info_style_options',
			[
				'label' => esc_html__('List Style', 'xcency-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs('xcency_info_list_style_tabs');

		//Default style tab start
		$this->start_controls_tab(
			'xcency_info_list_style_default',
			[
				'label' => esc_html__('Default', 'xcency-core'),
			]
		);

		$this->add_control(
			'info_list_default_text_color',
			[
				'label'     => esc_html__('Text Color', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .widget.xcency_contact_info_widget ul li,{{WRAPPER}} .widget.xcency_contact_info_widget ul li a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();//Default style tab end

		//Hover style tab start
		$this->start_controls_tab(
			'xcency_info_list_style_hover',
			[
				'label' => esc_html__('Hover', 'xcency-core'),
			]
		);

		$this->add_control(
			'info_list_hover_text_color',
			[
				'label'     => esc_html__('Color', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .widget.xcency_contact_info_widget ul li a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tabs();//Hover style tab end

		$this->end_controls_section();// End Button section
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<div class="widget xcency_contact_info_widget xcency_el_contact_info_widget">
			<?php if ($settings['title']) : ?>
                <h4 class="widget-title"><?php echo $settings['title'];?></h4>
			<?php endif; ?>

            <div class="desc-text td-last-p-0">
	            <?php
	                echo $settings['desc_text'];
	            ?>
            </div>

			<div class="xcency-contact-info-wrapper">
				<?php if ($settings['title_two']) : ?>
                    <h4 class="widget-title-two"><?php echo $settings['title_two'];?></h4>
				<?php endif; ?>

				<ul class="xcency-list-style widget-contact-info-list">
                    <?php if ($settings['info_items']) {
                        foreach ($settings['info_items'] as $info_item) { ?>
                            <li>
                                <?php
                                    echo $info_item['info_text'];
                                ?>
                            </li>
                        <?php }
                    } ?>
				</ul>
			</div>
		</div>

		<?php
	}
}

Plugin::instance()->widgets_manager->register( new Xcency_Footer_Contact_Info_One_Widget );