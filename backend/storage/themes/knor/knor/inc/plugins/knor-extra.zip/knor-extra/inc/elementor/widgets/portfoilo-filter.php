<?php

/**
 * Elementor Widget
 * @package Knor
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_portfolio_filter extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'custom-portfolio-with-filter';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Portfolio with Filter V.1', 'knor-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'knor_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {

		//Content tab start
        $this->start_controls_section(
            'theme_portfolio_menu_options',
            [
                'label' => esc_html__( 'Portfolio With Filter', 'knor-extra' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
		
        $this->add_control(
            'theme_portfolio_item_numbers',
            [
                'label' => esc_html__( 'Display Items', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 3,
                'max' => 10,
                'step' => 1,
                'default' => 9,
            ]
        );
		
        $this->add_control(
            'theme_portfolio_filter_show',
            [
                'label' => esc_html__( 'Show Filter', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'knor-extra' ),
                'label_off' => esc_html__( 'Hide', 'knor-extra' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
		
        $this->add_control(
            'theme_portfolio_navigation_show',
            [
                'label' => esc_html__( 'Show Navigation', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'knor-extra' ),
                'label_off' => esc_html__( 'Hide', 'knor-extra' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );
        
        $this->end_controls_section();
		
	
	    $this->start_controls_section(
            'theme_portfolio_menu_css_options',
            [
                'label' => esc_html__( 'Portfolio Filter Styling', 'knor-extra' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		
		
        $this->add_control(
            'theme_portfolio_menu_align',
            [
                'label' => __( 'Alignment', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'knor-extra' ),
                        'icon' => 'fas fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'knor-extra' ),
                        'icon' => 'fas fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'knor-extra' ),
                        'icon' => 'fas fa-align-right',
                    ],
                ],
                'default' => 'left',
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .theme-portfolio-section-wrap .theme-portfolio-filter-wrap ul' => 'text-align: {{VALUE}}',
                ],
            ]
        );
		
		
        $this->add_responsive_control(
            'theme_portfolio_menu_color',
            [
                'label' => esc_html__( 'Color', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .theme-portfolio-section-wrap .theme-portfolio-filter-wrap ul li' => 'color: {{VALUE}}',
                ],
            ]
        );
		
        $this->add_responsive_control(
            'theme_portfolio_menu_active_color',
            [
                'label' => esc_html__( 'Active Color', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .theme-portfolio-section-wrap .theme-portfolio-filter-wrap ul li.active' => 'color: {{VALUE}}',
                ],
            ]
        );
		
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'theme_portfolio_menu_typo',
                'label' => esc_html__( 'Typography', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .theme-portfolio-section-wrap .theme-portfolio-filter-wrap ul li',
            ]
        );
		
		
		$this->add_responsive_control(
            'theme_portfolio_menu_wrapper_margin',
            [
                'label' => esc_html__( 'Filter Menu Margin', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .theme-portfolio-section-wrap .theme-portfolio-filter-wrap ul' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		
        $this->add_responsive_control(
            'theme_portfolio_menu_css_margin',
            [
                'label' => esc_html__( 'Filter Menu Item Margin', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .theme-portfolio-section-wrap .theme-portfolio-filter-wrap ul li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		
		
        $this->end_controls_section();
		
		
        $this->start_controls_section(
            'theme_portfolio_css_img_options',
            [
                'label' => esc_html__( 'Portfolio Image Styling', 'knor-extra' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		
		$this->add_responsive_control(
			'portfolio_img_height',
			[
				'label' =>esc_html__( 'Set Portfolio Image Height', 'knor-extra' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 400,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 400,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 400,
					'unit' => 'px',
				],
				
				'default'  => [
					'unit' => 'px',
					'size' => 400,
				],
				
				'selectors' => [
					'{{WRAPPER}} .theme-portfolio-grid-item .grid-portfolio-thumb img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);	
		
 
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'theme_portfolio_menu_img_box_border',
                'label' => esc_html__( 'Border', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .theme-portfolio-grid-item .grid-portfolio-thumb',
            ]
        );
		
        $this->add_responsive_control(
            'theme_portfolio_menu_CSS_box_radius',
            [
                'label' => esc_html__( 'Border Radius', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ]
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 5,
                ],
                'selectors' => [
                    '{{WRAPPER}} .theme-portfolio-grid-item .grid-portfolio-thumb img' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
		
        $this->add_responsive_control(
            'theme_portfolio_menu_CSS_box_margin',
            [
                'label' => esc_html__( 'Margin', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .theme-portfolio-grid-item .grid-portfolio-thumb' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		
        $this->add_responsive_control(
            'theme_portfolio_menu_CSS_box_padding',
            [
                'label' => esc_html__( 'Padding', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .theme-portfolio-grid-item .grid-portfolio-thumb' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		
        $this->end_controls_section();
		
		
        $this->start_controls_section(
            'theme_portfolio_menu_content_options',
            [
                'label' => esc_html__( 'Portfolio Content Styling', 'knor-extra' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		
        $this->add_control(
            'theme_portfolio_menu_css_content_align',
            [
                'label' => __( 'Alignment', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'knor-extra' ),
                        'icon' => 'fas fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'knor-extra' ),
                        'icon' => 'fas fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'knor-extra' ),
                        'icon' => 'fas fa-align-right',
                    ],
                ],
                'default' => 'left',
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .theme-portfolio-section-wrap .theme-portfolio-grid-item .grid-portfolio-text' => 'text-align: {{VALUE}}',
                ],
            ]
        );
		
        $this->add_responsive_control(
            'portfolio_wrap_css_content_margin',
            [
                'label' => esc_html__( 'Margin', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .theme-portfolio-section-wrap .theme-portfolio-grid-item .grid-portfolio-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		
        $this->add_responsive_control(
            'portfoli_wrap_css_content_padding',
            [
                'label' => esc_html__( 'Padding', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .theme-portfolio-section-wrap .theme-portfolio-grid-item .grid-portfolio-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		
		$this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'portfolio_title_typography',
            'label'    => __( 'Title Typography', 'knor-extra' ),
            'selector' => '{{WRAPPER}} .theme-portfolio-section-wrap .theme-portfolio-grid-item .grid-portfolio-text h4',
        ] );

        $this->add_control( 'portfolio_title_color', [
            'label'     => __( 'Title Color', 'knor-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-portfolio-section-wrap .theme-portfolio-grid-item .grid-portfolio-text h4 a' => 'color: {{VALUE}}',
            ],

        ] );
		
		$this->add_responsive_control(
			'portfolio_title_margin',
			[
				'label' => esc_html__( 'Title Margin', 'knor-extra' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .theme-portfolio-section-wrap .theme-portfolio-grid-item .grid-portfolio-text h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		
		$this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'portfolio_sub_typography',
            'label'    => __( 'Short Content Typography', 'knor-extra' ),
            'selector' => '{{WRAPPER}} .theme-portfolio-section-wrap .theme-portfolio-grid-item .grid-portfolio-text p',
        ] );

        $this->add_control( 'portfolio_subtitle_color', [
            'label'     => __( 'Short Content Color', 'knor-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-portfolio-section-wrap .theme-portfolio-grid-item .grid-portfolio-text p' => 'color: {{VALUE}}',
            ],

        ] );
		
		
		$this->add_responsive_control(
			'portfolio_sub_title_margin',
			[
				'label' => esc_html__( 'Short Content Margin', 'knor-extra' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .theme-portfolio-section-wrap .theme-portfolio-grid-item .grid-portfolio-text p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		

        $this->end_controls_section();



		
	}
	


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();
	
		$dynamic_num = rand(799523678395, 3762272956024);
		
		?>

		<script>
			jQuery(window).ready(function($) {
			 
                'use strict';

				jQuery('.theme-portfolio-section-wrap .project-filter-navv ul#projects-filter-menu-new li').on('click',function(){
					jQuery('.theme-portfolio-section-wrap .project-filter-navv ul#projects-filter-menu-new li').removeClass('active');
					jQuery(this).addClass('active');
					var selector = jQuery(this).attr('data-filter');
					jQuery('.theme-portfolio-section-wrap .project-filter-itemlist-<?php echo esc_attr($dynamic_num) ?>').isotope({
						filter:selector,
					});
				});

			});
			jQuery(window).on('load',function($) {
				'use strict';
				jQuery(".theme-portfolio-section-wrap .project-filter-itemlist-<?php echo esc_attr($dynamic_num) ?>").isotope();
			});
		</script>
		
		<?php
        ob_start();
        ?>
		
		
		<div class="projects_filter_nav__Wrapper theme-portfolio-section-wrap">
            <?php $theme_portfolio_menus = get_terms( 'theme_portfolio_cat' ); 
			
			if( $settings['theme_portfolio_filter_show'] == 'yes' && !empty($theme_portfolio_menus) && ! is_wp_error( $theme_portfolio_menus ) ) : ?>
            <div class="project-filter-navv theme-portfolio-filter-wrap">
                <ul id="projects-filter-menu-new" class="projects_filter_nav__menu">
                    <li class="active" data-filter="*"><?php esc_html_e('All','knor-extra'); ?></li>
                    <?php foreach($theme_portfolio_menus as $theme_portfolio_menu){
                        echo '<li data-filter=".'.esc_attr($theme_portfolio_menu->slug).'">'.esc_html($theme_portfolio_menu->name).'</li>';
                    }?>
                </ul>
            </div>
            <?php endif; ?>
			
            <div class="theme-portfolio-grid-wrapper projects_filter_grid__Items">
                <div class="row theme-portfolio-grid project-filter-itemlist-<?php echo esc_attr($dynamic_num); ?>">
				
                    <?php global $post;
					
						$paged = get_query_var('paged') ? get_query_var('paged') : 1;
						
						$p = new \WP_Query(array(
							'posts_per_page' => esc_attr($settings['theme_portfolio_item_numbers']),
							'post_type' => 'theme_portfolio',
							'paged' => $paged
						));
					
					while($p->have_posts()) : $p->the_post();
					
					$portfolio_catagory = get_the_terms( get_the_ID(), 'theme_portfolio_cat' );
					
					if ( $portfolio_catagory && ! is_wp_error( $portfolio_catagory ) ) {
						$portfolio_cat_list = array();
						foreach ( $portfolio_catagory as $portfolio_cat ) {
							$portfolio_cat_list[] = $portfolio_cat->slug;
						}
						$portfolio_catshow = join( " ", $portfolio_cat_list );
						
					}else{
						$portfolio_catshow = '';
					}?>
					
                    <div class="col-sm-12 col-md-12 col-lg-4 <?php echo esc_attr($portfolio_catshow); ?>">
                        <div class="theme-portfolio-grid-item projects_filter_grid_item__Single">
                            <div class="theme-portfolio-item-inner projects_filter_grid_item__Innr">
									
								<div class="grid-portfolio-thumb">
									<?php the_post_thumbnail('full', array('class' => 'img-responsive portfolio-three-image'), true); ?> 
								</div>
								
								<div class="grid-portfolio-text">
									<h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>

                                    <p><?php echo esc_html( wp_trim_words(get_the_excerpt(), 13 ,'') );?></p>
								</div>
									
                            </div>
						</div>
                    </div>
					
                    <?php endwhile; wp_reset_postdata(); wp_reset_query();?>
					
                </div>
				
                <?php if($settings['theme_portfolio_navigation_show'] == 'yes' ) { ?>
                <div class="theme-portfolo-nav">
                    <?php knor_paginate_nav($p); ?>
                </div>
                <?php } ?>
				
            </div>
        </div>


	

	<?php echo ob_get_clean();


	}
				

}

