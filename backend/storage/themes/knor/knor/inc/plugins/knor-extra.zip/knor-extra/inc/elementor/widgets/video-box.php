<?php

/**
 * Elementor Widget
 * @package Knor
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_video_box extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'custom-video-box-wid';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Video Box V.1', 'knor-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'knor_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {


		$this->start_controls_section(
            'video_box_options',
            [
                'label' => esc_html__( 'Video Box Content', 'knor-extra' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'video_box_img',
            [
                'label' => esc_html__('Video Wrapper Image','knor-extra'),
                'type'=> \Elementor\Controls_Manager::MEDIA,
                'default' => [
                  'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'label_block' => true,
            ]
        );

        $this->add_responsive_control(
            'box_img_height',
            [
                'label' =>esc_html__( 'Set Box Image Height', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'desktop_default' => [
                    'size' => 247,
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'size' => 300,
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'size' => 300,
                    'unit' => 'px',
                ],
                
                'default'  => [
                    'unit' => 'px',
                    'size' => 247,
                ],
                
                'selectors' => [
                    '{{WRAPPER}} .theme-video-box-one-wrapper' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );      
        


         $this->add_control(
			'video_box_icon_type',
			[
			    'label' => esc_html__('Icon Type','knor-extra'),
			    'type' => \Elementor\Controls_Manager::CHOOSE,
			    'options' =>[
				  'img' =>[
					'title' => esc_html__('Image','knor-extra'),
					'icon' => 'fa fa-picture-o',
				  ],
				  'icon' =>[
					'title' => esc_html__('Icon','knor-extra'),
					'icon' => 'fa fa-info',
				  ]
			    ],
			    'default' => 'icon',
			]
		);

        $this->add_control(
			'video_box_icon_img',
			[
			    'label' => esc_html__('Image Icon','knor-extra'),
			    'type'=> \Elementor\Controls_Manager::MEDIA,
			    'default' => [
				  'url' => \Elementor\Utils::get_placeholder_image_src(),
			    ],
                'label_block' => true,
			    'condition' => [
				  'video_box_icon_type' => 'img',
			    ]
			]
		);

		$this->add_control(
            'video_box_icon_self',
            [
                'label' => esc_html__( 'Icon', 'knor-extra' ),
                'type'     => \Elementor\Controls_Manager::ICONS,
                'default'  => [
					'value'   => 'fas fa-star',
					'library' => 'solid',
				],
                'condition' => [
                    'video_box_icon_type' => 'icon',
                  ]
            ]
        );

        $this->add_control(
            'video_link', [
                'label' => __( 'Insert Self Hosted Video URL Link in Video format(eg. mp4/flv etc).', 'gazania-extra' ),
                'type'        => \Elementor\Controls_Manager::URL,

                'default'     => [
                    'url' => 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
                ],
                
                'description' => esc_html__( 'Enter Video URL', 'gazania-extra' )
            ]
        );


        $this->end_controls_section();


        $this->start_controls_section(
            'video_box_wrapper_options',
            [
                'label' => esc_html__( 'Wrapper Styling', 'knor-extra' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control( 'video_boxx_overlay_color', [
            'label'     => __( 'Box Overlay Color', 'knor-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-video-box-one-wrapper:after' => 'background-color: {{VALUE}}',
            ],

        ] );



        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'video_box_border',
                'label' => esc_html__( 'Border', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .theme-video-box-one-wrapper',
            ]
        );

        $this->add_responsive_control(
            'video_box_border_radius',
            [
                'label' => __( 'Border Radius', 'knor-extra' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .theme-video-box-one-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .theme-video-box-one-wrapper::after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
            ]
        );


       	$this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'video_box_shadow',
                'label' => esc_html__( 'Box Shadow', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .theme-video-box-one-wrapper',
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            'video_box_icon_options',
            [
                'label' => esc_html__( 'Icon Styling', 'knor-extra' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );


         $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'video_box_iconn_bg',
                'label' => esc_html__( 'Select Icon Background', 'knor-extra' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .theme-video-box-one-wrapper .theme-video-box-icon',
            ]
        );


        $this->add_control( 'video_boxx_icon_color', [
            'label'     => __( 'Icon Color', 'knor-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-video-box-one-wrapper .theme-video-box-icon i' => 'color: {{VALUE}}',
            ],

        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'video_boxx_icon_typo',
                'label' => esc_html__( 'Typography', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .theme-video-box-one-wrapper .theme-video-box-icon i',
                'exclude' => [
                    'letter_spacing',
                    'text_transform',
                ],
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'video_box_iccon_border',
                'label' => esc_html__( 'Border', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .theme-video-box-one-wrapper .theme-video-box-icon',
            ]
        );

        $this->add_responsive_control(
            'video_box_iconn_border_radius',
            [
                'label' => __( 'Border Radius', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .theme-video-box-one-wrapper .theme-video-box-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'video_box_iconn_shadow',
                'label' => esc_html__( 'Box Shadow', 'knor-extra' ),
                'selector' => '{{WRAPPER}} .theme-video-box-one-wrapper .theme-video-box-icon',
            ]
        );



        $this->end_controls_section();

		
	}
	


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

		
		?>


        <div class="theme-video-box-one-wrapper" style="background-image: url(<?php echo esc_url( $settings['video_box_img']['url'] ); ?>);">



            <div class="theme-video-box-icon">

                <a href="<?php echo esc_url( $settings['video_link']['url'] ) ?>" class="play-btn-wrap theme-video-play-btn">

                <?php if($settings['video_box_icon_type'] == 'img' ) : ?>
                    
                    <div class="theme-video-box-icon-img">
                        <?php echo wp_get_attachment_image( $settings['video_box_icon_img']['id'], 'full' ); ?>
                    </div>
                    

                <?php else : ?>

                    <?php \Elementor\Icons_Manager::render_icon( $settings['video_box_icon_self'], [ 'aria-hidden' => 'true' ] ); ?>

                <?php endif; ?>

                </a>

            </div>


        </div>


	

	<?php 


	}
				

}

