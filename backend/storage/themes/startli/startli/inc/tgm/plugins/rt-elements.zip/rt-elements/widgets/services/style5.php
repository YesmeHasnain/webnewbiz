<div class="react-addon-services services-<?php echo esc_attr( $settings['services_style'] ); ?>">
 	<div class="single-service-four services-part">
			<?php if(!empty($settings['select_image_style5'])) :?>
				<div class="thumbnail">
					<img src="<?php echo esc_url( $settings['select_image_style5']['url'] );?>" alt="image"/>
				</div>
			<?php endif;?>		
		
			<div class="services-text">
		<?php 
				$link_open = $settings['services_btn_link_open'] == 'yes' ? 'target=_blank' : ''; 		    		 
				$icon_position = $settings['services_btn_icon_position'] == 'before' ? 'icon-before' : 'icon-after';
			?>
			
			   <div class="react-button">
				<a class="rts-btn btn-primary <?php echo esc_html($icon_position); ?>" href="<?php echo esc_url($settings['services_btn_link']);?>" <?php echo wp_kses_post($link_open); ?>>
				
						<?php echo esc_html($settings['services_btn_text']);?>   						
				
					<i class="rt-plus-regular"></i>

				</a>	  
			</div>  
			<span><?php echo $settings['title_prefix']?></span>
			<?php if( !empty($settings['title']) ): ?>
				<div class="services-title">
				<a href="<?php echo esc_url($settings['title_link']);?>">
					<h5 class="title"><?php echo esc_html($settings['title']); ?></h5>
				</a>	</div>
			<?php endif; ?>
		</div>
	</div>
</div>