<?php 

/**
 * All Elementor widget init
 * @package Knor
 * @since 1.0.0
 */

function register_elementor_extra_widgets( $widgets_manager ) {



	require_once( KNOR_EXTRA_ELEMENTOR . '/widgets/accordion.php' );
    require_once( KNOR_EXTRA_ELEMENTOR . '/widgets/feature-box.php' );
    require_once( KNOR_EXTRA_ELEMENTOR . '/widgets/pricing-tabs.php' );
    require_once( KNOR_EXTRA_ELEMENTOR . '/widgets/testimonials.php' );
    require_once( KNOR_EXTRA_ELEMENTOR . '/widgets/home-banner-startup.php' );
    require_once( KNOR_EXTRA_ELEMENTOR . '/widgets/video-box.php' );
    require_once( KNOR_EXTRA_ELEMENTOR . '/widgets/home-banner-digital-agency.php' );
    require_once( KNOR_EXTRA_ELEMENTOR . '/widgets/portfoilo-filter.php' );
    require_once( KNOR_EXTRA_ELEMENTOR . '/widgets/team-members.php' );
    require_once( KNOR_EXTRA_ELEMENTOR . '/widgets/home-banner-it-solution.php' );
	require_once( KNOR_EXTRA_ELEMENTOR . '/widgets/home-blog-column.php' );
    require_once( KNOR_EXTRA_ELEMENTOR . '/widgets/home-blog-column-two.php' );




	$widgets_manager->register( new \theme_accordion_section() );
    $widgets_manager->register( new \theme_feature_box_one() );
    $widgets_manager->register( new \theme_pricing_table_tab() );
    $widgets_manager->register( new \theme_testimonials_one() );
    $widgets_manager->register( new \theme_banner_startup() );
    $widgets_manager->register( new \theme_video_box() );
    $widgets_manager->register( new \theme_banner_digital_agency() );
    $widgets_manager->register( new \theme_portfolio_filter() );
    $widgets_manager->register( new \theme_team_members() );
    $widgets_manager->register( new \theme_banner_it_solution() );
	$widgets_manager->register( new \knor_home_blog_grid() );
    $widgets_manager->register( new \knor_home_blog_grid_two() );
    

    


}


add_action( 'elementor/widgets/register', 'register_elementor_extra_widgets' );



/**
 * Knor Elementor _widget_categories()
 * @since 1.0.0
 * */


function knor_elementor_widget_categories($elements_manager) {

    $elements_manager->add_category(
        'knor_widgets',
        [
            'title' => __('Knor Widgets', 'knor-extra'),
        ]
    );

}

add_action('elementor/elements/categories_registered', 'knor_elementor_widget_categories');