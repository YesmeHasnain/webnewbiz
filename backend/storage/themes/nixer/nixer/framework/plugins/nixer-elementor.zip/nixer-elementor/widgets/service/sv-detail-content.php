<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsSVDetailContent extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-sv-detail-content';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Service Detail Content', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-post-content';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-service' ];
	}

	public function get_keywords() {
		return [ 'servicedetailcontent', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_sv_detail_content',
			[
				'label' => esc_html__( 'Service Detail Content', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'bg_color',
			[
				'label' 		=> esc_html__( 'Background Color (Default: #FFFFFF)', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::COLOR,
				'default'		=> '#FFFFFF',
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'item_style',
			[
				'label'     	=> esc_html__( 'Choose Type Content', 'bdevs-elementor' ),
				'type'      	=> Controls_Manager::SELECT,
				'options'   	=> [
					'type1'  		=> esc_html__( 'Content Column', 'bdevs-elementor' ),
					'type2'  		=> esc_html__( 'Content Thumb', 'bdevs-elementor' ),
					'type3' 		=> esc_html__( 'Content Wrapper', 'bdevs-elementor' ),
				],
				'default'   	=> 'type3',
			]
		);
		$repeater->add_control(
			'type1_title_1',
			[
				'label' 		=> esc_html__( 'Title Left Content', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( 'Detailed service overview' , 'bdevs-elementor' ),
				'show_label' 	=> true,
				'condition' 	=> [
					'item_style' 	=> 'type1',
				],
			]
		);
		$rp_type1_left = new \Elementor\Repeater();
		$rp_type1_left->add_control(
			'type1_para',
			[
				'label' 		=> esc_html__( 'Paragraph Left', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( 'Paragraph' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'tab_type1_left',
			[
				'label' 		=> esc_html__( 'List Paragraph Left', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $rp_type1_left->get_controls(),
				'default' 		=> [
					[
						
					],
				],
				'condition' 	=> [
					'item_style' 	=> 'type1',
				],
			]
		);
		$repeater->add_control(
			'type1_title_2',
			[
				'label' 		=> esc_html__( 'Title Right Content', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( "Here's a list of services" , 'bdevs-elementor' ),
				'show_label' 	=> true,
				'condition' 	=> [
					'item_style' 	=> 'type1',
				],
			]
		);
		$rp_type1_right = new \Elementor\Repeater();
		$rp_type1_right->add_control(
			'type1_text',
			[
				'label' 		=> esc_html__( 'Text Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( 'Text Item' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'tab_type1_right',
			[
				'label' 		=> esc_html__( 'List Right', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $rp_type1_right->get_controls(),
				'default' 		=> [
					[
						
					],
				],
				'condition' 	=> [
					'item_style' 	=> 'type1',
				],
				'title_field' 	=> '{{{ type1_text }}}',
			]
		);
		$repeater->add_control(
			'type2_img_1',
			[
				'label'       	=> esc_html__( 'Image Item Left', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image item', 'bdevs-elementor' ),
				'condition' 	=> [
					'item_style' 	=> 'type2',
				],
			]
		);
		$repeater->add_control(
			'type2_img_2',
			[
				'label'       	=> esc_html__( 'Image Item Right', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image item', 'bdevs-elementor' ),
				'condition' 	=> [
					'item_style' 	=> 'type2',
				],
			]
		);
		$rp_type3_para = new \Elementor\Repeater();
		$rp_type3_para->add_control(
			'type3_para',
			[
				'label' 		=> esc_html__( 'Paragraph Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( 'Paragraph Item' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'tab_type3_para',
			[
				'label' 		=> esc_html__( 'List Paragraph', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $rp_type3_para->get_controls(),
				'default' 		=> [
					[
						
					],
				],
				'condition' 	=> [
					'item_style' 	=> 'type3',
				],
			]
		);
		$rp_type3_list = new \Elementor\Repeater();
		$rp_type3_list->add_control(
			'type3_text',
			[
				'label' 		=> esc_html__( 'Text Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( 'Text Item' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'tab_type3_list',
			[
				'label' 		=> esc_html__( 'List Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $rp_type3_list->get_controls(),
				'default' 		=> [
					[
						
					],
				],
				'condition' 	=> [
					'item_style' 	=> 'type3',
				],
			]
		);
		$this->add_control(
			'tabs',
			[
				'label' 		=> esc_html__( 'List Content Service', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						
					],
				],
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-service-details-ov-ptb pt-130 pb-130" data-bg-color="<?php echo wp_kses_post($settings['bg_color']); ?>">
	<div class="container container-1430">
		<?php
		foreach ($settings['tabs'] as $item) :
		?>
			<?php if ($item['item_style'] == 'type1') { ?>
				<div class="row">
					<div class="col-lg-6">
						<div class="tp-service-details-ov-heading pb-100">
							<?php if (!empty($item['type1_title_1'])): ?>
								<h4 class="tp-service-details-ov-title"><?php echo wp_kses_post($item['type1_title_1']); ?></h4>
							<?php endif ?>
							<?php
							foreach ($item['tab_type1_left'] as $item11) :
							?>
								<?php if (!empty($item11['type1_para'])): ?>
									<p><?php echo wp_kses_post($item11['type1_para']); ?></p>
								<?php endif ?>
							<?php endforeach; ?>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="tp-service-details-ov-list pb-100">
							<?php if (!empty($item['type1_title_2'])): ?>
								<h4 class="tp-service-details-ov-title"><?php echo wp_kses_post($item['type1_title_2']); ?></h4>
							<?php endif ?>
							<ul>
								<?php
								foreach ($item['tab_type1_right'] as $item12) :
								?>
									<?php if (!empty($item12['type1_text'])): ?>
										<li><?php echo wp_kses_post($item12['type1_text']); ?></li>
									<?php endif ?>
								<?php endforeach; ?>
							</ul>
						</div>
					</div>
				</div>
			<?php } elseif ($item['item_style'] == 'type2') { ?>
				<div class="tp-service-details-ov-thumb-wrap pb-80">
					<div class="row">
						<div class="col-lg-8">
							<div class="tp-service-details-ov-thumb pb-20">
								<?php if (!empty($item['type2_img_1']['url'])): ?>
									<a href="<?php echo wp_kses_post($item['type2_img_1']['url']); ?>" class="about-popup-image">
										<img class="h-100" src="<?php echo wp_kses_post($item['type2_img_1']['url']); ?>" alt="<?php echo wp_kses_post($item['type2_img_1']['alt']); ?>">
									</a>
								<?php endif ?>
							</div>
						</div>
						<div class="col-lg-4">
							<div class="tp-service-details-ov-thumb text-end pb-20">
								<?php if (!empty($item['type2_img_2']['url'])): ?>
									<a href="<?php echo wp_kses_post($item['type2_img_2']['url']); ?>" class="about-popup-image">
										<img src="<?php echo wp_kses_post($item['type2_img_2']['url']); ?>" alt="<?php echo wp_kses_post($item['type2_img_2']['alt']); ?>">
									</a>
								<?php endif ?>
							</div>
						</div>
					</div>
				</div>
			<?php }  else { ?>
				<div class="tp-service-details-ov-wrapper">
					<div class="row">

						<div class="col-lg-12">
							<?php
							foreach ($item['tab_type3_para'] as $item31) :
							?>
								<?php if (!empty($item31['type3_para'])): ?>
									<p><?php echo wp_kses_post($item31['type3_para']); ?></p>
								<?php endif ?>
							<?php endforeach; ?>
						</div>

						<div class="col-lg-6">
							<ul>
								<?php
								$i = 0;
								foreach ($item['tab_type3_list'] as $item32) :
									 $i++;
								?>
									<?php if (($i % 2 == 1) && !empty($item32['type3_text'])): ?>
										<li>
											<span>
												<svg xmlns="http://www.w3.org/2000/svg" width="28" height="24" viewBox="0 0 28 24" fill="none">
													<path fill-rule="evenodd" clip-rule="evenodd" d="M12.1393 24C5.44328 24 0 18.6192 0 12C0 5.38084 5.44328 0 12.1393 0C15.2099 0 18.0913 1.10243 20.3362 3.13665C19.5896 3.57312 18.869 4.05658 18.1759 4.57989C16.4749 3.22337 14.3598 2.4765 12.1393 2.4765C6.8326 2.4765 2.50527 6.75421 2.50527 12C2.50527 17.2458 6.8326 21.5235 12.1393 21.5235C19.5231 21.5235 23.9069 13.7214 20.7311 7.65517C21.2124 7.21271 21.7078 6.78384 22.2163 6.36929C22.3665 6.24687 22.5179 6.12561 22.6704 6.00556C23.7328 7.81941 24.2789 9.87599 24.2789 11.9999C24.2788 18.6192 18.8354 24 12.1393 24Z" fill="black"/>
													<path fill-rule="evenodd" clip-rule="evenodd" d="M12.4589 18.1684C12.3222 18.1684 12.2084 18.0784 12.1628 17.9658C12.1401 17.9208 10.1813 12.9226 7.15216 11.0315C6.55998 10.6712 6.10456 10.2885 6.28673 9.43292C6.4689 8.59991 7.03833 8.12711 8.06319 7.90195C9.8852 7.51919 11.8439 10.311 12.5728 11.4592C15.1236 7.78943 20.2253 2.02577 27.6502 1.35035C28.0084 1.30885 28.1408 1.83369 27.8096 1.98075C27.6957 2.02577 17.0822 6.82136 12.7777 17.9883C12.7094 18.1009 12.5955 18.1684 12.4589 18.1684Z" fill="black"/>
												</svg>
											</span> 
											<?php echo wp_kses_post($item32['type3_text']); ?>
										</li>
									<?php endif ?>
								<?php endforeach; ?>
							</ul>
						</div>
						<div class="col-lg-6">
							<ul>
								<?php
								$i = 0;
								foreach ($item['tab_type3_list'] as $item32) :
									 $i++;
								?>
									<?php if (($i % 2 == 0) && !empty($item32['type3_text'])): ?>
										<li>
											<span>
												<svg xmlns="http://www.w3.org/2000/svg" width="28" height="24" viewBox="0 0 28 24" fill="none">
													<path fill-rule="evenodd" clip-rule="evenodd" d="M12.1393 24C5.44328 24 0 18.6192 0 12C0 5.38084 5.44328 0 12.1393 0C15.2099 0 18.0913 1.10243 20.3362 3.13665C19.5896 3.57312 18.869 4.05658 18.1759 4.57989C16.4749 3.22337 14.3598 2.4765 12.1393 2.4765C6.8326 2.4765 2.50527 6.75421 2.50527 12C2.50527 17.2458 6.8326 21.5235 12.1393 21.5235C19.5231 21.5235 23.9069 13.7214 20.7311 7.65517C21.2124 7.21271 21.7078 6.78384 22.2163 6.36929C22.3665 6.24687 22.5179 6.12561 22.6704 6.00556C23.7328 7.81941 24.2789 9.87599 24.2789 11.9999C24.2788 18.6192 18.8354 24 12.1393 24Z" fill="black"/>
													<path fill-rule="evenodd" clip-rule="evenodd" d="M12.4589 18.1684C12.3222 18.1684 12.2084 18.0784 12.1628 17.9658C12.1401 17.9208 10.1813 12.9226 7.15216 11.0315C6.55998 10.6712 6.10456 10.2885 6.28673 9.43292C6.4689 8.59991 7.03833 8.12711 8.06319 7.90195C9.8852 7.51919 11.8439 10.311 12.5728 11.4592C15.1236 7.78943 20.2253 2.02577 27.6502 1.35035C28.0084 1.30885 28.1408 1.83369 27.8096 1.98075C27.6957 2.02577 17.0822 6.82136 12.7777 17.9883C12.7094 18.1009 12.5955 18.1684 12.4589 18.1684Z" fill="black"/>
												</svg>
											</span> 
											<?php echo wp_kses_post($item32['type3_text']); ?>
										</li>
									<?php endif ?>
								<?php endforeach; ?>
							</ul>
						</div>
					</div>
				</div>
			<?php } ?>
		<?php endforeach; ?>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-bg-color]").each(function () {
			jQuery(this).css("background-color", jQuery(this).attr("data-bg-color"));
		});
	</script>
<?php } ?>

<?php
}

}