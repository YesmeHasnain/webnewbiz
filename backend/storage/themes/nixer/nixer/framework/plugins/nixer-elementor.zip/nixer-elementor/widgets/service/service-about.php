<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsSVAbout extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-sv-about';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Service About', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-info-circle';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-service' ];
	}

	public function get_keywords() {
		return [ 'serviceabout', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	public function get_category_options() {
		$category_options = [];
		$args = [
			'taxonomy'   => 'service-cat',
			'hide_empty' => true,
		];
		$categories = get_terms($args);
		if (!is_wp_error($categories)) {
			foreach ($categories as $category) {
				$category_options[$category->slug] = $category->name;
			}
		}
		return $category_options;
	}

	protected function _register_controls() {
		$category_options = $this->get_category_options();
		$this->start_controls_section(
			'section_content_service_about',
			[
				'label' => esc_html__( 'Service About', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'img_bg_sec',
			[
				'label'       	=> esc_html__( 'Image Background Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image background section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'heading_sec',
			[
				'label' 		=> esc_html__( 'Heading Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( 'Our Services' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( 'Elevate your brand with our expert digital blend and services.' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'cat_tab',
			[
				'label'     	=> esc_html__( 'Choose Category Tab', 'bdevs-elementor' ),
				'type'      	=> Controls_Manager::SELECT,
				'options'   	=> $category_options,
				'default'   	=> array_key_first($category_options),
				'label_block' 	=> true,
			]
		);
		$this->add_control(
			'tabs',
			[
				'label' 		=> esc_html__( 'Project Category List Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						
					],
				],
			]
		);
		$this->add_control(
			'img_thumb_sec',
			[
				'label'       	=> esc_html__( 'Image Thumbnail Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image thumbnail section', 'bdevs-elementor' ),
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-service-ptb pt-200 p-relative">
	<?php if (!empty($settings['img_bg_sec']['url'])): ?>
		<div class="tp-about-me-bg" data-background="<?php echo wp_kses_post($settings['img_bg_sec']['url']); ?>"></div>
	<?php endif ?>
	<div class="container container-1720">
		<div class="row">
			<div class="col-xl-3">
				<?php if (!empty($settings['heading_sec'])): ?>
					<div class="tp-about-us-heading mb-40">
						<span class="tp-breadcrumb-subtitle"><?php echo wp_kses_post($settings['heading_sec']); ?></span>
					</div>
				<?php endif ?>
			</div>
			<div class="col-xl-9">
				<?php if (!empty($settings['title_sec'])): ?>
					<div class="tp-about-us-heading mb-60">
						<h3 class="tp-breadcrumb-title tp-title-anim"><?php echo wp_kses_post($settings['title_sec']); ?></h3>
					</div>
				<?php endif ?>
				<div class="tp-service-list-wrap mb-80">
					<div class="row">
						<div class="col-lg-4 order-2 order-xl-1"></div>
						<div class="col-lg-8 order-1 order-xl-2">
							<div class="tp-service-list">
								<?php 
								if (!empty($settings['tabs'])) {
									echo '<ul>';
									foreach ($settings['tabs'] as $tab) {
										if (!empty($tab['cat_tab'])) {
											$cat_slug = esc_attr($tab['cat_tab']);
											$cat_name = esc_html($this->get_category_options()[$cat_slug]);
											$term = get_term_by('slug', $cat_slug, 'service-cat');
											$cat_link = get_term_link($term->term_id, 'service-cat');

											echo '<li>';
											echo '<a href="' . esc_url($cat_link) . '">+ ' . $cat_name . '</a>';
											echo '</li>';
										}
									}
									echo '</ul>';
								} ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php if (!empty($settings['img_thumb_sec']['url'])): ?>
		<div class="container container-1520">
			<div class="row">
				<div class="col-lg-12">
					<div class="tp-service-thumb fix">
						<img data-speed=".8" src="<?php echo wp_kses_post($settings['img_thumb_sec']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_thumb_sec']['alt']); ?>">
					</div>
				</div>
			</div>
		</div>
	<?php endif ?>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-background]").each(function () {
			jQuery(this).css("background-image", "url( " + jQuery(this).attr("data-background") + "  )");
		});
		
		if (jQuery('.tp-title-anim').length > 0) {
			var splitTitleLines = gsap.utils.toArray(".tp-title-anim");
			splitTitleLines.forEach(splitTextLine => {
				var tl = gsap.timeline({
				scrollTrigger: {
					trigger: splitTextLine,
					start: 'top 90%',
					end: 'bottom 60%',
					scrub: false,
					markers: false,
					toggleActions: 'play none none none'
				}
				});
	
				var itemSplitted = new SplitText(splitTextLine, { type: "words, lines" });
				gsap.set(splitTextLine, { perspective: 300});
				itemSplitted.split({ type: "lines" })
				tl.from(itemSplitted.lines, { duration: 1, delay: 0.3, opacity: 0, rotationX: -50, force3D: true, transformOrigin: "top center -50", stagger: 0.2 });
			});	
		}

		gsap.registerPlugin(ScrollTrigger, ScrollSmoother);
		var smoother = ScrollSmoother.create({
			smooth: 2,
			effects: true,
			smoothTouch: true
		});
	</script>
<?php } ?>

<?php
}

}