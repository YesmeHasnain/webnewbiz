<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Project Widget .
 *
 */ 
class Barab_Project_Info extends Widget_Base {

	public function get_name() {
		return 'barabprojectinfo'; 
	}
	public function get_title() {
		return __( 'Project Info', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		 $this->start_controls_section(
			'project_section',
			[
				'label'     => __( 'Projects', 'barab' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One'] );

		barab_general_fields( $this, 'title', 'Title', 'TEXTAREA2', 'Project info', ['1'] );

		$repeater = new Repeater();

		barab_general_fields($repeater, 'icon', 'Icon', 'TEXTAREA2', '');
		barab_general_fields($repeater, 'label', 'Label', 'TEXTAREA2', 'Label');
		barab_general_fields($repeater, 'content', 'Content', 'TEXTAREA2', 'AI Machine Learning');

		$this->add_control(
			'project_info',
			[
				'label' 		=> __( 'Project Info', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'AI Machine Learning', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['1']
				]
			]
		);
		
        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------

		barab_common_style_fields( $this, '011', 'Title', '{{WRAPPER}} .widget_title', ['1'] );

		barab_common_style_fields( $this, '01', 'Label', '{{WRAPPER}} .box-title', ['1'] );
		barab_common_style_fields( $this, '02', 'Content', '{{WRAPPER}} .box-text', ['1'] );

	}
 
	protected function render() {

        $settings = $this->get_settings_for_display();

		if( $settings['layout_style'] == '1' ){
        echo '<aside class="sidebar-area sidebar-sticky rounded-0 p-0 bg-transparent">';
            echo '<div class="widget widget_info  ">';
                if(!empty($settings['title'])){
                    echo '<h3 class="widget_title">'.esc_html($settings['title']).'</h3>';
                }
                echo '<div class="info-list">';
                    echo '<ul>';
                        foreach( $settings['project_info'] as $key => $data ){
                            echo '<li>';
                                if(!empty($data['icon'])){
									echo '<div class="box-icon">'.wp_kses_post($data['icon']).'</div>';
								}
                                echo '<div>';
                                    if(!empty($data['label'])){
                                        echo '<div class="box-title">'.esc_html($data['label']).'</div>';
                                    }
                                    if(!empty($data['content'])){
                                        echo '<div class="box-text">'.esc_html($data['content']).'</div>';
                                    }
                                echo '</div>';
                            echo '</li>';
                        }
                    echo '</ul>';
                echo '</div>';
            echo '</div>';
        echo '</aside>';

		}elseif( $settings['layout_style'] == '2' ){

            echo '<div class="row gx-80 gy-80 justify-content-center">';
				foreach( $settings['project_list'] as $key => $data ){
					echo '<div class="col-md-6" data-cue="slideInUp">';
						echo '<div class="project-card2">';
							if($data['choose_image']['url'] ){
								echo '<div class="box-img">';
									echo barab_img_tag( array(
										'url'   => esc_url( $data['choose_image']['url'] ),
									));
									echo '<a href="'.esc_url( $data['button_url']['url'] ).'" class="icon-btn"><i class="fal fa-arrow-up-right"></i></a>';
								echo '</div>';
							}
							echo '<div class="box-content">';
								if(!empty($data['subtitle'])){
									echo '<p class="box-subtitle text-white">'.esc_html($data['subtitle']).'</p>';
								}
								if(!empty($data['title'])){
									echo '<h3 class="box-title"><a href="'.esc_url( $data['button_url']['url'] ).'">'.esc_html($data['title']).'</a></h3>';
								}
							echo '</div>';
						echo '</div>';
					echo '</div>';
				}
            echo '</div>';

		}


	}

}