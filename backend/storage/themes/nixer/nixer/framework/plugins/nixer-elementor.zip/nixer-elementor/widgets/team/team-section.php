<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsTeamSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-team-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Team Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-posts-grid';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-team' ];
	}

	public function get_keywords() {
		return [ 'teamsection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}
	

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_team_section',
			[
				'label' => esc_html__( 'Team Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'bg_color',
			[
				'label' 		=> esc_html__( 'Background Color (Default: #F5F7F5)', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::COLOR,
				'default'		=> '#F5F7F5',
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Our Expert' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'item_column',
			[
				'label'     	=> esc_html__( 'Item Column', 'bdevs-elementor' ),
				'type'      	=> Controls_Manager::SELECT,
				'options'   	=> [
					'type1'  		=> esc_html__( 'Two Columns', 'bdevs-elementor' ),
					'type2'  		=> esc_html__( 'Three Columns', 'bdevs-elementor' ),
					'type3'  		=> esc_html__( 'Four Columns', 'bdevs-elementor' ),
				],
				'default'   	=> 'type2',
			]
		);
		$this->add_control(
			'post_number',
			[
				'label'       => __( 'Post Number', 'bdevs-elementor' ),
				'type'        => Controls_Manager::NUMBER,
				'placeholder' => __( 'Enter your post number', 'bdevs-elementor' ),
				'min'		  	  => 0,
				'default'     => __( '3', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order_by',
			[
				'label'       => __( 'Post Order By', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text post order by', 'bdevs-elementor' ),
				'default'     => __( 'ID', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
				],
				'default'   => 'desc',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-team-2-ptb fix p-relative pt-110 pb-90" data-bg-color="<?php echo wp_kses_post($settings['bg_color']); ?>">
	<?php if (!empty($settings['title_sec'])): ?>
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="tp-experiance-heading tp-team-2-heading text-center mb-50">
						<h3 class="tp-section-title tp-char-animation"><?php echo wp_kses_post($settings['title_sec']); ?></h3>
					</div>
				</div>
			</div>
		</div>
	<?php endif ?>
	<div class="container-fluid gx-0">
		<div class="tp-team-2-wrapper">
			<div class="row tp-gx-50">
				<?php
				$wp_query = new \WP_Query([
					'post_type'      => 'team',
					'posts_per_page' => intval($settings['post_number']),
					'orderby'        => sanitize_text_field($settings['post_order_by']),
					'order'          => sanitize_text_field($settings['post_order']),
				]);

				$column_class = match ($settings['item_column']) {
					'type1' => 'col-lg-6 col-md-6',
					'type3' => 'col-lg-3 col-md-6',
					default => 'col-lg-4 col-md-6',
				};

				$i = 0;
				while ($wp_query->have_posts()) : $wp_query->the_post();
					$i++;
					$post_id = get_the_ID();

					$custom_title = get_post_meta($post_id, '_cmb_team_title_home_2', true);
					$team_excerpt = get_post_meta($post_id, '_cmb_team_excerpt_home_2', true);
					$img_id       = get_post_meta($post_id, '_cmb_team_thumb_home_2', true);

					$title = !empty($custom_title) ? $custom_title : get_the_title();
					$thumbnail_url = '';

					if (!empty($img_id)) {
						$thumbnail_url = wp_get_attachment_image_url($img_id, 'full');
					} elseif (has_post_thumbnail()) {
						$thumbnail_url = get_the_post_thumbnail_url($post_id, 'full');
					} ?>
					<div class="<?php echo wp_kses_post($column_class); ?>">
						<div class="tp-team-2-item mb-50">
							<div class="tp-team-2-item-thumb p-relative">
								<a href="<?php the_permalink(); ?>">
									<img src="<?php echo esc_url($thumbnail_url); ?>" alt="<?php the_title_attribute(); ?>">
								</a>
								<span>
									<?php if (!empty($item['job_item'])) { ?>
										<?php echo wp_kses_post($item['job_item']); ?>
									<?php } else { ?>
										<?php
										$terms = get_the_terms(get_the_ID(), 'team-job');
										if ($terms && !is_wp_error($terms)) {
										    echo esc_html($terms[0]->name);
										} ?>
									<?php } ?>
								</span>
							</div>
							<div class="tp-team-2-item-content text-center">
								<h3 class="tp-team-2-item-title">
									<a class="textline" href="<?php the_permalink(); ?>">
										<?php echo wp_kses_post($title); ?>
									</a>
								</h3>
								<p>
									<?php if ( '' !== wp_specialchars_decode($team_excerpt)): ?>
										<?php print wp_specialchars_decode($team_excerpt); ?>
									<?php else:?>
										<?php if(isset($nixer_redux_demo['blog_excerpt'])){?>
										<?php echo esc_attr(nixer_excerpt($nixer_redux_demo['blog_excerpt'])); ?>
										<?php }else{?>
										<?php echo esc_attr(nixer_excerpt(20)); 
										}?>
									<?php endif ?>
								</p>
							</div>
						</div>
					</div>
				<?php endwhile; ?>
			</div>
		</div>
	</div>
</section>

<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-bg-color]").each(function () {
			jQuery(this).css("background-color", jQuery(this).attr("data-bg-color"));
		});

		if (jQuery('.tp-experiance-heading .tp-char-animation').length > 0) {
			var char_come = gsap.utils.toArray(".tp-experiance-heading .tp-char-animation");
			char_come.forEach(splitTextLine => {
				var tl = gsap.timeline({
					scrollTrigger: {
						trigger: splitTextLine,
						start: 'top 90%',
						end: 'bottom 60%',
						scrub: false,
						markers: false,
						toggleActions: 'play none none none'
					}
				});

				var itemSplitted = new SplitText(splitTextLine, { type: "chars, words" });
				gsap.set(splitTextLine, { perspective: 300 });
				itemSplitted.split({ type: "chars, words" })
				tl.from(itemSplitted.chars,
					{
						duration: 1,
						delay: 0.5,
						x: 100,
						autoAlpha: 0,
						stagger: 0.05
					});
			});
		}
	</script>
<?php } ?>

<?php
}

}