<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Marquee Widget .
 *
 */
class Barab_Marquee extends Widget_Base {

	public function get_name() {
		return 'barabmarquee';
	}
	public function get_title() {
		return __( 'Marquee Slider', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}
 
	protected function register_controls() {

		$this->start_controls_section(
			'arrow_section',
			[
				'label'     => __( 'Marquee', 'barab' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two' ] );

        $repeater = new Repeater();

		barab_media_fields($repeater, 'image', 'Choose Image');
		barab_general_fields($repeater, 'title', 'title', 'TEXT', 'Content Generator');
		barab_url_fields($repeater, 'button_url', 'Button URL');
		
		$this->add_control(
			'marquee_lists',
			[
				'label' 		=> __( 'Marquee Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'button_text' 	=> __( 'Content Generator', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['1', '2']
				]
			]
		);

		$repeater = new Repeater();

		barab_media_fields($repeater, 'image', 'Choose Image');
		barab_general_fields($repeater, 'title', 'title', 'TEXT', 'Bite Now');
		barab_url_fields($repeater, 'button_url', 'Button URL');
		
		$this->add_control(
			'marquee_lists2',
			[
				'label' 		=> __( 'Marquee Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'button_text' 	=> __( 'Bite Now', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['2']
				]
			]
		);

        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------
		barab_common_style_fields( $this, '01', 'Title', '{{WRAPPER}} .marquee-card a', ['1', '2'] );

	}

	protected function render() {

    $settings = $this->get_settings_for_display(); 

		if( $settings['layout_style'] == '1' ){ 
			echo '<div class="marquee1-wrapper">';
                echo '<div class="swiper th-slider marquee-slider1" data-slider-options=\'{"breakpoints":{"0":{"slidesPerView":"auto"}},"autoplay":{"delay":0,"disableOnInteraction":false},"noSwiping":"true","speed":10000,"spaceBetween":30}\'>';
                    echo '<div class="swiper-wrapper">';
						foreach( $settings['marquee_lists'] as $data ){
							echo '<div class="swiper-slide">';
								echo '<div class="marquee-card">';
									echo '<a '.barab_link_attrs($data['button_url']).'>';
										if(!empty($data['title'])){
											echo esc_html($data['title']);
										}
										echo barab_img_tag( array(
											'url'   => esc_url( $data['image']['url'] ),
										));
									echo '</a>';
								echo '</div>';
							echo '</div> ';
						}
                    echo '</div>';
                echo '</div>';
            echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
            echo '<div class="marquee2-wrapper style-2">';
                echo '<div class="swiper th-slider marquee-slider2" data-slider-options=\'{"breakpoints":{"0":{"slidesPerView":"auto"}},"autoplay":{"delay":0,"disableOnInteraction":false},"noSwiping":"true","speed":10000,"spaceBetween":30}\'>';
                    echo '<div class="swiper-wrapper">';
						foreach( $settings['marquee_lists'] as $data ){
							echo '<div class="swiper-slide">';
								echo '<div class="marquee-card">';
									echo '<a '.barab_link_attrs($data['button_url']).' >';
										if(!empty($data['title'])){
											echo esc_html($data['title']);
										}
										echo barab_img_tag( array(
											'url'   => esc_url( $data['image']['url'] ),
										));
									echo '</a>';
								echo '</div>';
							echo '</div>';
						}
                    echo '</div>';
                echo '</div>';
            echo '</div>';

			echo '<div class="marquee2-wrapper style-3">';
                echo '<div class="swiper th-slider marquee-slider2" data-slider-options=\'{"breakpoints":{"0":{"slidesPerView":"auto"}},"autoplay":{"delay":0,"disableOnInteraction":false,"reverseDirection":true},"noSwiping":"true","speed":10000,"spaceBetween":30}\'>';
                    echo '<div class="swiper-wrapper">';
						foreach( $settings['marquee_lists2'] as $data ){
							echo '<div class="swiper-slide">';
								echo '<div class="marquee-card">';
									echo '<a '.barab_link_attrs($data['button_url']).' >';
										if(!empty($data['title'])){
											echo esc_html($data['title']);
										}
										echo barab_img_tag( array(
											'url'   => esc_url( $data['image']['url'] ),
										));
									echo '</a>';
								echo '</div>';
							echo '</div>';
						}
                    echo '</div>';
                echo '</div>';
            echo '</div>';

		}elseif( $settings['layout_style'] == '3' ){

			
		}
			
	}
}