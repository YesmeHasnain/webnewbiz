<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsBlogHome extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-blog-home';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Blog Home', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Slider widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-info-circle';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Slider widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'home-elementor' ];
	}

	public function get_keywords() {
		return [ 'bloghome', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_blog_home',
			[
				'label' => esc_html__( 'Blog Home', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
	        'title',
	        [
	            'label'       => __( 'Title', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

	   	$this->add_control(
	        'link',
	        [
	            'label'       => __( 'Link', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your link', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

	   	$this->add_control(
	        'button',
	        [
	            'label'       => __( 'Button', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

	   	$this->add_control(
	         'post_number',
	         [
	            'label'     => esc_html__( 'Post Count', 'bdevs-elementor' ),
	            'type'      => Controls_Manager::TEXT,
	            'default'   => '3',
	         ]
	    );

	    $this->add_control(
	        'orderpost',
	        [
	            'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
	            'type'      => Controls_Manager::SELECT,
	            'options'   => [
	               'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
	               'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
	            ],
	            'default'   => 'desc',
	        ]
	    );

    	$this->add_control(
	       	'orderby',
	       	[
	            'label'     => esc_html__( 'Order By', 'bdevs-elementor' ),
	            'type'      => Controls_Manager::SELECT,
	            'options'   => [
	               'date'  => esc_html__( 'Date', 'bdevs-elementor' ),
	               'title' => esc_html__( 'Title', 'bdevs-elementor' ),
	               'rand' => esc_html__( 'Random', 'bdevs-elementor' ),
	            ],
	            'default'   => 'desc',
	       	]
    	);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		$wp_query = new \WP_Query(array('post_type' => 'post', 'posts_per_page' => $settings['post_number'],'orderby' => $settings['orderby'], 'order' => $settings['orderpost'],));
		extract($settings);
		?>
<section id="blog" class="tCenter ofsBottom">
    <div class="container clearfix">
        <h1 class="title"><?php echo wp_kses_post($settings['title']); ?></h1>
        <div class="postsHolder ofsTop">
            <div class="postInner clearfix">

                <?php
			    $idd = 0;
			        while($wp_query->have_posts()): $wp_query->the_post();
			        $idd++;
			        $rival_redux_demo = get_option('redux_demo');
			    ?>
			    <?php $img_blog = get_post_meta(get_the_ID(),'_cmb_img_blog', true); ?>
	                <div class="eight columns post">
	                	<?php $gallery = get_post_gallery( get_the_ID(), false ); ?>
	               		<?php if (has_post_format('gallery') && isset($gallery['ids'])) {?>
		                    <div class="postMedia postSlider flexslider">
		                        <ul class="slides">
		                        	<?php
				                     if(isset($gallery['ids'])){    
				                        $gallery_ids = $gallery['ids'];
				                        $img_ids = explode(",",$gallery_ids);
				                        $i=0; $j=0;?>
				                        <?php
				                        foreach( $img_ids AS $img_id ){ 
				                     $image_src = wp_get_attachment_image_src($img_id,'');
				                    ?>
			                            <li>
			                                <img src="<?php echo esc_url($image_src[0]); ?>" alt="Blog Post 2">
			                                <div class="postDate short">
			                                    <h3><?php the_time(get_option( 'date_format' ));?><span>by <?php the_author_posts_link(); ?></span></h3>
			                                </div>
			                            </li>
		                        	<?php } } ?>
		                        </ul>
		                    </div>
	                    <?php } else{?>
		                    <div class="postMedia imgPost">
		                        <img src="<?php echo wp_get_attachment_url($img_blog);?>" alt="Blog Post 1">
		                        <div class="postDate short">
		                            <h3><?php the_time(get_option( 'date_format' ));?><span>by <?php the_author_posts_link(); ?></span></h3>
		                        </div>
		                    </div>
		                <?php } ?>
	                    <div class="postDetails">
	                        <h1><a href="<?php the_permalink() ?>"><?php the_title();?></a></h1>
	                        <div class="postMeta">
	                            <span class="metaAuthor">
			                        <?php if(isset($rival_redux_demo['post_blog_single'])){?>
			                        <?php echo esc_attr($rival_redux_demo['post_blog_single']);?>
			                        <?php }else{?>
			                        <?php echo esc_html__( 'Posted by ', 'rival' ); } ?>
			                        <?php the_author_posts_link(); ?></span>
			                     <span class="metaCategory">/ <?php echo get_the_category_list();?> </span>
			                     /<span class="metaComment"> <?php comments_number( esc_html__('0 Comments', 'rival'), esc_html__('1 Comment', 'rival'), esc_html__('% Comments', 'rival') ); ?></span>
	                        </div>
	                        <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam...
	                        	<?php if(isset($rival_redux_demo['blog_home_excerpt'])){?>
				                <?php echo esc_attr(rival_excerpt2($rival_redux_demo['blog_home_excerpt'])); ?>
				                <?php }else{?>
				                <?php echo esc_attr(rival_excerpt2(17)); } ?>
	                        </p>
	                        <div class="btn more">
	                            <a href="<?php the_permalink() ?>">
	                            	<?php if(isset($rival_redux_demo['read_more'])){?>
				                    <?php echo esc_attr($rival_redux_demo['read_more']);?>
				                    <?php }else{?>
				                    <?php echo esc_html__( 'Read More', 'rival' ); } ?>
	                            </a>
	                        </div>
	                    </div>
	                </div>
                <?php endwhile; ?>
            </div>
            <div class="allPosts ofsInTop btn clearfix">
                <a href="<?php echo wp_kses_post($settings['link']); ?>"><?php echo wp_kses_post($settings['button']); ?></a>
            </div>
        </div>
    </div>
</section>
<?php
if (is_admin()) { ?>
<script>
    $('.postSlider, .postSliderLarge, .projectSlider').flexslider({
        animation: "slide",
        slideshow: true,
        directionNav:false,
        controlNav: true
    });
</script>
<?php } ?>
<?php
}

}