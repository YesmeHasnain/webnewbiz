<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Xcency_Contact_Form7_Two_Widget extends Widget_Base {

	public function get_name() {
		return 'xcency_contact_form7_two';
	}

	public function get_title() {
		return __( 'Contact Form 7 Two', 'xcency-core' );
	}

	public function get_icon() {
		return 'eicon-mail';
	}

	public function get_categories() {
		return array( 'xcency_core_elements' );
	}

	protected function register_controls() {

		$this->start_controls_section(
			'contact_form_accordion',
			[
				'label' => __( 'Contact Form', 'xcency-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'wpcf7_form_list',
			[
				'label' => __( 'Select Contact Form', 'xcency-core' ),
				'label_block' => true,
				'type' => Controls_Manager::SELECT,
				'options' => $this->xcency_contact_form7_two(),
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'xcency_contact_field_style',
			[
				'label' => __( 'Field Style', 'xcency-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);


		$this->add_control(
			'field_border_color',
			[
				'label'       => esc_html__('Field Border Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-contact-form-container select' => 'border-color: {{VALUE}};',
					'{{WRAPPER}} .xcency-contact-form-container input' => 'border-color: {{VALUE}};',
					'{{WRAPPER}} .xcency-contact-form-container textarea' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'field_border_color_on_focus',
			[
				'label'       => esc_html__('Field Border Color On Focus', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-contact-form-container select:focus' => 'border-color: {{VALUE}};',
					'{{WRAPPER}} .xcency-contact-form-container input:focus' => 'border-color: {{VALUE}};',
					'{{WRAPPER}} .xcency-contact-form-container textarea:focus' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'field_text_color',
			[
				'label'       => esc_html__('Field Text Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-contact-form-container ::placeholder' => 'color: {{VALUE}};',
					'{{WRAPPER}} .xcency-contact-form-container :-ms-input-placeholder' => 'color: {{VALUE}};',
					'{{WRAPPER}} .xcency-contact-form-container ::-ms-input-placeholder' => 'color: {{VALUE}};',
					'{{WRAPPER}} .xcency-contact-form-container select' => 'color: {{VALUE}};',
					'{{WRAPPER}} .xcency-contact-form-container input' => 'color: {{VALUE}};',
					'{{WRAPPER}} .xcency-contact-form-container textarea' => 'color: {{VALUE}};',
					'{{WRAPPER}} .xcency-contact-form-container .select-arrow:before' => 'border-top-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'textarea_height',
			[
				'label' => __( 'Textarea Height', 'xcency-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 100,
						'max' => 1000,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'selectors' => [
					'{{WRAPPER}} .xcency-contact-form-container textarea' => 'height: {{SIZE}}px;',
				],
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'xcency_contact_submit_style',
			[
				'label' => __( 'Submit Button', 'xcency-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		//Normal & hover option start
		$this->start_controls_tabs('xcency_btn_styles');

		//Normal style start
		$this->start_controls_tab(
			'btn_normal_style',
			[
				'label' => esc_html__('Default', 'xcency-core'),
			]
		);

		$this->add_control(
			'normal_txt_color',
			[
				'label'     => esc_html__('Text Color', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .xcency-contact-form-container input[type="submit"]' => 'color: {{VALUE}};',
					'{{WRAPPER}} .xcency-contact-form-container button[type="submit"]' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_default_background',
			[
				'label'     => esc_html__('Background Color', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .xcency-contact-form-container input[type="submit"],{{WRAPPER}} .xcency-contact-form-container button[type="submit"]' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_default_border',
			[
				'label'     => esc_html__('Border Color', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .xcency-contact-form-container input[type="submit"],{{WRAPPER}} .xcency-contact-form-container button[type="submit"]' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();
		//Normal style end

		//Hover style start
		$this->start_controls_tab(
			'btn_hover_style',
			[
				'label' => esc_html__('Hover', 'xcency-core'),
			]
		);

		$this->add_control(
			'hover_txt_color',
			[
				'label'     => esc_html__('Text Color', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .xcency-contact-form-container input[type="submit"]:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .xcency-contact-form-container button[type="submit"]:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_hover_background',
			[
				'label'     => esc_html__('Background Color', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .xcency-contact-form-container input[type="submit"]:hover,{{WRAPPER}} .xcency-contact-form-container button[type="submit"]:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_hover_border',
			[
				'label'     => esc_html__('Border Color', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .xcency-contact-form-container input[type="submit"]:hover,{{WRAPPER}} .xcency-contact-form-container button[type="submit"]:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();
		//Hover style end
		$this->end_controls_tabs();
		//Normal & hover option end

		$this->end_controls_section();

        $this->start_controls_section(
            'wrapper_style',
            [
                'label' => esc_html__( 'Wrapper', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'wrapper_padding',
            [
                'label'      => esc_html__( 'Wrapper Padding', 'xcency-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .xcency-contact-form7-two-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->end_controls_section();

	}

	protected function xcency_contact_form7_two( ) {

		if ( ! class_exists( 'WPCF7_ContactForm' ) ) {
			return array();
		}

		$forms = \WPCF7_ContactForm::find( array(
			'orderby' => 'title',
			'order'   => 'ASC',
		) );

		if ( empty( $forms ) ) {
			return array();
		}

		$result = array();

		foreach ( $forms as $item ) {
			$key            = sprintf( '%1$s::%2$s', $item->id(), $item->title() );
			$result[ $key ] = $item->title();
		}

		return $result;
	}

	protected function render()  {
		$settings = $this->get_settings();
		?>

		<div class="xcency-contact-form7-two-wrapper">
            <div class="xcency-cf7-contact-form">
                <div class="xcency-contact-form-container">
                    <?php if ( ! empty( $settings['wpcf7_form_list'] ) ) {?>
                        <div class="xcency-contact-form-container">
                            <?php echo do_shortcode( '[contact-form-7 id="' . $settings['wpcf7_form_list'] . '" ]' );?>
                        </div>
                    <?php } ?>
                </div>
            </div>
		</div>
		<?php

	}
}

Plugin::instance()->widgets_manager->register( new Xcency_Contact_Form7_Two_Widget );
