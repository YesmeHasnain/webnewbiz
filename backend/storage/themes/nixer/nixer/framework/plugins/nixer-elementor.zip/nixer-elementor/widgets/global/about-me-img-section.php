<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsAboutMeImgSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-about-me-img-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'About Me Image Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-alert';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-global' ];
	}

	public function get_keywords() {
		return [ 'aboutmeimgsection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_about_me_image',
			[
				'label' => esc_html__( 'About Me Image Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'item_column',
			[
				'label'     	=> esc_html__( 'Item Column', 'bdevs-elementor' ),
				'type'      	=> Controls_Manager::SELECT,
				'options'   	=> [
					'type1'  		=> esc_html__( 'Two Columns', 'bdevs-elementor' ),
					'type2'  		=> esc_html__( 'Three Columns', 'bdevs-elementor' ),
					'type3'  		=> esc_html__( 'Four Columns', 'bdevs-elementor' ),
				],
				'default'   	=> 'type3',
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'img_item',
			[
				'label'       	=> esc_html__( 'Image Item', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image item', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'tabs',
			[
				'label' 		=> esc_html__( 'List Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
					],
				],
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<div class="tp-about-me-img-ptb pb-100">
	<div class="container-fluid tp-gx-5">
		<div class="row tp-gx-5">
			<?php
			foreach ($settings['tabs'] as $item) :
			?>
				<?php if (!empty($item['img_item']['url'])): ?>
					<?php if ($settings['item_column'] === 'type1') { ?>
						<div class="col-xl-36 col-lg-6 col-sm-6">
					<?php } elseif ($settings['item_column'] === 'type2') { ?>
						<div class="col-xl-4 col-lg-4 col-sm-6">
					<?php } else { ?>
						<div class="col-xl-3 col-lg-4 col-sm-6">
					<?php } ?>
							<a href="<?php echo wp_kses_post($item['img_item']['url']); ?>" class="about-popup-image">
								<div class="tp-about-me-img-thumb mb-30">
									<img src="<?php echo wp_kses_post($item['img_item']['url']); ?>" alt="<?php echo wp_kses_post($item['img_item']['alt']); ?>">
								</div>
							</a>
						</div>
				<?php endif ?>
			<?php endforeach; ?>
		</div>
	</div>
</div>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		
	</script>
<?php } ?>

<?php
}

}