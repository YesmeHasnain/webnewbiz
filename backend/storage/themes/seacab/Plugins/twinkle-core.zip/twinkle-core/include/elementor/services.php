<?php

namespace TwinkleCore\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Twinkle Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Twinkle_Services extends Widget_Base {

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'twinkle_services';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Services', 'twinkle-core' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'twinkle-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'twinkle_core' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'twinkle-services' ];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls() {

        // layout Panel
        $this->start_controls_section(
            'twinkle_layout',
            [
                'label' => esc_html__('Design Layout', 'twinkle-core'),
            ]
        );
        $this->add_control(
            'twinkle_design_style',
            [
                'label' => esc_html__('Select Layout', 'twinkle-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'twinkle-core'),
                    'layout-2' => esc_html__('Layout 2', 'twinkle-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // Service group
        $this->start_controls_section(
            'twinkle_services',
            [
                'label' => esc_html__('Services List', 'twinkle-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'twinkle-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'twinkle_service_icon_type',
            [
                'label' => esc_html__('Select Icon Type', 'twinkle-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'icon',
                'options' => [
                    'image' => esc_html__('Image', 'twinkle-core'),
                    'icon' => esc_html__('Icon', 'twinkle-core'),
                ],
            ]
        );

        $this->add_control(
            'twinkle_service_image',
            [
                'label' => esc_html__('Upload Icon Image', 'twinkle-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'twinkle_service_icon_type' => 'image'
                ]
            ]
        );

        if (twinkle_is_elementor_version('<', '2.6.0')) {
            $this->add_control(
                'twinkle_service_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'icon-university',
                    'condition' => [
                        'twinkle_service_icon_type' => 'icon'
                    ]
                ]
            );
        } else {
            $this->add_control(
                'twinkle_service_selected_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'icon-university',
                        'library' => 'solid',
                    ],
                    'condition' => [
                        'twinkle_service_icon_type' => 'icon'
                    ]
                ]
            );
        }
        $this->add_control(
            'twinkle_service_title', [
                'label' => esc_html__('Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Institution Business', 'twinkle-core'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'twinkle_service_description',
            [
                'label' => esc_html__('Description', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('These cases are simple and eas hour power of untrammelled being able to do what we like.', 'twinkle-core'),
                'label_block' => true,
            ]
        ); 

        $this->add_control(
            'twinkle_services_link_switcher',
            [
                'label' => esc_html__( 'Add Services link', 'twinkle-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'twinkle-core' ),
                'label_off' => esc_html__( 'No', 'twinkle-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'twinkle_services_btn_text',
            [
                'label' => esc_html__('Button Text', 'twinkle-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Read More', 'twinkle-core'),
                'title' => esc_html__('Enter button text', 'twinkle-core'),
                'label_block' => true,
                'condition' => [
                    'twinkle_services_link_switcher' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'twinkle_services_link_type',
            [
                'label' => esc_html__( 'Service Link Type', 'twinkle-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'condition' => [
                    'twinkle_services_link_switcher' => 'yes'
                ]
            ]
        );
        $this->add_control(
            'twinkle_services_link',
            [
                'label' => esc_html__( 'Service Link link', 'twinkle-core' ),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'https://your-link.com', 'twinkle-core' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'twinkle_services_link_type' => '1',
                    'twinkle_services_link_switcher' => 'yes',
                ]
            ]
        );
        $this->add_control(
            'twinkle_services_page_link',
            [
                'label' => esc_html__( 'Select Service Link Page', 'twinkle-core' ),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => twinkle_get_all_pages(),
                'condition' => [
                    'twinkle_services_link_type' => '2',
                    'twinkle_services_link_switcher' => 'yes',
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
			'twinkle_layout_style',
			[
				'label' => __( 'Design Layout', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __( 'Content Padding', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .services-one__single-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .services-two__single-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'content_background_color',
            [
                'label' => __( 'Content Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-one__single' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .services-two__single' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_border_size',
            [
                'label' => __( 'Content Border Size', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .services-two__single' => 'border: {{SIZE}}{{UNIT}} solid;',
                    '{{WRAPPER}} .services-two__single:hover' => 'border: {{SIZE}}{{UNIT}} solid;',
                ],
                'condition' => [
                    'twinkle_design_style' => 'layout-2'
                ],
            ]
        );

        $this->add_control(
            'content_border_color',
            [
                'label' => __( 'Content Border', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-two__single' => 'border-color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => 'layout-2'
                ]
            ]
        );

        $this->add_control(
            'content_border_color_hover',
            [
                'label' => __( 'Content Border (Hover)', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-two__single:hover' => 'border-color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => 'layout-2'
                ]
            ]
        );

        $this->end_controls_section();

        // TAB_STYLE
        $this->start_controls_section(
            'twinkle_services_list_style',
            [
                'label' => __( 'Services List', 'twinkle-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            '_icon_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Icon', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'icon_size',
            [
                'label' => __( 'Icon Size', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .services-one__icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .services-two__icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs( 'tabs_button_style' );

        $this->start_controls_tab(
            'icon_tab',
            [
                'label' => esc_html__( 'Normal', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => __( 'Text', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-one__icon i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services-two__icon i' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'icon_background_color',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-one__icon' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .services-two__icon' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .services-one__icon:before' => 'border-bottom-color: {{VALUE}}',
                    '{{WRAPPER}} .services-two__icon:before' => 'border-bottom-color: {{VALUE}}',
                    '{{WRAPPER}} .services-one__icon:after' => 'border-top-color: {{VALUE}}',
                    '{{WRAPPER}} .services-two__icon:after' => 'border-top-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'icon_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'icon_color_hover',
            [
                'label' => __( 'Text (Hover)', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-one__single:hover .services-one__icon i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services-two__single:hover .services-two__icon i' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'icon_background_color_hover',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-one__single:hover .services-one__icon' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .services-one__single:hover .services-one__icon:before' => 'border-bottom-color: {{VALUE}}',
                    '{{WRAPPER}} .services-one__single:hover .services-one__icon:after' => 'border-top-color: {{VALUE}}',
                    '{{WRAPPER}} .services-two__single:hover .services-two__icon' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .services-two__single:hover .services-two__icon:before' => 'border-bottom-color: {{VALUE}}',
                    '{{WRAPPER}} .services-two__single:hover .services-two__icon:after' => 'border-top-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_responsive_control(
            'icon_bottom_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .services-one__title' => 'margin-top: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .services-two__title' => 'margin-top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            '_heading_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Title', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'title_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .services-one__title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .services-two__title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Text', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-one__title' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services-two__title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .services-one__title, .services-two__title',
            ]
        );

        // Description
        $this->add_control(
            '_content_description',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Description', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'description_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .services-one__text' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .services-two__text' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'services_list_description_color',
            [
                'label' => __( 'Text', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-one__text' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services-two__text' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'selector' => '{{WRAPPER}} .services-one__text, .services-two__text',
            ]
        );
        
        $this->add_control(
            '_button_icon_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Icon', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'button_color',
            [
                'label' => __( 'Text', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-one__icon-plus a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services-two__read-more' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => 'layout-2'
                ]
            ]
        );

        $this->add_control(
            'button_color_hover',
            [
                'label' => __( 'Text (Hover)', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-two__read-more:hover' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => 'layout-2'
                ]
            ]
        );

        $this->add_control(
            'button_background',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-one__single::before' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .services-one__single::after' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .services-one__icon-plus a:before' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => 'layout-1'
                ]
            ]
        );

        $this->add_control(
            'button_background_hover',
            [
                'label' => __( 'Background Hover', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-one__single:hover .services-one__icon-plus a:before' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .services-one__single:hover::after' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => 'layout-1'
                ]
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        // Link
        if ('2' == $settings['twinkle_services_link_type']) {
            $link = get_permalink($settings['twinkle_services_page_link']);
            $target = '_self';
            $rel = 'nofollow';
        } else {
            $link = !empty($settings['twinkle_services_link']['url']) ? $settings['twinkle_services_link']['url'] : '';
            $target = !empty($settings['twinkle_services_link']['is_external']) ? '_blank' : '';
            $rel = !empty($settings['twinkle_services_link']['nofollow']) ? 'nofollow' : '';
        }

        ?>

        <?php if ( $settings['twinkle_design_style']  == 'layout-1' ): ?>

            <div class="services-one__single">
                <div class="services-one__single-inner">
                    <?php if($settings['twinkle_service_icon_type'] !== 'image') : ?>
                        <?php if (!empty($settings['twinkle_service_icon']) || !empty($settings['twinkle_service_selected_icon']['value'])) : ?>
                            <div class="services-one__icon">
                                <?php twinkle_render_icon($settings, 'twinkle_service_icon', 'twinkle_service_selected_icon'); ?></span>
                            </div>
                        <?php endif; ?>   
                    <?php else : ?>
                        <div class="twinkle-sv-icon">
                            <?php if (!empty($settings['twinkle_service_image']['url'])): ?>
                            <img src="<?php echo $settings['twinkle_service_image']['url']; ?>" alt="<?php echo get_post_meta(attachment_url_to_postid($settings['twinkle_service_image']['url']), '_wp_attachment_image_alt', true); ?>">
                            <?php endif; ?>  
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($settings['twinkle_service_title' ])): ?>
                        <h3 class="services-one__title"><?php echo twinkle_kses($settings['twinkle_service_title' ]); ?></h3>
                    <?php endif; ?>
                    <?php if (!empty($settings['twinkle_service_description' ])): ?>
                        <p class="services-one__text"><?php echo twinkle_kses($settings['twinkle_service_description']); ?></p>
                    <?php endif; ?>
                    <?php if (!empty($link)) : ?>
                        <div class="services-one__icon-plus">
                            <a target="<?php echo esc_attr($target); ?>" rel="<?php echo esc_attr($rel); ?>" href="<?php echo esc_url($link); ?>">
                                <i class="fa fa-plus"></i>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        <?php elseif ( $settings['twinkle_design_style']  == 'layout-2' ): ?>

            <div class="services-two__single">
                <?php if($settings['twinkle_service_icon_type'] !== 'image') : ?>
                    <?php if (!empty($settings['twinkle_service_icon']) || !empty($settings['twinkle_service_selected_icon']['value'])) : ?>
                        <div class="services-two__icon">
                            <?php twinkle_render_icon($settings, 'twinkle_service_icon', 'twinkle_service_selected_icon'); ?></span>
                        </div>
                    <?php endif; ?>   
                <?php else : ?>
                    <div class="twinkle-sv-icon">
                        <?php if (!empty($settings['twinkle_service_image']['url'])): ?>
                        <img src="<?php echo $settings['twinkle_service_image']['url']; ?>" alt="<?php echo get_post_meta(attachment_url_to_postid($settings['twinkle_service_image']['url']), '_wp_attachment_image_alt', true); ?>">
                        <?php endif; ?>  
                    </div>
                <?php endif; ?>     
                
                <?php if (!empty($settings['twinkle_service_title' ])): ?>
                    <h3 class="services-two__title"><?php echo twinkle_kses($settings['twinkle_service_title' ]); ?></h3>
                <?php endif; ?>
                <?php if (!empty($settings['twinkle_service_description' ])): ?>
                    <p class="services-two__text"><?php echo twinkle_kses($settings['twinkle_service_description']); ?></p>
                <?php endif; ?>
                <?php if (!empty($link)) : ?>
                    <a target="<?php echo esc_attr($target); ?>" rel="<?php echo esc_attr($rel); ?>" href="<?php echo esc_url($link); ?>" class="services-two__read-more">
                        <?php echo twinkle_kses($settings['twinkle_services_btn_text']); ?> <span class="icon-plus-sign"></span>
                    </a>
                <?php endif; ?>
            </div>

        <?php endif; ?>

        <?php 
    }
}

$widgets_manager->register( new Twinkle_Services() );