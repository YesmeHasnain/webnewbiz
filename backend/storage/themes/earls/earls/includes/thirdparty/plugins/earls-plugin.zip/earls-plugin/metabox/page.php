<?php
return array(
	'title'      => 'Earls Setting',
	'id'         => 'earls_meta',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'page', 'post', 'team', 'project', 'product', 'menu' ),
	'sections'   => array(
		require_once EARLSPLUGIN_PLUGIN_PATH . '/metabox/header.php',
		require_once EARLSPLUGIN_PLUGIN_PATH . '/metabox/banner.php',
		require_once EARLSPLUGIN_PLUGIN_PATH . '/metabox/sidebar.php',
		require_once EARLSPLUGIN_PLUGIN_PATH . '/metabox/footer.php',
	),
);