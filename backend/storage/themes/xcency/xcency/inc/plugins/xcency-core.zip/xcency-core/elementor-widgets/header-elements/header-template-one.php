<?php
namespace Elementor;
class Xcency_Header_Template_One_Widget extends Widget_Base {

	public function get_name() {
		return 'xcency_header_template_one';
	}

	public function get_title() {
		return esc_html__( 'Header Template One', 'xcency-core' );
	}

	public function get_icon() {
		return 'flaticon-sections';
	}

	public function get_categories() {
		return [ 'xcency_core_elements' ];
	}


	protected function register_controls() {

        $this->start_controls_section(
            'header_layout_option',
            [
                'label' => esc_html__( 'Header Layout', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'header_layout',
            [
                'label'   => __( 'Header Layout', 'xcency-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'layout-one',
                'options' => [
                    'layout-one' => __( 'Layout One', 'xcency-core' ),
                    'layout-two' => __( 'Layout Two', 'xcency-core' ),
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'header_top_options',
            [
                'label' => esc_html__( 'Header Top', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'enable_header_top',
            [
                'label'     => esc_html__( 'Enable Header Top', 'xcency-core' ),
                'type'      => Controls_Manager::SWITCHER,
                'label_on'  => esc_html__( 'Yes', 'xcency-core' ),
                'label_off' => esc_html__( 'No', 'xcency-core' ),
                'default'   => 'yes',
            ]
        );

		$repeater = new Repeater();

		$repeater->add_control(
			'top_info_text',
			[
				'label'       => __( 'Information Text', 'xcency-core' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => '55 Main Street, 2nd block, Malborne ,Australia',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'top_info_icon',
			[
				'label'            => esc_html__( 'Information Icon', 'xcency-core' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fas fa-map-marker-alt',
					'library' => 'solid',
				],
			]
		);

		$this->add_control(
			'top_info_lists',
			[
				'label'       => __( 'Top Info List', 'xcency-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'top_info_text' => '55 Main Street, 2nd block, Malborne ,Australia',
					],

					[
						'top_info_text' => 'Email:<a href="mailto:help@quintexit.com">help@quintexit.com</a>',
					],
				],
				'title_field' => '{{{ top_info_text }}}',
                'condition' => [
                    'enable_header_top' => 'yes',
                ],
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'top_link_text',
			[
				'label'       => __( 'Link Text', 'xcency-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Help',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'top_link_url',
			[
				'label'         => __( 'Link URL', 'xcency-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'xcency-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'top_links',
			[
				'label'       => __( 'Top Link List', 'xcency-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'top_link_text' => 'Help',
					],
				],
				'title_field' => '{{{ top_link_text }}}',
				'condition' => [
					'enable_header_top' => 'yes',
				],
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'site_name',
			[
				'label'       => __( 'Social Site Name', 'xcency-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Facebook',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'social_icon',
			[
				'label'            => esc_html__( 'Select Icon', 'xcency-core' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fab fa-facebook-f',
					'library' => 'brand',
				],
			]
		);

		$repeater->add_control(
			'social_profile',
			[
				'label'         => __( 'Profile URL', 'xcency-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'xcency-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '#',
					'is_external' => true,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'socials_sites',
			[
				'label'       => __( 'Social Profile List', 'xcency-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'site_name' => 'Facebook',
					],
				],
				'title_field' => '<i class="{{{ social_icon.value }}}"></i>{{{ site_name }}}',
				'condition' => [
					'enable_header_top' => 'yes',
				],
			]
		);

        $this->end_controls_section();



		$this->start_controls_section(
			'logo_settings',
			[
				'label' => esc_html__( 'Logo & Menu', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'logo',
			[
				'label'       => __( 'Logo', 'xcency-core' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'default'     => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_responsive_control(
			'logo_width',
			[
				'label' => esc_html__( 'Logo Width', 'xcency-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .site-branding a img' => 'width: {{SIZE}}px;max-width: {{SIZE}}px;',
				],
			]
		);

		$this->add_responsive_control(
			'logo_height',
			[
				'label' => esc_html__( 'Logo Height', 'xcency-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .site-branding a img' => 'height: {{SIZE}}px;max-height: {{SIZE}}px;',
				],
			]
		);

		$this->add_control(
			'menu_list',
			[
				'label'   => __( 'Select Menu', 'xcency-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' =>xcency_core_get_custom_menu(),
			]
		);

		$this->add_responsive_control(
			'menu_align',
			[
				'label'       => esc_html__('Menu Align', 'xcency-core'),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options' => [
					'start' => [
						'title' => __('Left', 'xcency-core'),
						'icon'  => 'eicon-text-align-left',
					],

					'center' => [
						'title' => __('Center', 'xcency-core'),
						'icon'  => 'eicon-text-align-center',
					],

					'end' => [
						'title' => __('Right', 'xcency-core'),
						'icon'  => 'eicon-text-align-right',
					],
				],

				'devices' => ['desktop', 'tablet', 'mobile'],

				'selectors' => [
					'{{WRAPPER}} .xcency-header-template-one .header-navigation-area' => 'justify-content: {{VALUE}};',
				],

			]
		);

		$this->add_control(
			'sticky_header',
			[
				'label'     => esc_html__( 'Sticky Menu', 'xcency-core' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Yes', 'xcency-core' ),
				'label_off' => esc_html__( 'No', 'xcency-core' ),
				'default'   => 'yes',
			]
		);

		$this->add_control(
			'sticky_logo',
			[
				'label'       => __( 'Sticky Logo', 'xcency-core' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'condition' => [
					'sticky_header' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'header_buttons',
			[
				'label' => esc_html__( 'Buttons', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
            'enable_mobile',
            [
                'label'     => esc_html__( 'Enable Mobile Number Button', 'xcency-core' ),
                'type'      => Controls_Manager::SWITCHER,
                'label_on'  => esc_html__( 'Yes', 'xcency-core' ),
                'label_off' => esc_html__( 'No', 'xcency-core' ),
                'default'   => 'yes',
            ]
        );

        $this->add_control(
            'mobile_btn_subtitle',
            [
                'label'       => __( 'Mobile Subtitle', 'xcency-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Any Questions?', 'xcency-core' ),
                'condition' => [
                    'enable_mobile' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'mobile_number',
            [
                'label'       => __( 'Mobile Text', 'xcency-core' ),
                'type'        => Controls_Manager::WYSIWYG,
                'default'     => '<a href="tel:123456">+000 111 222 388</a>',
                'label_block' => true,
                'condition' => [
	                'enable_mobile' => 'yes',
                ],
            ]
        );

		$this->add_control(
			'enable_cta_btn',
			[
				'label'     => esc_html__( 'Enable CTA Button', 'xcency-core' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Yes', 'xcency-core' ),
				'label_off' => esc_html__( 'No', 'xcency-core' ),
				'default'   => 'yes',
			]
		);

		$this->add_control(
			'cta_btn_text',
			[
				'label'       => __( 'Button One Text', 'xcency-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Get Started',
				'condition' => [
					'enable_cta_btn' => 'yes',
				],
			]
		);

		$this->add_control(
			'cta_url',
			[
				'label'         => __( 'Button One URL', 'xcency-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'xcency-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
				'condition' => [
					'enable_cta_btn' => 'yes',
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'offcanvus_menu_area',
			[
				'label' => esc_html__( 'OffCanvas Menu', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'enable_offcanvas_menu',
			[
				'label'     => esc_html__( 'Enable Offcanvas Menu', 'xcency-core' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Yes', 'xcency-core' ),
				'label_off' => esc_html__( 'No', 'xcency-core' ),
				'default'   => 'yes',
			]
		);

		$this->add_control(
			'enable_page_scroll_while_offcanvas_open',
			[
				'label'     => esc_html__( 'Enable Page Scroll When Offcanvas Activate', 'xcency-core' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Yes', 'xcency-core' ),
				'label_off' => esc_html__( 'No', 'xcency-core' ),
				'default'   => 'no',
				'condition' => [
					'enable_offcanvas_menu' => 'yes',
				],
			]
		);

		$this->add_control(
			'close_offcanvas',
			[
				'label'   => __( 'Close Offcanvas Click On', 'xcency-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'dynamic',
				'options' => [
					'dynamic' => __( 'Close Button Or Back Drop', 'xcency-core' ),
					'static'  => __( 'Only Close Button', 'xcency-core' ),
				],
				'condition' => [
					'enable_offcanvas_menu' => 'yes',
				],
			]
		);

		$this->add_control(
			'offcanvas_position',
			[
				'label'   => __( 'Offcanvas Placement', 'xcency-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'end',
				'options' => [
					'start' => __( 'Left', 'xcency-core' ),
					'end'  => __( 'Right', 'xcency-core' ),
				],
				'condition' => [
					'enable_offcanvas_menu' => 'yes',
				],
			]
		);

		$this->add_control(
			'offcanvas_logo',
			[
				'label'       => __( 'Logo', 'xcency-core' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'default'     => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'enable_offcanvas_menu' => 'yes',
				],
			]
		);

		$this->add_control(
			'offcanvas_desc',
			[
				'label'       => __( 'offcanvas Description', 'xcency-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 5,
				'default'     => __( 'We are digital agency that helps businesses develop immersive and engaging.', 'xcency-core' ),
				'condition' => [
					'enable_offcanvas_menu' => 'yes',
				],
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'offcanvas_info_text',
			[
				'label'       => __( 'Info Text', 'xcency-core' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => 'Baird House, 15-17 St Cross StLondon EC1N 8UW',
				'label_block' => true,
			]
		);

		$this->add_control(
			'offcanvas_infos',
			[
				'label'       => __( 'Info List', 'xcency-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'offcanvas_info_text' => 'Baird House, 15-17 St Cross StLondon NewYork City, USA',
					],
					[
						'offcanvas_info_text' => '<a href="tel:123456789">+820-3400-2300</a>',
					],
					[
						'offcanvas_info_text' => '<a href="mailto:xcency@quintexbd.com">xcency@quintexbd.com</a>',
					],
				],
				'title_field' => '{{{ offcanvas_info_text }}}',
				'condition' => [
					'enable_offcanvas_menu' => 'yes',
				],
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'selected_social_icon',
			[
				'label'            => esc_html__( 'Select Icon', 'xcency-core' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fab fa-facebook-f',
					'library' => 'brands',
				],
			]
		);

		$repeater->add_control(
			'profile_url',
			[
				'label'         => __( 'Profile URL', 'xcency-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'xcency-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'socials',
			[
				'label'       => __( 'Social Profile List', 'xcency-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),

				'default'     => [
					[
						'selected_social_icon' => 'fab fa-facebook-f',
					],
				],
				'title_field' => '<i class="{{{selected_social_icon.value}}}"></i>',
				'condition' => [
					'enable_offcanvas_menu' => 'yes',
				],
			]
		);


		$this->end_controls_section();

        $this->start_controls_section(
            'header_top_style',
            [
                'label' => esc_html__( 'Header Top', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'enable_header_top' => 'yes',
                ],

            ]
        );

        $this->add_control(
            'header_top_bg',
            [
                'label'       => esc_html__('Background Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .header-top-area' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'header_top_text',
            [
                'label'       => esc_html__('Text Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .header-top-info-item, {{WRAPPER}} .header-top-info-item a,{{WRAPPER}} .header-top-menu a,{{WRAPPER}} .header-top-social a' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .header-top-menu:before' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .header-top-info-item svg,{{WRAPPER}} .header-top-social a svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'header_top_text_hover',
            [
                'label'       => esc_html__('Link Hover Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .header-top-info-item a:hover,{{WRAPPER}} .header-top-menu a:hover,{{WRAPPER}} .header-top-social a:hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .header-top-social a:hover svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();


		$this->start_controls_section(
			'header_menu_wrapper',
			[
				'label' => esc_html__( 'Menu Wrapper', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'menu_wrapper_bg',
			[
				'label'       => esc_html__('Background Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .main-menu-area' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'bottom_border_color',
			[
				'label'       => esc_html__('Bottom Border Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .main-menu-area' => 'border-bottom: 1px solid {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'menu_wrapper_width',
			[
				'label' => esc_html__( 'Container Max Width', 'xcency-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 1200,
						'max' => 2500,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .xcency-header-template-one .container' => 'max-width: {{SIZE}}px;',
				],
			]
		);

		$this->add_responsive_control(
			'menu_wrapper_padding',
			[
				'label'      => esc_html__( 'Wrapper Padding', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .main-menu-area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'wrapper_position',
			[
				'label'   => __( 'Wrapper Position', 'xcency-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'wrapper-relative',
				'options' => [
					'wrapper-relative' => __( 'Relative', 'xcency-core' ),
					'wrapper-absolute'  => __( 'Absolute', 'xcency-core' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'menu_area',
			[
				'label' => esc_html__( 'Menu', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'menu_typography',
				'label' => esc_html__( 'Typography', 'xcency-core' ),
				'selector' => '{{WRAPPER}} .xcency-header-template-one .main-navigation ul li a',
			]
		);

		$this->add_control(
			'menu_color',
			[
				'label'       => esc_html__('Menu Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .main-navigation ul li a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'active_menu_color',
			[
				'label'       => esc_html__('Active / Hover Menu Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .main-navigation ul li a:hover,{{WRAPPER}} .main-navigation ul li.current-menu-item > a,{{WRAPPER}} .main-navigation ul li.current_page_item > a,{{WRAPPER}} .main-navigation ul li.current-menu-ancestor > a,{{WRAPPER}} .main-navigation ul li.current_page_ancestor > a' => 'color: {{VALUE}};',
				],
			]
		);

        $this->add_control(
            'active_menu_bg_color',
            [
                'label'       => esc_html__('Active / Hover Menu Background Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .xcency-header-template-one .main-navigation ul li a:after' => 'background-color: {{VALUE}};',
                ],
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'dropdown_menu_style',
			[
				'label' => esc_html__( 'Dropdown Menu', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'background_color',
			[
				'label'       => esc_html__('Background Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .main-navigation ul li ul' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'dm_text_color',
			[
				'label'       => esc_html__('Text Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .main-navigation ul li ul li a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'dm_active_color',
			[
				'label'       => esc_html__('Hover Text Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .main-navigation ul li ul li a:hover,{{WRAPPER}} .main-navigation ul li ul li.current-menu-item > a,{{WRAPPER}} .main-navigation ul li ul li.current_page_item > a,{{WRAPPER}} .main-navigation ul li ul li.current-menu-ancestor > a,{{WRAPPER}} .main-navigation ul li ul li.current_page_ancestor > a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'dm_bottom_border_color',
			[
				'label'       => esc_html__('Bottom Border Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .main-navigation ul li ul li' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();



		// Start Mobile Button section
		$this->start_controls_section(
			'xcency_mobile_button_style_options',
			[
				'label' => esc_html__('Mobile Button', 'xcency-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'enable_mobile' => 'yes',
				],
			]
		);

        $this->add_control(
            'mbl_icon_bg',
            [
                'label'       => esc_html__('Icon Background', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .header-mobile-icon' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'mbl_icon_border_color',
            [
                'label'       => esc_html__('Icon Border Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .header-mobile-icon' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'mbl_icon_color',
            [
                'label'       => esc_html__('Icon Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .header-mobile-icon' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'mbl_subtitle_color',
            [
                'label'       => esc_html__('Subtitle Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .mobile-subtitle' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'mbl_number_color',
            [
                'label'       => esc_html__('Number Text Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .mobile-number-content,{{WRAPPER}} .mobile-number-content a' => 'color: {{VALUE}};',
                ],
            ]
        );



		$this->end_controls_section();

		// Start Button section
		$this->start_controls_section(
			'xcency_cta_button_style_options',
			[
				'label' => esc_html__('CTA Button', 'xcency-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'enable_cta_btn' => 'yes',
				],
			]
		);

		$this->add_control(
			'cta_btn_bg_color',
			[
				'label'       => esc_html__('CTA Button Background', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-header-template-one .header-cta-button .xcency-button' => 'background-color: {{VALUE}};border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cta_btn_color',
			[
				'label'       => esc_html__('CTA Button Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-header-template-one .header-cta-button .xcency-button' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cta_btn_hover_bg_color',
			[
				'label'       => esc_html__('CTA Button Background', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-header-template-one .header-cta-button .xcency-button:hover' => 'background-color: {{VALUE}};border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cta_btn_hover_color',
			[
				'label'       => esc_html__('CTA Button Hover Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-header-template-one .header-cta-button .xcency-button:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();


		$this->start_controls_section(
			'offcanvas_style',
			[
				'label' => esc_html__( 'Offcanvas', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'enable_offcanvas_menu' => 'yes',
				],
			]
		);

		$this->add_control(
			'trigger_icon_color',
			[
				'label'       => esc_html__('Trigger Icon Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .offcanvas-menu-trigger span' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'backdrop_bg_color',
			[
				'label'       => esc_html__('Backdrop Background Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .offcanvas-backdrop' => 'background-color: {{VALUE}};opacity:1;',
				],
			]
		);

		$this->add_control(
			'offcanvas_content_bg_color',
			[
				'label'       => esc_html__('Content Background Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-offcanvas-wrapper' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'offcanvas_close_icon_color',
			[
				'label'       => esc_html__('Close Icon Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-offcanvas-wrapper .btn-close' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'offcanvas_desc_typo',
				'label' => esc_html__( 'Description Typography', 'xcency-core' ),
				'selector' => '{{WRAPPER}} .xcency-offcanvas-desc',
			]
		);

		$this->add_responsive_control(
			'offcanvas_desc_margin',
			[
				'label'      => esc_html__( 'Description Margin', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .xcency-offcanvas-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'offcanvas_desc_padding',
			[
				'label'      => esc_html__( 'Description Padding', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .xcency-offcanvas-desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'offcanvas_info_typo',
				'label' => esc_html__( 'Information Typography', 'xcency-core' ),
				'selector' => '{{WRAPPER}} .xcency-offcanvas-contact-info-wrapper',
			]
		);

		$this->add_control(
			'offcanvas_text_color',
			[
				'label'       => esc_html__('Text Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-offcanvas-desc,{{WRAPPER}} .xcency-offcanvas-contact-info-wrapper,{{WRAPPER}} .xcency-offcanvas-contact-info-wrapper a,{{WRAPPER}} .offcanvas-social a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'offcanvas_text_hover_color',
			[
				'label'       => esc_html__('Link Text Hover Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-offcanvas-contact-info-wrapper a:hover,{{WRAPPER}} .offcanvas-social a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'sticky_header_options',
			[
				'label' => esc_html__( 'Sticky Header', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'sticky_header' => 'yes',
				],
			]
		);

		$this->add_control(
			'sticky_menu_bg',
			[
				'label'       => esc_html__('Background Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .main-menu-area.uk-sticky-fixed' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'sticky_menu_color',
			[
				'label'       => esc_html__('Text Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .main-menu-area.uk-sticky-fixed .main-navigation ul li a,{{WRAPPER}} .main-menu-area.uk-sticky-fixed .xcency-button.xcency-header-btn-1' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'sticky_buttons_color',
			[
				'label'       => esc_html__('Buttons Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-header-template-one .uk-sticky-fixed .header-cta-button .xcency-text-button' => 'color: {{VALUE}};',
					'{{WRAPPER}} .uk-sticky-fixed .offcanvas-menu-trigger span' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'sticky_menu_bottom_border_color',
			[
				'label'       => esc_html__('Bottom Border Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .main-menu-area.uk-sticky-fixed' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'mobile_options',
			[
				'label' => esc_html__( 'Mobile Menu', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'mobile_menu_trigger_color',
			[
				'label'       => esc_html__('Trigger Icon Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .mobile-menu-trigger span' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'stiky_mobile_menu_trigger_color',
			[
				'label'       => esc_html__('Sticky Trigger Icon Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .uk-sticky-fixed .mobile-menu-trigger span' => 'background-color: {{VALUE}};',
				],
			]
		);

        $this->add_control(
            'mobile_menu_bg_color',
            [
                'label'       => esc_html__('Background Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .mobile-menu-container' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'mobile_menu_item_color',
            [
                'label'       => esc_html__('Menu Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .slicknav_nav a, {{WRAPPER}} .slicknav_row a' => 'color: {{VALUE}};',
                ],
            ]
        );

		$this->add_control(
			'active_menu_text_color',
			[
				'label'       => esc_html__('Active Menu Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .slicknav_nav a:hover,{{WRAPPER}} .slicknav_item.slicknav_row:hover a,{{WRAPPER}} .slicknav_item.slicknav_row:hover .slicknav_arrow,{{WRAPPER}} .slicknav_menu .current-menu-item>a,{{WRAPPER}} .slicknav_menu .current-menu-ancestor>a,{{WRAPPER}} .slicknav_menu .current-menu-ancestor>.slicknav_row>a,{{WRAPPER}} .current-menu-ancestor>.slicknav_row .slicknav_arrow' => 'color: {{VALUE}};',
				],
			]
		);

        $this->add_control(
            'mobile_menu_border_color',
            [
                'label'       => esc_html__('Border Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .slicknav_nav li a' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'mobile_menu_close_icon__color',
            [
                'label'       => esc_html__('Close Icon Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .mobile-menu-close::before, {{WRAPPER}} .mobile-menu-close::after' => 'background-color: {{VALUE}};',
                ],
            ]
        );
		$this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<?php if ($settings['enable_offcanvas_menu'] == 'yes') :?>
            <div class="xcency-offcanvas-wrapper offcanvas offcanvas-<?php echo $settings['offcanvas_position'];?>" <?php if ($settings['enable_page_scroll_while_offcanvas_open'] == 'yes'){echo 'data-bs-scroll="true"';} ?> data-bs-backdrop="<?php echo $settings['close_offcanvas'];?>" id="xcency-offcanvas-wrapper">
                <div class="offcanvas-header">
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"><i class="flaticon-plus-1"></i></button>
                </div>

                <div class="offcanvas-body">
                    <div class="xcency-offcanvas-logo">

                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
							<?php
							$offcanvas_logo_alt = get_post_meta( $settings['logo']['id'], '_wp_attachment_image_alt', true );
							$offcanvas_logo_title = get_the_title( $settings['logo']['id']);
							?>

                            <img src="<?php echo $settings['offcanvas_logo']['url'];?>" alt="<?php echo esc_attr($offcanvas_logo_alt);?>" title="<?php echo esc_attr($offcanvas_logo_title);?>">
                        </a>
                    </div>

                    <div class="xcency-offcanvas-desc xcency-last-p-0">
						<?php echo $settings['offcanvas_desc'];?>
                    </div>

                    <div class="xcency-offcanvas-contact-info-wrapper">
                        <ul class="xcency-list-style">
							<?php if ($settings['offcanvas_infos']) {
								foreach ($settings['offcanvas_infos'] as $offcanvas_info) { ?>
                                    <li>
										<?php echo $offcanvas_info['offcanvas_info_text'];?>
                                    </li>
								<?php }
							} ?>
                        </ul>
                    </div>

                    <div class="offcanvas-social">
                        <ul class="xcency-list-style xcency-list-inline">
							<?php if ( $settings['socials'] ) {
								foreach ( $settings['socials'] as $social ) {
									$profile_url = $social['profile_url']['url'];
									$target      = $social['profile_url']['is_external'] ? ' target="_blank"' : '';
									$nofollow    = $social['profile_url']['nofollow'] ? ' rel="nofollow"' : '';
									?>
                                    <li>
                                        <a href="<?php echo $profile_url; ?>" <?php echo $target . $nofollow ?>>

                                            <i class="<?php echo $social['selected_social_icon']['value']; ?>"></i>
                                        </a>
                                    </li>
								<?php }
							} ?>
                        </ul>
                    </div>
                </div>
            </div>
		<?php endif; ?>

        <div class="mobile-menu-container">
            <div class="mobile-menu-close"></div>
            <div id="mobile-menu-wrap"></div>
        </div>

        <header class="header-area site-header">
            <div id="xcency-header-template-one" class="xcency-header-builder xcency-header-template-one <?php echo $settings['header_layout'];?>">
                <?php if($settings['enable_header_top'] == 'yes') : ?>
                <div class="header-top-area">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-xl-8 col-lg-12">
                                <div class="header-top-info">
                                    <ul class="xcency-list-style xcency-list-inline">
			                            <?php if($settings['top_info_lists']){
				                            foreach ($settings['top_info_lists'] as $top_info_list){ ?>
                                                <li class="header-top-info-item xcency-last-p-0">
						                            <?php  xcency_custom_icon_render( $top_info_list, 'icon', 'top_info_icon' );?>
						                            <?php echo $top_info_list['top_info_text'];?>
                                                </li>
				                            <?php }
			                            } ?>
                                    </ul>
                                </div>
                            </div>

                            <div class="col-xl-4 col-lg-12">
                                <div class="header-top-menu-and-socials">
                                    <div class="header-top-menu">
	                                    <?php if ($settings['top_links']) {
		                                    foreach ($settings['top_links'] as $top_link) { ?>
                                                <a href="<?php echo $top_link['top_link_url']['url'];?>"><?php echo $top_link['top_link_text'];?></a>
		                                    <?php }
	                                    } ?>
                                    </div>

                                    <div class="header-top-social">
	                                    <?php if ( $settings['socials_sites'] ) {
		                                    foreach ( $settings['socials_sites'] as $social ) { ?>
                                                <a href="<?php echo $social['social_profile']['url']?>" target="_blank">
                                                    <?php xcency_custom_icon_render( $social, 'icon', 'social_icon' ); ?>
                                                </a>
		                                    <?php }
	                                    } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <div class="header-logo-and-menu-area-content-wrapper">
                    <div class="header-logo-and-menu-area-wrapper <?php echo esc_attr($settings['wrapper_position']);?>">
                        <div class="main-menu-area" <?php if($settings['sticky_header'] == 'yes' ){echo 'data-uk-sticky="top: 250; animation: uk-animation-slide-top;"';} ?>>
                            <div class="container">
                                <div class="row align-items-center">
                                    <div class="col-lg-2 col-sm-3 col-6">
                                        <div class="site-branding<?php if ($settings['sticky_header'] == 'yes' && $settings['sticky_logo']['url']){echo ' xcency-have-sticky-logo';}?>">
                                            <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                                                <?php
                                                $logo_alt = get_post_meta( $settings['logo']['id'], '_wp_attachment_image_alt', true );
                                                $logo_title = get_the_title( $settings['logo']['id']);
                                                ?>
                                                <img class="xcency-site-default-logo" src="<?php echo $settings['logo']['url'] ?>" alt="<?php echo $logo_alt;?>" title="<?php echo $logo_title;?>">
                                                <?php if ($settings['sticky_header'] == 'yes' && $settings['sticky_logo']['url']) :?>
                                                    <img class="xcency-site-sticky-logo"  src="<?php echo $settings['sticky_logo']['url'] ?>" alt="<?php echo $logo_alt;?>" title="<?php echo $logo_title;?>">
                                                <?php endif; ?>
                                            </a>
                                        </div>
                                    </div>

                                    <div class="col-lg-10 col-sm-9 col-6">
                                        <div class="header-nav-and-buttons">
                                            <div class="header-navigation-area">
                                                <nav id="site-navigation" class="main-navigation xcency-list-style">
                                                    <?php
                                                    if($settings['menu_list']){
                                                        $header_menu = $settings['menu_list'];
                                                    }else{
                                                        $header_menu = '';
                                                    }

                                                    wp_nav_menu( array(
                                                        'menu'            => $header_menu,
                                                        'theme_location'  => 'main-menu',
                                                        'menu_id'         => 'main-menu',
                                                        'container_class' => 'main-menu-container',
                                                    ) );
                                                    ?>
                                                </nav><!-- #site-navigation -->
                                            </div>
                                            <div class="header-buttons-area">
                                                <ul class="header-buttons-wrapper xcency-list-style">
                                                    <?php if($settings['enable_mobile'] == 'yes'):?>
                                                        <li class="header-mobile-number">
                                                            <div class="header-mobile-icon">
                                                                <i class="flaticon-phone-call"></i>
                                                            </div>

                                                            <div class="mobile-number-content-wrapper">
                                                                <div class="mobile-subtitle"><?php echo $settings['mobile_btn_subtitle'];?></div>
                                                                <div class="mobile-number-content xcency-last-p-0">
                                                                    <?php echo $settings['mobile_number'];?>
                                                                </div>
                                                            </div>
                                                        </li>
                                                    <?php endif; ?>
                                                    <?php if($settings['enable_cta_btn'] == 'yes'):?>
                                                        <li class="header-cta-button">
                                                            <a class="xcency-button" href="<?php echo $settings['cta_url']['url'];?>"><?php echo $settings['cta_btn_text'];?>
                                                            </a>
                                                        </li>
                                                    <?php endif; ?>

                                                    <?php if ($settings['enable_offcanvas_menu'] == 'yes') :?>
                                                        <li data-bs-toggle="offcanvas" data-bs-target="#xcency-offcanvas-wrapper" aria-controls="xcency-offcanvas-wrapper" class="offcanvas-menu-trigger"><span></span><span></span><span></span></li>
                                                    <?php endif; ?>
                                                    <li class="mobile-menu-trigger"><span></span><span></span><span></span></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <script>
            (function ($) {
                "use strict";
                /*====  Document Ready Function =====*/
                jQuery(document).ready(function($){
                    $( ".banner-area" ).addClass( "xcency-header-template-one-selected <?php echo $settings['header_layout'];?>-selected" );
                });
            }(jQuery));
        </script>
		<?php
	}
}

Plugin::instance()->widgets_manager->register( new Xcency_Header_Template_One_Widget );