<?php
// single event script
function rdn_single_event_script() {
	global $post;
	if ( is_singular( 'event' ) ) {
		wp_enqueue_script('jquery-isotope',MANCINK_URL .'widgets/js/isotope.pkgd.js', array('jquery'), null, true  );
		wp_enqueue_script('jquery-slick-slider' ,MANCINK_URL . 'widgets/js/slick.min.js' , array('jquery'), null, true );
		wp_enqueue_script('slick-slider-animation' ,MANCINK_URL . 'widgets/js/slick-animation.js' , array('jquery'), null, true );
        wp_enqueue_script('imgbg-script',MANCINK_URL . 'widgets/js/imgbg.js' , array('jquery'), null, true );
		wp_enqueue_script('single-event',MANCINK_URL . 'widgets/js/single-event.js' , array('jquery'), null, true );
		wp_enqueue_script('slider-script',MANCINK_URL . 'widgets/js/slider.js' , array('jquery'), null, true );
		if (get_post_meta( get_the_ID(), 'port_format', true) == 'port_two' && get_post_meta( get_the_ID(), 'top_type', true) == 'top_content_slider' ){
			wp_enqueue_script('sliderbg-script',MANCINK_URL . 'widgets/js/sliderbg.js' , array('jquery'), null, true );
		}
    }

}

add_action( 'wp_enqueue_scripts', 'rdn_single_event_script',100 );