<?php namespace EARLSPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Blog_Grid extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'earls_blog_grid';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Earls Blog Grid', 'earls' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-post-list';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'earls' ];
    }
    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'blog_grid',
            [
                'label' => esc_html__( 'Earls Blog Grid', 'earls' ),
            ]
        );
		
		$this->add_control(
            'comment',
            [
                'label'        => esc_html__( 'Show Comment', 'earls' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'On', 'earls' ),
                'label_off'    => esc_html__( 'Off', 'earls' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );
		$this->add_control(
            'author',
            [
                'label'        => esc_html__( 'Show Author', 'earls' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'On', 'earls' ),
                'label_off'    => esc_html__( 'Off', 'earls' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );
		$this->add_control(
            'date',
            [
                'label'        => esc_html__( 'Show Date', 'earls' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'On', 'earls' ),
                'label_off'    => esc_html__( 'Off', 'earls' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );
		$this->add_control(
			'btn_title',
			[
				'label' => esc_html__( 'Button Title', 'earls' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter button title', 'earls' ),
				'default' => esc_html__( 'View More', 'earls' ),
			]
		);
		$this->add_control(
			'col_grid',
			[
				'label'   => esc_html__( 'Choose Column', 'earls' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'default',
				'options' => array(
					'default'  => esc_html__( 'Default', 'earls' ),
					'one' => esc_html__( 'One Column Grid ', 'earls'),
					'two'  => esc_html__( 'Two Column Grid', 'earls' ),
					'three'  => esc_html__( 'Three Column Grid', 'earls' ),
					'four'  => esc_html__( 'Four Column Grid', 'earls' ),
					'five'  => esc_html__( 'Six Column Grid', 'earls' ),
				),
			]
		);
		$this->add_control(
			'text_limit',
			[
				'label'   => esc_html__( 'Text Limit', 'earls' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			]
		);
		$this->add_control(
            'query_number',
            [
                'label'   => esc_html__( 'Number of post', 'earls' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 5,
                'min'     => 1,
                'max'     => 100,
                'step'    => 1,
            ]
        );
        $this->add_control(
            'query_orderby',
            [
                'label'   => esc_html__( 'Order By', 'earls' ),
				'label_block' => true,
                'type'    => Controls_Manager::SELECT,
                'default' => 'date',
                'options' => array(
                    'date'       => esc_html__( 'Date', 'earls' ),
                    'title'      => esc_html__( 'Title', 'earls' ),
                    'menu_order' => esc_html__( 'Menu Order', 'earls' ),
                    'rand'       => esc_html__( 'Random', 'earls' ),
                ),
            ]
        );
        $this->add_control(
            'query_order',
            [
                'label'   => esc_html__( 'Order', 'earls' ),
				'label_block' => true,
                'type'    => Controls_Manager::SELECT,
                'default' => 'ASC',
                'options' => array(
                    'DESC' => esc_html__( 'DESC', 'earls' ),
                    'ASC'  => esc_html__( 'ASC', 'earls' ),
                ),
            ]
        );
        $this->add_control(
            'query_category',
            [
                'type' => Controls_Manager::SELECT,
                'label' => esc_html__('Category', 'earls'),
				'label_block' => true,
                'options' => get_blog_categories(),
            ]
        );
		
		$this->end_controls_section();
		
		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'earls' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'earls' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .blog__section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
        $this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'earls' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .blog__section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'earls' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .blog__section',				
			]
		);
		
		
	}
	
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		$coment = $settings[ 'comment' ];
		$date = $settings[ 'date' ];
		$author = $settings[ 'author' ];
		$btn_title = $settings[ 'btn_title' ]; 
		
		$grid_col = $settings[ 'col_grid' ];
		if( $grid_col == 'one' ){
			$classes = 'col-lg-12 col-md-12';
		}elseif( $grid_col == 'two' ){
			$classes = 'col-lg-6 col-md-6 col-sm-12';
		}elseif( $grid_col == 'three' ){
			$classes = 'col-lg-4 col-md-6 col-sm-12';
		}elseif( $grid_col == 'four' ){
			$classes = 'col-lg-3 col-md-3 col-sm-12';
		}elseif( $grid_col == 'five' ){
			$classes = 'col-lg-2 col-md-4 col-sm-12';
		}else{
			$classes = 'col-lg-6 col-md-6 col-sm-12';
		}
		
		$paged = earls_set($_POST, 'paged') ? esc_attr($_POST['paged']) : 1;
        $this->add_render_attribute( 'wrapper', 'class', 'templatepath-greenture' );
        $args = array(
            'post_type'      => 'post',
            'posts_per_page' => earls_set( $settings, 'query_number' ),
            'orderby'        => earls_set( $settings, 'query_orderby' ),
            'order'          => earls_set( $settings, 'query_order' ),
            'paged'         => $paged
        );
        if( earls_set( $settings, 'query_category' ) ) $args['category_name'] = earls_set( $settings, 'query_category' );
        $query = new \WP_Query( $args );
		if ( $query->have_posts() ) { 
	?>
    
    <section class="blog__section p-0 m-0">
        <div class="row clearfix">
            <?php while ( $query->have_posts() ) : $query->the_post(); ?>
            <div class="<?php echo esc_attr( $classes );?>">
                <div class="news-block-one wow slideInUp animated animated" data-wow-delay="00ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: slideInUp;">
                    <div class="inner-box p_relative d_block">
                        <?php if(has_post_thumbnail()){ ?>
                        <figure class="image-box">
                        	<a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
								<?php the_post_thumbnail('earls_606x430'); ?>
                            </a>
                        </figure>
                        <?php } ?>
                        <div class="lower-content p_relative d_block">
                            <?php if( $author == 'yes' || $date == 'yes' || $coment == 'yes' ){?>
                            <ul class="post-info clearfix">
                                <?php if( $author == 'yes' ){?><li><a href="<?php echo esc_url(get_author_posts_url( get_the_author_meta('ID') )); ?>"><i class="fal fa-user"></i> <?php the_author(); ?></a> </li><?php } ?>
                                <?php if( $date == 'yes' ){?><li><a href="<?php echo get_month_link(get_the_date('Y'), get_the_date('m')); ?>"><i class="fal fa-calendar"></i> <?php echo get_the_date(); ?> </a> </li><?php } ?>
                                <?php if( $coment == 'yes' ){?><li><i class="far fa-comments-alt"></i> <?php comments_number( wp_kses(__('0 Comments' , 'earls'), true), wp_kses(__('01 Comment' , 'earls'), true), wp_kses(__('0% Comments' , 'earls'), true)); ?></li><?php } ?>
                            </ul>
                            <?php } ?>
                            <h4><a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h4>
                            <div class="short__des">
                                <p><?php echo wp_kses(earls_trim(get_the_content(), $settings['text_limit']), true); ?></p>
                            </div>
                            <div class="link">
                            	<a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
									<?php if( !empty( $btn_title ) ):?>
                                        <?php echo wp_kses( $btn_title, true );?>
                                    <?php else:?>
                                        <?php esc_html_e('Read More', 'earls');?>
                                    <?php endif;?>
                            	</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div><!-- /.row gutter-y-30 -->
    </section>         
   
   	<?php }
	wp_reset_postdata();
	}
}