<?php
namespace Elementor;

class Xcency_Recent_Post_One_Widget extends Widget_Base {

    public function get_name() {
        return 'xcency_recent_post_one';
    }

    public function get_title() {
        return esc_html__( 'Recent Post One', 'xcency-core' );
    }

    public function get_icon() {
        return 'eicon-post-excerpt';
    }

    public function get_categories() {
        return [ 'xcency_core_elements' ];
    }

    protected function register_controls() {

        $this->start_controls_section(
            'recent_post_settings',
            [
                'label' => esc_html__( 'Post Settings', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'post_count',
            [
                'label'   => __( 'Number Of Post To Show', 'xcency-core' ),
                'type'    => Controls_Manager::NUMBER,
                'min'     => 1,
                'max'     => 12,
                'step'    => 1,
                'default' => 4,
            ]
        );

        $this->add_control(
            'category',
            [
                'label'       => __( 'Categories', 'xcency-core' ),
                'type'        => Controls_Manager::SELECT2,
                'label_block' => true,
                'multiple'    => true,
                'options'     => xcency_core_post_categories(),
            ]
        );

        $this->add_control(
            'post_offset',
            [
                'label'   => __( 'Post Offset', 'xcency-core' ),
                'type'    => Controls_Manager::NUMBER,
                'min'     => 0,
                'max'     => '',
                'step'    => 1,
                'default' => 0,
            ]
        );

        $this->add_control(
            'post_orderby',
            [
                'label'   => __( 'Order By', 'xcency-core' ),
                'type'    => Controls_Manager::SELECT,
                'options' => xcency_core_post_orderby_options(),
                'default' => 'date',

            ]
        );

        $this->add_control(
            'post_order',
            [
                'label'   => __( 'Order', 'xcency-core' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'asc'  => 'Ascending',
                    'desc' => 'Descending'
                ],
                'default' => 'desc',

            ]
        );

        $this->add_control(
            'comment_count',
            [
                'label'     => esc_html__( 'Comment Count', 'xcency-core' ),
                'type'      => Controls_Manager::SWITCHER,
                'label_on'  => esc_html__( 'Yes', 'xcency-core' ),
                'label_off' => esc_html__( 'No', 'xcency-core' ),
                'default'   => 'yes',
            ]
        );

        $this->add_control(
            'show_author',
            [
                'label'   => __( 'Show Author', 'xcency-core' ),
                'type'    => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'title_word',
            [
                'label'   => __( 'Title Word Count', 'xcency-core' ),
                'type'    => Controls_Manager::NUMBER,
                'min'     => 0,
                'max'     => '',
                'step'    => 1,
                'default' => 10,
            ]
        );

        $this->add_control(
            'details_btn_text',
            [
                'label'       => esc_html__( 'Details Button Text', 'xcency-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => esc_html__( 'Read More', 'xcency-core' ),
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'recent_post_style',
            [
                'label' => esc_html__( 'Post Style', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label'     => esc_html__( 'Icon Color', 'xcency-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .post-meta li i,{{WRAPPER}} .post-meta li a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'btn_bg_color',
            [
                'label'     => esc_html__( 'Button Background Color', 'xcency-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .xcency-post-meta-and-button .xcency-icon-button' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'btn_hover_bg_color',
            [
                'label'     => esc_html__( 'Button Hover Background Color', 'xcency-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .xcency-post-meta-and-button .xcency-icon-button:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );


        $this->end_controls_section();

    }

    //Render
    protected function render() {
        $settings = $this->get_settings_for_display();

        if ( ! empty( $settings['category'] ) ) {
            $post_query = new \WP_Query( array(
                'post_type'           => 'post',
                'posts_per_page'      => $settings['post_count'],
                'ignore_sticky_posts' => 1,
                'offset'              => $settings['post_offset'],
                'orderby'             => $settings['post_orderby'],
                'order'               => $settings['post_order'],
                'tax_query'           => array(
                    array(
                        'taxonomy' => 'category',
                        'terms'    => $settings['category'],
                        'field'    => 'slug',
                    )
                )
            ) );
        } else {

            $post_query = new \WP_Query(
                array(
                    'posts_per_page'      => $settings['post_count'],
                    'post_type'           => 'post',
                    'ignore_sticky_posts' => 1,
                    'offset'              => $settings['post_offset'],
                    'orderby'             => $settings['post_orderby'],
                    'order'               => $settings['post_order'],
                )
            );
        }
        ?>

        <div class="xcency-recent-post-one-wrapper">

	        <?php
	        $counter = 0;
	        $group = [];

	        while ($post_query->have_posts()) : $post_query->the_post();
		        $group[] = get_post();
		        $counter++;

		        // Render every group of 4 or at the end of the loop
		        if ($counter % 4 === 0 || $counter === $post_query->post_count) :

			        // Big Post
			        $big_post = $group[0];
			        global $post;
			        $post = $big_post;
			        setup_postdata($post);
			        ?>

                    <div class="row">
                        <div class="col-xl-6">
                            <div class="recent-post-one-item recent-post-one-big-item">
                                <a class="post-thumb-url" href="<?php echo esc_url(get_permalink($big_post)); ?>">
                                    <div class="xcency-post-thumbnail xcency-cover-bg"
                                         style="background-image: url(<?php echo get_the_post_thumbnail_url($big_post, 'full'); ?>)">
                                    </div>
                                </a>


                                <div class="xcency-post-meta post-meta">
                                    <ul class="xcency-list-style xcency-list-inline">
								        <?php if ($settings['show_author'] == 'yes' && function_exists('xcency_posted_by')) : ?>
                                            <li><?php xcency_posted_by(); ?></li>
								        <?php endif; ?>

								        <?php if ($settings['comment_count'] == 'yes' && get_comments_number() > 0 && function_exists('xcency_comment_count')) : ?>
                                            <li class="comment-number"><?php xcency_comment_count(); ?></li>
								        <?php endif; ?>
                                    </ul>
                                </div>

                                <div class="xcency-recent-post-title">
                                    <a href="<?php echo esc_url(get_permalink($big_post)); ?>">
                                        <h4 class="post-title">
									        <?php echo wp_trim_words(get_the_title($big_post), $settings['title_word'], ' ...'); ?>
                                        </h4>
                                    </a>
                                </div>

                                <div class="xcency-recent-post-button">
                                    <a class="xcency-button"  href="<?php echo esc_url(get_permalink($big_post)); ?>">
			                            <?php echo $settings['details_btn_text'];?>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-6">
					        <?php for ($i = 1; $i < count($group); $i++) :
						        $small_post = $group[$i];
						        global $post;
						        $post = $small_post;
						        setup_postdata($post);
						        ?>
                                <div class="recent-post-one-item recent-post-one-small-item">
                                    <a class="post-thumb-url"  href="<?php echo esc_url(get_permalink($small_post)); ?>">
                                        <div class="xcency-post-thumbnail xcency-cover-bg"
                                             style="background-image: url(<?php echo get_the_post_thumbnail_url($small_post, 'full'); ?>)">
                                        </div>
                                    </a>

                                    <div class="post-small-content">
                                        <div class="xcency-post-meta post-meta">
                                            <ul class="xcency-list-style xcency-list-inline">
			                                    <?php if ($settings['show_author'] === 'yes' && function_exists('xcency_posted_by')) : ?>
                                                    <li><?php xcency_posted_by(); ?></li>
			                                    <?php endif; ?>

			                                    <?php if ($settings['comment_count'] == 'yes' && get_comments_number() > 0 && function_exists('xcency_comment_count')) : ?>
                                                    <li class="comment-number"><?php xcency_comment_count(); ?></li>
			                                    <?php endif; ?>
                                            </ul>
                                        </div>

                                        <div class="xcency-recent-post-title">
                                            <a href="<?php echo esc_url(get_permalink($small_post)); ?>">
                                                <h4 class="post-title">
				                                    <?php echo wp_trim_words(get_the_title($small_post), $settings['title_word'], ' ...'); ?>
                                                </h4>
                                            </a>
                                        </div>

                                        <div class="xcency-recent-post-button">
                                            <a class="xcency-button"  href="<?php echo esc_url(get_permalink($small_post)); ?>">
			                                    <?php echo $settings['details_btn_text'];?>
                                            </a>
                                        </div>
                                    </div>
                                </div>
					        <?php endfor; ?>
                        </div>
                    </div>

			        <?php
			        wp_reset_postdata(); // Reset after each group
			        $group = []; // Clear group for next batch
		        endif;

	        endwhile;
	        ?>


        </div>

        <?php

    }
}

Plugin::instance()->widgets_manager->register( new Xcency_Recent_Post_One_Widget );