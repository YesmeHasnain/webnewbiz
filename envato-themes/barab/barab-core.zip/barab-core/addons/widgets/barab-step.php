<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Step Widget .
 *
 */
class barab_Step extends Widget_Base {

	public function get_name() {
		return 'barabstep';
	}
	public function get_title() {
		return __( 'Step/Process', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		 $this->start_controls_section(
			'section_title_section',
			[
				'label'		 	=> __( 'Steps', 'barab' ),
				'tab' 			=> Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two' ] ); 

		barab_general_fields($this, 'subtitle', 'Section Subtitle', 'TEXTAREA2', 'Our Delicious Pizzas', ['2'] );
		barab_general_fields($this, 'title', 'Section Title', 'TEXTAREA2', 'Our Signature Pizza', ['2'] );
		barab_general_fields($this, 'desc', 'Section Content', 'TEXTAREA', '', ['2'] );

		$repeater = new Repeater();
 
		barab_general_fields($repeater, 'subtitle', 'Subtitle', 'TEXTAREA2', 'Step 01');
		barab_general_fields($repeater, 'title', 'Title', 'TEXTAREA2', 'Fresh Dough, Hand-Stretched');
		barab_general_fields($repeater, 'description', 'Description', 'TEXTAREA', 'Proactively envisioned multimedia based expertisee cross-media growth'); 

		$this->add_control(
			'process_list',
			[
				'label' 		=> __( 'Process Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'Fresh Dough, Hand-Stretched', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['1']
				]
			]
		);

		$repeater = new Repeater();
 
		barab_media_fields($repeater, 'image', 'Choose Image');
		barab_general_fields($repeater, 'subtitle', 'Subtitle', 'TEXTAREA2', '01');
		barab_general_fields($repeater, 'title', 'Title', 'TEXTAREA2', 'Fresh Dough, Hand-Stretched');
		barab_general_fields($repeater, 'description', 'Description', 'TEXTAREA', 'Proactively envisioned multimedia based expertisee cross-media growth'); 

		$this->add_control(
			'process_list2',
			[
				'label' 		=> __( 'Process Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 	=> __( 'Fresh Dough, Hand-Stretched', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['2']
				]
			]
		);

        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------
		barab_common_style_fields( $this, '011', 'Section Subtitle', '{{WRAPPER}} .sub-title', ['2'] );
		barab_common_style_fields( $this, '012', 'Section Title', '{{WRAPPER}} .sec-title', ['2'] );
		barab_common_style_fields( $this, '013', 'Section Description', '{{WRAPPER}} .desc', ['2'] );

		barab_common_style_fields( $this, '10', 'Subtitle', '{{WRAPPER}} .count', [ '1' ] );
		barab_common_style_fields( $this, '11', 'Number', '{{WRAPPER}} .box-number', [ '2' ] );
		barab_common_style_fields( $this, '12', 'Title', '{{WRAPPER}} .box-title', [ '1', '2' ] );
		barab_common_style_fields( $this, '13', 'Description', '{{WRAPPER}} .text', [ '1', '2' ] );

	}

	protected function render() {

	$settings = $this->get_settings_for_display();

		if( $settings['layout_style'] == '1' ){
			echo '<div class="progress-content-wrap gsap-card-animation-wrapper">';
				foreach( $settings['process_list'] as $key => $data ){
					$delay  = number_format(0.2 + ($key * 0.2), 1); 
					echo '<div class="progress-item wow fadeinup" data-wow-delay="'.$delay.'s">';
						if(!empty($data['subtitle'])){
							echo '<h4 class="count">'.esc_html($data['subtitle']).'</h4>';
						}
						if(!empty($data['title'])){
							echo '<h3 class="box-title">'.esc_html($data['title']).'</h3>';
						}
						if(!empty($data['description'])){
							echo '<p class="box-text text">'.esc_html($data['description']).'</p>';
						}
					echo '</div>';
				}
            echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
			echo '<div class="process-sec-2-container-wrap" data-mask-src="'.BARAB_ASSETS.'img/bg/process-sec-2-bg-mask.png">';
                echo '<div class="row gy-4 justify-content-center align-items-center">';
                    echo '<div class="col-xl-5 col-lg-5">';
                        echo '<div class="title-area mb-1 pe-xl-5 me-xl-5">';
						    if(!empty($settings['subtitle'])){
								echo '<span class="sub-title text-anime-style-1">'.esc_html($settings['subtitle']).'</span>';
							}
							if(!empty($settings['title'])){
								echo '<h2 class="sec-title text-anime-style-2 text-white pe-xl-5">'.wp_kses_post($settings['title']).'</h2>';
                        	}
							if(!empty($settings['desc'])){
								echo '<p class="box-text text-anime-style-3 desc">'.wp_kses_post($settings['desc']).'</p>';
                        	}
                        echo '</div>';
                    echo '</div>';
                    echo '<div class="col-xl-7 col-lg-7">';
                        echo '<div class="process-sec-2-bg-inner-wrap" data-mask-src="'.BARAB_ASSETS.'img/bg/process-sec-2-bg-inner.png">';
                            echo '<div class="row gy-40">';
								foreach( $settings['process_list2'] as $key => $data ){
									$delay  = number_format(0.2 + ($key * 0.2), 1); 
									echo '<div class="col-xl-4 col-md-6">';
										echo '<div class="process-box-2 wow fadeinright" data-wow-delay="'.$delay.'s">';
											if($data['image']['url'] ){
												echo '<div class="box-img">';
													echo barab_img_tag( array(
														'url'   => esc_url( $data['image']['url'] ),
													));
												echo '</div>';
											}
											echo '<div class="content">';
												if(!empty($data['subtitle'])){
													echo '<p class="box-number">'.esc_html($data['subtitle']).'</p>';
												}
												if(!empty($data['title'])){
													echo '<h3 class="box-title">'.esc_html($data['title']).'</h3>';
												}
												if(!empty($data['description'])){
													echo '<p class="box-text text">'.esc_html($data['description']).'</p>';
												}
											echo '</div>';
										echo '</div>';
									echo '</div>';
								}
                            echo '</div>';
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
            echo '</div>';

		}
	

	}

}