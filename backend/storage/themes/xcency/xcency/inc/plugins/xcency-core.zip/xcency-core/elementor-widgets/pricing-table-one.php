<?php
namespace Elementor;
class Xcency_Pricing_Table_One_Widget extends Widget_Base {

	public function get_name() {

		return 'xcency_pricing_table_one';
	}

	public function get_title() {
		return esc_html__( 'Pricing Table One', 'xcency-core' );
	}

	public function get_icon() {

		return 'flaticon-pricing';
	}

	public function get_categories() {
		return [ 'xcency_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'monthly_price_options',
			[
				'label' => esc_html__( 'Monthly', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'monthly_button_text',
			[
				'label'       => __( 'Monthly Button Text', 'xcency-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Monthly',
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'monthly_table_title',
			[
				'label'       => __( 'Table Title', 'xcency-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Basic',
			]
		);

		$repeater->add_control(
            'monthly_table_desc',
            [
                'label'       => __( 'Table Description', 'xcency-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'rows'        => 5,
                'default'     => 'Basic features for up to 10 employees with everything you need',
            ]
        );

		$repeater->add_control(
			'monthly_price',
			[
				'label'       => __( 'Price', 'xcency-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => '$250',
			]
		);

		$repeater->add_control(
			'monthly_time_duration_text',
			[
				'label'       => __( 'Time Duration', 'xcency-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => '/ Month',
			]
		);

		$repeater->add_control(
			'monthly_top_right_text',
			[
				'label'       => __( 'Top Right Text', 'xcency-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
			]
		);

		$repeater->add_control(
			'monthly_btn_one_text',
			[
				'label'       => __( 'Button One Text', 'xcency-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Get Started',
			]
		);

		$repeater->add_control(
			'monthly_btn_one_url',
			[
				'label'         => __( 'Button One URL', 'xcency-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'xcency-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$repeater->add_control(
			'monthly_features',
			[
				'label'       => __( 'Features', 'xcency-core' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => '
                    <ul>
                        <li>Unlimited chats & websites</li>
                        <li>Live chat + email + FB Messenger</li>
                        <li>3-year conversations history</li>
                        <li>Engage visitors via visitor list</li>
                        <li>Live Chat Support</li>
                    </ul>
                ',
				'label_block' => true,
			]
		);

		$this->add_control(
			'monthly_tables',
			[
				'label'       => esc_html__('Table List', 'xcency-core'),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'monthly_table_title'        => 'Basic',
						'monthly_table_desc'     => 'Basic features for up to 10 employees with everything you need',
						'monthly_price'              => '$250',
						'monthly_time_duration_text' => '/ Month',
						'monthly_btn_one_text'       => 'Get Started',
						'monthly_btn_two_text'       => 'Start 14 Days Trial',
						'monthly_feature_title' => 'Feature includes:',
						'monthly_features'           => '<ul>
                        <li>Unlimited chats & websites</li>
                        <li>Live chat + email + FB Messenger</li>
                        <li>3-year conversations history</li>
                        <li>Engage visitors via visitor list</li>
                        <li>Live Chat Support</li>
                        </ul>',
					],
				],
				'title_field' => '{{{ monthly_table_title }}}',
			]
		);

		$this->end_controls_section();


		// Yearly

		$this->start_controls_section(
			'yearly_price_options',
			[
				'label' => esc_html__( 'Yearly', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'enable_yearly_table',
			[
				'label'       => esc_html__( 'Enable Yearly Table', 'xcency-core' ),
				'type'        => Controls_Manager::SWITCHER,
				'show_label'  => true,
				'label_block' => false,
				'default'     => 'yes',
				'separator'   => 'before',
			]
		);

		$this->add_control(
			'yearly_button_text',
			[
				'label'       => __( 'Yearly Button Text', 'xcency-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Annualy',
				'condition' => [
					'enable_yearly_table' => 'yes'
				],
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'yearly_table_title',
			[
				'label'       => __( 'Table Title', 'xcency-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Basic',
			]
		);

		$repeater->add_control(
			'yearly_table_desc',
			[
				'label'       => __( 'Table Description', 'xcency-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 5,
				'default'     => 'Basic features for up to 10 employees with everything you need',
			]
		);

		$repeater->add_control(
			'yearly_price',
			[
				'label'       => __( 'Price', 'xcency-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => '$250',
			]
		);

		$repeater->add_control(
			'yearly_time_duration_text',
			[
				'label'       => __( 'Time Duration', 'xcency-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => '/ Year',
			]
		);

		$repeater->add_control(
			'yearly_top_right_text',
			[
				'label'       => __( 'Top Right Text', 'xcency-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
			]
		);

		$repeater->add_control(
			'yearly_btn_one_text',
			[
				'label'       => __( 'Button One Text', 'xcency-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Get Started',
			]
		);

		$repeater->add_control(
			'yearly_btn_one_url',
			[
				'label'         => __( 'Button One URL', 'xcency-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'xcency-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$repeater->add_control(
			'yearly_features',
			[
				'label'       => __( 'Features', 'xcency-core' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => '
                    <ul>
                        <li>Unlimited chats & websites</li>
                        <li>Live chat + email + FB Messenger</li>
                        <li>3-year conversations history</li>
                        <li>Engage visitors via visitor list</li>
                        <li>Live Chat Support</li>
                    </ul>
                ',
				'label_block' => true,
			]
		);

		$this->add_control(
			'yearly_tables',
			[
				'label'       => esc_html__('Table List', 'xcency-core'),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'yearly_table_title'        => 'Basic',
						'yearly_table_subtitle'     => 'Best for personal use',
						'yearly_price'              => '$250',
						'yearly_time_duration_text' => '/ Year',
						'yearly_btn_one_text'       => 'Get Started',
						'yearly_btn_two_text'       => 'Start 14 Days Trial',
						'yearly_feature_title' => 'Feature includes:',
						'yearly_features'           => '<ul>
                        <li>Unlimited chats & websites</li>
                        <li>Live chat + email + FB Messenger</li>
                        <li>3-year conversations history</li>
                        <li>Engage visitors via visitor list</li>
                        <li>Live Chat Support</li>
                    </ul>',
					],
				],
				'title_field' => '{{{ yearly_table_title }}}',

				'condition' => [
					'enable_yearly_table' => 'yes'
				],
			]
		);

		$this->end_controls_section();

		// Start Button section
		$this->start_controls_section(
			'xcency_button_style_options',
			[
				'label' => esc_html__('Top Button Style', 'xcency-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
				'conditions' => [
					'relation' => 'and',
					'terms' => [
						[
							'name' => 'monthly_button_text',
							'operator' => '!=',
							'value' => [
								'',
							],
						],
						[
							'name' => 'enable_yearly_table',
							'operator' => '==',
							'value' => [
								'yes',
							],
						],
					],
				],
			]
		);

        $this->add_responsive_control(
            'button_align',
            [
                'label'       => esc_html__('Button Align', 'xcency-core'),
                'type'        => Controls_Manager::CHOOSE,
                'label_block' => false,

                'options' => [
                    'left' => [
                        'title' => __('Left', 'xcency-core'),
                        'icon'  => 'eicon-text-align-left',
                    ],

                    'center' => [
                        'title' => __('Center', 'xcency-core'),
                        'icon'  => 'eicon-text-align-center',
                    ],

                    'right' => [
                        'title' => __('Right', 'xcency-core'),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],

                'devices' => ['desktop', 'tablet', 'mobile'],

                'selectors' => [
                    '{{WRAPPER}} .xcency-pricing-one-plan-switcher-wrapper' => 'text-align: {{VALUE}};',
                ],

            ]
        );

        $this->add_responsive_control(
            'button_and_table_space',
            [
                'label' => esc_html__( 'Space Between Button And Table', 'xcency-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 30,
                        'max' => 100,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],

                'selectors' => [
                    '{{WRAPPER}} .xcency-pricing-one-plan-switcher-wrapper' => 'margin-bottom: {{SIZE}}px;',
                ],
            ]
        );

		$this->add_control(
			'button_area_bg',
			[
				'label'     => esc_html__('Button Area Background', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .xcency-pricing-one-plan-switcher' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'switcher_bg',
			[
				'label'     => esc_html__('Switcher Background', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .xcency-pricing-one-plan-switcher ul li.xcency-billing-switcher' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'switcher_btn_color',
			[
				'label'     => esc_html__('Switcher Color', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .xcency-pricing-one-plan-switcher ul li.xcency-billing-switcher span' => 'background-color: {{VALUE}};',
				],
			]
		);

        $this->add_control(
            'switcher_btn_text_color',
            [
                'label'       => esc_html__('Text Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .xcency-pricing-one-plan-switcher ul li' => 'color: {{VALUE}};',
                ],
            ]
        );

		$this->end_controls_section();// End Button section


		// Table Style
		$this->start_controls_section(
			'xcency_table_style_options',
			[
				'label' => esc_html__('Table Style', 'xcency-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs('xcency_table_style_tabs');

		//Default style tab start
		$this->start_controls_tab(
			'xcency_table_style_default',
			[
				'label' => esc_html__('Default', 'xcency-core'),
			]
		);

        $this->add_control(
            'default_table_bg_color',
            [
                'label'       => esc_html__('Background Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .pricing-one-table-content' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'default_title_color',
            [
                'label'       => esc_html__('Title Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .pricing-one-table-title' => 'color: {{VALUE}};',
                ],
            ]
        );

		$this->add_control(
			'default_price_color',
			[
				'label'       => esc_html__('Price Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .pricing-one-price' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'default_list_icon_color',
			[
				'label'       => esc_html__('List Icon Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .pricing-three-features-list li:before' => 'color: {{VALUE}};',
				],
			]
		);


		$this->end_controls_tab();//Default style tab end

		//Hover/active style tab start
		$this->start_controls_tab(
			'xcency_table_style_active',
			[
				'label' => esc_html__('Hover', 'xcency-core'),
			]
		);

		$this->add_control(
			'hover_table_bg_color',
			[
				'label'       => esc_html__('Background Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .pricing-one-table-content:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'hover_title_color',
			[
				'label'       => esc_html__('Title Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .pricing-one-table-content:hover .pricing-one-table-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'hover_price_color',
			[
				'label'       => esc_html__('Price Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .pricing-one-table-content:hover .pricing-one-price' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'hover_list_icon_color',
			[
				'label'       => esc_html__('List Icon Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .pricing-one-table-content:hover .pricing-three-features-list li:before' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tabs();//Hover style tab end

		$this->end_controls_section();// End Button section

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$xcency_tab_id = rand(10, 10000);
		?>

        <div class="xcency-pricing-one-main-wrapper">
            
            <?php if ($settings['monthly_button_text'] && $settings['yearly_button_text']) :?>
            <div class="xcency-pricing-one-plan-switcher-wrapper">
                <div class="xcency-pricing-one-plan-switcher">
                    <ul>
                        <li><?php echo $settings['monthly_button_text'];?></li>
                        <li class="xcency-billing-switcher monthly"><span></span></li>
                        <li><?php echo $settings['yearly_button_text'];?></li>
                    </ul>
                </div>
            </div>
            <?php endif; ?>
            <div class="xcency-pricing-one-table-wrapper xcency-pricing-one-monthly-table-wrapper">
                <div class="row">
		            <?php
		            if ($settings['monthly_tables']) {
			            foreach ($settings['monthly_tables'] as $monthly_table) {
				            ?>
                            <div class="col-xl-4 col-lg-6 col-md-6">
                                <div class="pricing-one-table-content">
						            <?php if ($monthly_table['monthly_top_right_text']) :?>
                                        <div class="pricing-one-top-right-text"><?php echo $monthly_table['monthly_top_right_text'];?></div>
						            <?php endif; ?>



                                    <h6 class="pricing-one-table-title"><?php echo $monthly_table['monthly_table_title']?></h6>

                                    <div class="pricing-one-price-time-duration">
                                        <span class="pricing-one-price">
                                            <?php echo $monthly_table['monthly_price']?>
                                        </span>

                                        <span class="pricing-one-duration">
                                            <?php echo $monthly_table['monthly_time_duration_text']?>
                                        </span>
                                    </div>

                                    <div class="pricing-one-table-desc">
		                                <?php echo $monthly_table['monthly_table_desc']?>
                                    </div>



                                    <div class="xcency-pricing-one-button-wrapper">
                                        <a class="xcency-button pricing-one-btn-one" href="<?php echo $monthly_table['monthly_btn_one_url']['url']; ?>"><?php echo $monthly_table['monthly_btn_one_text'];?></a>
                                    </div>

                                    <div class="pricing-three-features-list">
							            <?php echo $monthly_table['monthly_features'];?>
                                    </div>
                                </div>
                            </div>
				            <?php
			            }
		            }
		            ?>
                </div>
            </div>

            <?php if ($settings['enable_yearly_table'] == 'yes') : ?>
            <div class="xcency-pricing-one-table-wrapper xcency-pricing-one-yearly-table-wrapper">
                <div class="row">
		            <?php
		            if ($settings['yearly_tables']) {
			            foreach ($settings['yearly_tables'] as $yearly_table) {
				            ?>
                            <div class="col-xl-4 col-lg-6 col-md-6">
                                <div class="pricing-one-table-content">
						            <?php if ($yearly_table['yearly_top_right_text']) :?>
                                        <div class="pricing-one-top-right-text"><?php echo $yearly_table['yearly_top_right_text'];?></div>
						            <?php endif; ?>

                                    <h6 class="pricing-one-table-title"><?php echo $yearly_table['yearly_table_title'];?></h6>

                                    <div class="pricing-one-price-time-duration">
                                        <span class="pricing-one-price">
                                            <?php echo $yearly_table['yearly_price']?>
                                        </span>

                                        <span class="pricing-one-duration">
                                            <?php echo $yearly_table['yearly_time_duration_text']?>
                                        </span>
                                    </div>


                                    <div class="pricing-one-table-desc">
		                                <?php echo $yearly_table['yearly_table_desc']?>
                                    </div>

                                    <div class="xcency-pricing-one-button-wrapper">
                                        <a class="xcency-button pricing-one-btn-one" href="<?php echo $yearly_table['yearly_btn_one_url']['url']; ?>"><?php echo $yearly_table['yearly_btn_one_text'];?></a>
                                    </div>

                                    <div class="pricing-three-features-list">
							            <?php echo $yearly_table['yearly_features'];?>
                                    </div>
                                </div>
                            </div>
				            <?php
			            }
		            }
		            ?>
                </div>
            </div>
            <?php endif; ?>

            <script>
                jQuery(document).ready(function ($) {
                    function togglePricingTable() {
                        if ($('.xcency-billing-switcher').hasClass('yearly')) {
                            $('.xcency-pricing-one-monthly-table-wrapper').removeClass('show');
                            $('.xcency-pricing-one-yearly-table-wrapper').addClass('show');
                        } else {
                            $('.xcency-pricing-one-yearly-table-wrapper').removeClass('show');
                            $('.xcency-pricing-one-monthly-table-wrapper').addClass('show');
                        }
                    }

                    // Initial toggle based on the initial class
                    togglePricingTable();

                    $('.xcency-billing-switcher').on('click', function(){
                        $(this).toggleClass('monthly yearly');
                        togglePricingTable();
                    });

                });
            </script>
        </div>
		<?php
	}
}

Plugin::instance()->widgets_manager->register( new Xcency_Pricing_Table_One_Widget );