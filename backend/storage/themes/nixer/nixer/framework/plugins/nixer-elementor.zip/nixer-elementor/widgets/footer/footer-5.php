<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsFooterSection5 extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-footer-5';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Footer Section 5', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-footer';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-footer' ];
	}

	public function get_keywords() {
		return [ 'footer5', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_footer_section',
			[
				'label' => esc_html__( 'Footer Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'bg_color',
			[
				'label' 		=> esc_html__( 'Background Color (Default: #FFFFFF)', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::COLOR,
				'default'		=> '#FFFFF',
			]
		);
		$this->add_control(
			'ft_copyright',
			[
				'label'       => __( 'Footer Copyright', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your text footer copyright', 'bdevs-elementor' ),
				'default'     => __( '© 2025 All Rights Reserved.', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'switch_social',
			[
				'label'   		=> esc_html__( 'Switch Show/Hide Social Footer', 'bdevs-elementor' ),
				'type'    		=> Controls_Manager::SWITCHER,
				'label_on' 		=> esc_html__( 'Show', 'bdevs-elementor' ),
				'label_off' 	=> esc_html__( 'Hide', 'bdevs-elementor' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);
		$rp_social = new \Elementor\Repeater();
		$rp_social->add_control(
			'text_sc_item',
			[
				'label' 		=> esc_html__( 'Text Social Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Text Social' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_social->add_control(
			'link_sc_item',
			[
				'label' 		=> esc_html__( 'Link Social Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '#' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'tab_sc',
			[
				'label' 		=> esc_html__( 'List Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $rp_social->get_controls(),
				'default' 		=> [
					[
					],
				],
				'title_field' 	=> '{{{ text_sc_item }}}',
			]
		);
		$this->end_controls_section();




		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>

<footer class="tp-footer-8-ptb pb-25" data-bg-color="<?php echo wp_kses_post($settings['bg_color']); ?>">
	<div class="container container-1720">
		<div class="row align-items-center">
			<?php if (!empty($settings['switch_social'])): ?>
				<div class="col-md-6">
					<div class="tp-footer-8-social d-flex align-items-center">
						<?php
						foreach ($settings['tab_sc'] as $items) :
						?>
							<?php if (!empty($items['link_sc_item']) && !empty($items['text_sc_item'])): ?>
								<a href="<?php echo wp_kses_post($items['link_sc_item']); ?>">
									<?php echo wp_kses_post($items['text_sc_item']); ?>
								</a>
							<?php endif ?>
						<?php endforeach; ?>
					</div>
				</div>
			<?php endif ?>
			<?php if (!empty($settings['switch_social'])) { ?>
				<div class="col-md-6">
					<div class="tp-footer-8-copyright text-start text-md-end">
			<?php } else { ?>
				<div class="col-md-12 text-center">
					<div class="tp-footer-8-copyright">
			<?php } ?>
						<?php if (!empty($settings['ft_copyright'])): ?>
							<p><?php echo wp_kses_post($settings['ft_copyright']); ?></p>
						<?php endif ?>
					</div>
				</div>
		</div>
	</div>
</footer>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-bg-color]").each(function () {
			jQuery(this).css("background-color", jQuery(this).attr("data-bg-color"));
		});
	</script>
<?php } ?>

<?php
}

}