<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Contact Form Widget .
 *
 */
class barab_Contact_Form extends Widget_Base {

	public function get_name() {
		return 'barabcontactform';
	}
	public function get_title() {
		return __( 'Contact Form', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	public function get_as_contact_form(){
        if ( ! class_exists( 'WPCF7' ) ) {
            return;
        }
        $as_cfa         = array();
        $as_cf_args     = array( 'posts_per_page' => -1, 'post_type'=> 'wpcf7_contact_form' );
        $as_forms       = get_posts( $as_cf_args );
        $as_cfa         = ['0' => esc_html__( 'Select Form', 'barab' ) ];
        if( $as_forms ){
            foreach ( $as_forms as $as_form ){
                $as_cfa[$as_form->ID] = $as_form->post_title;
            }
        }else{
            $as_cfa[ esc_html__( 'No contact form found', 'barab' ) ] = 0;
        }
        return $as_cfa;
    }

	protected function register_controls() {

		$this->start_controls_section(
			'contact_form_section',
			[
				'label' 	=> __( 'Contact Form', 'barab' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two', 'Style Three', 'Style Four', 'Style Five' ] );  

		barab_general_fields($this, 'big_title', 'Big Title', 'TEXTAREA', 'Reach out to us', ['4'] );

		barab_general_fields($this, 'subtitle', 'Section Subtitle', 'TEXTAREA2', 'Reservation table', ['1', '4'] );
		barab_general_fields($this, 'title', 'Section Title', 'TEXTAREA', 'Contact Us', ['1', '2', '4', '5'] );
		barab_general_fields($this, 'desc', 'Section Description', 'TEXTAREA', '*reservations recommended', ['1', '4', '5'] );

		$this->add_control(
            'barab_select_contact_form',
            [
                'label'   => esc_html__( 'Select Form', 'barab' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '0',
                'options' => $this->get_as_contact_form(),
            ]
        );

		barab_general_fields($this, 'exta', 'Text', 'TEXTAREA2', '*Powered by Open Table', ['1', '3'] );
		

		barab_media_fields( $this, 'image1', 'Choose Image', ['1', '4', '5'] );
		barab_media_fields( $this, 'image2', 'Choose Image', ['4'] );
		barab_media_fields( $this, 'shape1', 'Choose Shape', ['1', '5'] );

		$this->add_control( 
			'barab_tab_builder_option',
			[
				'label'     => __( 'Tab Name', 'barab' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => $this->barab_tab_builder_choose_option(),
				'default'	=> ''
			]
		);

		barab_general_fields($this, 'subtitle2', 'Section Subtitle 2', 'TEXTAREA2', 'Reservation table', ['4'] );
		barab_general_fields($this, 'title2', 'Section Title 2', 'TEXTAREA2', 'Contact Us', ['4', '5'] );
		barab_general_fields($this, 'desc2', 'Section Description 2', 'TEXTAREA', '*reservations recommended', ['4', '5'] );
		barab_general_fields($this, 'desc22', 'Section Content', 'TEXTAREA', '*reservations recommended', ['4', '5'] );

		barab_switcher_fields($this, 'show_social', 'Show Social?', ['4', '5']);
		barab_social_fields( $this, 'social_icon_list', 'Social Media', ['4', '5'] ); 

		barab_general_fields($this, 'button_text', 'Button Text', 'TEXT', 'Locate Our Restaurant', ['5']);
		barab_url_fields($this, 'button_url', 'Button URL', ['5']);

        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------

		barab_common_style_fields( $this, '01', 'Section Subtitle', '{{WRAPPER}} .sub-title', ['1'] );
		barab_common_style_fields( $this, '011', 'Section Subtitle', '{{WRAPPER}} .subtitle4.v2', ['4'], '--theme-color5' );
		barab_common_style_fields( $this, '02', 'Section Title', '{{WRAPPER}} .sec-title', ['1', '4', '5'] );
		barab_common_style_fields( $this, '03', 'Section Description', '{{WRAPPER}} .box-text', ['1', '4', '5'] );
		barab_common_style_fields( $this, '04', 'Text', '{{WRAPPER}} .bottom-text', ['1', '3'] );

		barab_common_style_fields( $this, '051', 'Section Subtitle', '{{WRAPPER}} .reservation-thumb .subtitle4.v2', ['4'], '--theme-color5' );
		barab_common_style_fields( $this, '052', 'Section Title', '{{WRAPPER}} .reservation-thumb .sec-title', ['4', '5'] );
		barab_common_style_fields( $this, '053', 'Section Description', '{{WRAPPER}} .reservation-thumb .box-text', ['4', '5'] );

		barab_common_style_fields( $this, '10', 'Text', '{{WRAPPER}} .title', ['2'] );

	}

	public function barab_tab_builder_choose_option(){

		$barab_post_query = new WP_Query( array(
			'post_type'				=> 'barab_tab_builder',
			'posts_per_page'	    => -1,
		) );

		$barab_tab_builder_title = array();
		$barab_tab_builder_title[''] = __( 'Select a Tab','barab');

		while( $barab_post_query->have_posts() ) {
			$barab_post_query->the_post();
			$barab_tab_builder_title[ get_the_ID() ] =  get_the_title();
		}
		wp_reset_postdata();

		return $barab_tab_builder_title;

	}

	protected function render() {

	    $settings = $this->get_settings_for_display();

		if( $settings['layout_style'] == '1' ){
			echo '<div class="reservation-table-area space overflow-hidden">';
				echo '<div class="res-2-shape  d-lg-block d-none"></div>';
				if(!empty($settings['shape1']['url'])){
					echo '<div class="shape-mockup jump-reverse d-xl-block d-none" data-bottom="7%" data-right="2%">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['shape1']['url'] ),
						));
					echo '</div>';
				}
				echo '<div class="container">';
					echo '<div class="row gx-80 gy-30 align-items-center gsap-card-animation-wrapper">';
						echo '<div class="col-xl-7 col-lg-7 col-md-7">';
							if(!empty($settings['image1']['url'])){
								echo '<div class="reservation-thumb wow fadeinleft">';
									echo barab_img_tag( array(
										'url'   => esc_url( $settings['image1']['url'] ),
									));
								echo '</div>';
							}
						echo '</div>';
						echo '<div class="col-xl-5 col-lg-5 col-md-5">';
							echo '<div class="reservation-thumb">';
								echo '<div class="order-online-content pe-xl-5 me-xl-4">';
									echo '<div class="title-area mb-40">';
										if(!empty($settings['subtitle'])){
											echo '<span class="sub-title before-none style-2 text-anime-style-1">'.esc_html($settings['subtitle']).'</span>';
										}
										if(!empty($settings['title'])){
											echo '<h2 class="sec-title text-anime-style-2">'.wp_kses_post($settings['title']).'</h2>';
										}
										if(!empty($settings['desc'])){
											echo '<p class="box-text text-anime-style-3">'.wp_kses_post($settings['desc']).'</p>';
										}
									echo '</div>';
									echo '<div>';
										echo '<div class="res-form-wrap me-xl-5 pe-xl-5 wow fadeinup" data-wow-delay=".4s">';
											if( !empty($settings['barab_select_contact_form']) ){
												echo do_shortcode( '[contact-form-7  id="'.$settings['barab_select_contact_form'].'"]' ); 
											}else{
												echo '<div class="alert alert-warning"><p class="m-0">' . __('Please Select contact form.', 'barab' ). '</p></div>';
											}
											if(!empty($settings['exta'])){
												echo '<p class="bottom-text">'.wp_kses_post($settings['exta']).'</p>';
											}
										echo '</div>';
									echo '</div>';
								echo '</div>';
							echo '</div>';
						echo '</div>';
					echo '</div>';
				echo '</div>';
			echo '</div>';

		}elseif( $settings['layout_style'] == '2' ){
			echo '<div class="contact-form-v2 contact-page-form">';
				if(!empty($settings['title'])){
					echo '<h2 class="title mt-n3 fw-semibold mb-30">'.wp_kses_post($settings['title']).'</h2>';
				}
				echo '<div class="contact-form ajax-contact">';
					if( !empty($settings['barab_select_contact_form']) ){
						echo do_shortcode( '[contact-form-7  id="'.$settings['barab_select_contact_form'].'"]' ); 
					}else{
						echo '<div class="alert alert-warning"><p class="m-0">' . __('Please Select contact form.', 'barab' ). '</p></div>';
					}
				echo '</div>';
			echo '</div>';
			
		}elseif( $settings['layout_style'] == '3' ){
			echo '<div class="res-form-wrap style-2 me-xl-5 pe-xl-5 wow fadeinup" data-wow-delay=".4s">';
				if( !empty($settings['barab_select_contact_form']) ){
					echo do_shortcode( '[contact-form-7  id="'.$settings['barab_select_contact_form'].'"]' ); 
				}else{
					echo '<div class="alert alert-warning"><p class="m-0">' . __('Please Select contact form.', 'barab' ). '</p></div>';
				}
				if(!empty($settings['exta'])){
					echo '<p class="bottom-text">'.wp_kses_post($settings['exta']).'</p>';
				}
			echo '</div>';

		}elseif( $settings['layout_style'] == '4' ){
			if(!empty($settings['big_title'])){
				echo '<div class="row gy-4">';
					echo '<div class="col-12">';
						echo '<div class="big-title3-wrap style2 reservation-title-3">';
							echo '<h4 class="big-title3-title text-anime-style-2">'.esc_html($settings['big_title']).'</h4>';
						echo '</div>';
					echo '</div>';
				echo '</div>';
			}
            echo '<div class="row gx-60 gy-40 align-items-end justify-content-center">';
                echo '<div class="col-xl-4">';
                    echo '<div class="order-online-content style3">';
                        echo '<div class="title-area style3 mb-60">';
							if(!empty($settings['subtitle'])){
								echo '<span class="subtitle4  text-anime-style-1">'.esc_html($settings['subtitle']).'</span>';
							}
							if(!empty($settings['title'])){
								echo '<h2 class="sec-title text-anime-style-2">'.wp_kses_post($settings['title']).'</h2>';
							}
							if(!empty($settings['desc'])){
								echo '<p class="box-text v2 text-anime-style-3">'.wp_kses_post($settings['desc']).'</p>';
							}
                        echo '</div>';
                        echo '<div> ';
                            echo '<div class="res-2-form-wrap style2 pe-xxl-4 wow fadeinup" data-wow-delay=".4s">';
								if( !empty($settings['barab_select_contact_form']) ){
									echo do_shortcode( '[contact-form-7  id="'.$settings['barab_select_contact_form'].'"]' ); 
								}else{
									echo '<div class="alert alert-warning"><p class="m-0">' . __('Please Select contact form.', 'barab' ). '</p></div>';
								}
                            echo '</div>';
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
                echo '<div class="col-xl-4">';
					if(!empty($settings['image1']['url'])){
						echo '<div class="reservation-thumb3-middle global-img"">';
							echo barab_img_tag( array(
								'url'   => esc_url( $settings['image1']['url'] ),
							));
						echo '</div>';
					}
                echo '</div>';
                echo '<div class="col-xl-4">';
                    echo '<div class="reservation-thumb">';
                        echo '<div class="title-area style3 text-center mb-10">';
							if(!empty($settings['subtitle2'])){
								echo '<span class="subtitle4  text-anime-style-1">'.esc_html($settings['subtitle2']).'</span>';
							}
							if(!empty($settings['title2'])){
								echo '<h2 class="sec-title text-anime-style-2">'.wp_kses_post($settings['title2']).'</h2>';
							}
                        echo '</div>';
                        echo '<div class="location-content style2 mb-5">';
							if(!empty($settings['desc2'])){
								echo '<p class="box-text pe-xxl-5 ps-xxl-5 text-anime-style-3">'.wp_kses_post($settings['desc2']).'</p>';
							}
							if(!empty($settings['desc22'])){
								echo '<div class="line"></div>';
								echo '<div class="opening ow fadeinup" data-wow-delay=".3s">';
									echo wp_kses_post($settings['desc22']);
								echo '</div>';
							}
							if(!empty($settings['show_social'])){
								echo '<div class="th-social ow fadeinup" data-wow-delay=".5s">';
									foreach ( $settings['social_icon_list'] as $index => $social_icon ) {
										$link_key = 'social_icon_list_' . $index . '_icon_link';

										if ( ! empty( $social_icon['icon_link']['url'] ) ) {
											$this->add_link_attributes( $link_key, $social_icon['icon_link'] );

											echo '<a ' . $this->get_render_attribute_string( $link_key ) . '>';
											\Elementor\Icons_Manager::render_icon( $social_icon['social_icon'], [ 'aria-hidden' => 'true' ] );
											echo '</a>';
										}
									}
								echo '</div>';
							}
                        echo '</div>';
						if(!empty($settings['image2']['url'])){
							echo '<div class="reservation-3-right global-img"">';
								echo barab_img_tag( array(
									'url'   => esc_url( $settings['image2']['url'] ),
								));
							echo '</div>';
						}
                    echo '</div>';
                echo '</div>';
            echo '</div>';

		}elseif( $settings['layout_style'] == '5' ){
			echo '<section class="reservation-table-area-2 overflow-hidden">';
				if(!empty($settings['shape1']['url'])){
					echo '<div class="reservation-2-shape">';
						echo barab_img_tag( array(
							'url'   => esc_url( $settings['shape1']['url'] ),
						));
					echo '</div>';
				}
				echo '<div class="reservation2-wrapper">';
					echo '<div class="container">';
						echo '<div class="row gx-80 gy-30 align-items-center justify-content-center">';
							echo '<div class="col-xl-4">';
								echo '<div class="order-online-content">';
									echo '<div class="title-area style3 mb-60">';
										if(!empty($settings['title'])){
											echo '<h2 class="sec-title text-anime-style-2">'.wp_kses_post($settings['title']).'</h2>';
										}
										if(!empty($settings['desc'])){
											echo '<p class="box-text v2 text-anime-style-3">'.wp_kses_post($settings['desc']).'</p>';
										}
									echo '</div>';
									echo '<div>';
										echo '<div class="res-2-form-wrap me-xxl-5 pe-xxl-5 wow fadeinup" data-wow-delay=".4s">';
											if( !empty($settings['barab_select_contact_form']) ){
												echo do_shortcode( '[contact-form-7  id="'.$settings['barab_select_contact_form'].'"]' ); 
											}else{
												echo '<div class="alert alert-warning"><p class="m-0">' . __('Please Select contact form.', 'barab' ). '</p></div>';
											}
										echo '</div>';
									echo '</div>';
								echo '</div>';
							echo '</div>';
							echo '<div class="col-xl-4">';
								if(!empty($settings['image1']['url'])){
									echo '<div class="reservation-thumb-top-2-1">';
										echo barab_img_tag( array(
											'url'   => esc_url( $settings['image1']['url'] ),
										));
									echo '</div>';
								}
								echo '<div class="reservation2-map">';
									$elementor = \Elementor\Plugin::instance();
									if( ! empty( $settings['barab_tab_builder_option'] ) ){
										echo $elementor->frontend->get_builder_content_for_display( $settings['barab_tab_builder_option'] );
									}
								echo '</div>';
								if(!empty($settings['button_text'])){
									echo '<a '.barab_link_attrs($settings['button_url']).' class="th-btn style6 resr-2-btn">'.wp_kses_post( $settings['button_text'] ).'</a>';
								}
							echo '</div>';
							echo '<div class="col-xl-4">';
								echo '<div class="reservation-thumb">';
									if(!empty($settings['title2'])){
										echo '<div class="title-area style3 text-center mb-10">';
											echo '<h2 class="sec-title text-anime-style-2">'.wp_kses_post($settings['title2']).'</h2>';
										echo '</div>';
									}
									echo '<div class="location-content style2">';
										if(!empty($settings['desc2'])){
											echo '<p class="box-text pe-xxl-5 ps-xxl-5 text-anime-style-3">'.wp_kses_post($settings['desc2']).'</p>';
										}
										if(!empty($settings['desc22'])){
											echo '<div class="line"></div>';
											echo '<div class="opening ow fadeinup" data-wow-delay=".3s">';
												echo wp_kses_post($settings['desc22']);
											echo '</div>';
										}
										if(!empty($settings['show_social'])){
											echo '<div class="th-social ow fadeinup" data-wow-delay=".5s">';
												foreach ( $settings['social_icon_list'] as $index => $social_icon ) {
													$link_key = 'social_icon_list_' . $index . '_icon_link';

													if ( ! empty( $social_icon['icon_link']['url'] ) ) {
														$this->add_link_attributes( $link_key, $social_icon['icon_link'] );

														echo '<a ' . $this->get_render_attribute_string( $link_key ) . '>';
														\Elementor\Icons_Manager::render_icon( $social_icon['social_icon'], [ 'aria-hidden' => 'true' ] );
														echo '</a>';
													}
												}
											echo '</div>';
										}
									echo '</div>';
								echo '</div>';
							echo '</div>';
						echo '</div>';
					echo '</div>';
				echo '</div>';
			echo '</section>';

		}
		

	}

}