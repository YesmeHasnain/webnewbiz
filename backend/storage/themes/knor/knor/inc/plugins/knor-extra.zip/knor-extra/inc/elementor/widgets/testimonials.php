<?php

/**
 * Elementor Widget
 * @package Knor
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_testimonials_one extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'theme-testimonial-onee';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Testimonials V1', 'knor-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'knor_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {


        //Content tab start
        $this->start_controls_section(
            'theme_testimonial_options',
            [
                'label' => esc_html__( 'Testimonials', 'restlycore' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );


    
        $this->add_control(
            'testimonial_layout',
            [
                'type' => \Elementor\Controls_Manager::SELECT,
                'label' => esc_html__( 'Select Testimonial Layout', 'textdomain' ),
                'options' => [
                    '1' => esc_html__( 'One', 'textdomain' ),
                    '2' => esc_html__( 'two', 'textdomain' ),
                ],
                'default' => '1',
            ]
        );

        $this->add_control(
            'testimonial_quote',
            [
                'label' => esc_html__( 'Quote Icon', 'restlycore' ),
                'type' => \Elementor\Controls_Manager::ICONS,

            ]
        );


        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'testimonial_reviewer_img',
            [
                'label' => __( 'Choose Reviewer Image', 'restlycore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'testimonial_brand_img',
            [
                'label' => __( 'Choose Brand Image', 'restlycore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        
        
        $repeater->add_control(
            'testimonial_title',
            [
                'label' => esc_html__( 'Title', 'restlycore' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Rodney J. Sabo', 'restlycore' ),
                'placeholder' => esc_html__( 'Type your title here', 'restlycore' ),
            ]
        );
        
        $repeater->add_control(
            'testimonial_position',
            [
                'label' => esc_html__( 'Position', 'restlycore' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Design Lead', 'restlycore' ),
                'placeholder' => esc_html__( 'Type your title here', 'restlycore' ),
            ]
        );
        
        $repeater->add_control(
            'testimonial_description',
            [
                'label' => esc_html__( 'Description', 'restlycore' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation','restlycore')
            ]
        );

        $repeater->add_control( 'rating', [
            'label'   => __( 'Rating Number', 'quiety-core' ),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'default' => '50',
            'options' => [
                '10' => __( '1 Star', 'quiety-core' ),
                '20' => __( '2 Star', 'quiety-core' ),
                '30' => __( '3 Star', 'quiety-core' ),
                '40' => __( '4 Star', 'quiety-core' ),
                '50' => __( '5 Star', 'quiety-core' ),
            ],
        ] );

        
        $this->add_control(
            'theme_testimonials_block',
            [
                'label'   => esc_html__( 'Testimonial Item', 'restlycore' ),
                'type'    => \Elementor\Controls_Manager::REPEATER,
                'fields'  => $repeater->get_controls(),
                'default' => [
                    [
                        'testimonial_title' => __('Rodney J. Sabo','restlycore'),
                        'testimonial_position' => __('Design Lead','restlycore'),
                        'testimonial_description' => __('Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation','restlycore')
                    ],
                ],
            ]
        );

        
        $this->end_controls_section();


        $this->start_controls_section(
            'testimonial_slide_options',
            [
                'label' => esc_html__( 'Testimonial Slide Options', 'restlycore' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'testimonial_slide_enable',
            [
                'label' => esc_html__( 'Enable Slide', 'restlycore' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'restlycore' ),
                'label_off' => esc_html__( 'Hide', 'restlycore' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'testimonial_column_number',
            [
                'type' => \Elementor\Controls_Manager::SELECT,
                'label' => esc_html__( 'Testimonial Column', 'textdomain' ),
                'options' => [
                    '1' => esc_html__( '1 Column', 'textdomain' ),
                    '2' => esc_html__( '2 Columns', 'textdomain' ),
                    '3' => esc_html__( '3 Columns', 'textdomain' ),
                    '4' => esc_html__( '4 Columns', 'textdomain' ),
                    '6' => esc_html__( '6 Columns', 'textdomain' ),
                ],
                'default' => '2',
            ]
        );


        $this->add_control(
            'testimonial_loop',
            [
                'label'        => esc_html__( 'Enable Loop ', 'restlycore' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'On', 'restlycore' ),
                'label_off'    => esc_html__( 'Off', 'restlycore' ),
                'return_value' => 'yes',
                'default'      => 'no',
                'condition'    => [
                    'testimonial_slide_enable' => 'yes',
                ],
            ]
        );


        $this->add_control(
            'testimonial_speed',
            [
                'label'     => esc_html__( 'Slide Speed', 'restlycore' ),
                'type'      => \Elementor\Controls_Manager::NUMBER,
                'min'       => 500,
                'max'       => 8000,
                'step'      => 10,
                'default'   => 4000,
                'condition' => array(
                    'testimonial_slide_enable' => 'yes',
                    'testimonial_loop'  => 'yes',

                ),
            ]
        );


        $this->add_control(
            'testimonial_auto_loop',
            [
                'label'        => esc_html__( 'Enable Auto Loop ', 'restlycore' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'On', 'restlycore' ),
                'label_off'    => esc_html__( 'Off', 'restlycore' ),
                'return_value' => 'yes',
                'default'      => 'no',
                'condition'    => [
                    'testimonial_slide_enable' => 'yes',
                    'testimonial_loop' => 'yes',
                ],
            ]
        );


        $this->add_control(
            'testimonial_auto_speed',
            [
                'label'     => esc_html__( 'Slide auto Speed', 'restlycore' ),
                'type'      => \Elementor\Controls_Manager::NUMBER,
                'min'       => 500,
                'max'       => 8000,
                'step'      => 50,
                'default'   => 3000,
                'condition' => array(
                    'testimonial_auto_loop'    => 'yes',
                    'testimonial_loop'         => 'yes',
                    'testimonial_slide_enable' => 'yes',
                ),
            ]
        );


        $this->add_control(
            'testimonial_dot_enable',
            [
                'label'        => esc_html__( 'Enable Dots ', 'restlycore' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'On', 'restlycore' ),
                'label_off'    => esc_html__( 'Off', 'restlycore' ),
                'return_value' => 'yes',
                'default'      => 'no',
                'condition'    => [
                    'testimonial_slide_enable' => 'yes',
                ],
            ]
        );


        $this->end_controls_section();


        $this->start_controls_section(
            'testimonial_box_style_options',
            [
                'label' => esc_html__( 'Testimonial Box Styling', 'restlycore' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'testimonial_box_align',
            [
                'label' => __( 'Alignment', 'restlycore' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'restlycore' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'restlycore' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'restlycore' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'default' => 'left',
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .theme-testimonial-item' => 'text-align: {{VALUE}}',
                ],
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'testimonial_box_shadow',
                'label' => esc_html__( 'Box Shadow', 'restlycore' ),
                'selector' => '{{WRAPPER}} .theme-testimonial-item',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'testimonial_box_border',
                'label' => esc_html__( 'Border', 'restlycore' ),
                'selector' => '{{WRAPPER}} .theme-testimonial-item',
            ]
        );

        $this->add_responsive_control(
            'testimonial_box_radius',
            [
                'label' => esc_html__( 'Border Radius', 'restlycore' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 5,
                ],
                'selectors' => [
                    '{{WRAPPER}} .theme-testimonial-item' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );


        $this->add_responsive_control(
            'testimonial_box_padding',
            [
                'label' => esc_html__( 'Padding', 'restlycore' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .theme-testimonial-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->end_controls_section();


        
        $this->start_controls_section(
            'testimonial_content_styling_options',
            [
                'label' => esc_html__( 'Content', 'restlycore' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->start_controls_tabs(
            'testimonial_content_tabs'
        );
        
        $this->start_controls_tab(
            'testimonial_content_tabs_title',
            [
                'label' => __( 'Title', 'restlycore' ),
            ]
        );
        
        $this->add_responsive_control(
            'testimonial_content_title_color',
            [
                'label' => esc_html__( 'Color', 'restlycore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .theme-testimonial-item .testimonial-author-box h3' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .theme-testimonial-item.theme-testimonial-layout-item-two h3.testimonial-author-title' => 'color: {{VALUE}}',

                ],
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'testimonial_content_title_typo',
                'label' => esc_html__( 'Typography', 'restlycore' ),
                'selector' => '{{WRAPPER}} .theme-testimonial-item .testimonial-author-box h3, h3.testimonial-author-title',
            ]
        );
        
        $this->add_responsive_control(
            'testimonial_content_title_margin',
            [
                'label' => esc_html__( 'Margin', 'restlycore' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .theme-testimonial-item .testimonial-author-box h3, h3.testimonial-author-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        
        
        $this->end_controls_tab();
        
        
        $this->start_controls_tab(
            'testimonial_content_tabs_position',
            [
                'label' => __( 'Position', 'restlycore' ),
            ]
        );

        $this->add_responsive_control(
            'testimonial_content_position_color',
            [
                'label' => esc_html__( 'Color', 'restlycore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .theme-testimonial-item .testimonial-author-box h5' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'testimonial_content_position_typo',
                'label' => esc_html__( 'Typography', 'restlycore' ),
                'selector' => '{{WRAPPER}} .theme-testimonial-item .testimonial-author-box h5',
            ]
        );


        $this->add_responsive_control(
            'testimonial_content_position_margin',
            [
                'label' => esc_html__( 'Margin', 'restlycore' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .theme-testimonial-item .testimonial-author-box h5' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


        $this->end_controls_tab();

        
        $this->start_controls_tab(
            'testimonial_content_tabs_dec',
            [
                'label' => __( 'Description', 'restlycore' ),
            ]
        );

        $this->add_responsive_control(
            'testimonial_content_dec_color',
            [
                'label' => esc_html__( 'Color', 'restlycore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .theme-testimonial-item .testimonial-dec p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'testimonial_content_dec_typo',
                'label' => esc_html__( 'Typography', 'restlycore' ),
                'selector' => '{{WRAPPER}} .theme-testimonial-item .testimonial-dec p',
            ]
        );

        $this->add_responsive_control(
            'testimonial_content_dec_margin',
            [
                'label' => esc_html__( 'Margin', 'restlycore' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .theme-testimonial-item .testimonial-dec p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'testimonial_content_dec_padding',
            [
                'label' => esc_html__( 'Padding', 'restlycore' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .restly-testimonial-dec P' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();


		
	}
	


	protected function render() {
		
		
	$settings = $this->get_settings_for_display();

    $dynamic_id = rand(1575, 2850);

    if( $settings['testimonial_layout'] === '1' ) {
            $testimonial_layout = "test-layout-one-style";
        }else{
            $testimonial_layout = "test-layout-two-style";
    }



    if($settings['testimonial_slide_enable'] == 'yes'){

            $theme_row_custom__Class = 'review_carousel_Customrow';

            $theme_testimonial_item_Singleclass = 'review-item-wrap-customm';

            if($settings['testimonial_dot_enable'] == 'yes' ){
                $dots = 'true';
            }else{
                $dots = 'false';
            }

            if($settings['testimonial_auto_loop'] == 'yes' ){
                $aloop = 'true';
            }else{
                $aloop = 'false';
            }

            if($settings['testimonial_loop'] == 'yes' ){
                $loop = 'true';
            }else{
                $loop = 'false';
            }

            $testimonial_column = $settings['testimonial_column_number'];
            

            ?>

            <script type="text/javascript">

            jQuery(document).ready(function($) {

                "use strict";

                $('.tesimonials-slide-new').slick({

                    //slidesToShow: '.esc_attr($testimonial_column).',

                    slidesToShow: '<?php echo esc_attr($testimonial_column); ?>',

                    slidesToScroll: 2,

                    arrows: true,

                    dots: '<?php echo esc_attr($dots); ?>',
                    
                    infinite: true,
                    autoplay: false,

                    speed: 1500,

                    prevArrow: '<div class="slide-arrow-left"><i class="las la-long-arrow-alt-left"></i></div>',
                    nextArrow: '<div class="slide-arrow-right"><i class="las la-long-arrow-alt-right"></i></div>',

                    responsive: [
                        {
                        breakpoint: 1024,
                            settings: {
                                slidesToShow: 2,
                                slidesToScroll: 2,
                            }
                        },
                        {
                            breakpoint: 991,
                            settings: {
                                slidesToShow: 1,
                                slidesToScroll: 1
                            }
                        },
                        {
                            breakpoint: 480,
                            settings: {
                                slidesToShow: 1,
                                slidesToScroll: 1
                            }
                        }
                    ]
                });
            });


            </script>

        <?php } else {

            $theme_row_custom__Class = 'row';
            $theme_testimonial_item_Singleclass = 'col-xl-4 col-md-6';

        }
        
        ob_start();        

		
		?>



		<div class="them_main_testimonial__Wrapper_One theme-testimonials-section-one-wrapper <?php echo $testimonial_layout; ?>">

            <div class="theme_review__Innerwrap custom-col-<?php echo esc_attr($testimonial_column);?>">

                <div class="theme_review__innerSingle <?php echo esc_attr($theme_row_custom__Class); ?> tesimonials-slide-new">

                    <?php foreach($settings['theme_testimonials_block'] as $theme_testimonial_item_block_part ) : ?>

                    <div class="<?php echo esc_attr($theme_testimonial_item_Singleclass); ?>">


                        
                        <?php if ( $settings['testimonial_layout'] === '1' ) : ?>

                        <div class="them_main_testimonial__Wrapper theme-testimonial-item testimonial_quote__Singleitem">

                            <div class="review-top-part testimonial_quote__Top">

                                <div class="theme-testimonial-brand-img">
                                    <?php echo wp_get_attachment_image( $theme_testimonial_item_block_part['testimonial_brand_img']['id'], 'full' ); ?>
                                </div>

                                <div class="review_icon_style_Quote testimonial_quote__Design">
                                     <?php \Elementor\Icons_Manager::render_icon( $settings['testimonial_quote'], [ 'aria-hidden' => 'true' ] ); ?>
                                </div>


                            </div>

                            <div class="testimonial-dec testimonial_quote__Description">
                                <p><?php echo esc_html($theme_testimonial_item_block_part['testimonial_description']); ?></p>
                            </div>

                            <div class="testimonial_quote__Bottom">

                                <div class="testimonial-author-box testimonial_quote__Authorbox">

                                    <?php echo wp_get_attachment_image( $theme_testimonial_item_block_part['testimonial_reviewer_img']['id'], 'full' ); ?>

                                    <h3><?php echo esc_html($theme_testimonial_item_block_part['testimonial_title']); ?></h3>
                                    <h5><?php echo esc_html($theme_testimonial_item_block_part['testimonial_position']); ?></h5>

                                </div>

                                <div class="testimonial-rating-box testimonial_quote__Ratingbox">

                                    <?php
                                        $rating = $theme_testimonial_item_block_part['rating'];
                                        $this->add_render_attribute( 'star-rating', 'class', 'review-rating-numberr-rating review-rating-numberr-' . esc_attr( $rating ) );

                                        $testimonial_review_markup_wrapper = "<div class='star-rating review-rating-numberr-". $rating."'>\n";
                                        $testimonial_review_markup_wrapper .= "<div class=\"review-rating-numberr-1 fa-star\"></div>\n";
                                        $testimonial_review_markup_wrapper .= "<div class=\"review-rating-numberr-2 fa-star\"></div>\n";
                                        $testimonial_review_markup_wrapper .= "<div class=\"review-rating-numberr-3 fa-star\"></div>\n";
                                        $testimonial_review_markup_wrapper .= "<div class=\"review-rating-numberr-4 fa-star\"></div>\n";
                                        $testimonial_review_markup_wrapper .= "<div class=\"review-rating-numberr-5 fa-star\"></div>\n";
                                        $testimonial_review_markup_wrapper .= "</div>";

                                        echo $testimonial_review_markup_wrapper;
                                        
                                    ?>

                                </div>

                            </div>


                        </div>

                        <?php else : ?>


                        <div class="theme-testimonial-item theme-testimonial-layout-item-two">
                            <div class="testimonial-reviewer-media">

                                <?php echo wp_get_attachment_image( $theme_testimonial_item_block_part['testimonial_reviewer_img']['id'], 'full' ); ?>
                                
                            </div>

                            <div class="testimonial-dec">
                                <p><?php echo esc_html($theme_testimonial_item_block_part['testimonial_description']); ?></p>
                            </div>

                            <h3 class="testimonial-author-title"><?php echo esc_html($theme_testimonial_item_block_part['testimonial_title']); ?></h3>

                            <div class="testimonial-rating-box">

                                Star

                            </div>
                        </div>



                        <?php endif; ?>



                    </div>

                    <?php endforeach; ?>

                </div>

            </div>

        </div>
	

	<?php 


	}
				

}

