<?php
namespace Elementor;

class Xcency_Why_Choose_US_Widget extends Widget_Base {

	public function get_name() {
		return 'xcency_why_choose_us';
	}

	public function get_title() {
		return esc_html__( 'Why Choose Us', 'xcency-core' );
	}

	public function get_icon() {
		return 'flaticon-question-mark';
	}

	public function get_categories() {
		return [ 'xcency_core_elements' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'why_choose_us_title_option',
			[
				'label' => esc_html__( 'Section Title', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Subtitle', 'xcency-core' ),
				'label_block'       => true,
				'default'       => 'Why Choose Us',
				'type'        => Controls_Manager::TEXT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => __( 'title', 'xcency-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 5,
				'default'     => 'Why Should Choose Our Agency?',
			]
		);


		$this->add_control(
			'desc',
			[
				'label'       => __( 'Description', 'xcency-core' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => 'We are committed to developing innovative AI-driven CRM solutions that enable businesses to achieve exceptional customer engagement, streamline.',
				'label_block' => true,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'why_choose_us_box',
		    [
		        'label' => esc_html__( 'Why Choose Us', 'xcency-core' ),
		        'tab'   => Controls_Manager::TAB_CONTENT,
		    ]
		);

		$repeater = new Repeater();

		$repeater->add_control(
		    'box_title',
		    [
		        'label'       => esc_html__( 'Title', 'xcency-core' ),
		        'type'        => Controls_Manager::TEXT,
		        'default'     => esc_html__( 'Quality Services', 'xcency-core' ),
		        'label_block' => true,
		    ]
		);

		$repeater->add_control(
		    'selected_icon',
		    [
		        'label'            => esc_html__( 'Icon', 'xcency-core' ),
		        'type'             => Controls_Manager::ICONS,
		        'fa4compatibility' => 'icon',
		        'label_block'      => true,
		        'default'          => [
		            'value'   => 'flaticon-software',
		            'library' => 'xcency-icon',
		        ],
		    ]
		);

		$repeater->add_control(
		    'box_desc',
		    [
		        'label'       => esc_html__( 'Description', 'xcency-core' ),
		        'type'        => Controls_Manager::TEXTAREA,
		        'rows'        => 5,
		        'default'     => esc_html__( 'We are committed AI-driven CRM solutions.', 'xcency-core' ),
		        'placeholder' => esc_html__( '', 'xcency-core' ),
		    ]
		);

		$this->add_control(
		    'boxes',
		    [
		        'label'       => esc_html__( 'Choose Us Box List', 'xcency-core' ),
		        'type'        => Controls_Manager::REPEATER,
		        'fields'      => $repeater->get_controls(),
		        'default'     => [
		            [
		                'box_title' => esc_html__( 'Quality Services', 'xcency-core' ),
		                'box_desc' => esc_html__( 'We are committed AI-driven CRM solutions.', 'xcency-core' ),
		            ],
		        ],
		        'title_field' => '{{{ box_title }}}',
		    ]
		);

        $this->add_control(
            'right_image',
            [
                'label'       => esc_html__( 'Right Image', 'xcency-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

		$this->end_controls_section();


		$this->start_controls_section(
		    'section_title_style_options',
		    [
		        'label' => esc_html__( 'Section Title', 'xcency-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'subtitle_typography',
				'label'    => esc_html__( 'Subtitle Typography', 'xcency-core' ),
				'selector' => '{{WRAPPER}} .xcency-section-subtitle',
			]
		);

		$this->add_control(
			'subtitle_color',
			[
				'label'       => esc_html__('Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-section-subtitle' => 'color: {{VALUE}};',
					'{{WRAPPER}} .section-subtitle-dot' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'subtitle_bg_color',
			[
				'label'       => esc_html__('Subtitle Background Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-section-subtitle' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'subtitle_margin',
			[
				'label'      => esc_html__( 'Subtitle Margin', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .xcency-section-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'label'    => esc_html__( 'Title Typography', 'xcency-core' ),
				'selector' => '{{WRAPPER}} .xcency-section-title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Title Color', 'xcency-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .xcency-section-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_margin',
			[
				'label'      => esc_html__( 'Title Margin', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .xcency-section-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_width',
			[
				'label'      => esc_html__( 'TItle Width (%)', 'xcency-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ '%' ],
				'range'      => [
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'    => [ 'desktop', 'tablet', 'mobile' ],
				'selectors'  => [
					'{{WRAPPER}} .xcency-section-title' => 'width: {{SIZE}}%;',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'desc_typography',
				'label'    => esc_html__( 'Description Typography', 'xcency-core' ),
				'selector' => '{{WRAPPER}} .xcency-section-desc',
			]
		);

		$this->add_control(
			'desc_color',
			[
				'label'     => esc_html__( 'Description Color', 'xcency-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .xcency-section-desc' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'desc_margin',
			[
				'label'      => esc_html__( 'Description Margin', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .xcency-section-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'desc_width',
			[
				'label'      => esc_html__( 'Description Width (%)', 'xcency-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ '%' ],
				'range'      => [
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'    => [ 'desktop', 'tablet', 'mobile' ],
				'selectors'  => [
					'{{WRAPPER}} .xcency-section-desc' => 'width: {{SIZE}}%;',
				],
			]
		);

		$this->add_responsive_control(
			'wrapper_margin',
			[
				'label'      => esc_html__( 'Wrapper Margin', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .xcency-section-title-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$subtitle       = $settings['subtitle'];
		$title       = $settings['title'];
		$desc      = $settings['desc'];
		?>

		<div class="xcency-why-choose-section-wrapper">
			<div class="xcency-why-choose-us-section-title-wrapper">
				<div class="xcency-section-title-wrapper">
					<div class="xcency-section-title-content d-inline-block">
						<?php if ( $subtitle ) : ?>
							<div class="xcency-section-subtitle">
								<span class="section-subtitle-dot section-subtitle-dot-one"></span>
								<?php echo $subtitle; ?>
								<span class="section-subtitle-dot section-subtitle-dot-two"></span>
							</div>
						<?php endif; ?>

						<?php if ( $title ) : ?>
							<h2 class="xcency-section-title"><?php echo wp_kses( $title, xcency_allow_html() ); ?></h2>
						<?php endif; ?>

						<?php if ( $desc ) : ?>
							<div class="xcency-section-desc xcency-last-p-0">
								<?php echo wp_kses( $desc, xcency_allow_html() ); ?>
							</div>
						<?php endif; ?>
					</div>
				</div>
			</div>

            <div class="xcency-why-choose-box-wrapper">
                <div class="row">
                    <?php if($settings['boxes']){
                        foreach ($settings['boxes'] as $box){ ?>
                            <div class="col-xl-3 col-lg-4 col-md-6">
                                <div class="xcency-why-choose-us-box-item">
                                    <div class="why-choose-us-box-icon">
                                        <?php xcency_custom_icon_render( $box, 'icon', 'selected_icon' );?>
                                    </div>
                                    <h4 class="why-choose-us-box-title"><?php echo $box['box_title'];?></h4>

                                    <div class="why-choose-us-box-desc xcency-last-p-0">
                                        <?php echo $box['box_desc'];?>
                                    </div>
                                </div>
                            </div>
                    <?php	}
                    } ?>
                </div>
            </div>

            <div class="why-choose-us-section-image xcency-cover-bg" style="background-image: url(<?php echo $settings['right_image']['url'];?>)"></div>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new Xcency_Why_Choose_US_Widget );