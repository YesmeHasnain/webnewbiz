<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * About Widget .
 *
 */
class Barab_About_Us extends Widget_Base {

	public function get_name() {
		return 'barababoutus';
	}
	public function get_title() {
		return __( 'About Us', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		 $this->start_controls_section(
			'section_title_section',
			[
				'label'		 	=> __( 'About', 'barab' ),
				'tab' 			=> Controls_Manager::TAB_CONTENT,
				
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two', 'Style Three', 'Style Four' ] );

		barab_general_fields( $this, 'subtitle', 'Subtitle', 'TEXTAREA2', 'Our History', ['1', '4'] );
        barab_media_fields( $this, 'subtitle_shape', 'Choose Title Shape', ['4'] );
		barab_general_fields( $this, 'title', 'Title', 'TEXTAREA', 'A History of restaurant', ['1', '4'] );
        barab_media_fields( $this, 'title_shape', 'Choose Title Shape', ['1'] );

		barab_general_fields( $this, 'big_title', 'Big Title', 'TEXTAREA2', 'About Us', ['2', '3'] );

        barab_media_fields( $this, 'image11', 'Choose Image', ['2', '3'] );
		barab_general_fields( $this, 'title11', 'Title', 'TEXTAREA2', 'Welcome to Our Fine Dining Experience', ['2', '3'] );
		barab_general_fields( $this, 'content11', 'Content', 'TEXTAREA', '', ['2', '3'] );

        barab_general_fields($this, 'divider11', 'Divider', 'DIVIDER', 'Divider' );

        barab_media_fields( $this, 'image222', 'Choose Image 2', ['3'] );
        barab_general_fields( $this, 'title22', 'Title 2', 'TEXTAREA2', 'Welcome to Our Fine Dining Experience', ['3'] );
        barab_general_fields( $this, 'content22', 'Content 2', 'TEXTAREA', 'Is Fast Food Getting Healthier? Here’s What We’re Doing', ['2', '3'] );
        barab_media_fields( $this, 'image22', 'Choose Image 2', ['2'] );

        barab_general_fields($this, 'divider22', 'Divider', 'DIVIDER', 'Divider' );

        barab_media_fields( $this, 'image33', 'Choose Image 3', ['2'] );
        barab_general_fields( $this, 'title33', 'Title 2', 'TEXTAREA2', 'Some Feature of Fine Dining Restaurant', ['2'] );

        $repeater = new Repeater();

        barab_media_fields( $repeater, 'icon', 'Choose Icon' );
		barab_general_fields($repeater, 'content', 'Content', 'TEXTAREA2', '');

		$this->add_control(
			'feature_list2',
			[
				'label' 		=> __( 'Feature Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'content' 	=> __( 'Evolution of Restaurants', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['2', '3']
				]
			]
		);

        $repeater = new Repeater();

        barab_media_fields( $repeater, 'image', 'Choose Image' );
		barab_general_fields($repeater, 'number', 'Content', 'TEXTAREA2', '1998');
		barab_general_fields($repeater, 'title', 'Content', 'TEXTAREA2', 'Evolution of Restaurants');
		barab_general_fields($repeater, 'content', 'Content', 'TEXTAREA2', '');

		$this->add_control(
			'feature_list',
			[
				'label' 		=> __( 'History Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'content' 	=> __( 'Evolution of Restaurants', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['1']
				]
			]
		);

        barab_general_fields($this, 'divider', 'Divider', 'DIVIDER', 'Divider' );

		barab_media_fields( $this, 'image1', 'Choose Image', ['1'] );
		barab_media_fields( $this, 'section_curve_shape', 'Section Curve Shape', ['1'] );


        barab_media_fields( $this, 'about_icon', 'Choose Icon', ['4'] );
        barab_general_fields($this, 'about_title', 'Title', 'TEXTAREA2', 'Air Delivery', ['4']);
        barab_general_fields($this, 'about_content', 'Content', 'TEXTAREA2', '', ['4']);
        barab_media_fields( $this, 'middle_img', 'Middle Image', ['4'] );
        barab_media_fields( $this, 'about_icon2', 'Choose Icon', ['4'] );
        barab_general_fields($this, 'about_title2', 'Title', 'TEXTAREA2', 'Automated', ['4']);
        barab_general_fields($this, 'about_content2', 'Content', 'TEXTAREA2', '', ['4']);

        barab_media_fields( $this, 'shape_left', 'Choose Shape Left', ['4'] );
        barab_media_fields( $this, 'shape_right', 'Choose Shape Right', ['4'] );

        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------
		barab_common_style_fields( $this, '01', 'Section Subtitle', '{{WRAPPER}} .sub-title', ['1', '4'] );
		barab_common_style_fields( $this, '02', 'Section Title', '{{WRAPPER}} .sec-title', ['1'] );
		barab_common_style_fields( $this, '03', 'Section Title', '{{WRAPPER}} .about-top-title', ['4'] );

		barab_common_style_fields($this, '20', 'Feature Number', '{{WRAPPER}} .year', ['1'] );
		barab_common_style_fields($this, '21', 'Feature Title', '{{WRAPPER}} .box-title', ['1'] );
		barab_common_style_fields($this, '23', 'Feature Title', '{{WRAPPER}} .box-title3', ['4'] );
		barab_common_style_fields($this, '22', 'Feature Content', '{{WRAPPER}} .box-text', ['1', '4'] );

	}


	protected function render() {

        $settings = $this->get_settings_for_display();

			if( $settings['layout_style'] == '1' ){
                echo '<div class="history-sec1 bg-theme2 overflow-hidden " id="history-sec">';
                    echo barab_img_tag( array(
                        'url'   => esc_url( $settings['section_curve_shape']['url'] ),
                        'class' => 'round-shape-bottom'
                    ));
                    echo '<div class="container">';
                        echo '<div class="row gy-4 justify-content-center">';
                            echo '<div class="col-lg-6">';
                                if($settings['image1']['url'] ){
                                     echo '<div class="history-img">';
                                        echo barab_img_tag( array(
                                            'url'   => esc_url( $settings['image1']['url'] ),
                                        )); 
                                    echo '</div>';
                                }
                            echo '</div>';
                            echo '<div class="col-lg-6">';
                                echo '<div class="history-content-wrap ps-xl-5">';
                                    echo '<div class="title-area mb-40">';
                                    	if(!empty($settings['subtitle'])){
                                            echo '<span class="sub-title text-anime-style-1">'.esc_html($settings['subtitle']).'</span>';
                                        }
                                        if(!empty($settings['title'])){
                                            echo '<h2 class="sec-title text-anime-style-2">'.wp_kses_post($settings['title']).'</h2>';
                                        }
                                        echo barab_img_tag( array(
                                            'url'   => esc_url( $settings['title_shape']['url'] ),
                                            'class' => 'img-anime-style-1'
                                        )); 
                                    echo '</div>'; 
                                    foreach( $settings['feature_list'] as $key => $data ){
                                        $delay = 0.2 + ($key * 0.1);
                                        echo '<div class="history-box-1 wow fadeinup" data-wow-delay="'.$delay.'s">';
                                            echo '<div class="content">';
                                                if(!empty($data['number'])){
                                                    echo '<h4 class="year">'.esc_html($data['number']).'</h4>';
                                                }
                                                if(!empty($data['title'])){
                                                    echo '<h3 class="box-title">'.esc_html($data['title']).'</h3>';
                                                }
                                                if(!empty($data['content'])){
                                                    echo '<p class="box-text">'.esc_html($data['content']).'</p>';
                                                }
                                            echo '</div>';
                                            if($data['image']['url'] ){
                                                echo '<div class="thumb global-img">';
                                                    echo barab_img_tag( array(
                                                        'url'   => esc_url( $data['image']['url'] ),
                                                    )); 
                                                echo '</div>';
                                            }
                                        echo '</div>';
                                    }
                                echo '</div>';
                            echo '</div>';
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
				
			}elseif( $settings['layout_style'] == '2' ){
                if(!empty($settings['big_title'])){
                    echo '<div class="row">';
                        echo '<div class="col-12">';
                            echo '<div class="big-title3-wrap">';
                                echo '<h4 class="big-title3-title text-anime-style-2">'.wp_kses_post($settings['big_title']).'</h4>';
                            echo '</div>';
                        echo '</div>';
                    echo '</div>';
                }
                echo '<div class="row gy-40 justify-content-center align-items-xl-end">';
                    echo '<div class="col-xl-4 col-lg-6">';
                        echo '<div class="about-3-content-wrap pe-xxl-5 me-xxl-5 wow fadeinleft" data-wow-delay=".2s">';
                            if(!empty($settings['title11'])){
                                echo '<h4 class="box-title2">'.wp_kses_post($settings['title11']).'</h4>';
                            }
                            if(!empty($settings['content11'])){
                                echo '<p class="box-text">'.wp_kses_post($settings['content11']).'</p>';
                            }
                            if($settings['image11']['url'] ){
                                    echo '<div class="img-box">';
                                    echo barab_img_tag( array(
                                        'url'   => esc_url( $settings['image11']['url'] ),
                                    )); 
                                echo '</div>';
                            }
                        echo '</div>';
                    echo '</div>';
                    echo '<div class="col-xl-4 col-lg-6">';
                        echo '<div class="about3-img-box wow fadeinleft" data-wow-delay=".4s">';
                            if(!empty($settings['content22'])){
                                echo '<p class="about3-position-text">'.wp_kses_post($settings['content22']).'</p>';
                            }
                            if($settings['image22']['url'] ){
                                echo barab_img_tag( array(
                                    'url'   => esc_url( $settings['image22']['url'] ),
                                )); 
                            }
                        echo '</div>';
                    echo '</div>';
                    echo '<div class="col-xl-4 col-lg-6">';
                        echo '<div class="about3-right wow fadeinleft" data-wow-delay=".6s">';
                            if($settings['image33']['url'] ){
                                    echo '<div class="img-box3">';
                                    echo barab_img_tag( array(
                                        'url'   => esc_url( $settings['image33']['url'] ),
                                    )); 
                                echo '</div>';
                            }
                            if(!empty($settings['title33'])){
                                echo '<h4 class="box-title2">'.wp_kses_post($settings['title33']).'</h4>';
                            }
                            echo '<div class="checklist style2">';
                                echo '<ul>';
                                    foreach( $settings['feature_list2'] as $key => $data ){
                                        echo '<li>';
                                             echo barab_img_tag( array(
                                                'url'   => esc_url( $data['icon']['url'] ),
                                            )); 
                                            if(!empty($data['content'])){
                                                echo '<p>'.wp_kses_post($data['content']).'</p>';
                                            }
                                        echo '</li>';
                                    }
                                echo '</ul>';
                            echo '</div>';
                        echo '</div>';
                    echo '</div>';
                echo '</div>';

			}elseif( $settings['layout_style'] == '3' ){
                echo '<div class="row gy-40 justify-content-center align-items-xl-end">';
                    echo '<div class="col-xl-4 col-lg-6">';
                        if($settings['image11']['url'] ){
                            echo '<div class="about-4-left global-img wow fadeinleft" data-wow-delay=".2s">';
                                echo barab_img_tag( array(
                                    'url'   => esc_url( $settings['image11']['url'] ),
                                )); 
                            echo '</div>';
                        }
                    echo '</div>';
                    echo '<div class="col-xl-5 col-lg-6">';
                        echo '<div class="about-4-content-wrap ps-xxl-5 ms-xxl-4 wow fadeinleft" data-wow-delay=".2s">';
                            if(!empty($settings['big_title'])){
                                echo '<div class="big-title3-wrap">';
                                    echo '<h4 class="big-title3-title text-anime-style-2">'.wp_kses_post($settings['big_title']).'</h4>';
                                echo '</div>';
                            }
                            echo '<div class="title-area style3 pe-xl-5 me-xl-3">';
                                if(!empty($settings['title11'])){
                                    echo '<h4 class="sec-title text-anime-style-2">'.wp_kses_post($settings['title11']).'</h4>';
                                }
                                if(!empty($settings['content11'])){
                                    echo '<p class="box-text text-anime-style-3">'.wp_kses_post($settings['content11']).'</p>';
                                }
                            echo '</div>';
                             if($settings['image222']['url'] ){
                                echo '<div class="img-box me-xl-5 global-img">';
                                    echo barab_img_tag( array(
                                        'url'   => esc_url( $settings['image222']['url'] ),
                                    )); 
                                echo '</div>';
                            }
                        echo '</div>';
                    echo '</div>';
                    echo '<div class="col-xl-3 col-lg-6">';
                        echo '<div class="about3-right style-2 wow fadeinleft" data-wow-delay=".6s">';
                            if(!empty($settings['title22'])){
                                echo '<h4 class="box-title2">'.wp_kses_post($settings['title22']).'</h4>';
                            }
                            if(!empty($settings['content22'])){
                                echo '<p class="box-text mb-4">'.wp_kses_post($settings['content22']).'</p>';
                            }
                            echo '<div class="checklist style2">';
                                echo '<ul>';
                                    foreach( $settings['feature_list2'] as $key => $data ){
                                        echo '<li>';
                                                echo barab_img_tag( array(
                                                'url'   => esc_url( $data['icon']['url'] ),
                                            )); 
                                            if(!empty($data['content'])){
                                                echo '<p>'.wp_kses_post($data['content']).'</p>';
                                            }
                                        echo '</li>';
                                    }
                                echo '</ul>';
                            echo '</div>';
                        echo '</div>';
                    echo '</div>';
                echo '</div>';

            }elseif( $settings['layout_style'] == '4' ){
                echo '<div class="about-sec-5 space">';
                    if(!empty($settings['subtitle'])){
                    echo '<div class="row gy-4 justify-content-center">';
                        echo '<div class="col-xxl-10 col-xl-11">';
                            echo '<div class="title-area style-4 text-center mb-20">';
                                echo '<span class="sub-title text-anime-style-1">'.esc_html($settings['subtitle']).'</span>';
                                if($settings['subtitle_shape']['url'] ){
                                    echo barab_img_tag( array(
                                        'url'   => esc_url( $settings['subtitle_shape']['url'] ),
                                        'class' => 'img-anime-style-1'
                                    )); 
                                }
                            echo '</div>';
                        echo '</div>';
                    echo '</div>';
                    }
                    if(!empty($settings['title'])){
                    echo '<div class="row justify-content-center mb-30">';
                        echo '<div class="col-xxl-10 col-xl-11 pe-xxl-4 ms-xxl-4">';
                            echo '<h2 class="about-top-title pe-xxl-5 ps-xl-5 me-xxl-5 ms-xl-5">'.wp_kses_post($settings['title']).'</h2>';
                        echo '</div>';
                    echo '</div>';
                    }
                    echo '<div class="row gy-40 align-items-start position-relative">';
                        if($settings['shape_left']['url'] ){
                            echo barab_img_tag( array(
                                'url'   => esc_url( $settings['shape_left']['url'] ),
                                'class' => 'about-5-shape-1'
                            )); 
                        }
                        if($settings['shape_right']['url'] ){
                            echo barab_img_tag( array(
                                'url'   => esc_url( $settings['shape_right']['url'] ),
                                'class' => 'about-5-shape-2'
                            )); 
                        }
                        echo '<div class="col-xl-3 col-lg-3 col-md-12">';
                            echo '<div class="about-5-box ms-xxl-5">';
                                if($settings['about_icon']['url'] ){
                                    echo '<div class="img-box-5">';
                                        echo barab_img_tag( array(
                                            'url'   => esc_url( $settings['about_icon']['url'] ),
                                        )); 
                                    echo '</div>';
                                }
                                echo '<div class="content">';
                                    if(!empty($settings['about_title'])){
                                        echo '<h4 class="box-title3">'.wp_kses_post($settings['about_title']).'</h4>';
                                    }
                                    if(!empty($settings['about_content'])){
                                        echo '<p class="box-text">'.wp_kses_post($settings['about_content']).'</p>';
                                    }
                                echo '</div>';
                            echo '</div>';
                        echo '</div>';
                        echo '<div class="col-xl-6 col-lg-6 col-md-12">';
                            if($settings['middle_img']['url'] ){
                                echo '<div class="about-5-middle">';
                                    echo barab_img_tag( array(
                                        'url'   => esc_url( $settings['middle_img']['url'] ),
                                    ));
                                echo '</div>';
                            }
                        echo '</div>';
                        echo '<div class="col-xl-3 col-lg-3 col-md-12">';
                            echo '<div class="about-5-box style-2 me-xxl-5 pe-xxl-1">';
                                if($settings['about_icon2']['url'] ){
                                    echo '<div class="img-box-5">';
                                        echo barab_img_tag( array(
                                            'url'   => esc_url( $settings['about_icon2']['url'] ),
                                        )); 
                                    echo '</div>';
                                }
                                echo '<div class="content">';
                                    if(!empty($settings['about_title2'])){
                                        echo '<h4 class="box-title3">'.wp_kses_post($settings['about_title2']).'</h4>';
                                    }
                                    if(!empty($settings['about_content'])){
                                        echo '<p class="box-text">'.wp_kses_post($settings['about_content2']).'</p>';
                                    }
                                echo '</div>';
                            echo '</div>';
                        echo '</div>';
                    echo '</div>';
                echo '</div>';

            }


	}

}