<?php
namespace Elementor;

class Xcency_Footer_About_Company_Widget extends Widget_Base {

	public function get_name() {
		return 'xcency_footer_about_company';
	}

	public function get_title() {
		return esc_html__( 'About Company', 'xcency-core' );
	}

	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	public function get_categories() {
		return [ 'xcency_core_elements' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'footer_about',
			[
				'label' => esc_html__( 'About Company', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'about_title',
			[
				'label'       => __( 'Title', 'xcency-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'About Us',
			]
		);

		$this->add_control(
			'about_image',
			[
				'label'       => __( 'Image', 'xcency-core' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'default'     => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'about_desc',
			[
				'label'       => __( 'Description', 'xcency-core' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => 'It is a long established fact that the read will been distracted by there readable an important content.',
				'label_block' => true,
			]
		);

        $this->add_control(
            'enable_social',
            [
                'label'     => esc_html__( 'Enable Social', 'xcency-core' ),
                'type'      => Controls_Manager::SWITCHER,
                'label_on'  => esc_html__( 'Yes', 'xcency-core' ),
                'label_off' => esc_html__( 'No', 'xcency-core' ),
                'default'   => 'yes',
            ]
        );

		$repeater = new Repeater();

		$repeater->add_control(
			'selected_social_icon',
			[
				'label'            => esc_html__( 'Select Icon', 'xcency-core' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fab fa-facebook-f',
					'library' => 'brands',
				],
			]
		);

		$repeater->add_control(
			'profile_url',
			[
				'label'         => __( 'Profile URL', 'xcency-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'xcency-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '#',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'socials',
			[
				'label'       => __( 'Social Profile List', 'xcency-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
                'condition' => [
                    'enable_social' => 'yes',
                ],
				'default'     => [
					[
						'selected_social_icon' => 'fab fa-facebook-f',
					],
				],
				'title_field' => '<i class="{{{selected_social_icon.value}}}"></i>',
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'footer_about_title_style',
            [
                'label' => esc_html__( 'Title', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'about_title!' => '',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'about_title_typo',
                'label' => esc_html__( 'Typography', 'xcency-core' ),
                'selector' => '{{WRAPPER}} .widget_xcency_about_company_widget .widget-title',
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'       => esc_html__('Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .widget_xcency_about_company_widget .widget-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_margin',
            [
                'label'      => esc_html__( 'Title Margin', 'xcency-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .widget_xcency_about_company_widget .widget-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'company_logo',
            [
                'label' => esc_html__( 'Company Logo', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

		$this->add_responsive_control(
			'logo_width',
			[
				'label' => esc_html__( 'Logo Width', 'xcency-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .about-info-img img' => 'width: {{SIZE}}px;max-width: {{SIZE}}px;',
				],
			]
		);

		$this->add_responsive_control(
			'logo_height',
			[
				'label' => esc_html__( 'Logo Height', 'xcency-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .about-info-img img' => 'height: {{SIZE}}px;max-height: {{SIZE}}px;',
				],
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
            'about_company_desc_style',
            [
                'label' => esc_html__( 'Description Style', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'desc_typo',
                'label' => esc_html__( 'Typography', 'xcency-core' ),
                'selector' => '{{WRAPPER}} .widget-about-description',
            ]
        );

        $this->add_control(
            'desc_color',
            [
                'label'       => esc_html__('Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .widget-about-description' => 'color: {{VALUE}};',
                ],
            ]
        );

		$this->add_responsive_control(
			'desc_margin',
			[
				'label'      => esc_html__( 'Description Margin', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .widget-about-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();

        // Start Social section
        $this->start_controls_section(
            'xcency_social_style_options',
            [
                'label' => esc_html__('Social Icons', 'xcency-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs('xcency_social_style_tabs');

        //Default style tab start
        $this->start_controls_tab(
            'xcency_social_style_default',
            [
                'label' => esc_html__('Default', 'xcency-core'),
            ]
        );

        $this->add_control(
            'icon_default_color',
            [
                'label'     => esc_html__('Color', 'xcency-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .footer-social-icon li a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();//Default style tab end

        //Hover style tab start
        $this->start_controls_tab(
            'xcency_social_style_hover',
            [
                'label' => esc_html__('Hover', 'xcency-core'),
            ]
        );

		$this->add_control(
			'icon_hover_color',
			[
				'label'     => esc_html__('Color', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .footer-social-icon li a:hover' => 'color: {{VALUE}};',
				],
			]
		);

        $this->end_controls_tabs();//Hover style tab end

        $this->end_controls_section();// End Social section

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<div class="xcency-elementor-widget widget widget_xcency_about_company_widget">
			<?php if($settings['about_image']['id']) :
				$image_src = $settings['about_image']['url'];
				$image_alt = get_post_meta( $settings['about_image']['id'], '_wp_attachment_image_alt', true );
				$image_title = get_the_title( $settings['about_image']['id']);
				?>
				<div class="about-info-img">
					<img src="<?php echo $image_src;?>" alt="<?php echo $image_alt;?>" title="<?php echo $image_title;?>">
				</div>

			<?php else: ?>
				<h4 class="widget-title"><?php echo $settings['about_title'];?></h4>
			<?php endif;?>

			<div class="widget-about-description xcency-last-p-0">
				<?php echo $settings['about_desc'];?>
			</div>
            <?php if ($settings['enable_social'] == 'yes') :?>
			<ul class="widget-social-icons footer-social-icon xcency-list-inline">
				<?php if ( $settings['socials'] ) {
					foreach ( $settings['socials'] as $social ) {
						$profile_url = $social['profile_url']['url'];
						$target      = $social['profile_url']['is_external'] ? ' target="_blank"' : '';
						$nofollow    = $social['profile_url']['nofollow'] ? ' rel="nofollow"' : '';
						?>
						<li>
							<a href="<?php echo $profile_url; ?>" <?php echo $target . $nofollow ?>>

								<i class="<?php echo $social['selected_social_icon']['value']; ?>"></i>
							</a>
						</li>
					<?php }
				} ?>
			</ul>
            <?php endif; ?>
		</div>
		<?php
	}
}

Plugin::instance()->widgets_manager->register( new Xcency_Footer_About_Company_Widget );