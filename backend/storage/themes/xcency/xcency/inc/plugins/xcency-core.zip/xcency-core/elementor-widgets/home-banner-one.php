<?php
namespace Elementor;

class Xcency_Home_Banner_One_Widget extends Widget_Base {

	public function get_name() {
		return 'xcency_home_banner_one';
	}

	public function get_title() {
		return esc_html__( 'Home Banner One', 'xcency-core' );
	}

	public function get_icon() {
		return 'flaticon-flag-1';
	}

	public function get_categories() {
		return [ 'xcency_core_elements' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'banner_one_options',
			[
				'label' => esc_html__( 'Banner Options', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
            'banner_title',
            [
                'label'       => __( 'Title', 'xcency-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'rows'        => 5,
                'default'     => 'Empowering Tomorrow\'s Innovations',
            ]
        );

        $this->add_control(
            'desc',
            [
                'label'       => __( 'Description', 'xcency-core' ),
                'type'        => Controls_Manager::WYSIWYG,
                'default'     => 'We are dedicated to transforming visionary ideas into groundbreaking realities. As a leading startup agency, we specialize in pro comprehensive support and strategic guidance to budding entrepreneurs.',
                'label_block' => true,
            ]
        );

        $this->add_control(
            'btn_one_text',
            [
                'label'       => __( 'Button One Text', 'xcency-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => 'Get Started',
            ]
        );

        $this->add_control(
            'btn_one_url',
            [
                'label'         => __( 'Button One URL', 'xcency-core' ),
                'type'          => Controls_Manager::URL,
                'placeholder'   => __( 'https://your-link.com', 'xcency-core' ),
                'show_external' => true,
                'default'       => [
                    'url'         => '',
                    'is_external' => false,
                    'nofollow'    => false,
                ],
            ]
        );

        $this->add_control(
            'btn_two_text',
            [
                'label'       => __( 'Button Two Text', 'xcency-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => 'Get Started',
            ]
        );

        $this->add_control(
            'btn_two_url',
            [
                'label'         => __( 'Button Two URL', 'xcency-core' ),
                'type'          => Controls_Manager::URL,
                'placeholder'   => __( 'https://your-link.com', 'xcency-core' ),
                'show_external' => true,
                'default'       => [
                    'url'         => '',
                    'is_external' => false,
                    'nofollow'    => false,
                ],
            ]
        );

        $this->add_control(
            'left_image',
            [
                'label'       => __( 'Left Image', 'xcency-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'right_image',
            [
                'label'       => __( 'Right Image', 'xcency-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

		$this->end_controls_section();

        $this->start_controls_section(
            'title_style_options',
            [
                'label' => esc_html__( 'Title', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typo_options',
                'label' => esc_html__( 'Typography', 'xcency-core' ),
                'selector' => '{{WRAPPER}} .banner-one-title',
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'       => esc_html__('Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .banner-one-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_margin',
            [
                'label'      => esc_html__( 'Margin', 'xcency-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .banner-one-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'desc_style_options',
			[
				'label' => esc_html__( 'Description', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'desc_typo_options',
				'label' => esc_html__( 'Typography', 'xcency-core' ),
				'selector' => '{{WRAPPER}} .home-banner-one-desc',
			]
		);

		$this->add_control(
			'desc_color',
			[
				'label'       => esc_html__('Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .home-banner-one-desc' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'desc_margin',
			[
				'label'      => esc_html__( 'Margin', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .home-banner-one-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


        $this->start_controls_section(
            'button_style_options',
            [
                'label' => esc_html__( 'Buttons', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs('td_default_and_hover_style_tabs_start');

        //Default style tab start
        $this->start_controls_tab(
            'td_btn_style_default',
            [
                'label' => esc_html__('Default', 'xcency-core'),
            ]
        );

        $this->add_control(
            'btn_one_default_bg_color',
            [
                'label'       => esc_html__('Button One Background', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .xcency-button.home-banner-one-btn-one' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'btn_one_default_border_color',
            [
                'label'       => esc_html__('Button One Border Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .xcency-button.home-banner-one-btn-one' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'btn_one_default_text_color',
            [
                'label'       => esc_html__('Button One Text Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .xcency-button.home-banner-one-btn-one' => 'color: {{VALUE}};',
                ],
            ]
        );

		$this->add_control(
			'btn_two_default_bg_color',
			[
				'label'       => esc_html__('Button Two Background', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-button.home-banner-one-btn-two' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_two_default_border_color',
			[
				'label'       => esc_html__('Button Two Border Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-button.home-banner-one-btn-two' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_two_default_text_color',
			[
				'label'       => esc_html__('Button Two Text Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-button.home-banner-one-btn-two' => 'color: {{VALUE}};',
				],
			]
		);

        $this->end_controls_tab();//Default style tab end

        //Hover style tab start
        $this->start_controls_tab(
            'td_btns_style_hover',
            [
                'label' => esc_html__('Hover', 'xcency-core'),
            ]
        );

		$this->add_control(
			'btn_one_hover_bg_color',
			[
				'label'       => esc_html__('Button One Background', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-button.home-banner-one-btn-one:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_one_hover_border_color',
			[
				'label'       => esc_html__('Button One Border Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-button.home-banner-one-btn-one:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_one_hover_text_color',
			[
				'label'       => esc_html__('Button One Text Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-button.home-banner-one-btn-one:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_two_hover_bg_color',
			[
				'label'       => esc_html__('Button Two Background', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-button.home-banner-one-btn-two:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_two_hover_border_color',
			[
				'label'       => esc_html__('Button Two Border Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-button.home-banner-one-btn-two:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_two_hover_text_color',
			[
				'label'       => esc_html__('Button Two Text Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .xcency-button.home-banner-one-btn-two:hover' => 'color: {{VALUE}};',
				],
			]
		);

        $this->end_controls_tabs();//Hover style tab end

        $this->end_controls_section();

        $this->start_controls_section(
            'wrapper_style',
            [
                'label' => esc_html__( 'Wrapper', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'wrapper_background',
                'label' => esc_html__( 'Background', 'xcency-core' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .home-banner-one-wrapper',
            ]
        );

        $this->add_responsive_control(
            'wrapper_padding',
            [
                'label'      => esc_html__( 'Wrapper Padding', 'xcency-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .home-banner-one-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();

		$left_image_src = $settings['left_image']['url'];
        $left_image_alt = get_post_meta( $settings['left_image']['id'], '_wp_attachment_image_alt', true );
        $left_image_title = get_the_title( $settings['left_image']['id']);

		$right_image_src = $settings['right_image']['url'];
        $right_image_alt = get_post_meta( $settings['right_image']['id'], '_wp_attachment_image_alt', true );
        $right_image_title = get_the_title( $settings['right_image']['id']);
		?>

		<div class="home-banner-one-wrapper">
			<div class="home-banner-one-left-image">
                <img src="<?php echo $left_image_src;?>" alt="<?php echo $left_image_alt;?>" title="<?php echo $left_image_title;?>">
			</div>

			<div class="home-banner-one-right-image">
                <img src="<?php echo $right_image_src;?>" alt="<?php echo $right_image_alt;?>" title="<?php echo $right_image_title;?>">
			</div>

			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="home-banner-one-content-wrapper">
                            <div class="home-banner-one-content">
                                <h2 class="banner-one-title"><?php echo $settings['banner_title'];?></h2>

                                <div class="home-banner-one-desc xcency-last-p-0">
                                    <?php echo $settings['desc'];?>
                                </div>

                                <div class="home-banner-one-btn-wrapper">
                                    <?php
                                        $btn_one_text = $settings['btn_one_text'];
                                        $btn_one_url = $settings['btn_one_url']['url'];

                                        $btn_two_text = $settings['btn_two_text'];
                                        $btn_two_url = $settings['btn_two_url']['url'];
                                    ?>
                                    <a class="xcency-button home-banner-one-btn-one" href="<?php echo $btn_one_url;?>"><?php echo $btn_one_text;?></a>
                                    <?php if($btn_two_text) : ?>
                                    <a class="xcency-button home-banner-one-btn-two" href="<?php echo $btn_two_url;?>"><?php echo $btn_two_text;?></a>
                                    <?php endif; ?>
                                </div>
                            </div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new Xcency_Home_Banner_One_Widget );