<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
use Elementor\Icons_Manager;
/**
 *
 * Load More Widget .
 *
 */
class Barab_Load_More_Widget extends Widget_Base {

	public function get_name() {
		return 'barabloadmore'; 
	}
	public function get_title() {
		return __( 'Load More Widgets', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}

	protected function register_controls() {

		 $this->start_controls_section(
			'Load More_section',
			[
				'label'     => __( 'Load More Widgets', 'barab' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One' ] );

		$this->add_control(
			'th_show_load_more',
			[
				'label' 		=> __( 'Show Load More Option?', 'barab' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Show', 'barab' ),
				'label_off' 	=> __( 'Hide', 'barab' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);
		$this->add_control(
			'th_loop_item_show',
			[
				'label' 	=> __( 'No of Loop Item show', 'barab' ),
                'type' 		=> Controls_Manager::NUMBER,
                'min'       => 1,
                'max'       => 16,
                'default'  	=> __( '6', 'barab' ),
				'condition'	=> [
					'th_show_load_more' => [ 'yes' ],
				]
			]
        );
		$this->add_control(
			'th_loop_item_count',
			[
				'label' 	=> __( 'No of Loop Item show by click', 'barab' ),
                'type' 		=> Controls_Manager::NUMBER,
                'min'       => 1,
                'max'       => 16,
                'default'  	=> __( '3', 'barab' ),
				'condition'	=> [
					'th_show_load_more' => [ 'yes' ],
				]
			]
        );
		$this->add_control(
			'th_load_more_button_text',
			[
				'label' 		=> __( 'Load More Button Text', 'barab' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 	=> __( 'Load More', 'barab' ),
				'condition'	=> [
					'th_show_load_more' => [ 'yes' ],
				]
			]
		);

		$this->add_responsive_control(
			'section_align',
			[
				'label' 		=> __( 'Alignment', 'barab' ),
				'type' 			=> Controls_Manager::CHOOSE,
				'options' 		=> [
					'start' 	=> [
						'title' 		=> __( 'Left', 'barab' ),
						'icon' 			=> 'eicon-text-align-left',
					],
					'center' 	=> [
						'title' 		=> __( 'Center', 'barab' ),
						'icon' 			=> 'eicon-text-align-center',
					],
					'end' 	=> [
						'title' 		=> __( 'Right', 'barab' ),
						'icon' 			=> 'eicon-text-align-right',
					],
				],
				'default' 	=> 'center',
				'toggle' 	=> true,
				'selectors' 	=> [
					'{{WRAPPER}} .load-more-wrap' => 'justify-content: {{VALUE}};',
                ],
                'condition'	=> [
					'th_show_load_more' => [ 'yes' ],
				]
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
			'team_section',
			[
				'label'     => __( 'Widget Content', 'barab' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

        barab_media_fields($this, 'bg_shape', 'Choose BG Shape', ['1']);

		$repeater = new Repeater();

		barab_media_fields($repeater, 'team_image', 'Team Image');
		barab_general_fields($repeater, 'name', 'Name', 'TEXTAREA2', 'Mishel Marsh');
		barab_url_fields($repeater, 'profile_url', 'Profile URL');
		barab_general_fields($repeater, 'designation', 'Designation', 'TEXTAREA2', 'Founder');

		for ( $i = 1; $i <= 5; $i++ ) {
			barab_icon_field( $repeater, "social_icon{$i}", "Social Icon {$i}" );
			barab_url_fields( $repeater, "social_url{$i}", "Social URL {$i}" );
		}
		
		$this->add_control(
			'team_lists',
			[
				'label' 		=> __( 'Member Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'name' 	=> __( 'Mishel Marsh', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['1']
				]
			]
		);

        $this->end_controls_section();

        // Column Responsive controls
		if ( function_exists( 'barab_add_responsive_columns_controls' ) ) {
			barab_add_responsive_columns_controls( $this, ['layout_style' => ['1'] ] );
		}

        
        //---------------------------------------
			//Style Section Start
		//--------------------------------------- 
		barab_common2_style_fields( $this, '01', 'Name', '{{WRAPPER}} .box-title a' );
		barab_common_style_fields( $this, '02', 'Designation', '{{WRAPPER}} .team-desig' );


	}
 
	protected function render() {

        $settings = $this->get_settings_for_display();

        if(!empty($settings['th_show_load_more'])){
            $th_loop_item_show = $settings['th_loop_item_show'] ?? '8';
            $th_loop_item_count = $settings['th_loop_item_count'] ?? '3';
            $th_load_more_button_text = !empty($settings['th_load_more_button_text']) ? $settings['th_load_more_button_text'] : 'Load More';
        }

		if( $settings['layout_style'] == '1' ){
            // Get Column Responsive controls Class
            if ( function_exists( 'barab_get_responsive_columns_class' ) ) {
                $column_class = barab_get_responsive_columns_class( $settings );
            } else {
                $column_class = 'col-xl-3 col-lg-6 col-md-6';
            }

            echo '<div class="row gy-40">';
                $x=0;
                foreach( $settings['team_lists'] as $key => $data ){
                    $x++;
                    $delay = number_format(0.2 * (($key % 4) + 1), 1);
                    $animation = ( floor( (($key)/2) ) % 2 == 0 ) ? 'fadeinleft' : 'fadeinright';

                    echo '<div class="' . esc_attr( $column_class ) . ' th-loop-item">';
                        echo '<div class="th-team team-card wow '.esc_attr($animation).'" data-wow-delay="' . $delay . 's">';
                            echo '<div class="img-wrap">';
                                if(!empty($data['team_image']['url'])){
                                    echo '<div class="team-img">';
                                        echo barab_img_tag( array(
                                            'url'   => esc_url( $data['team_image']['url'] ),
                                        )); 
                                        echo barab_img_tag( array(
                                            'url'   => esc_url( $settings['bg_shape']['url'] ),
                                            'class' => 'team-1-bg-shape'
                                        ));
                                    echo '</div>';
                                }
                                echo '<div class="team-social-hover">';
                                    echo '<div class="th-social">';
											for ( $i = 1; $i <= 5; $i++ ) {
												$icon = $data["social_icon{$i}"] ?? [];
												$url_data = $data["social_url{$i}"] ?? [];

												if ( !empty($icon['value']) && !empty($url_data['url']) ) {
													echo '<a '.barab_link_attrs($url_data).'>';
														Icons_Manager::render_icon( $icon, [ 'aria-hidden' => 'true' ] );
													echo '</a>';
												}
											}
                                    echo '</div>';
                                echo '</div>';
                            echo '</div>';
                            echo '<div class="team-card-content">';
                                if ( $data['name'] ) {
                                    echo '<h3 class="box-title"><a '.barab_link_attrs($data['profile_url']).'>' . esc_html($data['name']) . '</a></h3>';
                                }
                                if($data['designation']){
                                    echo '<span class="team-desig">'.esc_html($data['designation']).'</span>';
                                }
                            echo '</div>';
                        echo '</div>';
                    echo '</div>';
                }
            echo '</div>';

        }elseif( $settings['layout_style'] == '2' ){
	

		}

        if(!empty( $th_loop_item_show )){
            if($x > $th_loop_item_count){
                echo '<div class="mt-5 pt-3 d-flex load-more-wrap">';
                    echo '<button id="load-more-btn" class="th-btn">'.esc_html($th_load_more_button_text).'</button>';
                echo '</div>';
            }
        }

?>
<script>
	jQuery(document).ready(function($) {
		// Set the number of items to show initially and load on each click
		var itemsToShow = <?php echo $th_loop_item_show; ?>;
		var itemsPerLoad = <?php echo $th_loop_item_count; ?>; 
		var currentIndex = itemsToShow;
	
		// Hide items beyond the initial count
		$('.th-loop-item').slice(itemsToShow).hide();      
	
		// Attach a click event to the "Load More" button
		$('#load-more-btn').on('click', function() {
			// Show the next batch of items
			$('.th-loop-item').slice(currentIndex, currentIndex + itemsPerLoad).fadeIn();
			
			// Update the current index
			currentIndex += itemsPerLoad;
	
			// Hide the "Load More" button if all items are displayed
			if (currentIndex >= $('.th-loop-item').length) {
				$('#load-more-btn').hide();
			}
		});
	});
</script>

		<?php


	}

}