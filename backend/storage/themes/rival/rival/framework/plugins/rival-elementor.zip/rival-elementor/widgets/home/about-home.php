<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsAboutHome extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-about-home';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'About Home', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Slider widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-info-circle';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Slider widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'home-elementor' ];
	}

	public function get_keywords() {
		return [ 'abouthome', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_about_home',
			[
				'label' => esc_html__( 'About Home', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
	        'title',
	        [
	            'label'       => __( 'Title', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

	   	$this->add_control(
	        'desc',
	        [
	            'label'       => __( 'Description', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXTAREA,
	            'placeholder' => __( 'Enter your description', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

	   	$this->add_control(
	        'heading',
	        [
	            'label'       => __( 'Heading', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

	   	$this->add_control(
	        'subheading',
	        [
	            'label'       => __( 'Subheading', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

	   	$this->add_control(
	        'image',
	        [
	            'label'       => esc_html__( 'Image Section', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::MEDIA,
	            'dynamic'     => [ 'active' => true ],
	            'label_block' => true,
	            'description' => esc_html__( 'Upload image section', 'bdevs-elementor' ),
	        ]   
	    );

	    $this->add_control(
	        'link_doubleLeft',
	        [
	            'label'       => __( 'Link doubleLeft', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your link', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

	   	$this->add_control(
	        'doubleLeft',
	        [
	            'label'       => __( 'doubleLeft', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

	   	$this->add_control(
	        'choose',
	        [
	            'label'       => __( 'Choose', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

	   	$this->add_control(
	        'link_doubleRight',
	        [
	            'label'       => __( 'Link doubleRight', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your link', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

	   	$this->add_control(
	        'doubleRight',
	        [
	            'label'       => __( 'doubleRight', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

	   	$this->add_control(
	        'info',
	        [
	            'label'       => __( 'Info', 'bdevs-elementor' ),
	            'type'        => Controls_Manager::TEXT,
	            'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),
	            'default'     => __( '', 'bdevs-elementor' ),
	            'label_block' => true,
	        ]   
	   	);

		$this->add_control(
        'tabs',
        [
            'label' => esc_html__( 'About Home Section Item', 'bdevs-elementor' ),
            'type' => Controls_Manager::REPEATER,
            'default' => [
                [
                    'tab_title'   => esc_html__( 'Slide #1', 'bdevs-elementor' ),
                    'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),
                ]
            ],
            'fields' => [
                [
                    'name'        => 'title',
                    'label'       => esc_html__( 'Title', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'link',
                    'label'       => esc_html__( 'Link', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'subtitle',
                    'label'       => esc_html__( 'Subtitle', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
            ],
        ]
  	);

		$this->add_control(
        'tabs2',
        [
            'label' => esc_html__( 'About Home Section Item', 'bdevs-elementor' ),
            'type' => Controls_Manager::REPEATER,
            'default' => [
                [
                    'tab_title'   => esc_html__( 'Slide #1', 'bdevs-elementor' ),
                    'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),
                ]
            ],
            'fields' => [
                [
                    'name'        => 'link',
                    'label'       => esc_html__( 'Link', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
                [
                    'name'        => 'icon',
                    'label'       => esc_html__( 'Icon', 'bdevs-elementor' ),
                    'type'        => Controls_Manager::TEXT,
                    'dynamic'     => [ 'active' => true ],
                    'default'     => esc_html__( '' , 'bdevs-elementor' ),
                    'label_block' => true,
                ],
            ],
        ]
  	);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>
<section id="about" class=" bgGrey">
	<div class="container clearfix">
		<div class="one-third column intro">
			<h1><?php echo wp_kses_post($settings['title']); ?></h1>
			<p><?php echo wp_kses_post($settings['desc']); ?></p>
		</div>
		<div class="one-third column profile tCenter">
			<div class="innerProfile">
				<h1 class="prfTitle"><?php echo wp_kses_post($settings['heading']); ?><span><?php echo wp_kses_post($settings['subheading']); ?></span></h1>
				<div class="imgProfile">
					<img width="220" height="200" alt="" src="<?php echo esc_url($settings['image']['url']); ?>">
				</div>
				<div class="doubleBtn profileBtn">
					<a class="doubleLeft scroll" href="<?php echo wp_kses_post($settings['link_doubleLeft']); ?>"><?php echo wp_kses_post($settings['doubleLeft']); ?></a>
					<span class="choose"><i><?php echo wp_kses_post($settings['choose']); ?></i></span>
					<a class="doubleRight scroll" href="<?php echo wp_kses_post($settings['link_doubleRight']); ?>"><?php echo wp_kses_post($settings['doubleRight']); ?></a>
				</div>
			</div>
		</div>
		<div class="one-third column info">
			<h1><?php echo wp_kses_post($settings['info']); ?></h1>
			<ul>
				<?php
			       $idd = 0;
			       foreach ( $settings['tabs'] as $item ) :
			       $idd++;
			    ?>
					<li><span><?php echo wp_kses_post($item['title']); ?></span><a href="<?php echo wp_kses_post($item['link']); ?>"> <?php echo wp_kses_post($item['subtitle']); ?></a></li>
				<?php endforeach; ?>
			</ul>
			<div class="infoSocial">
				<ul>
					<?php
				       $idd = 0;
				       foreach ( $settings['tabs2'] as $item ) :
				       $idd++;
				    ?>
						<li><a href="<?php echo wp_kses_post($item['link']); ?>"><i class="<?php echo wp_kses_post($item['icon']); ?>"></i></a></li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>
	</div>
</section>
<?php
}

}