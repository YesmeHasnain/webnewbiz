<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsAboutUsSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-about-us-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'About Us Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-alert';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-global' ];
	}

	public function get_keywords() {
		return [ 'aboutussection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_about_us_section',
			[
				'label' => esc_html__( 'About Us Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'img_bg_sec',
			[
				'label'       	=> esc_html__( 'Image Background Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image background section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'heading_sec',
			[
				'label' 		=> esc_html__( 'Heading Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'About Us' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Branding and <br> Identity' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_sec',
			[
				'label' 		=> esc_html__( 'Text Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Text Section' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_btn',
			[
				'label' 		=> esc_html__( 'Text Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Contact Me' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'link_btn',
			[
				'label' 		=> esc_html__( 'Link Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '#' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'img_thumb_1',
			[
				'label'       	=> esc_html__( 'Image Thumbnail 1', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image thumbnail', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'img_thumb_2',
			[
				'label'       	=> esc_html__( 'Image Thumbnail 2', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image thumbnail', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'img_thumb_3',
			[
				'label'       	=> esc_html__( 'Image Thumbnail 3', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image thumbnail', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'img_thumb_4',
			[
				'label'       	=> esc_html__( 'Image Thumbnail 4', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image thumbnail', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'img_thumb_5',
			[
				'label'       	=> esc_html__( 'Image Thumbnail 5', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image thumbnail', 'bdevs-elementor' ),
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-about-us-ptb pt-200 pb-100 p-relative">
	<?php if (!empty($settings['img_bg_sec']['url'])): ?>
		<div class="tp-about-us-bg" data-background="<?php echo wp_kses_post($settings['img_bg_sec']['url']); ?>"></div>
	<?php endif ?>
	<div class="container container-1720">
		<div class="row tp-gx-40">
			<div class="col-lg-3">
				<?php if (!empty($settings['heading_sec'])): ?>
					<div class="tp-about-us-heading-top mb-40">
						<span class="tp-breadcrumb-subtitle"><?php echo wp_kses_post($settings['heading_sec']); ?></span>
					</div>
				<?php endif ?>
			</div>
			<div class="col-lg-6">
				<div class="tp-about-us-heading mb-40">
					<?php if (!empty($settings['title_sec'])): ?>
						<h3 class="tp-breadcrumb-title tp-title-anim"><?php echo wp_kses_post($settings['title_sec']); ?></h3>
					<?php endif ?>
					<?php if (!empty($settings['text_sec'])): ?>						
						<p class="tp-title-anim"><?php echo wp_kses_post($settings['text_sec']); ?></p>
					<?php endif ?>
					<?php if (!empty($settings['text_btn']) && !empty($settings['link_btn'])): ?>
						<div class="tp-about-us-btn tp-title-anim">
							<a href="<?php echo wp_kses_post($settings['link_btn']); ?>">
								<?php echo wp_kses_post($settings['text_btn']); ?>
								<span>
									<svg xmlns="http://www.w3.org/2000/svg" width="19" height="16" viewBox="0 0 19 16" fill="none">
										<path d="M0.000244141 7.6864H17.6905M10.719 -0.00012207C10.719 4.25019 14.4209 7.68944 18.9958 7.68944M18.9958 7.6864C14.4209 7.6864 10.719 11.1257 10.719 15.376" stroke="#121212" stroke-width="1.5" stroke-miterlimit="10"/>
									</svg>
								</span>
							</a>
						</div>
					<?php endif ?>
				</div>
			</div>
			<div class="col-lg-3 col-md-6">
				<?php if (!empty($settings['img_thumb_1']['url'])): ?>
					<div class="anim-zoomin-wrap">
						<div class="tp-about-us-thumb anim-zoomin text-end mb-40">
							<a href="<?php echo wp_kses_post($settings['img_thumb_1']['url']); ?>" class="about-popup-image">
								<img src="<?php echo wp_kses_post($settings['img_thumb_1']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_thumb_1']['alt']); ?>">
							</a>
						</div>
					</div>
				<?php endif ?>
			</div>
			<div class="col-lg-3 col-md-6">
				<?php if (!empty($settings['img_thumb_2']['url'])): ?>
					<div class="anim-zoomin-wrap">
						<div class="tp-about-us-thumb anim-zoomin mb-40">
							<a href="<?php echo wp_kses_post($settings['img_thumb_2']['url']); ?>" class="about-popup-image">
								<img src="<?php echo wp_kses_post($settings['img_thumb_2']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_thumb_2']['alt']); ?>">
							</a>
						</div>
					</div>
				<?php endif ?>
				<?php if (!empty($settings['img_thumb_3']['url'])): ?>
					<div class="anim-zoomin-wrap">
						<div class="tp-about-us-thumb anim-zoomin mb-40">
							<a href="<?php echo wp_kses_post($settings['img_thumb_3']['url']); ?>" class="about-popup-image">
								<img src="<?php echo wp_kses_post($settings['img_thumb_3']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_thumb_3']['alt']); ?>">
							</a>
						</div>
					</div>
				<?php endif ?>
			</div>
			<div class="col-lg-6 col-md-6">
				<?php if (!empty($settings['img_thumb_4']['url'])): ?>
					<div class="anim-zoomin-wrap">
						<div class="tp-about-us-thumb anim-zoomin mb-40">
							<a href="<?php echo wp_kses_post($settings['img_thumb_4']['url']); ?>" class="about-popup-image">
								<img src="<?php echo wp_kses_post($settings['img_thumb_4']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_thumb_4']['alt']); ?>">
							</a>
						</div>
					</div>
				<?php endif ?>
			</div>
			<div class="col-lg-3 col-md-6">
				<?php if (!empty($settings['img_thumb_5']['url'])): ?>
					<div class="anim-zoomin-wrap">
						<div class="tp-about-us-thumb anim-zoomin mb-40">
							<a href="<?php echo wp_kses_post($settings['img_thumb_5']['url']); ?>" class="about-popup-image">
								<img src="<?php echo wp_kses_post($settings['img_thumb_5']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_thumb_5']['alt']); ?>">
							</a>
						</div>
					</div>
				<?php endif ?>
			</div>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-background]").each(function () {
			jQuery(this).css("background-image", "url( " + $(this).attr("data-background") + "  )");
		});

		if (jQuery('.tp-title-anim').length > 0) {
			let splitTitleLines = gsap.utils.toArray(".tp-title-anim");
			splitTitleLines.forEach(splitTextLine => {
				const tl = gsap.timeline({
				scrollTrigger: {
					trigger: splitTextLine,
					start: 'top 90%',
					end: 'bottom 60%',
					scrub: false,
					markers: false,
					toggleActions: 'play none none none'
				}
				});
	
				const itemSplitted = new SplitText(splitTextLine, { type: "words, lines" });
				gsap.set(splitTextLine, { perspective: 300});
				itemSplitted.split({ type: "lines" })
				tl.from(itemSplitted.lines, { duration: 1, delay: 0.3, opacity: 0, rotationX: -50, force3D: true, transformOrigin: "top center -50", stagger: 0.2 });
			});	
		}

		jQuery(".anim-zoomin").each(function() {

			// Add wrap <div>.
			jQuery(this).wrap('<div class="anim-zoomin-wrap"></div>');

			// Add overflow hidden.
			jQuery(".anim-zoomin-wrap").css({ "overflow": "hidden" })

			var $this = $(this);
			var $asiWrap = $this.parents(".anim-zoomin-wrap");

			let tp_ZoomIn = gsap.timeline({
				scrollTrigger: {
					trigger: $asiWrap,
					start: "top 100%",
					markers: false,
				}
			});
			tp_ZoomIn.from($this, { duration: 1.5, autoAlpha: 0, scale: 1.2, ease: Power2.easeOut, clearProps:"all" });

		});
	</script>
<?php } ?>

<?php
}

}