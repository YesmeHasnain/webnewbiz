<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
use Elementor\Icons_Manager;
/**
 *
 * Team Widget .
 *
 */
class barab_Team extends Widget_Base {

	public function get_name() {
		return 'barabteam';
	}
	public function get_title() {
		return __( 'Team', 'barab' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'barab' ];
	}
 
	protected function register_controls() {

		$this->start_controls_section(
			'team_section',
			[
				'label'     => __( 'Team Content', 'barab' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

		barab_select_field( $this, 'layout_style', 'Layout Style', [ 'Style One', 'Style Two', 'Style Three' ] );

		barab_media_fields($this, 'bg_shape', 'Choose BG Shape', ['1', '2']);
		barab_media_fields($this, 'bg_shape2', 'Choose Line Shape', ['3']);

		$repeater = new Repeater();

		barab_media_fields($repeater, 'team_image', 'Team Image');
		barab_general_fields($repeater, 'name', 'Name', 'TEXTAREA2', 'Mishel Marsh');
		barab_url_fields($repeater, 'profile_url', 'Profile URL');
		barab_general_fields($repeater, 'designation', 'Designation', 'TEXTAREA2', 'Founder');

		for ( $i = 1; $i <= 4; $i++ ) {
			barab_icon_field( $repeater, "social_icon{$i}", "Social Icon {$i}" );
			barab_url_fields( $repeater, "social_url{$i}", "Social URL {$i}" );
		}
		
		$this->add_control(
			'team_lists',
			[
				'label' 		=> __( 'Member Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'name' 	=> __( 'Mishel Marsh', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['1', '2']
				]
			]
		);

		$repeater = new Repeater();

		barab_media_fields($repeater, 'team_image', 'Team Image');
		barab_general_fields($repeater, 'name', 'Name', 'TEXTAREA2', 'Mishel Marsh');
		barab_url_fields($repeater, 'profile_url', 'Profile URL');
		barab_general_fields($repeater, 'designation', 'Designation', 'TEXTAREA2', 'Founder');
		barab_general_fields($repeater, 'circle_text', 'Circle Text', 'TEXTAREA2', 'View More Details* View More Details*');

		barab_url_fields($repeater, 'facebook_url', 'Facebook URL');
		barab_url_fields($repeater, 'twitter_url', 'Twitter URL');
		barab_url_fields($repeater, 'instagram_url', 'Instagram URL');
		barab_url_fields($repeater, 'linkedin_url', 'LinkedIn URL');
		
		$this->add_control(
			'team_lists2',
			[
				'label' 		=> __( 'Member Lists', 'barab' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'name' 	=> __( 'Mishel Marsh', 'barab' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['3']
				]
			]
		);

        $this->end_controls_section();

		// Column Responsive controls
		if ( function_exists( 'barab_add_responsive_columns_controls' ) ) {
			barab_add_responsive_columns_controls( $this, ['layout_style' => ['1', '2'] ] );
		}

        //---------------------------------------
			//Style Section Start
		//--------------------------------------- 
		barab_common2_style_fields( $this, '01', 'Name', '{{WRAPPER}} .box-title a' );
		barab_common_style_fields( $this, '02', 'Designation', '{{WRAPPER}} .team-desig' );

	}

	protected function render() {

        $settings = $this->get_settings_for_display();

			if( $settings['layout_style'] == '1' ){
				// Get Column Responsive controls Class
				if ( function_exists( 'barab_get_responsive_columns_class' ) ) {
					$column_class = barab_get_responsive_columns_class( $settings );
				} else {
					$column_class = 'col-xl-3 col-lg-6 col-md-6';
				}

	            echo '<div class="row gy-40 team-1-nth gsap-card-animation-wrapper">';
     				foreach( $settings['team_lists'] as $key => $data ){
						$delay = number_format(0.2 * (($key - 1) % 4 + 2), 1);
						$animation = ( floor( (($key)/2) ) % 2 == 0 ) ? 'fadeinleft' : 'fadeinright';

						echo '<div class="' . esc_attr( $column_class ) . '">';
							echo '<div class="th-team team-card wow '.esc_attr($animation).'" data-wow-delay="' . $delay . 's">';
								echo '<div class="img-wrap">';
									if(!empty($data['team_image']['url'])){
										echo '<div class="team-img">';
											echo barab_img_tag( array(
												'url'   => esc_url( $data['team_image']['url'] ),
											)); 
											echo barab_img_tag( array(
												'url'   => esc_url( $settings['bg_shape']['url'] ),
												'class' => 'team-1-bg-shape'
											));
										echo '</div>';
									}
									echo '<div class="team-social-hover">';
										echo '<div class="th-social">';
											for ( $i = 1; $i <= 4; $i++ ) {
												$icon = $data["social_icon{$i}"] ?? [];
												$url_data = $data["social_url{$i}"] ?? [];

												if ( !empty($icon['value']) && !empty($url_data['url']) ) {
													echo '<a '.barab_link_attrs($url_data).'>';
														Icons_Manager::render_icon( $icon, [ 'aria-hidden' => 'true' ] );
													echo '</a>';
												}
											}
										echo '</div>';
									echo '</div>';
								echo '</div>';
								echo '<div class="team-card-content">';
									if ( $data['name'] ) {
										echo '<h3 class="box-title"><a '.barab_link_attrs($data['profile_url']).'>' . esc_html($data['name']) . '</a></h3>';
									}
									if($data['designation']){
										echo '<span class="team-desig">'.esc_html($data['designation']).'</span>';
									}
								echo '</div>';
							echo '</div>';
						echo '</div>';
	 				}
                echo '</div>';

			}elseif( $settings['layout_style'] == '2' ){
			  	// Get Column Responsive controls Class
				if ( function_exists( 'barab_get_responsive_columns_class' ) ) {
					$column_class = barab_get_responsive_columns_class( $settings );
				} else {
					$column_class = 'col-xl-3 col-lg-6 col-md-6';
				}

	            echo '<div class="row gy-40">';
     				foreach( $settings['team_lists'] as $key => $data ){
						$delay = number_format(0.2 * (($key - 1) % 4 + 2), 1);
						$animation = ( floor( (($key)/2) ) % 2 == 0 ) ? 'fadeinleft' : 'fadeinright';

						echo '<div class="' . esc_attr( $column_class ) . '">';
							echo '<div class="th-team team-card wow '.esc_attr($animation).'" data-wow-delay="' . $delay . 's">';
								echo '<div class="img-wrap">';
									if(!empty($data['team_image']['url'])){
										echo '<div class="team-img">';
											echo barab_img_tag( array(
												'url'   => esc_url( $data['team_image']['url'] ),
											)); 
											echo barab_img_tag( array(
												'url'   => esc_url( $settings['bg_shape']['url'] ),
												'class' => 'team-1-bg-shape'
											));
										echo '</div>';
									}
									echo '<div class="team-social-hover">';
										echo '<div class="th-social">';
											for ( $i = 1; $i <= 4; $i++ ) {
												$icon = $data["social_icon{$i}"] ?? [];
												$url_data = $data["social_url{$i}"] ?? [];

												if ( !empty($icon['value']) && !empty($url_data['url']) ) {
													echo '<a '.barab_link_attrs($url_data).'>';
														Icons_Manager::render_icon( $icon, [ 'aria-hidden' => 'true' ] );
													echo '</a>';
												}
											}
										echo '</div>';
									echo '</div>';
								echo '</div>';
								echo '<div class="team-card-content">';
									if ( $data['name'] ) {
										echo '<h3 class="box-title"><a '.barab_link_attrs($data['profile_url']).'>' . esc_html($data['name']) . '</a></h3>';
									}
									if($data['designation']){
										echo '<span class="team-desig">'.esc_html($data['designation']).'</span>';
									}
								echo '</div>';
							echo '</div>';
						echo '</div>';
	 				}
                echo '</div>';

			}elseif( $settings['layout_style'] == '3' ){
				echo '<div class="slider-area"> ';
					if(!empty($settings['bg_shape2']['url'])){
						echo '<div class="team3-shape shape-mockup" data-top="29%">';
							echo barab_img_tag( array(
								'url'   => esc_url( $settings['bg_shape2']['url'] ),
							));
						echo '</div>';
					}
					echo '<div class="swiper th-slider has-shadow translateSlider team2Slider" id="team2Slider" data-slider-options=\'{"centeredSlides":true,"breakpoints":{"0":{"slidesPerView":1},"576":{"slidesPerView":1},"768":{"spaceBetween":50,"slidesPerView":2},"992":{"spaceBetween":130,"slidesPerView":2},"1200":{"spaceBetween":150,"slidesPerView":3}},"autoplay":false}\'>';
						echo '<div class="swiper-wrapper">';
						foreach( $settings['team_lists2'] as $key => $data ){
								echo '<div class="swiper-slide">';
									echo '<div class="th-team team-card style2 single">';
										echo '<div class="team-img">';
											echo barab_img_tag( array(
												'url'   => esc_url( $data['team_image']['url'] ),
											)); 
											echo '<div class="team-left-social">';
												echo '<ul>';
													if(!empty($data['facebook_url']['url'])){
														echo '<li><a '.barab_link_attrs($data['facebook_url']).'>'.esc_html__('Facebook', 'faren').'</a></li>';
													}
													if(!empty($data['twitter_url']['url'])){
														echo '<li><a '.barab_link_attrs($data['twitter_url']).'>'.esc_html__('Twitter', 'faren').'</a></li>';
													}
													if(!empty($data['instagram_url']['url'])){
														echo '<li><a '.barab_link_attrs($data['instagram_url']).'>'.esc_html__('Instagram', 'faren').'</a></li>';
													}
													if(!empty($data['linkedin_url']['url'])){
														echo '<li><a '.barab_link_attrs($data['linkedin_url']).'>'.esc_html__('Linkedin', 'faren').'</a></li>';
													}
												echo '</ul>';
											echo '</div>';
											if(!empty($data['circle_text'])){
												echo '<div class="team3-img-shape">';
													echo '<div class="logo-icon-wrap">';
														echo '<div class="logo-icon">';
															echo '<a '.barab_link_attrs($data['profile_url']).'>';
																echo '<img src="'.BARAB_ASSETS.'img/icon/menu-right-arrows.svg" alt="img">';
															echo '</a>';
														echo '</div>';
														echo '<div class="logo-icon-wrap__text">';
															echo '<span class="logo-animation">'.esc_html($data['circle_text']).'</span>';
														echo '</div>';
													echo '</div>';
												echo '</div>';
											}
										echo '</div>';
										echo '<div class="team-card-content">';
											if ( $data['name'] ) {
												echo '<h3 class="box-title2"><a '.barab_link_attrs($data['profile_url']).'>' . esc_html($data['name']) . '</a></h3>';
											}
											if($data['designation']){
												echo '<span class="team-desig">'.esc_html($data['designation']).'</span>';
											}
										echo '</div>';
									echo '</div>';
								echo '</div>';
						}
						echo '</div>';
						echo '<div class="team-3-pagination">';
							echo '<span class="line-1"></span>';
							echo '<div class="slider-pagination"></div>';
							echo '<span class="line-1 style2"></span>';
						echo '</div>';
					echo '</div>';

					echo '<button data-slider-prev="#team2Slider" class="testi3-arrow slider-arrow slider-prev"><i class="far fa-arrow-left"></i></button>';
					echo '<button data-slider-next="#team2Slider" class="testi3-arrow slider-arrow slider-next"><i class="far fa-arrow-right"></i></button>';
				echo '</div>';
 
			}elseif( $settings['layout_style'] == '4' ){


			}
	
			
	}
}