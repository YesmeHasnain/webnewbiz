<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome1PortfolioSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home1-portfolio-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 1 - Portfolio Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-posts-grid';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home1' ];
	}

	public function get_keywords() {
		return [ 'home1portfoliosection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}
	

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_portfolio_section',
			[
				'label' => esc_html__( 'Home 1 Portfolio Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'bg_color',
			[
				'label' 		=> esc_html__( 'Background Color (Default: #ffffff)', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::COLOR,
				'default'		=> '#ffffff',
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Explore <br> our recent  work' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_btn',
			[
				'label' 		=> esc_html__( 'Text Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'View All' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'link_btn',
			[
				'label' 		=> esc_html__( 'Link Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '#' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'item_column',
			[
				'label'     	=> esc_html__( 'Item Column', 'bdevs-elementor' ),
				'type'      	=> Controls_Manager::SELECT,
				'options'   	=> [
					'type1'  		=> esc_html__( 'Two Columns', 'bdevs-elementor' ),
					'type2'  		=> esc_html__( 'Three Columns', 'bdevs-elementor' ),
					'type3'  		=> esc_html__( 'Four Columns', 'bdevs-elementor' ),
				],
				'default'   	=> 'type1',
			]
		);
		$this->add_control(
			'post_number',
			[
				'label'       => __( 'Post Number', 'bdevs-elementor' ),
				'type'        => Controls_Manager::NUMBER,
				'placeholder' => __( 'Enter your post number', 'bdevs-elementor' ),
				'min'		  => 0,
				'default'     => __( '6', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order_by',
			[
				'label'       => __( 'Post Order By', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text post order by', 'bdevs-elementor' ),
				'default'     => __( 'ID', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
				],
				'default'   => 'desc',
			]
		);
		$this->add_control(
			'text_btn_hover',
			[
				'label' 		=> esc_html__( 'Text Button Hover Image', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'View<br>Demo' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section id="down" class="tp-project-ptb pt-150 pb-40" data-bg-color="<?php echo wp_kses_post($settings['bg_color']); ?>">
	<div class="container">
		<?php if (!empty($settings['title_sec']) || (!empty($settings['link_btn']) && !empty($settings['text_btn']))): ?>
			<div class="row align-items-end">
				<div class="col-lg-8">
					<?php if (!empty($settings['title_sec'])): ?>
						<div class="tp-project-heading mb-70">
							<h3 class="tp-section-title titleBurrowing"><?php echo wp_kses_post($settings['title_sec']); ?></h3>
						</div>
					<?php endif ?>
				</div>
				<?php if (!empty($settings['link_btn']) && !empty($settings['text_btn'])): ?>
					<div class="col-lg-4">
						<div class="tp-project-btn text-lg-end mb-70">
							<a class="tp-btn button-style-2" href="<?php echo wp_kses_post($settings['link_btn']); ?>">
								<?php echo wp_kses_post($settings['text_btn']); ?>
								<span>
									<svg xmlns="http://www.w3.org/2000/svg" width="19" height="16" viewBox="0 0 19 16" fill="none">
										<path d="M0 7.80933H17.6902M10.7188 0C10.7188 4.31672 14.4207 7.80972 18.9956 7.80972C14.4207 7.80972 10.7188 11.3023 10.7188 15.6191" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10"/>
									</svg>
								</span>
							</a>
						</div>
					</div>
				<?php endif ?>
			</div>
		<?php endif ?>
		<div class="row tp-gx-50">
			<?php
			$wp_query = new \WP_Query([
				'post_type'      => 'portfolio',
				'posts_per_page' => intval($settings['post_number']),
				'orderby'        => sanitize_text_field($settings['post_order_by']),
				'order'          => sanitize_text_field($settings['post_order']),
			]);
			$i = 0;
			while($wp_query->have_posts()): $wp_query->the_post();
				$i++;
				$data_speed = '1.1';
				if ($i % 4 == 1) {
				    $data_speed = '0.9';
				} elseif ($i % 4 == 3) {
				    $data_speed = '0.8';
				}
				$port_title = get_post_meta(get_the_ID(),'_cmb_port_title_home_1', true);
				$port_excerpt = get_post_meta(get_the_ID(),'_cmb_port_excerpt_home_1', true);
				$img_id = get_post_meta(get_the_ID(),'_cmb_port_thumb_home_1', true);
				if (!empty($img_id)) {
					$img_url = wp_get_attachment_url($img_id);
				} else {
					$img_url = get_the_post_thumbnail_url();
				}
			?>
				<?php if ($settings['item_column'] === 'type2') { ?>
					<div class="col-lg-4">
				<?php } elseif ($settings['item_column'] === 'type3') { ?>
					<div class="col-lg-3">
				<?php } else { ?>
					<div class="col-lg-6">
				<?php } ?>
						<div class="tp-project-item mb-120">
							<?php if (!empty($img_id) || has_post_thumbnail()): ?>
								<?php if (!empty($settings['text_btn_hover'])) { ?>
									<div class="tp-project-item-thumb p-relative fix not-hide-cursor" data-cursor="<?php echo wp_kses_post($settings['text_btn_hover']); ?>">
								<?php } else { ?>
									<div class="tp-project-item-thumb p-relative fix not-hide-cursor">
								<?php } ?>
										<a class="cursor-hide" href="<?php the_permalink(); ?>">
											<?php if (!empty($img_id)) { ?>
												<img data-speed="<?php echo esc_attr($data_speed); ?>" src="<?php echo esc_url($img_url); ?>" alt="<?php the_title_attribute(); ?>">
											<?php } else { ?>
												<img data-speed="<?php echo esc_attr($data_speed); ?>" src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title_attribute(); ?>">
											<?php } ?>
										</a>
									</div>
							<?php endif ?>
							<div class="tp-project-item-content d-flex align-items-start justify-content-between">
								<div class="tp-project-item-content-left">
									<h3 class="tp-project-item-title">
										<a class="textline" href="<?php the_permalink(); ?>">
											<?php if (!empty($port_title)) { ?>
												<?php print wp_specialchars_decode($port_title); ?>
											<?php } else { ?>
												<?php the_title(); ?>
											<?php } ?>
										</a>
									</h3>
									<p>
										<?php if ( '' !== wp_specialchars_decode($port_excerpt)): ?>
											<?php print wp_specialchars_decode($port_excerpt); ?>
										<?php else:?>
											<?php if(isset($nixer_redux_demo['blog_excerpt'])){?>
											<?php echo esc_attr(nixer_excerpt_2($nixer_redux_demo['blog_excerpt'])); ?>
											<?php }else{?>
											<?php echo esc_attr(nixer_excerpt_2(15)); 
											}?>
										<?php endif ?>
									</p>
								</div>
								<div class="tp-project-item-content-right">
									<?php 
									$terms = get_the_terms( get_the_ID(), 'portfolio-cat' );
									if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
										foreach ( $terms as $term ) {
											echo '<div class="tp-project-item-content-right-btn"><span>' . esc_html( $term->name ) . '</span></div>';
										}
									} ?>
								</div>
							</div>
						</div>
					</div>
			<?php endwhile; ?>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-bg-color]").each(function () {
			jQuery(this).css("background-color", jQuery(this).attr("data-bg-color"));
		});

		function setupSplits() {
		// Target all elements with class "animate-text"
		var elements = document.querySelectorAll('.titleBurrowing');

		// Loop over each element and apply SplitText animation
		elements.forEach(element => {
			var tlSplit = gsap.timeline(),
				splitInstance = new SplitText(element, {type: "words,chars"}),
				chars = splitInstance.chars; // Array of divs wrapping each character
			
			tlSplit.from(chars, {
			duration: 0.8,
			opacity: 0,
			y: 10,
			ease: "circ.out",
			stagger: 0.02,
			scrollTrigger: {
				trigger: element,
				start: "top 75%",
				end: "bottom center",
				scrub: 1
			}
			});
		});
		}

		ScrollTrigger.addEventListener("refresh", setupSplits);
		setupSplits();

		if ($("body").not(".is-mobile").hasClass("tp-magic-cursor")) {
			$(".tp-magnetic-item").wrap('<div class="tp-magnetic-wrap"></div>');
			
			if ($("a.tp-magnetic-item").length) {
				$("a.tp-magnetic-item").addClass("not-hide-cursor");
			}

			var $mouse = { x: 0, y: 0 }; // Cursor position
			var $pos = { x: 0, y: 0 }; // Cursor position
			var $ratio = 0.15; // delay follow cursor
			var $active = false;
			var $ball = $("#ball");

			var $ballWidth = 14; // Ball default width
			var $ballHeight = 14; // Ball default height
			var $ballScale = 1; // Ball default scale
			var $ballOpacity = 1; // Ball default opacity
			var $ballBorderWidth = 1; // Ball default border width

			gsap.set($ball, {  // scale from middle and style ball
				xPercent: -50, 
				yPercent: -50, 
				width: $ballWidth,
				height: $ballHeight,
				borderWidth: $ballBorderWidth, 
				opacity: $ballOpacity 
			});

			document.addEventListener("mousemove", mouseMove);

			function mouseMove(e) {
				$mouse.x = e.clientX;
				$mouse.y = e.clientY;
			}

			gsap.ticker.add(updatePosition);

			function updatePosition() {
				if (!$active) {
					$pos.x += ($mouse.x - $pos.x) * $ratio;
					$pos.y += ($mouse.y - $pos.y) * $ratio;

					gsap.set($ball, { x: $pos.x, y: $pos.y });
				}
			}

			$(".tp-magnetic-wrap").mousemove(function(e) {
				parallaxCursor(e, this, 2); // magnetic ball = low number is more attractive
				callParallax(e, this);
			});

			function callParallax(e, parent) {
				parallaxIt(e, parent, parent.querySelector(".tp-magnetic-item"), 25); // magnetic area = higher number is more attractive
			}

			function parallaxIt(e, parent, target, movement) {
				var boundingRect = parent.getBoundingClientRect();
				var relX = e.clientX - boundingRect.left;
				var relY = e.clientY - boundingRect.top;

				gsap.to(target, {
					duration: 0.3, 
					x: ((relX - boundingRect.width / 2) / boundingRect.width) * movement,
					y: ((relY - boundingRect.height / 2) / boundingRect.height) * movement,
					ease: Power2.easeOut
				});
			}

			function parallaxCursor(e, parent, movement) {
				var rect = parent.getBoundingClientRect();
				var relX = e.clientX - rect.left;
				var relY = e.clientY - rect.top;
				$pos.x = rect.left + rect.width / 2 + (relX - rect.width / 2) / movement;
				$pos.y = rect.top + rect.height / 2 + (relY - rect.height / 2) / movement;
				gsap.to($ball, {duration: 0.3, x: $pos.x, y: $pos.y });
			}


			// Magnetic item hover.
			$(".tp-magnetic-wrap").on("mouseenter", function(e) {
				gsap.to($ball, { duration: 0.3, scale: 2, borderWidth: 1, opacity: $ballOpacity });
				$active = true;
			}).on("mouseleave", function(e) {
				gsap.to($ball, { duration: 0.3, scale: $ballScale, borderWidth: $ballBorderWidth, opacity: $ballOpacity });
				gsap.to(this.querySelector(".tp-magnetic-item"), { duration: 0.3, x: 0, y: 0, clearProps:"all" });
				$active = false;
			});

			// Cursor view on hover (data attribute "data-cursor="...").
			$("[data-cursor]").each(function() {
				$(this).on("mouseenter", function() {
					$("#ball").addClass("with-blur");
					$ball.append('<div class="ball-view"></div>');
					$(".ball-view").append($(this).attr("data-cursor"));
					gsap.to($ball, { duration: 0.3, xPercent: is_rtl()? 50 : -50,yPercent: -60, width: 110, height: 110, opacity: 1, borderWidth: 0, zIndex:1, backdropFilter: "blur(14px)",
					backgroundColor: "#fff"});
					gsap.to(".ball-view", { duration: 0.3, scale: 1, autoAlpha: 1 });
				}).on("mouseleave", function() {
					gsap.to($ball, { duration: 0.3, yPercent: -50, width: $ballWidth, height: $ballHeight, opacity: $ballOpacity, borderWidth: $ballBorderWidth, backgroundColor: "#000" });
					gsap.to(".ball-view", { duration: 0.3, scale: 0, autoAlpha: 0, clearProps:"all" });
					$ball.find(".ball-view").remove();
				});
				$(this).addClass("not-hide-cursor");
			});
			
			
			// Show/hide magic cursor // 

			// Hide on hover//
			$("a, button") // class "hide-cursor" is for global use.
			.not('.cursor-hide') // omit from selection.
			.on("mouseenter", function() {
				gsap.to($ball, { duration: 0.3, scale: 0, opacity: 0 });
			}).on("mouseleave", function() {
				gsap.to($ball, { duration: 0.3, scale: $ballScale, opacity: $ballOpacity });
			});

			// Hide on click//
			$("a")
				.not('[target="_blank"]') // omit from selection.
				.not('.cursor-hide') // omit from selection.
				.not('[href^="#"]') // omit from selection.
				.not('[href^="mailto"]') // omit from selection.
				.not('[href^="tel"]') // omit from selection.
				.not(".lg-trigger") // omit from selection.
				.not(".tp-btn-disabled a") // omit from selection.
				.on('click', function() {
					gsap.to($ball, { duration: 0.3, scale: 1.3, autoAlpha: 0 });
			});

			// Show/hide on document leave/enter//
			$(document).on("mouseleave", function() {
				gsap.to("#magic-cursor", { duration: 0.3, autoAlpha: 0 });
			}).on("mouseenter", function() {
				gsap.to("#magic-cursor", {duration: 0.3, autoAlpha: 1 });
			});

			// Show as the mouse moves//
			$(document).on("mousemove", function() {
				gsap.to("#magic-cursor", {duration: 0.3, autoAlpha: 1 });
			});
		}


		function is_rtl(){
			return $('html').attr('dir') == 'rtl' ? true: false;
		}

		gsap.registerPlugin(ScrollTrigger, ScrollSmoother);
		var smoother = ScrollSmoother.create({
			smooth: 2,
			effects: true,
			smoothTouch: true
		});
	</script>
<?php } ?>

<?php
}

}