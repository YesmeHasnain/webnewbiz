<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome8PortfolioCarousel extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home-8-portfolio-carousel';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 8 - Portfolio Carousel', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-posts-carousel';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home8' ];
	}

	public function get_keywords() {
		return [ 'home8portfoliocarousel', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_portfolio_section',
			[
				'label' => esc_html__( 'Portfolio Carousel', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Nicolas' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'post_number',
			[
				'label'       => __( 'Post Number', 'bdevs-elementor' ),
				'type'        => Controls_Manager::NUMBER,
				'placeholder' => __( 'Enter your post number', 'bdevs-elementor' ),
				'min'		  => 0,
				'default'     => __( '10', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order_by',
			[
				'label'       => __( 'Post Order By', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text post order by', 'bdevs-elementor' ),
				'default'     => __( 'ID', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
				],
				'default'   => 'desc',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-hero-8-ptb pt-100 pb-50">
	<div class="container-fluid gx-0">
		<?php if (!empty($settings['title_sec'])): ?>
			<div class="row">
				<div class="col-lg-12">
					<div class="tp-hero-8-slider-heading pb-50">
						<h3 class="tp-hero-8-slider-title"><?php echo wp_kses_post($settings['title_sec']); ?></h3>
					</div>
				</div>
			</div>
		<?php endif ?>
		<div class="row gx-0">
			<div class="tp-hero-8-wrapper">
				<div class="tp-hero-8-active swiper">
					<div class="swiper-wrapper">
						<?php
						$wp_query = new \WP_Query([
							'post_type'      => 'portfolio',
							'posts_per_page' => intval($settings['post_number']),
							'orderby'        => sanitize_text_field($settings['post_order_by']),
							'order'          => sanitize_text_field($settings['post_order']),
						]);

						$i = 0;
						while($wp_query->have_posts()): $wp_query->the_post();
							$i++;

							$port_title = get_post_meta(get_the_ID(),'_cmb_port_title_home_8', true);
							$port_year 	= get_post_meta(get_the_ID(),'_cmb_port_year_home_8', true);
							$img_id 	= get_post_meta(get_the_ID(),'_cmb_port_thumb_home_8', true);

							$title = !empty($port_title) ? $port_title : get_the_title();
							if (!empty($img_id)) {
								$img_url = wp_get_attachment_url($img_id);
							} elseif (has_post_thumbnail()) {
								$img_url = get_the_post_thumbnail_url();
							} else {
								$img_url = get_template_directory_uri() . '/assets/img/hero/home-8/hero-8-1.jpg';
							}
						?>
							<div class="swiper-slide">
								<div class="tp-hero-8-slider-item p-relative">
									<div class="tp-hero-8-slider-item-thumb p-relative">
										<img class="ratio-21x25" src="<?php echo esc_url($img_url); ?>" alt="<?php the_title_attribute(); ?>">
										<?php if (!empty($port_year)): ?>
											<span class="tp-hero-8-slider-item-yer"><?php echo wp_kses_post($port_year); ?></span>
										<?php endif ?>
									</div>
									<div class="tp-hero-8-slider-item-content">
										<h4 class="tp-hero-8-slider-item-title">
											<a href="<?php the_permalink() ?>"><?php echo wp_kses_post($title); ?></a>
										</h4>
									</div>
								</div>
							</div>
						<?php endwhile; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		if (jQuery('.tp-hero-8-active').length > 0) {
			var slider = new Swiper('.tp-hero-8-active', {
				slidesPerView: 4,
				speed: 1000,
				loop: true,
				mousewheel: true,
				spaceBetween: 30,
				autoplay: {
					delay: 5000,
				},
				breakpoints: {
					'1400': {
						slidesPerView: 4,
					},
					'1200': {
						slidesPerView: 4,
					},
					'992': {
						slidesPerView: 4,
					},
					'768': {
						slidesPerView: 3,
					},
					'576': {
						slidesPerView: 2,
					},
					'0': {
						slidesPerView: 1,
					},
				},
			});
		}
	</script>
<?php } ?>

<?php
}

}