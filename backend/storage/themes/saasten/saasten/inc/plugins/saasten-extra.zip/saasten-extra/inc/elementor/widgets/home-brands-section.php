<?php

/**
 * Elementor Widget
 * @package Saasten
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_home_brands_one extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'theme-brands-onee';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Home Brands 1', 'saasten-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saasten_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {



       $this->start_controls_section( 'section_content_brandtop_one', [
            'label' => esc_html__( 'Top Heading', 'saasten-extra' ),
        ] ); 

        $this->add_control( 'sub-title', [
            'label'       => __( 'Sub Title', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => __( 'Trusted by 20,000+ clients', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type section subtitle here.", 'saasten-extra' ),
        ] );

        $this->add_control( 'title', [
            'label'       => __( 'Title', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Invest in Startup', 'saasten-extra' ),
            'label_block' => true,
            'description' => __( "Type section title here.", 'saasten-extra' ),

        ] );


        $this->end_controls_section();



        $this->start_controls_section( 'section_content_brands_one1', [
            'label' => esc_html__( 'Brand Items', 'saasten-extra' ),
        ] ); 

        $this->add_control( 'featureItems', [
            'label'       => esc_html__( 'Brand items', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'default'     => [
                [
                    'brand_title'        => esc_html__( 'Krisp', 'saasten-extra' ),
                ]
            ],

            'fields'      => [
                [
                    'name'        => 'brand_title',
                    'label'       => esc_html__( 'Brand Title', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'description' => esc_html__( 'Enter Brand Title', 'saasten-extra' )
                ],

                [
                    'name'        => 'brand_image',
                    'label'       => esc_html__( 'Service Image', 'deaxautt-extra' ),
                    'type'        => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                    ],

                    'description' => esc_html__( 'Upload brand image', 'deaxautt-extra' )
                ],
                

                [
                    'name'        => 'brand_link',
                    'label'       => esc_html__( 'Brand Link', 'deaxautt-extra' ),
                    'type'        => \Elementor\Controls_Manager::URL,
                    'placeholder' => __( 'https://your-link.com', 'deaxautt-extra' ),
                    'default'     => [
                        'url' => '#',
                    ],
                ],


                

            ],
            'title_field' => "{{name}}"
        ] );



        $this->end_controls_section();


		
	}
	


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

        $featureItems = $settings['featureItems'];

        extract($settings); 


		
		?>





    <section class="trust-area fluid-space">
      <div class="container-fluid p-0">
        <div class="row">
          <div class="col-12 mg-btm-40">
            <!-- Section Title -->
            <div
              class="section-title-v3 text-center aos-init aos-animate"
              data-aos="fade-in"
            >
              <div class="section-title-v3-flex mg-btm-20">
                <p class="section-title-v3__label m-0">
                  <?php echo wp_kses_post( $settings['sub-title'] ); ?>
                </p>
                <div
                  class="ratting-icons ratting-icons--v3 saastain-flex-start saastain-flex-gap-5"
                >
                  <span><i class="fas fa-star"></i></span>
                  <span><i class="fas fa-star"></i></span>
                  <span><i class="fas fa-star"></i></span>
                  <span><i class="fas fa-star"></i></span>
                  <span><i class="far fa-star"></i></span>
                </div>
              </div>
              <h2 class="section-title-v3__title m-0 saastain-gsap-anim2">
                <?php echo wp_kses_post( $settings['title'] ); ?>
              </h2>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="trusted-brands">


            <?php
                foreach ( $featureItems as $item ):
            ?>


            <a data-aos="fade-up" data-aos-delay="100" href="<?php echo esc_url( $item['brand_link']['url'] ) ?>">
              <img src="<?php echo esc_url( $item['brand_image']['url'] ); ?>" alt="#" />
            </a>

            <?php endforeach; ?>



          </div>
        </div>
      </div>
    </section>
    <!-- End Hero Banner -->




	<?php 


	}
				

}

