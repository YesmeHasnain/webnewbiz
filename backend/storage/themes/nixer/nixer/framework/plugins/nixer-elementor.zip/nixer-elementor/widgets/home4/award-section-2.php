<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome4AwardSection2 extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home4-award-section-2';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 4 - Award Section 2', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home4' ];
	}

	public function get_keywords() {
		return [ 'home4awardsection2', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_award_section',
			[
				'label' => esc_html__( 'Award Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'heading_sec',
			[
				'label' 		=> esc_html__( 'Heading Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Achieved award' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'My achievement <br> at a glance' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'time_item',
			[
				'label' 		=> esc_html__( 'Time Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( '2021' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'label_item',
			[
				'label' 		=> esc_html__( 'Label Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( 'Label Item:' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'text_item',
			[
				'label' 		=> esc_html__( 'Text Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( 'Text Item' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$repeater->add_control(
			'img_icon_item',
			[
				'label'       	=> esc_html__( 'Image Icon Item', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image icon item', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'tabs',
			[
				'label' 		=> esc_html__( 'Content Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						
					],
				],
				'title_field' 	=> '{{{ label_item }}}',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-awerd-4-ptb pt-140 pb-140">
	<div class="container">
		<?php if (!empty($settings['heading_sec']) || !empty($settings['title_sec'])): ?>
			<div class="row">
				<div class="col-lg-12">
					<div class="tp-awerd-4-heading pb-70">
						<?php if (!empty($settings['heading_sec'])): ?>
							<span class="tp-service-4-subtitle tp-title-anim"><?php echo wp_kses_post($settings['heading_sec']); ?></span>
						<?php endif ?>
						<?php if (!empty($settings['title_sec'])): ?>
							<h3 class="tp-section-4-title tp-title-anim"><?php echo wp_kses_post($settings['title_sec']); ?></h3>
						<?php endif ?>
					</div>
				</div>
			</div>
		<?php endif ?>
		<div class="row tp-gx-50">
			<?php
			$i = 0;
			foreach ( $settings['tabs'] as $item ) :
				$i++;
			?>
				<div class="col-lg-6">
					<?php if ($i % 2 == 1) { ?>
						<div class="tp-awerd-4-item d-flex tp_fade_left mb-50">
					<?php } else { ?>
						<div class="tp-awerd-4-item d-flex tp_fade_right mb-50">
					<?php } ?>
							<?php if (!empty($item['time_item'])): ?>
								<span class="tp-awerd-4-item-sub"><?php echo wp_kses_post($item['time_item']); ?></span>
							<?php endif ?>
							<?php if (!empty($item['label_item']) || !empty($item['text_item'])): ?>
								<div class="tp-awerd-4-item-content">
									<?php if (!empty($item['label_item'])): ?>
										<span><?php echo wp_kses_post($item['label_item']); ?></span>
									<?php endif ?>
									<?php if (!empty($item['text_item'])): ?>
										<h4 class="tp-awerd-4-item-title"><?php echo wp_kses_post($item['text_item']); ?></h4>
									<?php endif ?>
								</div>
							<?php endif ?>
							<?php if (!empty($item['img_icon_item']['url'])): ?>
								<div class="tp-awerd-4-item-icon">
									<img src="<?php echo wp_kses_post($item['img_icon_item']['url']); ?>" alt="<?php echo wp_kses_post($item['img_icon_item']['alt']); ?>">
								</div>
							<?php endif ?>
						</div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		if (jQuery('.tp-awerd-4-heading .tp-title-anim').length > 0) {
			var splitTitleLines = gsap.utils.toArray(".tp-awerd-4-heading .tp-title-anim");
			splitTitleLines.forEach(splitTextLine => {
				var tl = gsap.timeline({
				scrollTrigger: {
					trigger: splitTextLine,
					start: 'top 90%',
					end: 'bottom 60%',
					scrub: false,
					markers: false,
					toggleActions: 'play none none none'
				}
				});
	
				var itemSplitted = new SplitText(splitTextLine, { type: "words, lines" });
				gsap.set(splitTextLine, { perspective: 300});
				itemSplitted.split({ type: "lines" })
				tl.from(itemSplitted.lines, { duration: 1, delay: 0.3, opacity: 0, rotationX: -50, force3D: true, transformOrigin: "top center -50", stagger: 0.2 });
			});	
		}

		gsap.set(".tp_fade_left", { x: -100, opacity: 0 });
		var fadeleftArray = gsap.utils.toArray(".tp_fade_left")
		fadeleftArray.forEach((item, i) => {
			var fadeTl = gsap.timeline({
				scrollTrigger: {
					trigger: item,
					start: "top center+=100",
				}
			})
			fadeTl.to(item, {
				x: 0,
				opacity: 1,
				ease: "power2.out",
				duration: 2.5,
			})
		})

		gsap.set(".tp_fade_right", { x: 100, opacity: 0 });
		var faderightArray = gsap.utils.toArray(".tp_fade_right")
		faderightArray.forEach((item, i) => {
			var fadeTl = gsap.timeline({
				scrollTrigger: {
					trigger: item,
					start: "top center+=100",
				}
			})
			fadeTl.to(item, {
				x: 0,
				opacity: 1,
				ease: "power2.out",
				duration: 2.5,
			})
		})
	</script>
<?php } ?>

<?php
}

}