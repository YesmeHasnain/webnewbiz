<?php

/**
 * Elementor Widget
 * @package Knor
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_banner_it_solution extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'theme-it-solution-banner';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Banner It Solution', 'knor-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'knor_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {


        // ===================== Content ================//

        $this->start_controls_section( 'it_banner_section_content', [
            'label' => esc_html__( 'Contents', 'knor-extra' ),
        ] );

        $this->add_control( 'subtitle', [
            'label'       => __( 'Sub Title', 'knor-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => __( 'A Trusted Digital Agency', 'knor-extra' ),
            'label_block' => true,
            'description' => __( "Type your title here.", 'knor-extra' ),
        ] );

        $this->add_control(
            'it_subtitle_iconn',
            [
                'label' => esc_html__( 'Sub Heading Icon', 'knor-extra' ),
                'type'     => \Elementor\Controls_Manager::ICONS,
                'default'  => [
                    'value'   => 'fas fa-star',
                    'library' => 'solid',
                ],
            ]
        );


        $this->add_control( 'title', [
            'label'       => __( 'Title', 'knor-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Invest in Startup The Smart way ', 'knor-extra' ),
            'label_block' => true,
            'description' => __( "Type banner title here.", 'knor-extra' ),

        ] );

        $this->add_control( 'description', [
            'label'       => __( 'Description', 'knor-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Proactively coordinate quality quality vectors vis-a-vis supply chains. Quickly engage client-centric web services.', 'knor-extra' ),
            'label_block' => true,
        ] );

        $this->end_controls_section(); 


        // ===================== Buttons ================//

        $this->start_controls_section( 'button_section', [
            'label' => esc_html__( 'Button', 'knor-extra' ),
        ] );

        $this->add_control(
            'dgbtnn_button_options', [
                'label' => __( 'Primary Button', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control( 'it_btn_text', [
            'label'       => __( 'Filled Button Label', 'knor-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'placeholder' => __( 'Type your button label here', 'knor-extra' ),
            'default'     => __( 'Request For Demo', 'knor-extra' ),
        ] );

        $this->add_control( 'it_banner_btn_link', [
            'label'       => __( 'Button Link', 'knor-extra' ),
            'type'        => \Elementor\Controls_Manager::URL,
            'placeholder' => __( 'https://your-link.com', 'knor-extra' ),
            'default'     => [
                'url' => '#',
            ],
        ] );

        $this->add_control(
            'it_filled_btn_iconn',
            [
                'label' => esc_html__( 'Filled Button Icon', 'knor-extra' ),
                'type'     => \Elementor\Controls_Manager::ICONS,
                'default'  => [
                    'value'   => 'fas fa-star',
                    'library' => 'solid',
                ],
            ]
        );


        $this->add_control(
            'it_banner_secondary_button_options', [
                'label' => __( 'Bordered Button', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control( 'it_banner_sec_btn_text', [
            'label'       => __( 'Bordered Button Label', 'knor-extra' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'placeholder' => __( 'Type your button label here', 'knor-extra' ),
            'default'     => __( 'How It Works', 'knor-extra' ),
        ] );

        $this->add_control( 'it_banner_sec_btn_link', [
            'label'       => __( 'Video Button Link', 'knor-extra' ),
            'type'        => \Elementor\Controls_Manager::URL,
            'placeholder' => __( 'https://your-link.com', 'knor-extra' ),
            'default'     => [
                'url' => '#',
            ],
        ] );


        $this->add_control(
            'it_bordered_btn_iconn',
            [
                'label' => esc_html__( 'Bordered Button Icon', 'knor-extra' ),
                'type'     => \Elementor\Controls_Manager::ICONS,
                'default'  => [
                    'value'   => 'fas fa-star',
                    'library' => 'solid',
                ],
            ]
        );


        $this->add_control( 'banner_btn_shape_image', [
            'label'   => __( 'Choose Shape Image', 'knor-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );


        $this->end_controls_section(); //End Buttons



        // ===================== Feature Image ===================//
        $this->start_controls_section( 'it_feature_image_section', [
            'label' => __( 'Featured Image', 'knor-extra' ),
        ] );

        $this->add_control( 'it_banner_feature_image', [
            'label'   => __( 'Choose Banner Image', 'knor-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        $this->add_responsive_control( 'it_banner_image_margin', [
            'label'      => __( 'Margin', 'knor-extra' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [
                '{{WRAPPER}} .theme-banner-it-wrapper .banner-featured-image' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ] );

        $this->add_control( 'it_banner_shape_image', [
            'label'   => __( 'Choose Shape Image 1', 'knor-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        $this->add_control( 'it_banner_shape_image_two', [
            'label'   => __( 'Choose Shape Image 2', 'knor-extra' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        $this->end_controls_section();


        // ===================== Title ======================//

        $this->start_controls_section( 'it_banner_title_style', [
            'label' => __( 'Title', 'knor-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'it_banner_title_typography',
            'label'    => __( 'Typography', 'knor-extra' ),
            'selector' => '
                {{WRAPPER}} .theme-banner-it-wrapper h1.banner-heading,
                {{WRAPPER}} .__title
            ',
        ] );


        $this->add_control( 'it_banner_title_color', [
            'label'     => __( 'Color', 'knor-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-it-wrapper h1.banner-heading' => 'color: {{VALUE}}',
                '{{WRAPPER}} .__title' => 'color: {{VALUE}}',
            ],
        ] );

        $this->add_responsive_control( 'it_banner_title_margin', [
            'label'      => __( 'Margin', 'knor-extra' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [
                '{{WRAPPER}} .theme-banner-it-wrapper h1.banner-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ] );


        $this->end_controls_section(); //End Title Style


        // ===================== Subtitle Style ========================//
        $this->start_controls_section( 'it_banner_sub_title_style', [
            'label' => __( 'Sub Title', 'knor-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'sub_title_background',
                'label' => __( 'Set Sub Heading Background', 'knor-extra' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .theme-banner-it-wrapper h4.banner-sub-heading',
            ]
        );

        $this->add_responsive_control(
            'sub_title_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 48,
                ],
                'selectors' => [
                    '{{WRAPPER}} .theme-banner-it-wrapper h4.banner-sub-heading' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'it_banner_title_sub_typography',
            'label'    => __( 'Typography', 'knor-extra' ),
            'selector' => '{{WRAPPER}} .theme-banner-it-wrapper h4.banner-sub-heading',
        ] );

        $this->add_control( 'it_banner_sub_title_color', [
            'label'     => __( 'Title Color', 'knor-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-it-wrapper h4.banner-sub-heading' => 'color: {{VALUE}}',
            ],

        ] );

        $this->add_responsive_control( 'it_banner_sub_title_margin', [
            'label'      => __( 'Margin', 'knor-extra' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [
                '{{WRAPPER}} .theme-banner-it-wrapper h4.banner-sub-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ] );

        $this->add_responsive_control(
            'it_banner_sub_title_padding',
            [
                'label' => esc_html__( 'Padding', 'knor-extra' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .theme-banner-it-wrapper h4.banner-sub-heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );



        $this->end_controls_section(); //End Subtitle Style


        // ===================== Description ======================//
        $this->start_controls_section( 'description_section', [
            'label' => __( 'Description', 'knor-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'it_banner_desc_typography',
            'selector' => '
                {{WRAPPER}} .theme-banner-it-wrapper .banner-description,
                {{WRAPPER}} .__description
            ',
        ] );

        $this->add_control( 'it_banner_des_color', [
            'label'     => __( 'Color', 'knor-extra' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .theme-banner-it-wrapper .banner-description' => 'color: {{VALUE}}',
                '{{WRAPPER}} .__description' => 'color: {{VALUE}}',
            ],
        ] );

        $this->add_responsive_control( 'it_banner_des_margin', [
            'label'      => __( 'Margin', 'knor-extra' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [
                '{{WRAPPER}} .theme-banner-it-wrapper .banner-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ] );


        $this->end_controls_section(); //End Description


        // ===================== Button ======================//

        $this->start_controls_section( 'btnn_section', [
            'label' => __( 'Button', 'knor-extra' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'it_banner_btn_typography',
            'label' => esc_html__( 'Filled Button Typography', 'knor-extra' ),
            'selector' => '
                {{WRAPPER}} .theme-banner-it-wrapper a.banner-btn.banner-btn-rounded,
                {{WRAPPER}} .theme-banner-it-wrapper a.banner-btn.banner-btn-bordellred
            ',
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'it_banner_btn_two_typography',
            'label' => esc_html__( 'Bordered Button Typography', 'knor-extra' ),
            'selector' => '
                {{WRAPPER}} .theme-banner-it-wrapper a.banner-btn-play,
                {{WRAPPER}} .theme-banner-it-wrapper a.banner-btn-playteo
            ',
        ] );


        $this->end_controls_section(); //End Description


		
	}
	


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

        extract($settings); 


		
		?>


<div class="theme-banner-default-wrap theme-banner-it-wrapper d-flex align-items-center">
    
    <div class="container">
        
    
        <div class="row align-items-center">

            <div class="col-lg-6">
                <div class="theme-banner-content-wrap">

                    <?php if ( ! empty( $settings['subtitle'] ) ) : ?>
                        <h4 class="banner-sub-heading animated themeFadeInUp">
                            <?php \Elementor\Icons_Manager::render_icon( $settings['it_subtitle_iconn'], [ 'aria-hidden' => 'true' ] ); ?><?php echo $settings['subtitle']; ?>
                        </h4>
                    <?php endif ?>

                    <?php if ( ! empty( $settings['title'] ) ) : ?>
                        <h1 class="banner-heading animated themeFadeInUp">
                            <?php echo $settings['title']; ?>
                        </h1>
                    <?php endif ?>

                    <?php if ( ! empty( $settings['description'] ) ) : ?>
                        <p class="banner-description animated themeFadeInUp">
                            <?php echo $settings['description']; ?>
                        </p>
                    <?php endif ?>

                    <div class="banner-buttons animated themeFadeInUp">

                        <?php if ( ! empty( $settings['it_banner_btn_link']['url'] ) ) : ?>
                            <a href="<?php echo esc_url( $settings['it_banner_btn_link']['url'] ) ?>"  class="banner-btn banner-btn-rounded">
                                <?php echo $settings['it_btn_text'] ?>
                                <?php \Elementor\Icons_Manager::render_icon( $settings['it_filled_btn_iconn'], [ 'aria-hidden' => 'true' ] ); ?>
                            </a>
                        <?php endif; ?>

                       <?php if ( ! empty( $settings['it_banner_sec_btn_link']['url'] ) ) : ?>
                            <a href="<?php echo esc_url( $settings['it_banner_sec_btn_link']['url'] ) ?>"  class="banner-btn banner-btn-bordered"> 
                                <?php echo $settings['it_banner_sec_btn_text'] ?>
                                <span class="icon-it-arrow"><?php \Elementor\Icons_Manager::render_icon( $settings['it_bordered_btn_iconn'], [ 'aria-hidden' => 'true' ] ); ?></span> 
                                
                            </a>
                        <?php endif; ?>

                        <div class="it-banner-btn-shape">

                            <?php if ( ! empty( $settings['banner_btn_shape_image']['url'] ) ) : ?>
                                <img src="<?php echo esc_url( $settings['banner_btn_shape_image']['url'] ); ?>" class="it-btn-shape" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                            <?php endif; ?>

                        </div>

                    </div>

                </div>

            </div>

            <div class="col-lg-6">

                <div class="banner-featured-image">
                    <?php if ( ! empty( $settings['it_banner_feature_image']['url'] ) ) : ?>
                        <img src="<?php echo esc_url( $settings['it_banner_feature_image']['url'] ); ?>" class="nn" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                    <?php endif; ?>
                </div>
                <!-- /.banner-feature-image -->

            </div>


        </div>

        <div class="it-banner-shape-wrap">
            <img src="<?php echo esc_url( $settings['it_banner_shape_image']['url'] ); ?>" class="nn" alt="<?php echo esc_attr( $settings['title'] ); ?>">
        </div>

         <div class="it-banner-shape-wrap-two">
            <img src="<?php echo esc_url( $settings['it_banner_shape_image_two']['url'] ); ?>" class="nn" alt="<?php echo esc_attr( $settings['title'] ); ?>">
        </div>
    
</div>

</div>
	

	<?php 


	}
				

}

