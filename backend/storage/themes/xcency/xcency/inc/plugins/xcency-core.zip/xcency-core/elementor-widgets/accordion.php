<?php
namespace Elementor;

class Xcency_Accordion_Widget extends Widget_Base {

	public function get_name() {

		return 'xcency_accordion';
	}

	public function get_title() {
		return esc_html__( 'Accordion One', 'xcency-core' );
	}

	public function get_icon() {

		return 'eicon-accordion';
	}

	public function get_categories() {
		return [ 'xcency_core_elements' ];
	}

	public function get_script_depends() {
		return ['counterup'];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'accordion_content_options',
			[
				'label' => esc_html__( 'Accordion', 'xcency-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'accordion_title',
			[
				'label'       => esc_html__( 'Accordion Title', 'xcency-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 5,
				'default' => 'Accordion Title Here',
				'placeholder' => esc_html__( 'Type Accordion Title Here', 'xcency-core' ),
			]
		);

		$repeater->add_control(
			'accordion_content', [
				'label' => esc_html__( 'Accordion Content', 'xcency-core' ),
				'type' => Controls_Manager::WYSIWYG,
				'default' => 'I must explain to you how all this mistaken idea of denouncing pleasure and prais pain was born and I will give you a complete account.',
				'label_block' => true,
			]
		);

		$this->add_control(
			'accordion_list',
			[
				'label' => __( 'Accordion Lists', 'xcency-core' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'list_title' => 'Accordion Title Here',
						'accordion_content' => 'I must explain to you how all this mistaken idea of denouncing pleasure and prais pain was born and I will give you a complete account.',
					],
				],
				'title_field' => '{{{ accordion_title }}}',
			]
		);

		$this->add_control(
			'open_by_default',
			[
				'label'       => esc_html__('Open By Default', 'xcency-core'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 1,
				'max'         => 1000,
				'step'        => 1,
				'default'     => 1,
				'separator'     => 'before',
				'description' => esc_html__('Which accordion you want to open by default.', 'xcency-core'),
			]
		);

		$this->add_control(
			'open_icon',
			[
				'label'            => esc_html__( 'Open Icon', 'xcency-core' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fas fa-angle-up',
					'library' => 'solid',
				],
			]
		);

		$this->add_control(
			'close_icon',
			[
				'label'            => esc_html__( 'Close Icon', 'xcency-core' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fas fa-angle-down',
					'library' => 'solid',
				],
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'accordion_style',
            [
                'label' => esc_html__( 'Accordion', 'xcency-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'accordion_bg',
            [
                'label'       => esc_html__('Background Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .xcency-accordion-wrapper .accordion-body,{{WRAPPER}} .xcency-accordion-wrapper .accordion-button:not(.collapsed),{{WRAPPER}} .xcency-accordion-wrapper button.xcency-accordion-title' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'accordion_border_color',
            [
                'label'       => esc_html__('Border Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .xcency-accordion-wrapper .accordion-item,{{WRAPPER}} .xcency-accordion-wrapper .accordion-body' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$id = rand(100, 100000);
		?>



            <div class="xcency-accordion-wrapper xcency-accordion-wrapper-<?php echo $id;?>">
                <div class="accordion" id="xcency-accordion-<?php echo $id;?>">

                    <?php
                    if($settings['accordion_list']){
                        $i = 0;
                        foreach($settings['accordion_list'] as $accordionItem){
                            $i++;

                            if($i == $settings['open_by_default']){
                                $show = 'show';
                                $open = 'true';
                                $collapsed = '';
                            }else{
                                $show = '';
                                $open = 'false';
                                $collapsed = 'collapsed';
                            }

                            ?>
                            <div class="accordion-item <?php if ($open == 'true'){echo 'open';} ?>">
                                <h2 class="accordion-header">
                                    <button class="xcency-accordion-title accordion-button <?php echo $collapsed;?>" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-<?php echo $i.$id;?>" aria-expanded="<?php echo $open;?>" aria-controls="collapse-<?php echo $i.$id;?>">
                                        <?php
                                            echo $accordionItem['accordion_title'];
                                        ?>
                                        <span class="xcency-accordion-icon open-icon"><?php xcency_custom_icon_render( $settings, 'icon', 'open_icon' ); ?></span>
                                        <span class="xcency-accordion-icon close-icon"><?php xcency_custom_icon_render( $settings, 'icon', 'close_icon' ); ?></span>
                                    </button>
                                </h2>

                                <div id="collapse-<?php echo $i.$id;?>" class="accordion-collapse collapse <?php echo $show ?>" data-bs-parent="#xcency-accordion-<?php echo $id;?>">
                                    <div class="accordion-body xcency-last-p-0">
                                        <?php echo wp_kses_post( $accordionItem['accordion_content']) ?>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                    }
                    ?>

                    <script>
                        // Get all accordion items
                        const accordionItems = document.querySelectorAll('.accordion-item');

                        // Add event listener to each accordion item
                        accordionItems.forEach(item => {
                            item.addEventListener('click', function() {
                                // Check if the clicked accordion item has the 'open' class
                                const isOpen = this.classList.contains('open');

                                // Remove 'open' class from all accordion items
                                accordionItems.forEach(item => {
                                    item.classList.remove('open');
                                });

                                // Add 'open' class to clicked accordion item if it wasn't already open
                                if (!isOpen) {
                                    this.classList.add('open');
                                }
                            });
                        });
                    </script>
                </div>
            </div>

		<?php
	}
}

Plugin::instance()->widgets_manager->register( new Xcency_Accordion_Widget );