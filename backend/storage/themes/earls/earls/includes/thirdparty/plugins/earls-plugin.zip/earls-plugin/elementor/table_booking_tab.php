<?php
namespace EARLSPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Table_Booking_Tab extends Widget_Base {
	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'earls_table_booking_tab';
	}
	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Earls Table Booking Tab', 'earls' );
	}
	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-table';
	}
	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'earls' ];
	}
	
	public function get_script_depends() {
		wp_register_script( 'table_tab', YT_URL . 'assets/js/booking-tabs.js', [ 'elementor-frontend' ], '1.0.0', true );
		return [ 'table_tab' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'table_booking_tab',
			[
				'label' => esc_html__( 'Earls Table Booking Tab', 'earls' ),
			]
		);
		//Banner SLide Repeater
		$repeater = new Repeater();
		$repeater->add_control(
			'tab_btn_title',
			[
				'label'       => __( 'Tab Button Title', 'earls' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Tab Button Title', 'earls' ),
			]
		);
		$repeater->add_control(
			'block_title',
			[
				'label'       => __( 'Title', 'earls' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Sub Title', 'earls' ),
			]
		);
		$repeater->add_control(
			'block_text',
			[
				'label'       => __( 'Description', 'earls' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Description', 'earls' ),
			]
		);
		$repeater->add_control(
            'cf7_shortocde',
            [
                'label' => esc_html__('Select Contact Form 7', 'earls'),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => get_contact_form_7_list(),
            ]
        );
		$this->add_control(
			'tab_form',
			[
				'label'                 => __('Add Tab Form Item', 'earls'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
			]
		);
		
		$this->end_controls_section();
		
		/************************************************************************
								Tab Style Start
		*************************************************************************/
		
		/**Layout Control Style**/		
		$this->start_controls_section(
			'earls_layout_style',
			[
				'label' => esc_html__('Earls Layout Setting', 'earls'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'earls_layout_margin',
            [
                'label'              => __( 'Spacing', 'earls' ),
                'type'               => Controls_Manager::DIMENSIONS,
                'size_units'         => [ 'px', 'em', '%' ],
                'selectors'          => [
                    '{{WRAPPER}} .tab___secrtion' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ],
				'frontend_available' => true,
				
            ]
        );
		$this->add_responsive_control(
            'earls_layout_padding',
            [
                'label'              => __( 'Gapping', 'earls' ),
                'type'               => Controls_Manager::DIMENSIONS,
                'size_units'         => [ 'px', 'em', '%' ],
                'selectors'          => [
                    '{{WRAPPER}} .tab___secrtion' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ],
				'frontend_available' => true,
				
            ]
        );
		$this->add_control(
			'earls_layout_background',
			[
				'label'                 => __( 'Background', 'earls' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'earls_layout_bgtype',
				'label' => __( 'Section Background', 'earls' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => 
					'{{WRAPPER}} .tab___secrtion
					 ',				
			]
		);
		$this->end_controls_section();
		
	}
	/**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post'); 
	?>
	
    <div class="tab___secrtion">
        <div class="tabs-box">
            <div class="tab-btn-box p_relative">
                <ul class="tab-btns tab-buttons clearfix">
                    <?php $count = 1; foreach($settings['tab_form'] as $key => $item): ?>
                    <li class="tab-btn <?php if($count == 1) echo 'active-btn'; ?> theme-btn-two" data-tab="#tab-6<?php echo esc_attr($count); ?>">
                        <span class="tab___all body__four"> <?php echo wp_kses($item['tab_btn_title'], true); ?> </span>
                    </li>
                    <?php $count++; endforeach; ?>
                </ul>
            </div>
            <div class="tabs-content wow fadeInUp animated" data-wow-delay="00ms" data-wow-duration="1500ms">
                <?php $count = 1; foreach($settings['tab_form'] as $key => $item): ?>
                <div class="tab <?php if($count == 1) echo 'active-tab'; ?>" id="tab-6<?php echo esc_attr($count); ?>">
                    <div class="inner-box row">
                        <div class="tab___left__data col-lg-4 col-md-12 col-sm-12">
                            <h1><?php echo wp_kses($item['block_title'], true); ?></h1>
                            <p><?php echo wp_kses($item['block_text'], true); ?></p>
                        </div>
                        
						<?php if( $item['cf7_shortocde'] ){?>
                        <div class="booking__form col-lg-8 col-md-12 col-sm-12">
                            <div class="reserve-form">
								<?php echo do_shortcode('[contact-form-7 id="'.esc_attr($item['cf7_shortocde']).'"]'); ?>
                            </div>
                        </div>
                        <?php };?>
                    </div>
                </div>
                <?php $count++; endforeach; ?>
            </div>
        </div>
    </div>
    
    <?php 
	}
}