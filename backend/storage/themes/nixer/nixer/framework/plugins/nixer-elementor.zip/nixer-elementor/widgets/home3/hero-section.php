<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome3HeroSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home3-hero-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 3 - Hero Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-featured-image';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home3' ];
	}

	public function get_keywords() {
		return [ 'home3herosection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_hero_section',
			[
				'label' => esc_html__( 'Hero Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'img_bottom_sec',
			[
				'label'       	=> esc_html__( 'Image Bottom Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image bottom section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Where every detail is <br> a stroke of nixer' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_sec',
			[
				'label' 		=> esc_html__( 'Text Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( "We're an innovative global ui/ux design agency building high-end products <br> and experiences that grow your business exponentially." , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->end_controls_section();


		$this->start_controls_section(
			'section_content_hero_down',
			[
				'label' => esc_html__( 'Hero Down Smooth', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'show_hero_down_smooth',
			[
				'label'   => esc_html__( 'Show Hero Down Smooth', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'text_btn',
			[
				'label' 		=> esc_html__( 'Text Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Keep <br> Scrolling' , 'bdevs-elementor' ),
				'show_label' 	=> true,
				'condition' 	=> [
					'show_hero_down_smooth' 	=> 'yes',
				],
			]
		);
		$this->add_control(
			'link_btn',
			[
				'label' 		=> esc_html__( 'Link Button', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '#down' , 'bdevs-elementor' ),
				'show_label' 	=> true,
				'condition' 	=> [
					'show_hero_down_smooth' 	=> 'yes',
				],
			]
		);
		$this->add_control(
			'shortcode',
			[
				'label'       => __( 'Shortcode Contact Form', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your shortcode contact form', 'bdevs-elementor' ),
				'default'     => __( '[contact-form-7 id="a259793" title="Prompt Form"]', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->end_controls_section();


		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-hero-3-ptb fix pb-160 p-relative">
	<?php if (!empty($settings['img_bottom_sec']['url'])): ?>
		<div class="tp-hero-3-bg tp_fade_bottom">
			<img src="<?php echo wp_kses_post($settings['img_bottom_sec']['url']); ?>" alt="<?php echo wp_kses_post($settings['img_bottom_sec']['alt']); ?>">
		</div>
	<?php endif ?>
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="tp-hero-3-conetnt text-center">
					<div class="tp-hero-3-heading tp_fade_anim" data-delay="0.5">
						<?php if (!empty($settings['title_sec'])): ?>
							<h3 class="tp-hero-3-title"><?php echo wp_kses_post($settings['title_sec']); ?></h3>
						<?php endif ?>
						<?php if (!empty($settings['text_sec'])): ?>
							<p><?php echo wp_kses_post($settings['text_sec']); ?></p>
						<?php endif ?>
					</div>
					<?php echo do_shortcode($settings['shortcode']); ?>
				</div>
			</div>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		gsap.set(".tp_fade_bottom", { y: 100, opacity: 0 });
		var fadeArray = gsap.utils.toArray(".tp_fade_bottom")
		fadeArray.forEach((item, i) => {
			var fadeTl = gsap.timeline({
				scrollTrigger: {
					trigger: item,
					start: "top center+=400",
				}
			})
			fadeTl.to(item, {
				y: 0,
				opacity: 1,
				ease: "power2.out",
				duration: 1.5,
			})
		})

		if (jQuery(".tp_fade_anim").length > 0) {
			gsap.utils.toArray(".tp_fade_anim").forEach((item) => {
				var tp_fade_offset = item.getAttribute("data-fade-offset") || 40,
					tp_duration_value = item.getAttribute("data-duration") || 0.75,
					tp_fade_direction = item.getAttribute("data-fade-from") || "bottom",
					tp_onscroll_value = item.getAttribute("data-on-scroll") || 1,
					tp_delay_value = item.getAttribute("data-delay") || 0.15,
					tp_ease_value = item.getAttribute("data-ease") || "power2.out",
					tp_anim_setting = {
						opacity: 0,
						ease: tp_ease_value,
						duration: tp_duration_value,
						delay: tp_delay_value,
						x: (tp_fade_direction == "left" ? -tp_fade_offset : (tp_fade_direction == "right" ? tp_fade_offset : 0)),
						y: (tp_fade_direction == "top" ? -tp_fade_offset : (tp_fade_direction == "bottom" ? tp_fade_offset : 0)),
					};
	
				if (tp_onscroll_value == 1) {
					tp_anim_setting.scrollTrigger = {
						trigger: item,
						start: 'top 85%',
					};
				}
				gsap.from(item, tp_anim_setting);
			});
		}
	</script>
<?php } ?>

<?php
}

}