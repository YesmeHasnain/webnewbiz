<?php
namespace Elementor;

class Xcency_Quick_Links_Widget extends Widget_Base {

	public function get_name() {
		return 'xcency_core_quick_links';
	}

	public function get_title() {
		return esc_html__( 'Quick Links', 'xcency-core' );
	}

	public function get_icon() {
		return 'fas fa-link';
	}

	public function get_categories() {
		return [ 'xcency_core_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'quick_links',
			[
				'label' => esc_html__( 'Quick Links', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'xcency-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Quick Links',
			]
		);

		$this->add_control(
		    'select_a_menu',
		    [
		        'label'     => esc_html__( 'Select A menu', 'xcency-core' ),
		        'type'      => Controls_Manager::SWITCHER,
		        'label_on'  => esc_html__( 'Yes', 'xcency-core' ),
		        'label_off' => esc_html__( 'No', 'xcency-core' ),
		        'default'   => 'yes',
		    ]
		);

		$this->add_control(
			'menu_list',
			[
				'label'   => __( 'Select Menu', 'xcency-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' =>xcency_core_get_custom_menu(),
				'condition' => [
				    'select_a_menu' => 'yes',
				],
			]
		);

		$repeater = new Repeater();
		$repeater->add_control(
			'list_text',
			[
				'label'       => __( 'List Text', 'xcency-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'List Text Here', 'xcency-core' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'list_url',
			[
				'label'         => __( 'URL', 'xcency-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'xcency-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'list_items',
			[
				'label'       => __( 'List Items', 'xcency-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'list_text' => __( 'List Text Here', 'xcency-core' ),
					],
				],
				'title_field' => '{{{ list_text }}}',
                'condition' => [
                    'select_a_menu!' => 'yes',
                ],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'title!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typo',
				'label' => esc_html__( 'Typography', 'xcency-core' ),
				'selector' => '{{WRAPPER}} .widget-title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'       => esc_html__('Color', 'xcency-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .widget-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_margin',
			[
				'label'      => esc_html__( 'Title Margin', 'xcency-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .widget-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


        // Start List Style section
        $this->start_controls_section(
            'xcency_list_style_options',
            [
                'label' => esc_html__('List Style', 'xcency-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs('xcency_list_style_tabs');

        //Default style tab start
        $this->start_controls_tab(
            'xcency_list_style_default',
            [
                'label' => esc_html__('Default', 'xcency-core'),
            ]
        );

        $this->add_control(
            'list_default_text_color',
            [
                'label'     => esc_html__('Color', 'xcency-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .xcency-elementor-widget.widget_xcency_nav_menu li a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();//Default style tab end

        //Hover style tab start
        $this->start_controls_tab(
            'xcency_list_style_hover',
            [
                'label' => esc_html__('Hover', 'xcency-core'),
            ]
        );

		$this->add_control(
			'list_hover_text_color',
			[
				'label'     => esc_html__('Color', 'xcency-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .xcency-elementor-widget.widget_xcency_nav_menu li a:hover' => 'color: {{VALUE}};',
				],
			]
		);

        $this->end_controls_tabs();//Hover style tab end

        $this->end_controls_section();// End Button section

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<div class="xcency-elementor-widget widget widget_nav_menu widget_xcency_nav_menu widget_nav_menu">
			<?php if ($settings['title']) : ?>
            <h4 class="widget-title"><?php echo $settings['title'];?></h4>
            <?php endif; ?>

			<?php
            if ($settings['select_a_menu'] == 'yes'){
	            if($settings['menu_list']){
		            $quick_link = $settings['menu_list'];
	            }else{
		            $quick_link = '';
	            }

	            wp_nav_menu( array(
		            'menu'            => $quick_link,
	            ) );
            }else{ ?>
                <ul class="menu">
		            <?php if ( $settings['list_items'] ) {
			            foreach ( $settings['list_items'] as $list ) {
				            $list_text = $list['list_text'];
				            $list_url = $list['list_url']['url'];
				            $list_target      = $list['list_url']['is_external'] ? ' target="_blank"' : '';
				            $list_nofollow    = $list['list_url']['nofollow'] ? ' rel="nofollow"' : '';
				            ?>
                            <li>
                                <a href="<?php echo $list_url; ?>" <?php echo $list_target . $list_nofollow ?>><?php echo $list_text;?></a>
                            </li>
			            <?php }
		            } ?>
                </ul>
            <?php }
			?>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new Xcency_Quick_Links_Widget );