<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsSVDetailInstagram extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-sv-detail-instagram';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Service Detail Instagram', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-instagram-gallery';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-service' ];
	}

	public function get_keywords() {
		return [ 'servicedetailinstagram', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_sv_detail_instagram',
			[
				'label' => esc_html__( 'Service Detail Instagram', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'bg_color',
			[
				'label' 		=> esc_html__( 'Background Color (Default: #FFFFFF)', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::COLOR,
				'default'		=> '#FFFFFF',
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'img_item',
			[
				'label'       	=> esc_html__( 'Image Item', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image item', 'bdevs-elementor' ),
			]
		);
		$repeater->add_control(
			'img_popup_item',
			[
				'label'       	=> esc_html__( 'Image Popup Item', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image popup item', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'tabs',
			[
				'label' 		=> esc_html__( 'List Image Carousel', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						
					],
				],
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<div class="tp-service-details-instragram pb-100" data-bg-color="<?php echo wp_kses_post($settings['bg_color']); ?>">
	<div class="container-fluid tp-gx-0">
		<div class="row tp-gx-0">
			<div class="col-lg-12">
				<div class="tp-about-me-instragram-wrapper">
					<div class="tp-instragram-active swiper">
						<div class="swiper-wrapper">
							<?php
							foreach ($settings['tabs'] as $item) :
							?>
								<?php if (!empty($item['img_item']['url'])): ?>
									<div class="swiper-slide">
										<div class="tp-about-me-instragram-item">
											<div class="tp-about-me-instragram-thumb">
												<img src="<?php echo wp_kses_post($item['img_item']['url']); ?>" alt="<?php echo wp_kses_post($item['img_item']['alt']); ?>">
												<?php if (!empty($item['img_popup_item']['url'])): ?>
													<div class="tp-about-me-instragram-icon">
														<a href="<?php echo wp_kses_post($item['img_popup_item']['url']); ?>" class="popup-image">
															<i class="fa-brands fa-instagram"></i>
														</a>
													</div>
												<?php endif ?>
											</div>
										</div>
									</div>
								<?php endif ?>
							<?php endforeach; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		if (jQuery('.tp-instragram-active').length > 0) {
			var slider = new Swiper('.tp-instragram-active', {
				slidesPerView: 6,
				loop: true,
				spaceBetween: 30,
				breakpoints: {
					'1700': {
						slidesPerView: 6,
					},
					'1600': {
						slidesPerView: 6,
					},
					'1400': {
						slidesPerView: 5,
					},
					'1200': {
						slidesPerView: 4,
					},
					'992': {
						slidesPerView: 3.5,
					},
					'768': {
						slidesPerView: 2.8,
					},
					'576': {
						slidesPerView: 2,
					},
					'0': {
						slidesPerView: 1,
					},
				},
			});
		}

		jQuery('.popup-image').magnificPopup({
			type: 'image',
			gallery: {
				enabled: true
			}
		});

		jQuery("[data-bg-color]").each(function () {
			jQuery(this).css("background-color", jQuery(this).attr("data-bg-color"));
		});
	</script>
<?php } ?>

<?php
}

}