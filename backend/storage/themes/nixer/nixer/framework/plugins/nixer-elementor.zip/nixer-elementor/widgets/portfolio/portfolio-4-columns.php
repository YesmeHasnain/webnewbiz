<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsPortfolio4Columns extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-portfolio-4-columns';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Portfolio 4 Columns', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-posts-grid';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-portfolio' ];
	}

	public function get_keywords() {
		return [ 'portfolio4columns', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}
	

	protected function _register_controls() {		
		$this->start_controls_section(
			'section_content_portfolio_4_columns',
			[
				'label' => esc_html__( 'Portfolio 4 Columns', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'img_bg_sec',
			[
				'label'       	=> esc_html__( 'Image Background Section', 'bdevs-elementor' ),
				'type'        	=> Controls_Manager::MEDIA,
				'dynamic'     	=> [ 'active' => true ],
				'label_block' 	=> true,
				'description' 	=> esc_html__( 'Upload image background section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'heading_sec',
			[
				'label' 		=> esc_html__( 'Heading Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Our Portfolio' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Explore our works' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'text_sec',
			[
				'label' 		=> esc_html__( 'Text Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'We are a passionate team of...' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'post_number',
			[
				'label'       => __( 'Post Number', 'bdevs-elementor' ),
				'type'        => Controls_Manager::NUMBER,
				'placeholder' => __( 'Enter your post number', 'bdevs-elementor' ),
				'min'		  => 0,
				'default'     => __( '8', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order_by',
			[
				'label'       => __( 'Post Order By', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text post order by', 'bdevs-elementor' ),
				'default'     => __( 'ID', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
				],
				'default'   => 'desc',
			]
		);
		$this->add_control(
			'show_pagi',
			[
				'label'   => esc_html__( 'Show Pagination', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-portfolio-col-2-ptb pt-235 pb-130 p-relative">
	<?php if (!empty($settings['img_bg_sec']['url'])): ?>
		<div class="tp-about-me-bg" data-background="<?php echo wp_kses_post($settings['img_bg_sec']['url']); ?>"></div>
	<?php endif ?>
	<?php if (!empty($settings['heading_sec']) || !empty($settings['title_sec']) || !empty($settings['text_sec'])): ?>
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="tp-blog-heading portfolio p-relative pb-100 mb-155">
						<?php if (!empty($settings['heading_sec'])): ?>
							<span class="tp-breadcrumb-subtitle"><?php echo wp_kses_post($settings['heading_sec']); ?></span>
						<?php endif ?>
						<?php if (!empty($settings['title_sec'])): ?>
							<h3 class="tp-breadcrumb-title tp-title-anim"><?php echo wp_kses_post($settings['title_sec']); ?></h3>
						<?php endif ?>
						<?php if (!empty($settings['text_sec'])): ?>
							<div class="tp-portfolio-col-2-heading z-index-1">
								<p><?php echo wp_kses_post($settings['text_sec']); ?></p>
							</div>
						<?php endif ?>
					</div>
				</div>
			</div>
		</div>
	<?php endif ?>
	<div class="container container-1800">
		<div class="row">
			<?php
			$paged = max(1, get_query_var('paged', get_query_var('page', 1)));
			$wp_query = new \WP_Query(array(
				'post_type' => 'portfolio',
				'paged' => $paged,
				'posts_per_page' => wp_kses_post($settings['post_number']),
				'orderby' => wp_kses_post($settings['post_order_by']),
				'order' => wp_kses_post($settings['post_order']),
			));

			while($wp_query->have_posts()): $wp_query->the_post();
			?>
				<div class="col-xxl-3 col-xl-4 col-md-6">
					<div class="tp-portfolio-6-item p-relative mb-30">
						<div class="tp-portfolio-6-item-thumb">
							<a href="<?php the_permalink(); ?>">
								<?php if (has_post_thumbnail()) { ?>
									<img class="ratio-49x58" src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title_attribute(); ?>">
								<?php } else { ?>
									<img class="ratio-49x58" src="<?php echo get_template_directory_uri(); ?>/assets/img/project/home-6/portfolio-6-1.jpg" alt="<?php the_title_attribute(); ?>">
								<?php } ?>
							</a>
						</div>
						<div class="tp-portfolio-6-item-content">
							<div class="tp-portfolio-6-item-content-hide">
								<span><?php echo get_the_date('M Y'); ?></span>
								<h4 class="tp-portfolio-6-item-title">
									<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
								</h4>
							</div>
						</div>
					</div>
				</div>
			<?php endwhile; ?>
			<?php if ($settings['show_pagi']): ?>
				<?php 
				$big = 999999999;
				$pagination = array(
					'base'      	=> str_replace($big, '%#%', get_pagenum_link($big)),
					'format'    	=> '',
					'current'   	=> $paged,
					'total'     	=> $wp_query->max_num_pages,
					'prev_text'     => wp_specialchars_decode('<i class="fa-regular fa-arrow-left icon"></i>', ENT_QUOTES),
					'next_text'     => wp_specialchars_decode('<i class="fa-regular fa-arrow-right icon"></i>', ENT_QUOTES),
					'type'      	=> 'list',
					'end_size'    	=> 3,
					'mid_size'    	=> 3
				);
				$pagination_links = paginate_links($pagination);
				if (!empty($pagination_links)): ?>
					<div class="basic-pagination text-center mt-80">
						<nav>
							<?php 
							echo str_replace("<ul class='page-numbers'>", '<ul class="page-pagination">', $pagination_links); 
							?>
						</nav>
					</div>
				<?php endif; ?>
			<?php endif ?>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-background]").each(function () {
			jQuery(this).css("background-image", "url( " + $(this).attr("data-background") + "  )");
		});
	</script>
<?php } ?>

<?php
}

}