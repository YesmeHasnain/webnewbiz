<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome6PortfolioSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home-6-portfolio-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 6 - Portfolio Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-posts-grid';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home6' ];
	}

	public function get_keywords() {
		return [ 'home6portfoliosection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_portfolio_section',
			[
				'label' => esc_html__( 'Portfolio Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'design studio design studio design studio design studio' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'show_portfolio_top_info',
			[
				'label'   => esc_html__( 'Show Portfolio Top Info', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$rp_info = new \Elementor\Repeater();
		$rp_info->add_control(
			'text_item',
			[
				'label' 		=> esc_html__( 'Text Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( 'Text Item' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_info->add_control(
			'text_btn_item',
			[
				'label' 		=> esc_html__( 'Text Button Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( 'Text Button Item' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$rp_info->add_control(
			'link_btn_item',
			[
				'label' 		=> esc_html__( 'Link Button Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> esc_html__( '#' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'tab_info',
			[
				'label' 		=> esc_html__( 'Content Info Item', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $rp_info->get_controls(),
				'default' 		=> [
					[
						
					],
				],
				'condition' 	=> [
					'show_portfolio_top_info' 	=> 'yes',
				],
			]
		);
		$this->add_control(
			'item_column',
			[
				'label'     	=> esc_html__( 'Item Column', 'bdevs-elementor' ),
				'type'      	=> Controls_Manager::SELECT,
				'options'   	=> [
					'type1'  		=> esc_html__( 'Two Columns', 'bdevs-elementor' ),
					'type2'  		=> esc_html__( 'Three Columns', 'bdevs-elementor' ),
					'type3'  		=> esc_html__( 'Four Columns', 'bdevs-elementor' ),
				],
				'default'   	=> 'type1',
			]
		);
		$this->add_control(
			'post_number',
			[
				'label'       => __( 'Post Number', 'bdevs-elementor' ),
				'type'        => Controls_Manager::NUMBER,
				'placeholder' => __( 'Enter your post number', 'bdevs-elementor' ),
				'min'		  => 0,
				'default'     => __( '8', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order_by',
			[
				'label'       => __( 'Post Order By', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text post order by', 'bdevs-elementor' ),
				'default'     => __( 'ID', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
				],
				'default'   => 'desc',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-portfolio-6-ptb">

	<div class="tp-portfolio-6-top pb-160">
		<?php if (!empty($settings['title_sec'])): ?>
			<div class="container-fluid gx-0 p-0">
				<div class="row">
					<div class="col-lg-12"> 
						<div class="tp-portfolio-6-heading p-relative fix text-center pb-40">
							<div class="tp-hero-2-text-scroll-hr">
								<div class="tp-hero-2-text-scroll-wrap">
									<h3 class="tp-portfolio-6-title"><?php echo wp_kses_post($settings['title_sec']); ?></h3>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php endif ?>
		<?php if (!empty($settings['show_portfolio_top_info'])): ?>
			<div class="container container-1720">
				<div class="row">
					<?php
					$i = 0;
					foreach ( $settings['tab_info'] as $item1 ) :
						$j = $i % 3 + 1;
						$i++;
					?>
						<?php if (!empty($item1['text_item']) || (!empty($item1['link_btn_item']) && !empty($item1['text_btn_item']))): ?>
							<div class="col-lg-4">
								<?php if ($j == 2) { ?>
									<div class="d-flex justify-content-stat justify-content-lg-center">
								<?php } elseif ($j == 3) { ?>
									<div class="d-flex justify-content-start justify-content-lg-end">
								<?php } else { ?>
								<?php } ?>
										<div class="tp-portfolio-6-text">
											<?php if (!empty($item1['text_item'])): ?>
												<p><?php echo wp_kses_post($item1['text_item']); ?></p>
											<?php endif ?>
											<?php if (!empty($item1['link_btn_item']) && !empty($item1['text_btn_item'])): ?>
												<a href="<?php echo wp_kses_post($item1['link_btn_item']); ?>">
													<?php echo wp_kses_post($item1['text_btn_item']); ?>
													<span>
														<svg xmlns="http://www.w3.org/2000/svg" width="15" height="12" viewBox="0 0 15 12" fill="none">
															<path d="M0 5.9989H13.9692M8.46094 0C8.46094 3.31708 11.3842 6.0012 14.9968 6.0012M14.9968 5.99888C11.3842 5.99888 8.46094 8.68299 8.46094 12.0001" stroke="white" stroke-width="2" stroke-miterlimit="10"/>
														</svg>
													</span>
												</a>
											<?php endif ?>
										</div>
								<?php if ($j != 1): ?>
									</div>
								<?php endif ?>
							</div>
						<?php endif ?>
					<?php endforeach; ?>
				</div>
			</div>
		<?php endif ?>
	</div>

	<div class="container container-1520">
		<div class="row">
			<?php
			$wp_query = new \WP_Query([
				'post_type'      => 'portfolio',
				'posts_per_page' => intval($settings['post_number']),
				'orderby'        => sanitize_text_field($settings['post_order_by']),
				'order'          => sanitize_text_field($settings['post_order']),
			]);

			$column_class = match ($settings['item_column']) {
				'type2' => 'col-lg-4',
				'type3' => 'col-lg-3',
				default => 'col-lg-6',
			};

			$i = 0;
			while($wp_query->have_posts()): $wp_query->the_post();
				$i++;

				$port_title = get_post_meta(get_the_ID(),'_cmb_port_title_home_6', true);
				$img_id = get_post_meta(get_the_ID(),'_cmb_port_thumb_home_6', true);

				$title = !empty($port_title) ? $port_title : get_the_title();
				if (!empty($img_id)) {
					$img_url = wp_get_attachment_url($img_id);
				} elseif (has_post_thumbnail()) {
					$img_url = get_the_post_thumbnail_url();
				} else {
					$img_url = get_template_directory_uri() . '/assets/img/project/home-6/portfolio-6-1.jpg';
				}

			?>
				<div class="<?php echo esc_attr($column_class); ?>">
					<div class="tp-portfolio-6-item anim-zoomin-wrap p-relative mb-30">
						<div class="tp-portfolio-6-item-thumb anim-zoomin">
							<a href="<?php the_permalink(); ?>">
								<img class="ratio-49x58" src="<?php echo esc_url($img_url); ?>" alt="<?php the_title_attribute(); ?>">
							</a>
						</div>
						<div class="tp-portfolio-6-item-content">
							<div class="tp-portfolio-6-item-content-hide">
								<span><?php echo get_the_time('M Y'); ?></span>
								<h4 class="tp-portfolio-6-item-title">
									<a href="<?php the_permalink(); ?>"><?php echo wp_kses_post($title); ?></a>
								</h4>
							</div>
						</div>
					</div>
				</div>
			<?php endwhile; ?>
		</div>
	</div>
</section>


<?php
}

}