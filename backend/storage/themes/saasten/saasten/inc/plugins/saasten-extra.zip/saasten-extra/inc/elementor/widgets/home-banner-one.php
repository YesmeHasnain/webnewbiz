<?php

/**
 * Elementor Widget
 * @package Saasten
 * @since 1.0.0
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class theme_banner_one extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'theme-banner-style-one';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Banner One', 'saasten-extra' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fas fa-th-large'; 
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saasten_widgets' ];
	}

	/**
	 * Register Elementor widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	 
	
	protected function register_controls() {


        $this->start_controls_section( 'section_content_banner_one', [
            'label' => esc_html__( 'Banner Top Content', 'saasten-core' ),
        ] );

        $this->add_control( 'title', [
            'label'       => __( 'Title', 'saasten-core' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'The Only all', 'saasten-core' ),
            'label_block' => true,
            'description' => __( "Type banner title here.", 'saasten-core' ),

        ] );


        $this->add_control( 'sub-title', [
            'label'       => __( 'Sub Title', 'saasten-core' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Digital Agency', 'saasten-core' ),
            'label_block' => true,
            'description' => __( "Type banner sub title here.", 'saasten-core' ),

        ] );

        $this->add_control( 'review-title', [
            'label'       => __( 'Review Title', 'saasten-core' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Trusted Client', 'saasten-core' ),
            'label_block' => true,
            'description' => __( "Type banner review title here.", 'saasten-core' ),

        ] );

        $this->add_control( 'review-text', [
            'label'       => __( 'Review Text', 'saasten-core' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( '(4900+) Review', 'saasten-core' ),
            'label_block' => true,
            'description' => __( "Type banner review text here.", 'saasten-core' ),

        ] );


        $this->add_control( 'btn_text', [
            'label'       => __( 'Button Label', 'saasten-core' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'placeholder' => __( 'Type your button label here', 'saasten-core' ),
            'default'     => __( 'Request For Demo', 'techogy-core' ),
        ] );

        $this->add_control( 'btn_link', [
            'label'       => __( 'Button Link', 'saasten-core' ),
            'type'        => \Elementor\Controls_Manager::URL,
            'placeholder' => __( 'https://your-link.com', 'saasten-core' ),
            'default'     => [
                'url' => '#',
            ],
        ] );


        $this->add_control( 'feature_image_bg', [
            'label'   => __( 'Choose Banner Image Background', 'saasten-core' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        $this->add_control( 'feature_image1', [
            'label'   => __( 'Choose Banner Image 1', 'saasten-core' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );


         $this->add_control( 'feature_image2', [
            'label'   => __( 'Choose Banner Image 2', 'saasten-core' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

          $this->add_control( 'feature_image3', [
            'label'   => __( 'Choose Banner Image 3', 'saasten-core' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );


        $this->end_controls_section(); 


        // ===================== Buttons ================//

        $this->start_controls_section( 'section_content_banner_bottom', [
            'label' => esc_html__( 'Banner Bottom Boxes', 'saasten-core' ),
        ] );


        $this->add_control( 'box_title1', [
            'label'       => __( 'Box Title 1', 'saasten-core' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Saas Management All Over Think', 'saasten-core' ),
            'label_block' => true,
            'description' => __( "Type box 1 title here.", 'saasten-core' ),

        ] );


        $this->add_control( 'banner_video_img', [
            'label'   => __( 'Choose Banner Image Video', 'saasten-core' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );


        $this->add_control(
            'video_btn_link', [
                'label' => __( 'Insert Self Hosted Video URL Link in Video format(eg. mp4/flv etc).', 'gazania-extra' ),
                'type'        => \Elementor\Controls_Manager::URL,

                'default'     => [
                    'url' => 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
                ],
                
                'description' => esc_html__( 'Enter Video URL', 'gazania-extra' )
            ]
        );


          $this->add_control( 'serviceItems', [
            'label'       => esc_html__( 'Banner Services List', 'saasten-extra' ),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'default'     => [
                [
                    'service-title'        => esc_html__( 'Web Development', 'saasten-extra' ),
                ]
            ],

            'fields'      => [

              

                [
                    'name'        => 'service-title',
                    'label'       => esc_html__( 'Title', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::TEXTAREA,
                    'default'     => __( 'Web Development', 'saasten-extra' ),
                    'description' => esc_html__( 'Enter Title', 'saasten-extra' )
                ],
                

                [
                    'name'        => 'service-link',
                    'label'       => esc_html__( 'Service Button Link', 'saasten-extra' ),
                    'type'        => \Elementor\Controls_Manager::URL,
                    'placeholder' => __( 'https://your-link.com', 'saasten-extra' ),
                    'default'     => [
                        'url' => '#',
                    ],
                ],



            ],
            'title_field' => "{{name}}"
        ] );





         $this->add_control( 'box_title3', [
            'label'       => __( 'Box Title 3', 'saasten-core' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Saas Management All Over Think', 'saasten-core' ),
            'label_block' => true,
            'description' => __( "Type box 3 title here.", 'saasten-core' ),

        ] );


        $this->add_control( 'description', [
            'label'       => __( 'Description text for Box 3', 'saasten-core' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => __( 'Proactively coordinate quality.', 'saasten-core' ),
            'label_block' => true,
        ] );


          $this->add_control( 'feature_image4', [
            'label'   => __( 'Choose Banner Box 3 image', 'saasten-core' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );




        $this->end_controls_section(); //End Buttons



		
	}
	


	protected function render() {
		
		
		$settings = $this->get_settings_for_display();

    $serviceItems = $settings['serviceItems'];

    extract($settings); 


		
		?>


    <div class="banner-main-v3 main-hero-wrap">
      <!-- Hero Banner -->
      <section
        class="banner-area-v3 saastain-bg__cover"
        style="background-image: url(<?php echo esc_url( $settings['feature_image_bg']['url'] ); ?>);"
      >


        <div class="banner-area-v3__shape">
          <div class="banner-area-v3__shape--1 saastain-anim-shape3">

            <img src="<?php echo SAASTEN_IMG ."/hero-v3-shape-1.svg"; ?>" alt="Image">

          </div>

          <div class="banner-area-v3__shape--2 saastain-anim-shape4">
            <img src="<?php echo SAASTEN_IMG ."/hero-v3-shape-3.svg"; ?>" />
          </div>

          <div class="banner-area-v3__shape--3 saastain-anim-shape5">
            <img src="<?php echo SAASTEN_IMG ."/hero-v3-shape-2.svg"; ?>" />
          </div>


        </div>


        <div class="banner-area-v3__inside">
          <div data-aos="fade-left" class="banner-area-v3__content">
            <p class="banner-area-v3__label saastain-gsap-anim1">
              <?php echo wp_kses_post( $settings['sub-title'] ); ?>
            </p>
            <h2 class="banner-area-v3__title saastain-gsap-anim2">
              <?php echo wp_kses_post( $settings['title'] ); ?>
            </h2>
            <div class="banner-area-v3__buttons">
              <a href="<?php echo esc_url( $settings['btn_link']['url'] ) ?>" class="saastain-btn primary-bg border-radius-31"
                ><?php echo $settings['btn_text'] ?></a
              >
              <div class="banner-area-v3__trusted">
                <i class="fas fa-star"></i>
                <h4 class="banner-area-v3__trusted-label">
                  <?php echo wp_kses_post( $settings['review-title'] ); ?> <span><?php echo wp_kses_post( $settings['review-text'] ); ?></span>
                </h4>
              </div>
            </div>
          </div>
          
          <div class="banner-area-v3__images">
            <div
              data-aos="fade-up"
              class="banner-area-v3__img1 z-index-1k xa-mp-2"
            >
              <img src="<?php echo esc_url( $settings['feature_image1']['url'] ); ?>" alt="#" />

            </div>
            <div data-aos="fade-down" class="banner-area-v3__img2">
              <img src="<?php echo esc_url( $settings['feature_image2']['url'] ); ?>" alt="#" />
            </div>
            <div class="banner-area-v3__img3">
              <img src="<?php echo esc_url( $settings['feature_image3']['url'] ); ?>" alt="#" />
            </div>
          </div>

        </div>
      </section>
      <!-- End Hero Banner -->

      <!-- Hero Features -->
      <section class="saastain-bg__cover mg-top-20">
        <div class="hero-features-v3__inside">
          <div data-aos="fade-right" class="hero-features-v3">
            <h2 class="hero-features-v3__title">
              <?php echo wp_kses_post( $settings['box_title1'] ); ?> 
            </h2>
            <ul class="hero-features-v3__list">


              <?php
                    foreach ( $serviceItems as $item ):
                ?>

              <li>
                <a href="<?php echo esc_url( $item['service-link']['url'] ) ?>"><i class="fas fa-check"></i><?php echo wp_kses_post( $item['service-title'] ); ?></a>
              </li>

              <?php endforeach; ?> 

              

            </ul>
          </div>
          <div
            data-aos="fade-up"
            class="hero-features-v3 hero-features-v3--video"
          >
            <div class="hero-features-v3--popup">
              <img
                src="<?php echo esc_url( $settings['banner_video_img']['url'] ); ?>"
                class="about-img"
                alt="#"
              />
              <div class="video-popup-img__icon">
                <a href="<?php echo esc_url( $settings['video_btn_link']['url'] ); ?>" class="js-video-btn video-btn theme-video-play-btn">
                  <svg
                    width="29"
                    height="32"
                    viewBox="0 0 29 32"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M26.1895 20.3647L7.43911 30.8429C4.10626 32.7053 0 30.2961 0 26.4781V16V5.52187C0 1.70393 4.10626 -0.70533 7.4391 1.15714L26.1895 11.6353C29.604 13.5434 29.604 18.4566 26.1895 20.3647Z"
                      fill="#151618"
                    />
                  </svg>
                </a>
              </div>
            </div>
          </div>
          <div
            data-aos="fade-left"
            class="hero-features-v3 hero-features-v3--banner"
          >
            <div class="hero-features-v3__heading">
              <h2 class="hero-features-v3__title">
                <?php echo wp_kses_post( $settings['box_title3'] ); ?> 
              </h2>
              <p class="hero-features-v3__text">
                <?php echo wp_kses_post( $settings['description'] ); ?> 
              </p>
            </div>
            <div class="hero-features-v3__inner xa-mp-1 mg-top-50 z-index-1k">
              <img src="<?php echo esc_url( $settings['feature_image4']['url'] ); ?>" alt="#" />
            </div>
          </div>
        </div>
      </section>
      <!-- End Hero Features -->
    </div>





	<?php 


	}
				

}

