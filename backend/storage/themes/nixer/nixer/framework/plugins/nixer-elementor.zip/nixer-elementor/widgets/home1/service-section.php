<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHome1ServiceSection extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home1-service-section';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 1 - Service Section', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Section widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-post-list';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Section widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nixer-home1' ];
	}

	public function get_keywords() {
		return [ 'home1servicesection', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_service_section',
			[
				'label' => esc_html__( 'Service Section', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'title_sec',
			[
				'label' 		=> esc_html__( 'Title Section', 'bdevs-elementor' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'We offer a wide range <br> of design services.' , 'bdevs-elementor' ),
				'show_label' 	=> true,
			]
		);
		$this->add_control(
			'post_number',
			[
				'label'       => __( 'Post Number', 'bdevs-elementor' ),
				'type'        => Controls_Manager::NUMBER,
				'placeholder' => __( 'Enter your post number', 'bdevs-elementor' ),
				'min'		  => 0,
				'default'     => __( '4', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order_by',
			[
				'label'       => __( 'Post Order By', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text post order by', 'bdevs-elementor' ),
				'default'     => __( 'ID', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
				],
				'default'   => 'desc',
			]
		);
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?>


<section class="tp-service-ptb fix pb-160">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="tp-about-heading tp-service-heading text-center mb-100">
					<h3 class="tp-section-title titleBurrowing"><?php echo wp_kses_post($settings['title_sec']); ?></h3>
				</div>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<div class="tp-service-wrapper p-relative z-index-1">
				<?php
				$wp_query = new \WP_Query([
					'post_type'      => 'service',
					'posts_per_page' => intval($settings['post_number']),
					'orderby'        => sanitize_text_field($settings['post_order_by']),
					'order'          => sanitize_text_field($settings['post_order']),
				]);
				$i = 0;
				while($wp_query->have_posts()): $wp_query->the_post();
					$i++;
					$sv_title = get_post_meta(get_the_ID(),'_cmb_sv_title_home_1', true);
					$img_id = get_post_meta(get_the_ID(),'_cmb_sv_thumb_home_1', true);
					if (!empty($img_id)) {
						$img_url = wp_get_attachment_url($img_id);
					} else {
						$img_url = get_the_post_thumbnail_url();
					}
				?>
					<?php if ($i == 2) { ?>
						<div class="tp-service-item current p-relative z-index-1 d-flex align-items-center">
					<?php } else { ?>
						<div class="tp-service-item p-relative z-index-1 d-flex align-items-center">
					<?php } ?>
							<?php if (!empty($img_id) || has_post_thumbnail()): ?>
								<div class="tp-service-item-thumb">
									<a href="<?php the_permalink(); ?>">
										<?php if (!empty($img_id)) { ?>
											<img class="ratio-33x16" src="<?php echo esc_url($img_url); ?>" alt="<?php the_title_attribute(); ?>">
										<?php } else { ?>
											<img class="ratio-33x16" src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title_attribute(); ?>">
										<?php } ?>
									</a>
								</div>
							<?php endif ?>
							<div class="tp-service-item-title">
								<h3 class="tp-service-title">
									<a href="<?php the_permalink(); ?>">
										<?php if (!empty($sv_title)) { ?>
											<?php print wp_specialchars_decode($sv_title); ?>
										<?php } else { ?>
											<?php the_title(); ?>
										<?php } ?>
									</a>
								</h3>
							</div>
							<div class="tp-service-item-title-pre">
								<?php 
								$terms = get_the_terms(get_the_ID(), 'service-cat');
								if (!empty($terms) && !is_wp_error($terms)) {
									$term = reset($terms);
									$term_link = get_term_link($term);
									echo '<span>' . esc_html($term->name) . '</span>';
								} ?>
							</div>
							<div class="tp-service-item-btn">
								<a href="<?php the_permalink(); ?>">
									<span>
										<svg xmlns="http://www.w3.org/2000/svg" width="19" height="16" viewBox="0 0 19 16" fill="none">
											<path d="M0.273438 7.69922H17.7077M10.8244 0C10.8229 4.25506 14.4699 7.69816 18.9786 7.69816M18.9815 7.69922C14.4728 7.69922 10.8232 11.1423 10.8216 15.3974" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10"/>
										</svg>
									</span>
								</a>
							</div>
						</div>
				<?php endwhile; ?>
				<span class="active-bg"></span>
			</div>
		</div>
	</div>
</section>


<?php
if (is_admin()) { ?>
	<script type="text/javascript">
		jQuery("[data-bg-color]").each(function () {
			jQuery(this).css("background-color", jQuery(this).attr("data-bg-color"));
		});

		function setupSplits() {
		// Target all elements with class "animate-text"
		var elements = document.querySelectorAll('.titleBurrowing');

		// Loop over each element and apply SplitText animation
		elements.forEach(element => {
			var tlSplit = gsap.timeline(),
				splitInstance = new SplitText(element, {type: "words,chars"}),
				chars = splitInstance.chars; // Array of divs wrapping each character
			
			tlSplit.from(chars, {
			duration: 0.8,
			opacity: 0,
			y: 10,
			ease: "circ.out",
			stagger: 0.02,
			scrollTrigger: {
				trigger: element,
				start: "top 75%",
				end: "bottom center",
				scrub: 1
			}
			});
		});
		}

		ScrollTrigger.addEventListener("refresh", setupSplits);
		setupSplits();
	</script>
<?php } ?>

<?php
}

}