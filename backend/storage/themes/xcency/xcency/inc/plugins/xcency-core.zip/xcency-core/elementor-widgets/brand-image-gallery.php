<?php
namespace Elementor;

class ThemeDraft_Brand_Image_Gallery_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_brand_image_gallery';
	}

	public function get_title() {
		return esc_html__( 'Brand Images Gallery', 'xcency-core' );
	}

	public function get_icon() {
		return 'xcency-icon flaticon-image-gallery';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'brand_image_gallery_options',
			[
				'label' => __( 'Images', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'enable_image_link',
			[
				'label'     => esc_html__( 'Upload Image With Link & Title', 'xcency-core' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Yes', 'xcency-core' ),
				'label_off' => esc_html__( 'No', 'xcency-core' ),
				'default'   => 'no',
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'brand_name',
			[
				'label'       => esc_html__( 'Brand Name / Title', 'xcency-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'    => 5,
				'label_block' => true,
				'description' => esc_html__( 'This field is optional.', 'xcency-core' ),
			]
		);

		$repeater->add_control(
			'image',
			[
				'label'       => esc_html__( 'Image', 'xcency-core' ),
				'type'        => Controls_Manager::MEDIA,
				'default'     => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'image_link',
			[
				'label'         => esc_html__( 'Image Link', 'xcency-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_url( 'https://your-link.com' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'brands',
			[
				'label'       => esc_html__( 'Images', 'xcency-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ brand_name }}}',
				'condition' => [
					'enable_image_link' => 'yes',
				],
			]
		);

		$this->add_control(
			'brand_images',
			[
				'label' => __( 'Add Images', 'xcency-core' ),
				'type' => Controls_Manager::GALLERY,
				'default' => [],
				'condition' => [
					'enable_image_link!' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'column_options',
			[
				'label' => __( 'Column', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'desktop_col',
			[
				'label'   => __( 'Columns On Desktop', 'xcency-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'xcency-col-xl-5',
				'options' => [
					'col-xl-12' => __( '1 Column', 'xcency-core' ),
					'col-xl-6'  => __( '2 Column', 'xcency-core' ),
					'col-xl-4'  => __( '3 Column', 'xcency-core' ),
					'col-xl-3'  => __( '4 Column', 'xcency-core' ),
					'xcency-col-xl-5'  => __( '5 Column', 'xcency-core' ),
				],
			]
		);

		$this->add_control(
			'iPad_pro_col',
			[
				'label'   => __( 'Columns On iPad Pro', 'xcency-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-lg-3',
				'options' => [
					'col-lg-12' => __( '1 Column', 'xcency-core' ),
					'col-lg-6'  => __( '2 Column', 'xcency-core' ),
					'col-lg-4'  => __( '3 Column', 'xcency-core' ),
					'col-lg-3'  => __( '4 Column', 'xcency-core' ),
				],
			]
		);

		$this->add_control(
			'tab_col',
			[
				'label'   => __( 'Columns On Tablet', 'xcency-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-md-3',
				'options' => [
					'col-md-12' => __( '1 Column', 'xcency-core' ),
					'col-md-6'  => __( '2 Column', 'xcency-core' ),
					'col-md-4'  => __( '3 Column', 'xcency-core' ),
					'col-md-3'  => __( '4 Column', 'xcency-core' ),
				],
			]
		);

		$this->add_control(
			'mobile_col',
			[
				'label'   => __( 'Columns On Mobile', 'xcency-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-6',
				'options' => [
					'col-12' => __( '1 Column', 'xcency-core' ),
					'col-6'  => __( '2 Column', 'xcency-core' ),
					'col-4'  => __( '3 Column', 'xcency-core' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'wrapper_and_item_options',
			[
				'label' => esc_html__( 'Wrapper & Item', 'xcency-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_responsive_control(
			'wrapper_height',
			[
				'label'     => __( 'Wrapper Height', 'xcency-core' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'devices'   => [ 'desktop', 'tablet', 'mobile' ],
				'description'   => __('Useful for different height\'s image.', 'xcency-core' ),
				'selectors' => [
					'{{WRAPPER}} .xcency-brand-image-gallery-wrapper .xcency-brand-item' => 'height: {{SIZE}}px;',
				],
			]
		);

        $this->add_control(
            'border_color',
            [
                'label'       => esc_html__('Border Color', 'xcency-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .xcency-brand-image-gallery-wrapper .xcency-brand-item,{{WRAPPER}} .xcency-brand-image-gallery-wrapper' => 'border-color: {{VALUE}};',
                ],
            ]
        );

		$this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$column = $settings['desktop_col'] . ' ' . $settings['iPad_pro_col'] . ' ' . $settings['tab_col'] . ' ' . $settings['mobile_col'];
		?>

        <div class="xcency-brand-image-gallery-wrapper">
            <div class="row">
                <?php if($settings['enable_image_link'] == 'yes') : ?>

                    <?php foreach ( $settings['brands'] as $brand ) :

                        $target = $brand['image_link']['is_external'] ? ' target="_blank"' : '';
                        $nofollow = $brand['image_link']['nofollow'] ? ' rel="nofollow"' : '';

                        $image_src = $brand['image']['url'];
                        $image_alt = get_post_meta( $brand['image']['id'], '_wp_attachment_image_alt', true );
                        $image_title = get_the_title( $brand['image']['id']);

                        $image_link = $brand['image_link']['url'];

                        ?>
                        <div class="<?php echo $column;?> p-0">
                            <div class="xcency-brand-item">
                                <div class="xcency-table">
                                    <div class="xcency-table-cell">
                                        <?php if ( $image_link ) : ?>
                                        <a href="<?php echo esc_url($image_link);?>" <?php echo esc_attr($target . $nofollow);?>>
                                            <?php endif; ?>

                                            <img src="<?php echo esc_url($image_src); ?>" alt="<?php echo esc_attr($image_alt);?>" title="<?php echo esc_attr($image_title);?>">

                                            <?php
                                            if (!empty($brand['brand_name']) && $brand['show_brand_name'] == 'yes')
                                                echo '<h6 class="brand-name">'.nl2br($brand['brand_name']).'</h6>';
                                            ?>
                                            <?php if ( $image_link ) : ?>
                                        </a>
                                    <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach;?>
                <?php else : ?>

                    <?php foreach ($settings['brand_images'] as $brand ) :
                        $image_src = $brand['url'];
                        $image_alt = get_post_meta( $brand['id'], '_wp_attachment_image_alt', true );
                        $image_title = get_the_title( $brand['id']);
                        ?>
                        <div class="<?php echo $column;?> p-0">
                            <div class="xcency-brand-item">
                                <div class="xcency-table">
                                    <div class="xcency-table-cell">
                                        <img src="<?php echo esc_url($image_src);?>" alt="<?php echo esc_attr($image_alt);?>" title="<?php echo $image_title;?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach;?>
                <?php endif; ?>
            </div>
        </div>
		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Brand_Image_Gallery_Widget );